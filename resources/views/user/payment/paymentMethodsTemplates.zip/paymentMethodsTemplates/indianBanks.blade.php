<!DOCTYPE html><html lang="en">
<head>
<meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>Buy, trade, and hold 100+ cryptocurrencies on Wealthmark</title>
  <meta content="" name="description">
  <meta content="" name="keywords">
  <meta name="theme-color" content="#287aff">
  <link href="{{ asset('public/assets/img/wealthmark-logo.svg') }}" rel="icon">
  <link href="{{ asset('public/assets/img/wealthmark-logo.svg') }}" rel="apple-touch-icon">
  <link rel="stylesheet" href="{{ asset('public/assets/css/dashboard.css') }}">
    <link rel="stylesheet" href="{{ asset('public/assets/css/payments.css') }}">
     <link rel="stylesheet" href="{{ asset('public/assets/css/alert.css') }}">
  @include('template.web_css') 
 

</head>
<body>
    @include('template.dashboard_mobile_menu')  
    @include('template.web_menu') 
                <div class="dashboard-main">
        @include('template.sidebar')
        <div class="container-fluid">
             <a href="{{ url()->previous() }}" class="btn btn-default">Back</a>
              <div class="css-breadcrumbs">
                            <div class="css-breadcrumbs_div">
                            
                            <a data-bn-type="link" class="css-breadcrumbs_anchore" href="{{ url(app()->getLocale().'/user/payment') }}">P2P Payment</a>
                            <i class="bi bi-chevron-right"></i>
                            <span class="css-breadcrumbs_method">Add payment method</span>
                            </div>
                </div>
         
             
            <section class="dashboard-breadcrumb payment_method_section mb-2rem bankTransfer-container">
                
             
                
                <div class="css-e4chz8">
                    <div class="css-13j7yrc">
                        <div class="css-xale73">
                             <div class="css-12rpxgg all_success alert " ></div>
                            <form action="#" id="bankTransferIndia_form">
                                <div class="css-5r43gd">
                                    
                                    <div class="css-12rpxgg all_error alert alert-danger" style="display:none">
                                       
                                    </div>
                                    <div data-bn-type="text" title="Bank Transfer (India)" class="css-c74olf">Bank Transfer (India) .. is working here</div>
                               </div>
                                    <div class="css-efn41d">
                                        <label for="account_holder" class="css-y6mvi3">Account holder name</label>
                                        <div data-bn-type="text" class="css-1u4ulvl">{{ Auth::user()->first_name.' '.Auth::user()->last_name}}</div>
                                        <div class="css-19oj9bu"> 
                                             <input type="hidden"  id="user_id" name="user_id"  value="{{ Auth::user()->id}}">
                                              <input type="hidden"  id="account_holder" name="account_holder"  value="{{ Auth::user()->first_name.' '.Auth::user()->last_name}}">
                                               <input type="hidden"  id="method_type" name="method_type"  value="Bank-Transfer-INDIA">
                                              
                                              <input type="hidden" name="_token" id="token" value="{{ csrf_token() }}">
                                        </div>
                                    </div>
                                        <div class="css-efn41d">
                                            <label for="account_number" class="css-y6mvi3">Bank account number</label>
                                            <div class=" css-18c7jg">
                                                <input data-bn-type="input" id="account_number" placeholder="Enter your account number" name="account_number" maxlength="25" class="css-16fg16t" value="{{ ($chkbanktransferMedhods && $chkbanktransferMedhods->account_number) ? $chkbanktransferMedhods->account_number : old('account_number')}}">
                                           </div>
                                            <div class="css-19oj9bu">
                                                <span class="account_number_error "></span>
                                            </div>
                                        </div>
                                        
                                         <div class="css-efn41d">
                                            <label for="ifsc" class="css-y6mvi3">IFSC code</label>
                                            <div class=" css-18c7jg">
                                                <input data-bn-type="input" id="ifsc" style="text-transform:uppercase" placeholder="Enter IFSC number" name="ifsc" maxlength="25" class="css-16fg16t" value="{{ ($chkbanktransferMedhods && $chkbanktransferMedhods->ifsc) ? $chkbanktransferMedhods->ifsc : old('ifsc')}}">
                                           </div>
                                            <div class="css-19oj9bu">
                                                <span class="ifsc_error "></span>
                                            </div>
                                        </div>
                                        
                                         <div class="css-efn41d">
                                            <label for="bank_name" class="css-y6mvi3">Bank name</label>
                                            <div class=" css-18c7jg">
                                                <input data-bn-type="input" id="bank_name" placeholder="Enter bank name" name="bank_name" maxlength="199" class="css-16fg16t" value="{{ ($chkbanktransferMedhods && $chkbanktransferMedhods->bank_name) ? $chkbanktransferMedhods->bank_name : old('bank_name')}}">
                                           </div>
                                            <div class="css-19oj9bu">
                                                <span class="bank_name_error "></span>
                                            </div>
                                        </div>
                                        
                                         <div class="css-efn41d">
                                            <label for="account_type" class="css-y6mvi3">Account type</label>
                                            <div class=" css-18c7jg">
                                                <input data-bn-type="input" id="account_type" placeholder="Please specify account type (saving or current)" name="account_type" maxlength="25" class="css-16fg16t" value="{{ ($chkbanktransferMedhods && $chkbanktransferMedhods->account_type) ? $chkbanktransferMedhods->account_type : old('account_type')}}">
                                           </div>
                                            <div class="css-19oj9bu">
                                                <span class="account_type_error "></span>
                                            </div>
                                        </div>
                                        
                                         <div class="css-efn41d">
                                            <label for="branch_name" class="css-y6mvi3"> Account opening branch</label>
                                            <div class=" css-18c7jg">
                                                <input data-bn-type="input" id="branch_name" placeholder="Enter branch information" name="branch_name" maxlength="199" class="css-16fg16t" value="{{ ($chkbanktransferMedhods && $chkbanktransferMedhods->branch_name) ? $chkbanktransferMedhods->branch_name : old('branch_name')}}">
                                           </div>
                                            <div class="css-19oj9bu">
                                                <span class="branch_name_error "></span>
                                            </div>
                                        </div>
                                              
                                                        <div class="css-m5asha">
                                                            <div data-bn-type="text" class="css-1c82c04">Tips</div>
                                                            <div data-bn-type="text" class="css-w5bmew">
                                                                Tips: The added payment method will be shown to the buyer during the transaction to accept fiat transfers. 
                                                            Please ensure that the information is correct, real, and matches your KYC information on Binance.</div>
                                                            <div class="css-1xx49qh">
                                                                <div class="css-1e8zq2i">  <button data-bn-type="button" type="button" class=" css-1iqy9ai cancelbankTransferIndia">Cancel</button>   </div>
                                                                    <div class="css-1e8zq2i">  <button data-bn-type="button" type="button" class=" css-ulq18s" id="add_method">Confirm</button> </div>
                                                             </div>
                                                        </div>
                                     </form>
                                </div>
                            </div>
                    </div>
            </section>
           
</div>
   
</div>
    
  @include('template.web_footer') 	
   @include('template.web_js') 

 
</body>


<script>


$(".cancelbankTransferIndia").click(function(){
     window.location.href = '{{ url(app()->getLocale().'/user/payment')}}';
});

    $("#bankTransferIndia_form #add_method").click(function(){
      console.log('bankTransferIndia clicked');
        if($("#account_number").val() == 0 || $("#account_number").val() === undefined ||  $("#account_number").val().length > 25 || ( $.isNumeric( $("#account_number").val()) !== true ) ){
                $("#bankTransferIndia_form .account_number_error").html('Valid Acoount number required and should be less than 25 characters!'); 
                setTimeout( function(){
                         $("#bankTransferIndia_form .account_number_error").html(''); 
                       } , 3000);
           
        }
        if($("#ifsc").val() == 0 || $("#ifsc").val() === undefined ||  $("#ifsc").val().length > 25 ){
              $("#bankTransferIndia_form .ifsc_error").html('Valid IFSC number required !'); 
                setTimeout( function(){
                         $("#bankTransferIndia_form .ifsc_error").html(''); 
                       } , 3000);
            
            }
            if($("#bank_name").val() == 0 || $("#bank_name").val() === undefined ||  $("#bank_name").val().length > 199 ){
                  $("#bankTransferIndia_form .bank_name_error").html('Valid bank name required and should be less than 199 characters!'); 
                setTimeout( function(){
                         $("#bankTransferIndia_form .bank_name_error").html(''); 
                       } , 3000);
            
            }
            if($("#account_type").val() == 0 || $("#account_type").val() === undefined ||  $("#account_type").val().length > 25 ){
                
                  $("#bankTransferIndia_form .account_type_error").html('Valid account type required and should be less than 25 characters!'); 
                setTimeout( function(){
                         $("#bankTransferIndia_form .account_type_error").html(''); 
                       } , 3000);
            
            }
            if($("#branch_name").val() == 0 || $("#branch_name").val() === undefined ||  $("#branch_name").val().length > 199 ){
                  $("#bankTransferIndia_form .branch_name_error").html('Valid branch_name required and should be less than 199 characters!'); 
                setTimeout( function(){
                         $("#bankTransferIndia_form .branch_name_error").html(''); 
                       } , 3000);
            
            }
                
                console.log('validatiion passed');
           
           
                      var bankTransferIndia_formData = new FormData( $('#bankTransferIndia_form')[0]);
                     
                      
                                        	$.ajax({
                                     					type: "POST",
                                                       
                                                         url: "<?php echo url(app()->getLocale().'/user/payment/c2c/add/Bank-Transfer-INDIA');  ?>",  
                                                         enctype : 'multipart/form-data',
                                                         processData: false,
                                                         contentType: false,
                                                         data : bankTransferIndia_formData,
                                                          
                                                     	success: function(data) {
                                                          
                                                                  if(data.success == 200){
                                                                   // triggerAlert('Congratulations! Account addded successfully.', 'success');
                                                                    $(".bankTransfer-container .all_success").html('Submitted Successfully!'); 
                                                                    $('.bankTransfer-container .all_success').addClass('alert-success');
                                                                   
                                                                    console.log(data.account_number);
                                                                  
                                                                    $("#bankTransferIndia_form #account_number").val(data.account_number); 
                                                                     $("#bankTransferIndia_form #ifsc").val(data.ifsc);
                                                                      $("#bankTransferIndia_form #bank_name").val(data.bank_name);
                                                                       $("#bankTransferIndia_form #account_type").val(data.account_type);
                                                                        $("#bankTransferIndia_form #branch_name").val(data.branch_name);
                                                                    
                                                                       
                                                                    }
                                                                    
                                                                     if(data.error){
                                                                         $("#bankTransferIndia_form .account_number_error").html('detail already exist!'); 
                                                                         $('#bankTransferIndia_form .account_number_error').addClass('alert alert-danger');
                                                                     }
                                                                      
                                                                     setTimeout( function(){
                                                                     $(".bankTransfer-container .all_success").html(''); 
                                                                    $('.bankTransfer-container .all_success').removeClass('alert-success');
                                                                    $("#bankTransferIndia_form .account_number_error").html(''); 
                                                                    $('#bankTransferIndia_form .account_number_error').removeClass('alert alert-danger');
                                                                         
                                                                    }, 2000);
                                                                },
                                                         
                                                        error: function(xhr, status, error) {
                                                                                var erroJson = JSON.parse(xhr.responseText);
                                                                                //alert(erroJson.error);
                                                                                var account_number_error = erroJson.error.account_number;
                                                                                  var ifsc_error = erroJson.error.ifsc;
                                                                                    var bank_name_error = erroJson.error.bank_name;
                                                                                      var account_type_error = erroJson.error.account_type;
                                                                                        var branch_name_error = erroJson.error.branch_name;
                                                 
                                                                                //  $.each(erroJson.error, function(key, value){
                                                                                //     $("#bankTransferIndia_form .all_error").html(key + ": " + value + '<br>');
                                                                                // });
                                                                                  
                                                                                  if(account_number_error){
                                                                                  $("#bankTransferIndia_form .account_number_error").html('Valid Acoount number required and should be less than 25 characters!'); 
                                                                                  $('#bankTransferIndia_form .account_number_error').addClass('alert alert-danger');
                                                                                  
                                                                                  
                                                                                   }
                                                                                   
                                                                                    if(ifsc_error){
                                                                                  $("#bankTransferIndia_form .ifsc_error").html('Valid IFSc code required and should be less than 25 characters!'); 
                                                                                  $('#bankTransferIndia_form .ifsc_error').addClass('alert alert-danger');
                                                                                   }
                                                                                   
                                                                                    if(bank_name_error){
                                                                                  $("#bankTransferIndia_form .bank_name_error").html('Valid bank name required and should be less than 199 characters!'); 
                                                                                  $('#bankTransferIndia_form .bank_name_error').addClass('alert alert-danger');
                                                                                   }
                                                                                   
                                                                                    if(account_type_error){
                                                                                  $("#bankTransferIndia_form .account_type_error").html('Valid acoount type required and should be less than 25 characters!'); 
                                                                                  $('#bankTransferIndia_form .account_type_error').addClass('alert alert-danger');
                                                                                   }
                                                                                   
                                                                                    if(branch_name_error){
                                                                                  $("#bankTransferIndia_form .branch_name_error").html('Valid branch name required and should be less than 199 characters!'); 
                                                                                  $('#bankTransferIndia_form .branch_name_error').addClass('alert alert-danger');
                                                                                   }
                                                
                                                                                setTimeout(function(){
                                                                                       $("#bankTransferIndia_form .account_number_error").html(''); 
                                                                                        $("#bankTransferIndia_form .ifsc_error").html(''); 
                                                                                         $("#bankTransferIndia_form .bank_name_error").html(''); 
                                                                                          $("#bankTransferIndia_form .account_type_error").html(''); 
                                                                                           $("#bankTransferIndia_form .branch_name_error").html(''); 
                                                                                           
                                                                                           $("#bankTransferIndia_form .account_number_error").removeClass('alert alert-danger'); 
                                                                                       $("#bankTransferIndia_form .ifsc_error").removeClass('alert alert-danger');  
                                                                                         $("#bankTransferIndia_form .bank_name_error").removeClass('alert alert-danger'); 
                                                                                          $("#bankTransferIndia_form .account_type_error").removeClass('alert alert-danger'); 
                                                                                           $("#bankTransferIndia_form .branch_name_error").removeClass('alert alert-danger'); 
                                                                                       
                                                                                              
                                                                                            }, 3000);
                                                                                 
                                                            
                                                                                }
                                     					
                                     				});
                                    
                     });
        
</script>
</html>