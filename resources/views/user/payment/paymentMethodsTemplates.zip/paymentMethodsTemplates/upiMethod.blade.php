<!DOCTYPE html><html lang="en">
<head>
<meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>Buy, trade, and hold 100+ cryptocurrencies on Wealthmark</title>
  <meta content="" name="description">
  <meta content="" name="keywords">
  <meta name="theme-color" content="#287aff">
  <link href="{{ asset('public/assets/img/wealthmark-logo.svg') }}" rel="icon">
  <link href="{{ asset('public/assets/img/wealthmark-logo.svg') }}" rel="apple-touch-icon">
  <link rel="stylesheet" href="{{ asset('public/assets/css/dashboard.css') }}">
    <link rel="stylesheet" href="{{ asset('public/assets/css/payments.css') }}">
    <link rel="stylesheet" href="{{ asset('public/assets/css/alert.css') }}">
  @include('template.web_css') 
 
<style>
    .bi-x{
        color:red;
        float: left;
    }
    .all_success{
        float:right;
    }
    
</style>
</head>
<body>
    @include('template.dashboard_mobile_menu')  
    @include('template.web_menu') 
                <div class="dashboard-main">
        @include('template.sidebar')
        <div class="container-fluid">
             <a href="{{ url()->previous() }}" class="btn btn-default">Back</a>
           <div class="css-breadcrumbs">
                            <div class="css-breadcrumbs_div">
                            
                            <a data-bn-type="link" class="css-breadcrumbs_anchore" href="{{ url(app()->getLocale().'/user/payment') }}">P2P Payment</a>
                            <i class="bi bi-chevron-right"></i>
                            <span class="css-breadcrumbs_method">Add payment method</span>
                            </div>
                </div>
             
            <section class="dashboard-breadcrumb payment_method_section mb-2rem UPI-container">
                
             
                <div class="css-e4chz8">
                    <div class="css-13j7yrc">
                        <div class="css-xale73">
                             <div class="css-12rpxgg all_success alert " ></div>
                            <form action="#" id="upi_Id_form">
                                <div class="css-5r43gd">
                                      
                                    <div class="css-12rpxgg all_error alert alert-danger" style="display:none">
                                       
                                    </div>
                                    <div data-bn-type="text" title="upi Id" class="css-c74olf">UPI ID</div>
                               </div>
                                    <div class="css-efn41d">
                                        <label for="account_holder" class="css-y6mvi3">Name</label>
                                        <div data-bn-type="text" class="css-1u4ulvl">{{ Auth::user()->first_name.' '.Auth::user()->last_name}}</div>
                                        <div class="css-19oj9bu"> 
                                             <input type="hidden"  id="user_id" name="user_id"  value="{{ Auth::user()->id}}">
                                              <input type="hidden"  id="account_holder" name="account_holder"  value="{{ Auth::user()->first_name.' '.Auth::user()->last_name}}"> 
                                               <input type="hidden"  id="method_type" name="method_type"  value="UPI">
                                               
                                              <input type="hidden" name="_token" id="token" value="{{ csrf_token() }}">
                                        </div>
                                    </div>
                                        <div class="css-efn41d">
                                            <label for="upi_Id" class="css-y6mvi3">UPI ID</label>
                                            <div class=" css-18c7jg">
                                                <input data-bn-type="input" id="upi_Id" placeholder="Enter your Upi ID" name="upi_Id" maxlength="100" class="css-16fg16t" value="{{ ($chkupiMedhods && $chkupiMedhods->upi_Id) ? $chkupiMedhods->upi_Id : old('upi_Id')}}">
                                           </div>
                                            <div class="css-19oj9bu">
                                                <span class="upi_Id_error "></span>
                                            </div> 
                                        </div>
                                                <div class="css-efn41d "> 
                                                <div class="upi_Id">
                                                   @if($chkupiMedhods && ($chkupiMedhods->qr_code != NULL))
                                                     <i class="bi-x"></i></br>
                                                     <img  class="img-thumbnail "   width="100px" src="{{ url('storage/app/'.$chkupiMedhods->qr_code) }}" alt="" title="" />
                                                      <input type="hidden"  id="uploadedQR" name="uploadedQR"  value="{{ ($chkupiMedhods && ($chkupiMedhods->qr_code != NULL) ? $chkupiMedhods->qr_code : '' ) }}"> 
                                                     @endif
                                                </div>
                                                    
                                                    <div  class="css-y6mvi3 qrmsg" >UPI ID QR code(Optional)</div>
                                                      <span class="paymentMethod_QRcaption"></span>
                                                    
                                                    <div class="css-7cm7ga">
                                                        <input type="file" accept=".jpg,.jpeg,.png,.bmp" id="uploads" name="uploads" style="display: none;" onChange="payment_method_caption(this.id);">
                                                        
                                                        <div data-bn-type="text" class="css-jhdjgf"><label for="uploads" class="css-y6mvi3"><i class="bi bi-upload"></i> <div>Upload</div></label></div>
                                                    </div>
                                                        <span class="css-1qborlq">(JPG/JPEG/PNG/BMP, less than 1MB)</span>
                                                        <div class="css-19oj9bu"></div>
                                                </div>
                                                        <div class="css-m5asha">
                                                            <div data-bn-type="text" class="css-1c82c04">Tips</div>
                                                            <div data-bn-type="text" class="css-w5bmew">
                                                                Tips: The added payment method will be shown to the buyer during the transaction to accept fiat transfers. 
                                                            Please ensure that the information is correct, real, and matches your KYC information on Binance.</div>
                                                            <div class="css-1xx49qh">
                                                                <div class="css-1e8zq2i">  <button data-bn-type="button" type="button" class=" css-1iqy9ai cancelupi_id">Cancel</button>   </div>
                                                                    <div class="css-1e8zq2i">  <button data-bn-type="button" type="button" class=" css-ulq18s" id="add_method">Confirm</button> </div>
                                                             </div>
                                                        </div>
                                     </form>
                                </div>
                            </div>
                    </div>
            </section>
           
</div>
   
</div>
    
  @include('template.web_footer') 	
   @include('template.web_js') 

 
</body>


<script>
 $("#upi_Id_form .bi-x").click(function(){
    $('#upi_Id_form input[type=file]').val('');
    $('#uploadedQR').val('');
     $('#upi_Id_form .upi_Id').html('');
});


$(".cancelupi_id").click(function(){
     window.location.href = '{{ url(app()->getLocale().'/user/payment')}}';
});

    $("#upi_Id_form #add_method").click(function(){
      console.log('upiId clicked');
        if($("#upi_Id").val() == 0 || $("#upi_Id").val() === undefined ||  $("#upi_Id").val().length > 18  || $("#upi_Id").val().search('@') == -1 ){
           $("#upi_Id_form .upi_Id_error").html('Valid Upi ID required and should be less than 18 characters!'); 
           
           setTimeout( function(){
             $("#upi_Id_form .upi_Id_error").html(''); 
           } , 3000);
           
        }else{
           console.log('validatiion passed');
           
           
                      var upi_Id_formData = new FormData( $('#upi_Id_form')[0]);
                      
                      upi_Id_formData.append('ifuploadSelected' , $("#uploads").val()); 
                        upi_Id_formData.append('ifuploadedQR' , $("#uploadedQR").val()); 
                      
                                        	$.ajax({
                                     					type: "POST",
                                                       
                                                         url: "<?php echo url(app()->getLocale().'/user/payment/c2c/add/UPI');  ?>",  
                                                         enctype : 'multipart/form-data',
                                                         processData: false,
                                                         contentType: false,
                                                         data : upi_Id_formData,
                                                          
                                                     	success: function(data) {
                                                          
                                                                  if(data.success == 200){
                                                                 //   triggerAlert('Congratulations! Account addded successfully.', 'success');
                                                                  $(".UPI-container .all_success").html('Submitted Successfully!'); 
                                                                    $('.UPI-container .all_success').addClass('alert-success');
                                                                    console.log(data.upi_Id);
                                                                   // document.getElementById("upi_Id_form").reset(); 
                                                                   
                                                                    $("#upi_Id_form #upi_Id").val(data.upi_Id); 
                                                                    
                                                                    if(data.upi_IdQR != ''){
                                                                      $("#upi_Id_form .upi_Id").html('');
                                                                     $("#upi_Id_form .upi_Id").append('  <i class="bi-x"></i></br><img class="img-thumbnail " width="100px" src="/storage/app/'+data.upi_IdQR +'" alt="" title="">'); 
                                                                    }
                                                                    
                                                                         
                                                                    }
                                                                    
                                                                     if(data.error){
                                                                         $("#upi_Id_form .account_number_error").html('detail already exist!'); 
                                                                         $('#upi_Id_form .account_number_error').addClass('alert alert-danger');
                                                                     }
                                                                    
                                                                     setTimeout( function(){
                                                                     $(".UPI-container .all_success").html(''); 
                                                                    $('.UPI-container .all_success').removeClass('alert-success');
                                                                    $("#upi_Id_form .account_number_error").html(''); 
                                                                         $('#upi_Id_form .account_number_error').removeClass('alert alert-danger');
                                                                    }, 2000); 
                                                                },
                                                         
                                                        error: function(xhr, status, error) {
                                                                                var erroJson = JSON.parse(xhr.responseText);
                                                                                //alert(erroJson.error);
                                                                                var upi_Id_error = erroJson.error.upi_Id;
                                                 
                                                                                //  $.each(erroJson.error, function(key, value){
                                                                                //     $("#upi_Id_form .all_error").html(key + ": " + value + '<br>');
                                                                                // });
                                                                                  
                                                                                  if(upi_Id_error){
                                                                                  $("#upi_Id_form .upi_Id_error").html('Valid Upi ID required and should be less than 18 characters!'); 
                                                                                  $('#upi_Id_form .upi_Id_error').addClass('alert alert-danger');
                                                                                   }
                                                
                                                           
                                                                                 setTimeout(function(){
                                                                                       $("#upi_Id_form .upi_Id_error").html(''); 
                                                                                      $('#upi_Id_form .upi_Id_error').removeClass('alert alert-danger');
                                                                                     }, 4000);
                                                            
                                                                                }
                                     					
                                     				});
                                    }
                     });
        
</script>

<script>
    
    function payment_method_caption(id){
    console.log(id);
  
    var input = document.getElementById( 'id');
    var input = event.srcElement;

 $("#upi_Id_form .paymentMethod_QRcaption").append('<div class="d-flex bg-gray" id="" style="margin: 10px 0px;">  <i class="bi bi-image" style="padding-right: 10px;"></i> '+input.files[0].name+'  <div onClick="captionRemove()"  class="file_delete"><i class="bi bi-x-circle-fill"></i> </div></div> ');
    }
    
    
    function captionRemove(){
  //  alert();
   
    $('#upi_Id_form input[type=file]').val('');
    $("#upi_Id_form .paymentMethod_QRcaption").html('');
  }
</script>
</html>