<!DOCTYPE html><html lang="en">
<head>
<meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>Buy, trade, and hold 100+ cryptocurrencies on Wealthmark</title>
  <meta content="" name="description">
  <meta content="" name="keywords">
  <meta name="theme-color" content="#287aff">
  <link href="{{ asset('public/assets/img/wealthmark-logo.svg') }}" rel="icon">
  <link href="{{ asset('public/assets/img/wealthmark-logo.svg') }}" rel="apple-touch-icon">
  <link rel="stylesheet" href="{{ asset('public/assets/css/dashboard.css') }}">
    <link rel="stylesheet" href="{{ asset('public/assets/css/payments.css') }}">
    <link rel="stylesheet" href="{{ asset('public/assets/css/alert.css') }}">
  @include('template.web_css') 
 

</head>
<body>
    @include('template.dashboard_mobile_menu')  
    @include('template.web_menu') 
                <div class="dashboard-main">
        @include('template.sidebar')
        <div class="container-fluid">
             <a href="{{ url()->previous() }}" class="btn btn-default">Back</a>
           <div class="css-breadcrumbs">
                            <div class="css-breadcrumbs_div">
                            
                            <a data-bn-type="link" class="css-breadcrumbs_anchore" href="{{ url(app()->getLocale().'/user/payment') }}">P2P Payment</a>
                            <i class="bi bi-chevron-right"></i>
                            <span class="css-breadcrumbs_method">Add payment method</span>
                            </div>
                </div>
             
            <section class="dashboard-breadcrumb payment_method_section mb-2rem paytm-container">
                
             
                
                <div class="css-e4chz8">
                    <div class="css-13j7yrc">
                        <div class="css-xale73">
                             <div class="css-12rpxgg all_success alert " ></div>
                            <form action="#" id="paytm_form">
                                <div class="css-5r43gd">
                                     
                                    <div class="css-12rpxgg all_error alert alert-danger" style="display:none">
                                       
                                    </div>
                                    <div data-bn-type="text" title="Paytm" class="css-c74olf">Paytm</div>
                               </div>
                                    <div class="css-efn41d">
                                        <label for="account_holder" class="css-y6mvi3">Name</label>
                                        <div data-bn-type="text" class="css-1u4ulvl">{{ Auth::user()->first_name.' '.Auth::user()->last_name}}</div>
                                        <div class="css-19oj9bu"> 
                                             <input type="hidden"  id="user_id" name="user_id"  value="{{ Auth::user()->id}}">
                                              <input type="hidden"  id="account_holder" name="account_holder"  value="{{ Auth::user()->first_name.' '.Auth::user()->last_name}}">
                                               <input type="hidden"  id="method_type" name="method_type"  value="Paytm">
                                               <input type="hidden"  id="bank_name" name="bank_name"  value="Paytm"> 
                                              <input type="hidden" name="_token" id="token" value="{{ csrf_token() }}">
                                        </div>
                                    </div>
                                        <div class="css-efn41d">
                                            <label for="account_number" class="css-y6mvi3">Account</label>
                                            <div class=" css-18c7jg">
                                                <input data-bn-type="input" id="account_number" placeholder="Enter your account number" name="account_number" maxlength="100" class="css-16fg16t" value="{{ ($chkpaytmMedhods && $chkpaytmMedhods->account_number) ? $chkpaytmMedhods->account_number : old('account_number')}}">
                                           </div>
                                            <div class="css-19oj9bu">
                                                <span class="account_number_error "></span>
                                            </div>
                                        </div>
                                                <div class="css-efn41d "> 
                                                <div class="paytm">
                                                   @if($chkpaytmMedhods && ($chkpaytmMedhods->qr_code != NULL))
                                                   <i class="bi-x"></i></br>
                                                     <img  class="img-thumbnail "   width="100px" src="{{ url('storage/app/'.$chkpaytmMedhods->qr_code) }}" alt="" title="" />
                                                    <input type="hidden"  id="uploadedQR" name="uploadedQR"  value="{{ ($chkpaytmMedhods && ($chkpaytmMedhods->qr_code != NULL) ? $chkpaytmMedhods->qr_code : '' ) }}"   > 
                                                     @endif
                                                </div>
                                                    
                                                    <div class="css-y6mvi3 qrmsg">Payment QR code(Optional)</div>
                                                    <span class="paymentMethod_QRcaption"></span>
                                                    <div class="css-7cm7ga">
                                                  
                                                       
                                                          <label for="uploads" class="css-y6mvi3"> <i class="bi bi-upload"></i> <div>Upload</div></label>
                                                <input type="file" accept=".jpg,.jpeg,.png,.bmp" id="uploads" name="uploads" style="display: none;" onChange="payment_method_caption(this.id);">
                                                       
                                                    </div>
                                                        <span class="css-1qborlq">(JPG/JPEG/PNG/BMP, less than 1MB)</span>
                                                        <div class="css-19oj9bu"></div>
                                                </div>
                                                        <div class="css-m5asha">
                                                            <div data-bn-type="text" class="css-1c82c04">Tips</div>
                                                            <div data-bn-type="text" class="css-w5bmew">
                                                                Tips: The added payment method will be shown to the buyer during the transaction to accept fiat transfers. 
                                                            Please ensure that the information is correct, real, and matches your KYC information on Binance.</div>
                                                            <div class="css-1xx49qh">
                                                                <div class="css-1e8zq2i">  <button data-bn-type="button" type="button" class=" css-1iqy9ai cancelpaytm">Cancel</button>   </div>
                                                                    <div class="css-1e8zq2i">  <button data-bn-type="button" type="button" class=" css-ulq18s" id="add_method">Confirm</button> </div> 
                                                             </div>
                                                        </div>
                                     </form>
                                </div>
                            </div>
                    </div>
            </section>
           
</div>
   
</div>
    
  @include('template.web_footer') 	
   @include('template.web_js') 

 
</body>


<script>
 $("#paytm_form .bi-x").click(function(){
    $('#paytm_form input[type=file]').val('');
     $('#uploadedQR').val('');
    
     $('#paytm_form .paytm').html('');
});

$(".cancelpaytm").click(function(){
     window.location.href = '{{ url(app()->getLocale().'/user/payment')}}';
});

    $("#paytm_form #add_method").click(function(){
      console.log('paytm clicked');
        if($("#account_number").val() == 0 || $("#account_number").val() === undefined ||  $("#account_number").val().length > 25 || ( $.isNumeric( $("#account_number").val()) !== true ) ){
           $("#paytm_form .account_number_error").html('Valid Acoount number required and should be less than 25 characters!'); 
           
           setTimeout( function(){
             $("#paytm_form .account_number_error").html(''); 
           } , 3000);
           
        }else{
           console.log('validatiion passed');
           
           
                      var paytm_formData = new FormData( $('#paytm_form')[0]);
                       paytm_formData.append('ifuploadSelected' , $("#uploads").val());  
                        paytm_formData.append('ifuploadedQR' , $("#uploadedQR").val()); 
                      
                                        	$.ajax({
                                     					type: "POST",
                                                       
                                                         url: "<?php echo url(app()->getLocale().'/user/payment/c2c/add/Paytm');  ?>",  
                                                         enctype : 'multipart/form-data',
                                                         processData: false,
                                                         contentType: false,
                                                         data : paytm_formData,
                                                          
                                                     	success: function(data) {
                                                          
                                                                  if(data.success == 200){
                                                                   // triggerAlert('Congratulations! Account addded successfully.', 'success');
                                                                   $(".paytm-container .all_success").html('Submitted Successfully!'); 
                                                                    $('.paytm-container .all_success').addClass('alert-success');
                                                                    console.log(data.account_number);
                                                                   // document.getElementById("paytm_form").reset(); 
                                                                   
                                                                    $("#paytm_form #account_number").val(data.account_number); 
                                                                    
                                                                         if(data.paytmQR != ''){
                                                                             $("#paytm_form .paytm").html('');
                                                                            $("#paytm_form .paytm").append('  <i class="bi-x"></i></br><img class="img-thumbnail " width="100px" src="/storage/app/'+data.paytmQR +'" alt="" title="">'); 
                                                                         } 
                                                                    }
                                                                    
                                                                     if(data.error){
                                                                         $("#paytm_form .account_number_error").html('detail already exist!'); 
                                                                         $('#paytm_form .account_number_error').addClass('alert alert-danger');
                                                                     }
                                                                    
                                                                   setTimeout( function(){
                                                                     $(".paytm-container .all_success").html(''); 
                                                                    $('.paytm-container .all_success').removeClass('alert-success');
                                                                     $("#paytm_form .account_number_error").html(''); 
                                                                        $('#paytm_form .account_number_error').removeClass('alert alert-danger');
                                                                    }, 2000); 
                                                                    
                                                                },
                                                         
                                                        error: function(xhr, status, error) {
                                                                                var erroJson = JSON.parse(xhr.responseText);
                                                                                //alert(erroJson.error);
                                                                                var account_number_error = erroJson.error.account_number;
                                                 
                                                                                //  $.each(erroJson.error, function(key, value){
                                                                                //     $("#paytm_form .all_error").html(key + ": " + value + '<br>');
                                                                                // });
                                                                                  
                                                                                  if(account_number_error){
                                                                                  $("#paytm_form .account_number_error").html('Valid Acoount number required and should be less than 25 characters!'); 
                                                                                  $('#paytm_form .account_number_error').addClass('alert alert-danger');
                                                                                   }
                                                
                                                           
                                                                                 setTimeout(function(){
                                                                                       $("#paytm_form .account_number_error").html(''); 
                                                                                      $('#paytm_form .account_number_error').removeClass('alert alert-danger');
                                                                                     }, 4000);
                                                            
                                                                                }
                                     					
                                     				});
                                    }
                     });
        
        
         


</script>

<script>
    
    function payment_method_caption(id){
    console.log(id);
  
    var input = document.getElementById( 'id');
    var input = event.srcElement;

 $("#paytm_form .paymentMethod_QRcaption").append('<div class="d-flex bg-gray" id="" style="margin: 10px 0px;">  <i class="bi bi-image" style="padding-right: 10px;"></i> '+input.files[0].name+' <div onClick="captionRemove()"  class="file_delete"><i class="bi bi-x-circle-fill"></i> </div></div>  ');                                                        
    }
    
    
    
function captionRemove(){
    //alert();
   
    $('#paytm_form input[type=file]').val('');
    $("#paytm_form .paymentMethod_QRcaption").html('');
  }
</script>
</html>
