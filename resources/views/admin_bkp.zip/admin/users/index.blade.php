

<!DOCTYPE html><html lang="en">
<head>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
<!-- JavaScript Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>

<style>

table {
    caption-side: bottom;
    border-collapse: collapse;
    background: radial-gradient(#f1f3f4, transparent);
}
    img, svg {
    width: 30px;
    vertical-align: middle;
    
    span a{
    padding: 2px !important;
  
    }
    .role nav a.py-2 {
    padding-top: 0.25rem!important;
    padding-bottom: 0.25rem!important;
    }
    .role nav a.px-2 {
    padding-right: 0.25rem!important;
    padding-left: 0.5rem!important;
    }
}
</style>

</head>
<body>
  <div class="container role">  

<div class="row" style="margin: 20px;">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2>Users Role Management</h2>
        </div>
        <div class="pull-right">
            <!--<a class="btn btn-success" href="{{ route('users.create') }}"> Create New User</a>-->
           
        </div>
    </div>
    <div lass="col-lg-12 margin-tb">
        <form>
            <input type="text" size="30" value="" name="searchUserlist" id="searchUserlist">
            <div id="livesearch"></div>
        </form>
    </div>
</div>





@if ($message = Session::get('success'))
<div class="alert alert-success" >
  <p>{{ $message }}</p>
</div>
@endif


<table class="table table-bordered" style="margin: 20px;">
   
 <tr>
   <th>No</th>
   <th>User Id</th>
   <th>Name</th>
   <th>Email</th>
   <th>Roles</th>
   <th width="280px">Action</th>
 </tr>
  
 @foreach ($data as $key => $user)
  <tr>
    <td>{{ ++$i }}</td>
    <td>{{ $user->id }}</td>
    <td>{{ $user->first_name }}</td>
    <td>{{ $user->email }}</td>
    <td >
      @if(!empty($user->getRoleNames()))
        @foreach($user->getRoleNames() as $v)
           <label class="badge badge-success" style="color: #198754;">{{ $v }}</label>
        @endforeach
      @endif
    </td>
    <td>
       <a class="btn" href="{{ route('users.show',$user->id) }}" style="background: linear-gradient(180deg, rgba(254,192,15,1) 0%, rgba(248,165,50,1) 100%); padding:3px 8px">Show</a>
       <a class="btn " href="{{ route('users.edit',$user->id) }}" style="background: #cacdd1; padding:3px 8px">Edit</a>
       <a class="btn btn-danger" href="#">Delete</a>
        <!--{!! Form::open(['method' => 'DELETE','route' => ['users.destroy', $user->id],'style'=>'display:inline']) !!}-->
        <!--    {!! Form::submit('Delete', ['class' => 'btn btn-danger']) !!}-->
        <!--{!! Form::close() !!}-->
    </td>
  </tr>
 @endforeach
</table>


{!! $data->render() !!}

</div>

<script type="text/javascript">
document.getElementById("searchUserlist").onkeyup = function() {
    
    

const value = document.getElementById("searchUserlist").value;
// alert(value);
jQuery.ajax({
type : 'get',
url : '{{URL::to('admin/searchUserlist')}}',
data:{
    'search':value
    
},
success:function(data){
$('.livesearch').html(data);
}
});
    
    
    
    
};



</script>
</body>


</html>
