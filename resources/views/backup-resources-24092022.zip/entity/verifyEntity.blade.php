<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
   <head>
      <meta charset="utf-8">
      <meta content="width=device-width, initial-scale=1.0" name="viewport">
      <title>Wealth Mark | Create Entity Account</title>
     
 @include('template.auth_page_cssLink') 
      
      
    <!------------------------Country flag dropdown css------------------------------->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/16.0.8/css/intlTelInput.css" />
     <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-select@1.13.14/dist/css/bootstrap-select.min.css">
    <link rel="stylesheet" href="{{ asset('public/assets/css/login_register.css') }}">
  
  <style>
  .scrollabletextbox .dropdown-menu.show{
      max-height:400px !important;
  }
  
  
  ._btn_div {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    -webkit-box-pack: justify;
    justify-content: space-between;
}
._btn_div button{
    margin:0px 10px;
}
  ._btn_default {
    margin: 0px;
    appearance: none;
    user-select: none;
    cursor: pointer;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    display: inline-flex;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: center;
    justify-content: center;
    box-sizing: border-box;
    font-family: inherit;
    font-weight: 500;
    text-align: center;
    text-decoration: none;
    outline: none;
    line-height: 20px;
    word-break: keep-all;
    color: rgb(30, 35, 41);
    border-radius: 4px;
    min-height: 24px;
    border: none;
    background-color: rgb(234, 236, 239);
    pointer-events: initial;
    font-size: 16px;
    padding: 14px 0px;
    min-width: 128px;
    width: 128px;
}
  
._btn_theme.inactive {
    background-color: rgb(252, 213, 53);
    opacity: 0.3;
    color: rgb(24, 26, 32);
    cursor: not-allowed;
}
._btn_theme {
    margin: 0px;
    appearance: none;
    user-select: none;
    cursor: pointer;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    display: inline-flex;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: center;
    justify-content: center;
    box-sizing: border-box;
    font-family: inherit;
    font-weight: 500;
    text-align: center;
    text-decoration: none;
    outline: none;
    line-height: 20px;
    word-break: keep-all;
    color: rgb(24, 26, 32);
    border-radius: 4px;
    min-height: 24px;
    border: none;
    background-image: none;
    background-color: rgb(252, 213, 53);
    pointer-events: initial;
    font-size: 16px;
    padding: 14px 54px;
    min-width: 164px;
    width: 282px;
}
a{
    color:black;
    text-decoration:none;
}



.inner_right_box {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    padding: 32px 24px;
    flex: 1 1 0%;
    -webkit-box-pack: center;
    justify-content: center;
}
._subtitle {
    box-sizing: border-box;
    margin: 8px 0px 32px;
    min-width: 0px;
    font-weight: 500;
    font-size: 14px;
    line-height: 20px;
    color: rgb(112, 122, 138);
}
.inner_right_box {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    padding: 32px 24px;
    flex: 1 1 0%;
    -webkit-box-pack: center;
    justify-content: center;
}
.inner_right_box {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    padding: 32px 24px;
    flex: 1 1 0%;
    -webkit-box-pack: center;
    justify-content: center;
}

._des_box {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
}

._title {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    font-weight: 600;
    font-size: 32px;
    line-height: 40px;
    color: rgb(30, 35, 41);
}

._des_list_box {
    box-sizing: border-box;
    margin: 16px 0px 0px;
    min-width: 0px;
    display: flex;
    -webkit-box-align: center;
    align-items: center;
}
._div_box {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    -webkit-box-align: center;
    align-items: center;
}
._svg_icon {
    box-sizing: border-box;
    margin: 0px 8px 0px 0px;
    color: rgb(183, 189, 198);
    font-size: 24px;
    fill: rgb(183, 189, 198);
    width: 1em;
    height: 1em;
    min-width: 24px;
}
._des {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    font-weight: 400;
    font-size: 16px;
    line-height: 24px;
    color: rgb(30, 35, 41);
}

._right_inner_main {
    box-sizing: border-box;
    margin: 30px 0px 0px;
    min-width: 0px;
    display: flex;
    width: 434px;
    min-height: 580px;
    flex-direction: column;
}
._title {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    font-weight: 600;
    font-size: 32px;
    line-height: 40px;
    color: rgb(30, 35, 41);
}

._right_main_content {
    box-sizing: border-box;
    margin: 40px 0px 0px;
    min-width: 0px;
    flex: 1 1 0%;
}
.main_content_inner {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    flex-direction: column;
    -webkit-box-pack: justify;
    justify-content: space-between;
    height: 100%;
    padding-bottom: 0px;
}
._mb-16px {
    box-sizing: border-box;
    margin: 0px 0px 16px;
    min-width: 0px;
}
._mb-16px {
    box-sizing: border-box;
    margin: 0px 0px 16px;
    min-width: 0px;
}
.legal_txt {
    box-sizing: border-box;
    margin: 8px 0px 0px;
    min-width: 0px;
    font-weight: 400;
    font-size: 12px;
    line-height: 16px;
    cursor: pointer;
    color: rgb(201, 148, 0);
    display: inline-block;
    text-decoration: underline;
}



._mb-40px {
    box-sizing: border-box;
    margin: 0px 0px 40px;
    min-width: 0px;
}
._border_box {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    width: 100%;
}
._des_heading {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    font-weight: 500;
    font-size: 16px;
    line-height: 24px;
    color: rgb(30, 35, 41);
}
.verify_btn.inactive {
    background-color: rgb(252, 213, 53);
    opacity: 0.3;
    color: rgb(24, 26, 32);
    cursor: not-allowed;
}
.verify_btn {
    margin: 0px 8px 0px 0px;
    appearance: none;
    user-select: none;
    cursor: pointer;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    display: inline-flex;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: center;
    justify-content: center;
    box-sizing: border-box;
    font-family: inherit;
    font-weight: 500;
    text-align: center;
    text-decoration: none;
    outline: none;
    line-height: 20px;
    word-break: keep-all;
    color: rgb(24, 26, 32);
    border-radius: 4px;
    min-height: 24px;
    border: none;
    background-image: none;
    background-color: rgb(252, 213, 53);
    pointer-events: initial;
    font-size: 16px;
    padding: 14px 54px;
    width: 100%;
    min-width: 164px;
}
.main_div {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    min-height: 0px;
    flex-direction: column;
}

.inner_left_box {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    background-image: url(https://bin.bnbstatic.com/image/julia/kyc/kyb-v5-light.png);
    background-size: cover;
    padding: 32px 24px;
    flex: 1 1 0%;
    flex-direction: column;
    -webkit-box-align: center;
    align-items: center;
}
.left_inner {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    align-self: flex-end;
    width: 434px;
}
._div_box {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    -webkit-box-align: center;
    align-items: center;
}
._des_info_title {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    font-weight: 600;
    font-size: 24px;
    line-height: 32px;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    color: rgb(30, 35, 41);
}


._des_box {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
}

.accordion-button:not(.collapsed) {
    color: rgb(146, 154, 165);
    background-color: #3d475400;
    box-shadow: none;
}
.accordion-item {
    background-color: #fff;
    border: 1px solid rgb(0 0 0 / 0%);
}

.accordion-button:hover{
    background:whitesmoke;
}
.accordion-button {
    position: relative;
    display: flex;
    align-items: center;
    width: 100%;
    padding: 1rem 1.25rem;
    font-size: 1rem;
    color: rgb(146, 154, 165);
    text-align: left;
    background-color: #fff;
    border: 0;
    border-radius: 0;
    overflow-anchor: none;
    transition: color .15s ease-in-out,background-color .15s ease-in-out,border-color .15s ease-in-out,box-shadow .15s ease-in-out,border-radius .15s ease;
}

/*---------------*/

@media screen and (min-width: 767px){
   
.inner_left_box {
    padding: 40px 24px;
    -webkit-box-align: center;
    align-items: center;
}
.main_content_inner {
    padding-bottom: 48px;
}

._right_inner_main {
    margin-left: 10%;
    margin-top: 0px;
}

.inner_right_box {
    padding: 64px 24px 32px;
    -webkit-box-pack: center;
    justify-content: center;
}
.inner_right_box {
    padding: 64px 24px 32px;
    -webkit-box-pack: center;
    justify-content: center;
}
 

.verify_btn {
    margin-top: 56px;
}
.verify_btn {
    margin: 0px;
    appearance: none;
    user-select: none;
    cursor: pointer;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    display: inline-flex;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: center;
    justify-content: center;
    box-sizing: border-box;
    font-family: inherit;
    text-align: center;
    text-decoration: none;
    outline: none;
    padding: 12px;
    line-height: 20px;
    min-width: 52px;
    word-break: keep-all;
    color: rgb(24, 26, 32);
    border-radius: 4px;
    min-height: 24px;
    border: none;
    background-image: none;
    background-color: rgb(252, 213, 53);
    width: 100%;
    font-size: 16px;
    font-weight: 500;
}
.inner_right_box {
    padding: 64px 24px 32px;
    -webkit-box-pack: center;
    justify-content: center;
}
._subtitle {
    margin-top: 8px;
    margin-bottom: 32px;
}
.main_div {
    min-height: 836px;
    flex-direction: column;
}

}

@media screen and (min-width: 1023px){

.inner_right_box {
    padding: 64px 0px 32px;
    -webkit-box-pack: start;
    justify-content: flex-end;
}
._subtitle {
    margin-top: 32px;
    margin-bottom: 0px;
}
.verify_btn {
    margin-top: 116px;
}
.main_div {
    flex-direction: row;
}
}

.bootstrap-select>.dropdown-toggle{
     height: calc(3.5rem + 2px);
    line-height: 1.25;
    border: 1px solid #ced4da;
    text-align:left;
    padding: 1rem 0.75rem;
    font-size:16px;
}

.country_dis {
    box-sizing: border-box;
    margin: 24px 0px 0px;
    min-width: 0px;
    display: flex;
    color: rgb(30, 35, 41);
    -webkit-box-align: center;
    align-items: center;
}
.icon_list {
    box-sizing: border-box;
    margin: 0px 8px 0px 0px;
    min-width: 0px;
    color: rgb(146, 154, 165);
    font-size: 24px;
    fill: rgb(146, 154, 165);
    width: 1em;
    height: 1em;
    vertical-align: middle;
    padding-bottom: 2px;
}
.flag {
    box-sizing: border-box;
    margin: 0px 8px 0px 0px;
    min-width: 0px;
    max-width: 100%;
    border-radius: 50%;
    flex-shrink: 0;
    width: 16px;
    height: 16px;
}
.content_dis {
    box-sizing: border-box;
    margin: 24px 0px 0px;
    min-width: 0px;
    display: flex;
    color: rgb(30, 35, 41);
}

.dis_text {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
}

.spprt-box-active {
    box-sizing: border-box;
    margin: 0px 32px 0px 0px;
    min-width: 0px;
    font-weight: 400;
    font-size: 14px;
    line-height: 20px;
    display: inline-block;
    cursor: pointer;
    color: rgb(30, 35, 41);
}
.spprt-label {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    flex-direction: row;
    -webkit-box-align: center;
    align-items: center;
}
.spprt-svgicon {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    color: currentcolor;
    width: 16px;
    height: 16px;
    font-size: 16px;
    fill: none;
}
.spprt-svgicon-active {
    color: rgb(240, 185, 11) !important;
       fill: rgb(240, 185, 11) !important;
}
.spprt-inpt_div {
    box-sizing: border-box;
    margin: 0px 0px 0px 8px;
    min-width: 0px;
}
[hidden] {
    display: none;
}
.spprt-box {
    box-sizing: border-box;
    margin: 0px 32px 0px 0px;
    min-width: 0px;
    font-weight: 400;
    font-size: 14px;
    line-height: 20px;
    display: inline-block;
    cursor: pointer;
    color: rgb(30, 35, 41);
}
.spprt-box svg {
    color: rgb(183, 189, 198);
}

.helpmail{
    color:rgb(240, 185, 11);
    font-weight:600 !important;
}



  
  
  
  
  
 /*=--------------------------- */

.main-content-box {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    min-height: 0px;
    flex-direction: column;
}

.leftbox {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    background-image: url(https://bin.bnbstatic.com/image/julia/kyc/kyb-v5-light.png);
    background-size: cover;
    padding: 32px 24px;
    background-color: rgb(250, 250, 250);
    flex: 1 1 0%;
    flex-direction: column;
    -webkit-box-align: center;
    align-items: center;
}
.left-inner {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    width: 100%;
    height: 100%;
    flex-direction: column;
    -webkit-box-pack: justify;
    justify-content: space-between;
}
.left-footer {
    box-sizing: border-box;
    margin: 24px 0px 0px;
    min-width: 0px;
}
/*.footer-optn {*/
/*    box-sizing: border-box;*/
/*    margin: 0px 0px 16px;*/
/*    min-width: 0px;*/
/*    font-weight: 500;*/
/*    font-size: 16px;*/
/*    line-height: 24px;*/
/*    color: rgb(30, 35, 41);*/
/*}*/
.footer-optn {
    box-sizing: border-box;
    margin: 0px 0px 16px;
    min-width: 0px;
    display: flex;
}
.left-svg-icon {
    box-sizing: border-box;
    margin: 0px 8px 0px 0px;
    color: rgb(146, 154, 165);
    font-size: 24px;
    fill: rgb(146, 154, 165);
    width: 1em;
    height: 1em;
    min-width: 24px}
.a-txt {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    text-decoration-line: underline;
    cursor: pointer;
    color: rgb(71, 77, 87);
}
.css-1cjl26j {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    font-weight: 400;
    font-size: 14px;
    line-height: 20px;
}
.checklist {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
}
.checklist-inner {
    box-sizing: border-box;
    margin: 24px 0px 0px;
    min-width: 0px;
    display: flex;
    border-radius: 48px;
    cursor: pointer;
    padding: 12px 16px;
    background-color: rgb(254, 246, 216);
    color: rgb(201, 148, 0);
    -webkit-box-align: center;
    align-items: center;
}
.checklist-svg {
    box-sizing: border-box;
    margin: 0px 8px 0px 0px;
    min-width: 0px;
    color: currentcolor;
    fill: currentcolor;
    width: 1em;
    height: 1em;
    font-size: 24px;
}

.rightbox {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    padding: 32px 24px;
    flex: 1 1 0%;
    -webkit-box-pack: center;
    justify-content: center;
}

.right-inner {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    width: 100%;
    flex-direction: column;
    -webkit-box-pack: justify;
    justify-content: space-between;
    padding-bottom: 48px;
}
.heading-box {
    box-sizing: border-box;
    margin: 0px 0px 32px;
    min-width: 0px;
    display: flex;
    -webkit-box-pack: justify;
    justify-content: space-between;
    width: 100%;
}
/*.p-bold {*/
/*    box-sizing: border-box;*/
/*    margin: 0px;*/
/*    min-width: 0px;*/
/*    font-weight: 500;*/
/*    font-size: 16px;*/
/*    line-height: 24px;*/
/*    color: rgb(30, 35, 41);*/
/*}*/
.counting {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    font-weight: 500;
    font-size: 16px;
    line-height: 24px;
    color: rgb(183, 189, 198);
}
.optn-box {
    box-sizing: border-box;
    margin: 0px 0px 24px;
    min-width: 0px;
    display: flex;
    cursor: pointer;
    border-radius: 8px;
    position: relative;
    -webkit-box-align: center;
    align-items: center;
    min-height: 80px;
    padding: 16px;
    background-color: rgb(250, 250, 250);
}
.optn-box-svg {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    color: currentcolor;
    font-size: 24px;
    fill: currentcolor;
    width: 1em;
    height: 1em;
}
.optn-box-txt {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    flex: 1 1 0%;
    padding-left: 16px;
    padding-right: 16px;
}
.p-bold {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    font-weight: 500;
    font-size: 16px;
    line-height: 24px;
    color: rgb(30, 35, 41);
}
@media (min-width: 1200px){
.h1 {
    font-size: 2.5rem !important;
}}
.p-light {
    box-sizing: border-box;
    margin: 4px 0px 0px;
    min-width: 0px;
    font-weight: 400;
    font-size: 14px;
    line-height: 20px;
    color: rgb(112, 122, 138);
}
.optn-arrow {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    color: rgb(71, 77, 87);
    font-size: 24px;
    fill: rgb(71, 77, 87);
    width: 1em;
    height: 1em;
}
.optn-box:hover {
    background-color: rgb(245, 245, 245);
}
.optn-box:hover > svg:last-child {
    color: rgb(240, 185, 11);
}
.border-box {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
}
.Main_title {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    -webkit-box-align: center;
    align-items: center;
}
.Edit-box {
    box-sizing: border-box;
    margin: 0px 0px 0px 8px;
    min-width: 0px;
    display: flex;
    border-radius: 4px;
    background-color: rgb(245, 245, 245);
    width: 32px;
    height: 32px;
    -webkit-box-pack: center;
    justify-content: center;
    -webkit-box-align: center;
    align-items: center;
}
.Edit-icon {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    color: rgb(146, 154, 165);
    font-size: 24px;
    fill: rgb(146, 154, 165);
    border-radius: 4px;
    width: 1em;
    height: 1em;
    vertical-align: middle;
}
.flag-img {
    box-sizing: border-box;
    margin: 0px 8px 0px 0px;
    min-width: 0px;
    max-width: 100%;
    border-radius: 50%;
    flex-shrink: 0;
    width: 16px;
    height: 16px;
}
.border-box {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
}
.opt-display {
    box-sizing: border-box;
    margin: 24px 0px 0px;
    min-width: 0px;
    display: flex;
    color: rgb(30, 35, 41);
    align-items: center;
}
.opt-display-txt {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
}
.btn-main-yellow.inactive {
    background-color: rgb(252, 213, 53);
    opacity: 0.3;
    color: rgb(24, 26, 32);
    cursor: not-allowed;
}
.btn-main-yellow {
    margin: 0px;
    appearance: none;
    user-select: none;
    cursor: pointer;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    display: inline-flex;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: center;
    justify-content: center;
    box-sizing: border-box;
    font-family: inherit;
    font-weight: 500;
    text-align: center;
    text-decoration: none;
    outline: none;
    line-height: 20px;
    word-break: keep-all;
    color: rgb(24, 26, 32);
    border-radius: 4px;
    min-height: 24px;
    border: none;
    background-image: none;
    background-color: rgb(252, 213, 53);
    pointer-events: initial;
    font-size: 16px;
    padding: 14px 54px;
    min-width: 164px;
    width: 100%;}
    .btn-inner-txt {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: inherit;
}
/*---------------*/

@media screen and (min-width: 767px){
.right-inner {
    margin-left: 0px;
    width: 536px;
}
.btn-main-yellow {
    width: 536px;
}
.rightbox {
    padding: 64px 24px 32px;
    -webkit-box-pack: center;
    justify-content: center;
}
.left-footer {
    margin-bottom: 0px;
}
.left-inner {
    margin-right: 0px;
    width: 536px;
}
.leftbox {
    padding: 40px 24px;
    -webkit-box-align: center;
    align-items: center;
}
.main-content-box {
    min-height: 836px;
    flex-direction: column;
} 

}

@media screen and (min-width: 1023px){
    .btn-main-yellow {
    width: 434px;
}
    .btn-div {
    padding: 0px;
    -webkit-box-pack: start;
    justify-content: flex-start;
}
.right-inner {
    margin-left: 10%;
    width: 434px;
}
.rightbox {
    padding: 64px 0px 32px;
    -webkit-box-pack: start;
    justify-content: flex-start;
}

.accordion-div .rightbox {
    padding: 64px 50px 32px 0px;
    -webkit-box-pack: start;
    justify-content: flex-start;
}
.accordion-div .rightbox .right-inner{
    width:90% !important;
}

.left-inner {
    margin-right: 10%;
    width: 434px;
}
.left-footer {
    margin-bottom: 48px;
}
.leftbox {
    padding: 64px 0px 32px;
    align-items: flex-end;
}
.main-content-box {
    flex-direction: row;
}
.Main_title {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    -webkit-box-align: center;
    align-items: center;
}

.validate_alrt{
    color:#dc3545 !important;
    font-size: 14px;
}

}
















/*--------------------only for need-kyc page---------------------------------*/

.modal-counrty-code .niceCountryInputMenuDropdownContent a{
    height:auto !important;
}

.modal-counrty-code .niceCountryInputMenu{
    display:flex;
    justify-content: space-between;
   
   height: calc(3.5rem + 2px);
    line-height: 1.25;
    border: 1px solid #ced4da;
    text-align:left;
    padding: 1rem 0.75rem;
}
.legal_txt_box.country_box{
    overflow:unset;
    min-height:auto;
}
.legal_txt_box.country_box .legal_text{
    margin:0px;
}

.modal-counrty-code  .niceCountryInputSelector{
    position: relative;
    display: flex;
    flex-direction: column;
    
}

.modal-counrty-code .niceCountryInputMenuFilter{
    position: absolute;
    width: 100%;
    top: 50px;
    z-index:99999999;
}
.modal-counrty-code .niceCountryInputMenuDropdownContent{
    position: absolute;
    width: 100%;
    background: white;
    z-index: 999999;
    top: 98px;

}
.modal-counrty-code .niceCountryInputMenuFilter input{
    width: 100%;
    margin: 0;
    border-radius:0px;
}
.modal-counrty-code .niceCountryInputMenuCountryFlag{
    border-radius:0px;
}

.modal-counrty-code .niceCountryInputMenuDropdownContent a:hover {
    background-color: whitesmoke !important;
    color: #000000 !important;
    text-decoration: none;
    border-radius: 0;
}
.modal-counrty-code .niceCountryInputMenuDropdownContent a{
        cursor: pointer;
}
.modal-counrty-code .niceCountryInputMenuDropdownContent a:nth-child(even){
    background:#ffc1081c;
}
/*--------------------only for need-kyc page---------------------------------*/


/*------------------------------------checklist document css popup---------------------*/

.css-1yi4org .style-dialog-body {
    padding: 0px;
}
.checklist_box {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    padding: 24px;
    font-size: 14px;
    line-height: 20px;
}

.checklist_header {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    -webkit-box-pack: justify;
    justify-content: space-between;
}
.checklist-flex {
    box-sizing: border-box;
    margin: 0px 16px 0px 0px;
    min-width: 0px;
    font-weight: 400;
    font-size: 16px;
    line-height: 24px;
    color: rgb(71, 77, 87);
}
.print-btn {
    box-sizing: border-box;
    margin: 0px;
    display: flex;
    cursor: pointer;
    min-width: 112px;
    -webkit-box-align: center;
    align-items: center;
}
.print-svg {
    box-sizing: border-box;
    margin: 0px 6px 0px 0px;
    min-width: 0px;
    color: rgb(201, 148, 0);
    fill: rgb(201, 148, 0);
    width: 1em;
    height: 1em;
    font-size: 16px;
}
.print-text {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    font-weight: 500;
    font-size: 14px;
    line-height: 20px;
    text-decoration: underline;
    color: rgb(201, 148, 0);
}
.css-15owl46 {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    position: relative;
}
.checklist-content-box {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    max-height: 100%;
    overflow-y: scroll;
}
.checklist-content-box {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    max-height: 100%;
    overflow-y: scroll;
}

.checklist-fulll-width {
    box-sizing: border-box;
    margin: 16px 0px;
    min-width: 0px;
    display: flex;
    -webkit-box-align: center;
    align-items: center;
    color: rgb(71, 77, 87);
    font-size: 14px;
}
/*.css-6qxdfh {*/
/*    box-sizing: border-box;*/
/*    margin: 0px 0px 12px;*/
/*    min-width: 0px;*/
/*    font-weight: 500;*/
/*    font-size: 16px;*/
/*    line-height: 24px;*/
/*    color: rgb(30, 35, 41);*/
/*}*/
.checklist-half-width {
    box-sizing: border-box;
    margin: 16px 0px;
    min-width: 0px;
    display: flex;
    flex-direction: column;
}
.checklist-label {
    box-sizing: border-box;
    margin: 0px 16px 0px 0px;
    min-width: 0px;
    display: flex;
    -webkit-box-align: center;
    align-items: center;
    color: rgb(71, 77, 87);
    font-size: 14px;
    flex: 1 1 0%;
}
.checklist-icon {
    box-sizing: border-box;
    margin: 0px 8px 0px 0px;
    min-width: 0px;
    flex-shrink: 0;
    width: 16px;
    height: 16px;
    line-height: 16px;
}
.checklist-input {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    position: absolute;
    opacity: 0;
    z-index: -1;
    width: 1px;
    height: 1px;
    overflow: hidden;
}
.checklist-icon > svg {
    box-sizing: border-box;
    cursor: pointer;
    border: 1px solid rgb(183, 189, 198);
    border-radius: 2px;
    max-width: 100%;
    max-height: 100%;
    background-color: transparent;
    fill: transparent;
}
.checklist-ssvg {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    color: currentcolor;
    font-size: 24px;
    fill: currentcolor;
    width: 1em;
    height: 1em;
}
.checklist-text {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    font-weight: 400;
    font-size: 14px;
    color: rgb(30, 35, 41);
    overflow: hidden;
    white-space: normal;
    text-overflow: ellipsis;
    line-height: 20px;
}
@media screen and (min-width: 767px){

.checklist-content-box {
    max-height: 480px;
}
    .checklist-half-width {
    flex-direction: row;
}

}




.checklist-footer {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    position: fixed;
    z-index: 1;
    left: 0px;
    bottom: 0px;
    padding: 32px 24px 24px;
    width: 100%;
    box-shadow: rgb(0 0 0 / 8%) 0px 2px 4px, rgb(0 0 0 / 8%) 0px 0px 4px;
    background-color: rgb(255, 255, 255);
    display: flex;
    -webkit-box-pack: justify;
    justify-content: space-between;
    -webkit-box-align: center;
    align-items: center;
}
.color-lightgray {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    color: rgb(112, 122, 138);
}
.large-text {
    box-sizing: border-box;
    margin: 0px 4px 0px 0px;
    min-width: 0px;
    font-weight: 600;
    font-size: 32px;
    line-height: 40px;
    color: rgb(30, 35, 41);
    display: inline;
}
@media screen and (min-width: 767px)
{
.checklist-footer {
    position: static;
    z-index: auto;
    left: unset;
    bottom: unset;
    padding-bottom: 0px;
    padding-left: 0px;
    padding-right: 0px;
    width: unset;
    box-shadow: none;
}
}

.disable_div{
        background: whitesmoke;
    padding: 10px 20px;
    position: relative;
    justify-content: start;
    align-items: center;
    box-sizing: border-box;
    cursor: not-allowed;
    border-radius: 0.25rem;
    height: calc(3.5rem + 2px);
    line-height: 1.25;
    
} 
         .img{
         width: 30px;
         height: 30px;
         position: relative;
         margin: 0px 10px;
         }
         .img .flag{
         box-sizing: border-box;
         margin: 0px 8px 0px 0px;
         min-width: 0px;
         max-width: 100%;
         border-radius: 50%;
         flex-shrink: 0;
         width: 100%;
         height: 100%;
         }
         .disable_div  .text{
         box-sizing: border-box;
         margin: 0px;
         min-width: 0px;
         position: relative;
         display: flex;
         font-weight: 500;
         font-size: 20px;
         line-height: 24px;
         -webkit-box-pack: center;
         justify-content: center;}
         .disable_div  .iconbox{
         right:20px;
         position:absolute;
         }

/*------------------------acordion css============**/
.threedotsvg {
    box-sizing: border-box;
    margin: 0px 8px 0px 0px;
    color: rgb(146, 154, 165);
    font-size: 24px;
    fill: rgb(146, 154, 165);
    width: 1em;
    height: 1em;
    min-width: 24px;
}
 


.accordion__header {
	padding: 1em;
	background-color: white;
	margin-top: 2px;
	display: flex;
	justify-content: space-between;
	align-items: center;
	cursor: pointer;
}
.accordion__header > * {
	margin-top: 0;
	margin-bottom: 0;
	font-size: 16px;
}
.accordion__header.is-active {
	background-color: white;
	color: black;
}

.accordion__toggle {
	margin-left: 10px;
	height: 3px;
	background-color: #222;
	width: 13px;
	display: block;
	position: relative;
	flex-shrink: 1;
	border-radius: 2px;
}

.accordion__toggle::before {
	content: "";
	width: 3px;
	height: 13px;
	display: block;
	background-color: #222;
	position: absolute;
	top: -5px;
	left: 5px;
	border-radius: 2px;
}

.is-active .accordion__toggle {
	background-color: black;
}
.is-active .accordion__toggle::before {
	display: none;
}


.accordion__body {
	display: none;
	padding: 1em;
	border: 1px solid white;
	border-top: 0;
}
.accordion__body.is-active {
	display: block;
}
   



.add-detail {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
}
.add-detail-inner {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    flex-direction: column;
}
.add-detail-inner-box {
    box-sizing: border-box;
    margin: 0px 20px 0px 0px;
    min-width: 0px;
    display: flex;
    overflow: auto;
    flex-wrap: wrap;
}
.add-detail-modal {
    box-sizing: border-box;
    margin: 8px 32px 8px 0px;
    min-width: 0px;
    display: flex;
    border-radius: 4px;
    cursor: pointer;
    width: 164px;
    height: 164px;
    background-color: rgb(245, 245, 245);
    -webkit-box-pack: center;
    justify-content: center;
    -webkit-box-align: center;
    align-items: center;
}
.add-detail-plus {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    flex-direction: column;
    -webkit-box-align: center;
    align-items: center;
}
.svg-plus-icon {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    color: rgb(146, 154, 165);
    font-size: 24px;
    fill: rgb(146, 154, 165);
    width: 1em;
    height: 1em;
}
.add-detail-modal:hover svg {
    color: rgb(240, 185, 11);
}
.add-detail {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
}

.btn-border-yellow:disabled:not(.inactive) {
    background-color: transparent;
    color: rgb(183, 189, 198);
}
.btn-border-yellow:disabled {
    cursor: not-allowed;
    background-image: none;
    background-color: rgb(234, 236, 239);
    color: rgb(183, 189, 198);
}
.btn-border-yellow {
    margin: 0px 10px;
    appearance: none;
    user-select: none;
    cursor: pointer;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    display: inline-flex;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: center;
    justify-content: center;
    box-sizing: border-box;
    font-size: 14px;
    font-family: inherit;
    font-weight: 500;
    text-align: center;
    text-decoration: none;
    outline: none;
    padding: 6px 12px;
    line-height: 20px;
    min-width: 52px;
    word-break: keep-all;
    color: rgb(201, 148, 0);
    border-radius: 4px;
    min-height: 24px;
    border: none;
    background-color: transparent;
    pointer-events: initial;
}
.divider-line{
    border: 1px solid whitesmoke;
    height: 2px;
    margin-top: 30px
}
  
  </style>
   </head>
   <body class="bg-white">
       
        <?php
        function getClientIP(){
          if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
          } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
          } else {
            $ip = $_SERVER['REMOTE_ADDR'];
          }
          return $ip;
        }
        
        $ipaddress = getClientIP();
        function ip_details($ip) {
          $json = file_get_contents("http://ipinfo.io/{$ip}/geo");
          $details = json_decode($json, true);
          return $details;
        }
        $details = ip_details($ipaddress);
        $country_code=$details['country'];
        //print_r($country_code);
        $url = 'http://country.io/names.json';
        $json = file_get_contents($url);
        $jo = json_decode($json);
    ?>
       
    
   
       
      
     
       
                
        <div class="main-content-box"  id="first">
           <div class="leftbox">
             <div class="left-inner">
      <div class="border-box">
        <div class="Main_title">
         <div class="p-bold">Shubham-1</div>
          <div class="Edit-box">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="Edit-icon">
              <path fill-rule="evenodd" clip-rule="evenodd" d="M17.879 3.293l2.828 2.828-2.12 2.121-2.83-2.828 2.122-2.121zm-3.183 3.182l2.829 2.829-4.667 4.666H10.03v-2.828l4.666-4.667zM7 4h4v3H7v10h10v-4h3v7H4V4h3z" fill="currentColor"></path>
            </svg>
          </div>
        </div>
        <div class="opt-display">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="left-svg-icon">
            <path fill-rule="evenodd" clip-rule="evenodd" d="M17.534 16.32a7.826 7.826 0 10-11.068 0L12 21.854l5.534-5.534zM12 7l-4 4 4 4 4-4-4-4z" fill="currentColor"></path>
          </svg>
          <img src="{{asset('public/assets/img/Flag_of_India.jpg') }}" class="flag-img">
          <div class="border-box">India</div>
        </div>
        <div class="opt-display">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="left-svg-icon">
            <path fill-rule="evenodd" clip-rule="evenodd" d="M5 3v18h14V7l-4-4H5zm3 6.5h8V12H8V9.5zm0 5h8V17H8v-2.5z" fill="currentColor"></path>
          </svg>
          <div class="opt-display-txt">Government Body/Agency</div>
        </div>
        <div class="opt-display">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="left-svg-icon">
            <path fill-rule="evenodd" clip-rule="evenodd" d="M4 4v12l8 5 8-5V4H4zm12 7a4 4 0 11-8 0 4 4 0 018 0zm-4-2.121L9.879 11 12 13.121 14.121 11 12 8.879z" fill="currentColor"></path>
          </svg>
          <div class="opt-display-txt">Sovereign Wealth Fund/ Government Investment Fund</div>
        </div>
      </div>
      <div class="left-footer">
        <div class="border-box">
          <div class="p-bold mb-3">FAQ</div>
          <div class="footer-optn">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="left-svg-icon">
              <path fill-rule="evenodd" clip-rule="evenodd" d="M5 3v18h14V7l-4-4H5zm3 6.5h8V12H8V9.5zm0 5h8V17H8v-2.5z" fill="currentColor"></path>
            </svg>
            <a  target="_blank" href="#" class="a-txt">
              <div class="css-1cjl26j">How to Apply for Entity Verification</div>
            </a>
          </div>
          <div class="checklist">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="left-svg-icon">
              <path fill-rule="evenodd" clip-rule="evenodd" d="M5 3v18h14V7l-4-4H5zm3 6.5h8V12H8V9.5zm0 5h8V17H8v-2.5z" fill="currentColor"></path>
            </svg>
            <a  target="_blank" href="#" class="a-txt">
              <div class="css-1cjl26j">How to Manage Sub-Account Functions and Frequently Asked Questions</div>
            </a>
          </div>
        </div>
        <div class="checklist">
          <div class="checklist-inner" >
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="checklist-svg">
              <path fill-rule="evenodd" clip-rule="evenodd" d="M20 3v19H4V3h16z" fill="url(#whitelist-g_svg__paint0_linear)"></path>
              <path d="M16 3h-3V1h-2v2H8v2h8V3zM6.498 13.492l4 4.01 7-6.992-1.42-1.42-5.58 5.582-2.59-2.59-1.41 1.41z" fill="#76808F"></path>
              <defs>
                <linearGradient id="whitelist-g_svg__paint0_linear" x1="12" y1="22" x2="12" y2="3" gradientUnits="userSpaceOnUse">
                  <stop stop-color="#F0B90B"></stop>
                  <stop offset="1" stop-color="#F8D33A"></stop>
                </linearGradient>
              </defs>
            </svg>Checklist
          </div>
        </div>
      </div>
    </div>
           </div>
           <div class="rightbox" >
             <div class="right-inner">
               <div class="_des_box">
                 <svg width="64" height="64" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                   <rect x="2" y="10" width="6" height="10" fill="#76808F"></rect>
                   <rect x="16" y="8" width="6" height="12" fill="#76808F"></rect>
                   <rect width="8" height="17" transform="matrix(1 0 0 -1 8 20)" fill="url(#paint108_1_linear)"></rect>
                   <path d="M10 9L12 7L14 9L12 11L10 9Z" fill="#76808F"></path>
                   <defs>
                     <linearGradient id="paint108_1_linear" x1="4" y1="0" x2="4" y2="17" gradientUnits="userSpaceOnUse">
                       <stop stop-color="#F0B90B"></stop>
                       <stop offset="1" stop-color="#F8D33A"></stop>
                     </linearGradient>
                   </defs>
                 </svg>
               </div>
               <div class="_des_box">
                 <div class="_title">Entity Verification</div>
               </div>  <div class="_subtitle">Account limits after Verification</div>
               <div class="_right_main_content">
               
                 <div class="_des_list_box">
                   <div class="_div_box">
                     <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="_svg_icon">
                       <path fill-rule="evenodd" clip-rule="evenodd" d="M12 21a9 9 0 100-18 9 9 0 000 18zM8.75 10.75h-2.5v2.5h2.5v-2.5zm9 0h-2.5v2.5h2.5v-2.5zm-7 0h2.5v2.5h-2.5v-2.5z" fill="currentColor"></path>
                     </svg>
                     <div class="_des">Unlimited crypto deposit</div>
                   </div>
                 </div>
                 <div class="_des_list_box">
                   <div class="_div_box">
                     <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="_svg_icon">
                       <path fill-rule="evenodd" clip-rule="evenodd" d="M12 21a9 9 0 100-18 9 9 0 000 18zM8.75 10.75h-2.5v2.5h2.5v-2.5zm9 0h-2.5v2.5h2.5v-2.5zm-7 0h2.5v2.5h-2.5v-2.5z" fill="currentColor"></path>
                     </svg>
                     <div class="_des">8000000 BUSD crypto withdrawal limit every 24 hours</div>
                   </div>
                 </div>
                 <div class="_des_list_box">
                   <div class="_div_box">
                     <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="_svg_icon">
                       <path fill-rule="evenodd" clip-rule="evenodd" d="M12 21a9 9 0 100-18 9 9 0 000 18zM8.75 10.75h-2.5v2.5h2.5v-2.5zm9 0h-2.5v2.5h2.5v-2.5zm-7 0h2.5v2.5h-2.5v-2.5z" fill="currentColor"></path>
                     </svg>
                     <div class="_des">
                       <a type="link" href="/en/vip-institutional-services" target="_blank" class="css-1e3kx25">Institutional &amp; VIP Services</a>
                     </div>
                   </div>
                 </div>
                 <div class="_des_list_box">
                   <div class="_div_box">
                     <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="_svg_icon">
                       <path fill-rule="evenodd" clip-rule="evenodd" d="M12 21a9 9 0 100-18 9 9 0 000 18zM8.75 10.75h-2.5v2.5h2.5v-2.5zm9 0h-2.5v2.5h2.5v-2.5zm-7 0h2.5v2.5h-2.5v-2.5z" fill="currentColor"></path>
                     </svg>
                     <div class="_des">Fiat deposit/withdrawal (optional)</div>
                   </div>
                 </div>
                 
               </div>
             
             
             <div class="btn-div">
                   <button type="button" id="verify_btn" class="btn-main-yellow">Verify</button>
                 </div>
             </div>
           </div>
          
          
         </div>
     
       
     
    <div id="second_div" style="display:none">
           <div class="main-content-box">
           <div class="leftbox">
             <div class="left-inner">
      <div class="border-box">
        <div class="Main_title">
         <div class="p-bold">Shubham</div>
          <div class="Edit-box">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="Edit-icon">
              <path fill-rule="evenodd" clip-rule="evenodd" d="M17.879 3.293l2.828 2.828-2.12 2.121-2.83-2.828 2.122-2.121zm-3.183 3.182l2.829 2.829-4.667 4.666H10.03v-2.828l4.666-4.667zM7 4h4v3H7v10h10v-4h3v7H4V4h3z" fill="currentColor"></path>
            </svg>
          </div>
        </div>
        <div class="opt-display">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="left-svg-icon">
            <path fill-rule="evenodd" clip-rule="evenodd" d="M17.534 16.32a7.826 7.826 0 10-11.068 0L12 21.854l5.534-5.534zM12 7l-4 4 4 4 4-4-4-4z" fill="currentColor"></path>
          </svg>
          <img src="{{asset('public/assets/img/Flag_of_India.jpg') }}" class="flag-img">
          <div class="border-box">India</div>
        </div>
        <div class="opt-display">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="left-svg-icon">
            <path fill-rule="evenodd" clip-rule="evenodd" d="M5 3v18h14V7l-4-4H5zm3 6.5h8V12H8V9.5zm0 5h8V17H8v-2.5z" fill="currentColor"></path>
          </svg>
          <div class="opt-display-txt">Government Body/Agency</div>
        </div>
        <div class="opt-display">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="left-svg-icon">
            <path fill-rule="evenodd" clip-rule="evenodd" d="M4 4v12l8 5 8-5V4H4zm12 7a4 4 0 11-8 0 4 4 0 018 0zm-4-2.121L9.879 11 12 13.121 14.121 11 12 8.879z" fill="currentColor"></path>
          </svg>
          <div class="opt-display-txt">Sovereign Wealth Fund/ Government Investment Fund</div>
        </div>
      </div>
      <div class="left-footer">
        <div class="border-box">
          <div class="p-bold mb-3">FAQ</div>
          <div class="footer-optn">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="left-svg-icon">
              <path fill-rule="evenodd" clip-rule="evenodd" d="M5 3v18h14V7l-4-4H5zm3 6.5h8V12H8V9.5zm0 5h8V17H8v-2.5z" fill="currentColor"></path>
            </svg>
            <a  target="_blank" href="#" class="a-txt">
              <div class="css-1cjl26j">How to Apply for Entity Verification</div>
            </a>
          </div>
          <div class="checklist">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="left-svg-icon">
              <path fill-rule="evenodd" clip-rule="evenodd" d="M5 3v18h14V7l-4-4H5zm3 6.5h8V12H8V9.5zm0 5h8V17H8v-2.5z" fill="currentColor"></path>
            </svg>
            <a  target="_blank" href="#" class="a-txt">
              <div class="css-1cjl26j">How to Manage Sub-Account Functions and Frequently Asked Questions</div>
            </a>
          </div>
        </div>
        <div class="checklist">
          <div class="checklist-inner">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="checklist-svg">
              <path fill-rule="evenodd" clip-rule="evenodd" d="M20 3v19H4V3h16z" fill="url(#whitelist-g_svg__paint0_linear)"></path>
              <path d="M16 3h-3V1h-2v2H8v2h8V3zM6.498 13.492l4 4.01 7-6.992-1.42-1.42-5.58 5.582-2.59-2.59-1.41 1.41z" fill="#76808F"></path>
              <defs>
                <linearGradient id="whitelist-g_svg__paint0_linear" x1="12" y1="22" x2="12" y2="3" gradientUnits="userSpaceOnUse">
                  <stop stop-color="#F0B90B"></stop>
                  <stop offset="1" stop-color="#F8D33A"></stop>
                </linearGradient>
              </defs>
            </svg>Checklist
          </div>
        </div>
      </div>
    </div>
           </div>
           <div class="rightbox" >
             <div class="right-inner">
                 
                 <div class="_des_box">
                 <div class="_title">Start your entity application</div>
                 <div class="_subtitle">Answer a few questions below to see what you need to prepare</div>
               </div>
               <div class="_right_main_content">
                 <form action="#" style="width: 100%; height: 100%;" >
                   <div class="main_content_inner">
                     <div class="_des_box">
                       <div class="_mb-40px">
                         <div class="_border_box">
                           <div class="_des_heading">What is the name of your entity?</div>
                           <div class="form-floating mt-3 mb-3">
                                        <input type="text" id="doccc" class="form-control" name="doccc" value="{{ old('doccc') }}" placeholder="As displayed on your original document" >
                                        
                                        <label for="floatingInput">As displayed on your original document</label>
                            </div>
                            <div  id="doccc_alert" class="validate_alrt"></div>
                        </div>
                       </div>
                       <div class="_mb-40px">
                            <div class="_border_box">
                           <div class="_des_heading">Which country is your entity registered in? </div>
                          </div>
                         <div class="modal-counrty-code  mt-3 mb-3">
                  <div id="regCntry" class="niceCountryInputSelector" data-selectedcountry="{{ $country_code }}" data-showspecial="false" data-showflags="true" data-i18nall="All selected" onclick="select_country();" data-i18nnofilter="No selection"  data-i18nfilter="no Filter"></div>
                </div>
                     </div>
                    </div>
                 </form>
               </div>
           </form>
             </div>
              <div class="_des_box">
                       <button type="button" id="btn-2" class="inactive btn-main-yellow">
                         <div class="_btn_text">Continue</div>
                       </button>
                     </div>
                 </div>
                 </div>
                 </div>
         </div>
      <div id="third" style="display:none">
        <div class="main-content-box">
   <div class="leftbox">
             <div class="left-inner">
      <div class="border-box">
        <div class="Main_title">
         <div class="p-bold">Shubham</div>
          <div class="Edit-box">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="Edit-icon">
              <path fill-rule="evenodd" clip-rule="evenodd" d="M17.879 3.293l2.828 2.828-2.12 2.121-2.83-2.828 2.122-2.121zm-3.183 3.182l2.829 2.829-4.667 4.666H10.03v-2.828l4.666-4.667zM7 4h4v3H7v10h10v-4h3v7H4V4h3z" fill="currentColor"></path>
            </svg>
          </div>
        </div>
        <div class="opt-display">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="left-svg-icon">
            <path fill-rule="evenodd" clip-rule="evenodd" d="M17.534 16.32a7.826 7.826 0 10-11.068 0L12 21.854l5.534-5.534zM12 7l-4 4 4 4 4-4-4-4z" fill="currentColor"></path>
          </svg>
          <img src="{{asset('public/assets/img/Flag_of_India.jpg') }}" class="flag-img">
          <div class="border-box">India</div>
        </div>
        <div class="opt-display">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="left-svg-icon">
            <path fill-rule="evenodd" clip-rule="evenodd" d="M5 3v18h14V7l-4-4H5zm3 6.5h8V12H8V9.5zm0 5h8V17H8v-2.5z" fill="currentColor"></path>
          </svg>
          <div class="opt-display-txt">Government Body/Agency</div>
        </div>
        <div class="opt-display">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="left-svg-icon">
            <path fill-rule="evenodd" clip-rule="evenodd" d="M4 4v12l8 5 8-5V4H4zm12 7a4 4 0 11-8 0 4 4 0 018 0zm-4-2.121L9.879 11 12 13.121 14.121 11 12 8.879z" fill="currentColor"></path>
          </svg>
          <div class="opt-display-txt">Sovereign Wealth Fund/ Government Investment Fund</div>
        </div>
      </div>
      <div class="left-footer">
        <div class="border-box">
          <div class="p-bold mb-3">FAQ</div>
          <div class="footer-optn">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="left-svg-icon">
              <path fill-rule="evenodd" clip-rule="evenodd" d="M5 3v18h14V7l-4-4H5zm3 6.5h8V12H8V9.5zm0 5h8V17H8v-2.5z" fill="currentColor"></path>
            </svg>
            <a  target="_blank" href="#" class="a-txt">
              <div class="css-1cjl26j">How to Apply for Entity Verification</div>
            </a>
          </div>
          <div class="checklist">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="left-svg-icon">
              <path fill-rule="evenodd" clip-rule="evenodd" d="M5 3v18h14V7l-4-4H5zm3 6.5h8V12H8V9.5zm0 5h8V17H8v-2.5z" fill="currentColor"></path>
            </svg>
            <a  target="_blank" href="#" class="a-txt">
              <div class="css-1cjl26j">How to Manage Sub-Account Functions and Frequently Asked Questions</div>
            </a>
          </div>
        </div>
        <div class="checklist">
          <div class="checklist-inner">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="checklist-svg">
              <path fill-rule="evenodd" clip-rule="evenodd" d="M20 3v19H4V3h16z" fill="url(#whitelist-g_svg__paint0_linear)"></path>
              <path d="M16 3h-3V1h-2v2H8v2h8V3zM6.498 13.492l4 4.01 7-6.992-1.42-1.42-5.58 5.582-2.59-2.59-1.41 1.41z" fill="#76808F"></path>
              <defs>
                <linearGradient id="whitelist-g_svg__paint0_linear" x1="12" y1="22" x2="12" y2="3" gradientUnits="userSpaceOnUse">
                  <stop stop-color="#F0B90B"></stop>
                  <stop offset="1" stop-color="#F8D33A"></stop>
                </linearGradient>
              </defs>
            </svg>Checklist
          </div>
        </div>
      </div>
    </div>
           </div>
   <div class="rightbox">
     <div class="right-inner">
         <div class="_des_box">
                 <div class="_title">What is your entity type?</div>
               </div>
               <div class="_right_main_content">
                 <form action="#" style="width: 100%; height: 100%;">
                   <div class="main_content_inner">
                     <div class="_des_box">
                       <div class="_mb-40px">
                         <div class="_border_box">
                           <div class="_mb-16px">
                             <div class="_des_heading">What is the legal form of your entity?</div>
                             <div class="legal_txt">What is legal form?</div>
                             
                              <div class="mt-3 mb-3">
                          <div class="dropdown-theme">
                        
                             <select class="selectpicker selectpicker1 w-100" id="legalForm" name="legalForm" data-selected-text-format="count > 1">
                                 <option value=""> Select Entity Type </option>
                                 @foreach( $entityTypes as $entityType )
                                  <option value="{{ $entityType->id }}"> {{ $entityType->entity_name }} </option>
                                
                                 @endforeach
                               
                                
                             </select>
                          </div>
                          
                        </div>
                        <div id="legalvalidateErr" class="validate_alrt" ></div>
                           </div>
                         </div>
                       </div>
                       <div class="_mb-40px">
                         <div class="_border_box">
                           <div class="_mb-16px">
                             <div class="_des_heading">Select your company type</div>
                             
                             <div class="mt-3 mb-3">
                          <div class="dropdown-theme">
                        
                             <select class="selectpicker selectpicker2 w-100" id="companyTpye" name="companyTpye" data-selected-text-format="count > 1">
                                  <option value=""> Select Company Type </option>
                                  @foreach( $companyTypes as $companyType )
                                  <option value="{{ $companyType->id }}"> {{ $companyType->name }} </option>
                                
                                 @endforeach
                                 
                             
                               
                             </select>
                          </div>
                           
                        </div>
                          </div>
                         </div>
                         <div id="companyvalidateErr" class="validate_alrt"></div>
                       </div>
                     </div>
                    
                   </div>
                 </form>
               </div>
               <div class="_btn_div">
                         <button type="button" class=" _btn_default" onclick="moveOn2nd();">
                           
                           <div class="_btn_text">Previous</div>
                         </button>
                         <button type="button" id="select_farm" class="btn-main-yellow inactive">
                           <div class="_btn_text">Continue</div>
                         </button>
                       </div>
     </div>
   </div>
 </div>
       
       </div>  
        <div id="fourth" style="display:none">
                <div class="main-content-box">
        <div class="leftbox">
             <div class="left-inner">
      <div class="border-box">
        <div class="Main_title">
         <div class="p-bold">Shubham</div>
          <div class="Edit-box">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="Edit-icon">
              <path fill-rule="evenodd" clip-rule="evenodd" d="M17.879 3.293l2.828 2.828-2.12 2.121-2.83-2.828 2.122-2.121zm-3.183 3.182l2.829 2.829-4.667 4.666H10.03v-2.828l4.666-4.667zM7 4h4v3H7v10h10v-4h3v7H4V4h3z" fill="currentColor"></path>
            </svg>
          </div>
        </div>
        <div class="opt-display">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="left-svg-icon">
            <path fill-rule="evenodd" clip-rule="evenodd" d="M17.534 16.32a7.826 7.826 0 10-11.068 0L12 21.854l5.534-5.534zM12 7l-4 4 4 4 4-4-4-4z" fill="currentColor"></path>
          </svg>
          <img src="{{asset('public/assets/img/Flag_of_India.jpg') }}" class="flag-img">
          <div class="border-box">India</div>
        </div>
        <div class="opt-display">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="left-svg-icon">
            <path fill-rule="evenodd" clip-rule="evenodd" d="M5 3v18h14V7l-4-4H5zm3 6.5h8V12H8V9.5zm0 5h8V17H8v-2.5z" fill="currentColor"></path>
          </svg>
          <div class="opt-display-txt">Government Body/Agency</div>
        </div>
        <div class="opt-display">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="left-svg-icon">
            <path fill-rule="evenodd" clip-rule="evenodd" d="M4 4v12l8 5 8-5V4H4zm12 7a4 4 0 11-8 0 4 4 0 018 0zm-4-2.121L9.879 11 12 13.121 14.121 11 12 8.879z" fill="currentColor"></path>
          </svg>
          <div class="opt-display-txt">Sovereign Wealth Fund/ Government Investment Fund</div>
        </div>
      </div>
      <div class="left-footer">
        <div class="border-box">
          <div class="p-bold mb-3">FAQ</div>
          <div class="footer-optn">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="left-svg-icon">
              <path fill-rule="evenodd" clip-rule="evenodd" d="M5 3v18h14V7l-4-4H5zm3 6.5h8V12H8V9.5zm0 5h8V17H8v-2.5z" fill="currentColor"></path>
            </svg>
            <a  target="_blank" href="#" class="a-txt">
              <div class="css-1cjl26j">How to Apply for Entity Verification</div>
            </a>
          </div>
          <div class="checklist">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="left-svg-icon">
              <path fill-rule="evenodd" clip-rule="evenodd" d="M5 3v18h14V7l-4-4H5zm3 6.5h8V12H8V9.5zm0 5h8V17H8v-2.5z" fill="currentColor"></path>
            </svg>
            <a  target="_blank" href="#" class="a-txt">
              <div class="css-1cjl26j">How to Manage Sub-Account Functions and Frequently Asked Questions</div>
            </a>
          </div>
        </div>
        <div class="checklist">
          <div class="checklist-inner">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="checklist-svg">
              <path fill-rule="evenodd" clip-rule="evenodd" d="M20 3v19H4V3h16z" fill="url(#whitelist-g_svg__paint0_linear)"></path>
              <path d="M16 3h-3V1h-2v2H8v2h8V3zM6.498 13.492l4 4.01 7-6.992-1.42-1.42-5.58 5.582-2.59-2.59-1.41 1.41z" fill="#76808F"></path>
              <defs>
                <linearGradient id="whitelist-g_svg__paint0_linear" x1="12" y1="22" x2="12" y2="3" gradientUnits="userSpaceOnUse">
                  <stop stop-color="#F0B90B"></stop>
                  <stop offset="1" stop-color="#F8D33A"></stop>
                </linearGradient>
              </defs>
            </svg>Checklist
          </div>
        </div>
      </div>
    </div>
           </div>
       <div class="rightbox">
         <div class="right-inner">
              <div class="_des_box">
                     <div class="_title">Additional support</div>
                   </div>
                   <div class="_right_main_content">
                       <div id="add_support" class="validate_alrt"> </div>
                     <form action="#" style="width: 100%; height: 100%;">
                       <div class="main_content_inner">
                         <div class="_des_box">
                           <div class="_mb-40px">
                             <div class="_border_box">
                               <div class="_mb-16px">
                                 <div class="_des_heading">Have you already been in touch with a Binance Key Account Manager?</div>
                                    <div class="mt-3 mb-3">
                             <div class="spprt-box">
                                      <label class="spprt-label">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="none" class="spprt-svgicon selectYes add1">
                                          <circle cx="8" cy="8" r="7.5" stroke="currentColor"></circle>
                                          <circle cx="8" cy="8" r="4" fill="currentColor" style="display:none"></circle>
                                        </svg>
                                        <div class="spprt-inpt_div">Yes, I have <input hidden=""  type="radio"  value="1" style="clip: rect(0px, 0px, 0px, 0px); position: absolute;">
                                        </div>
                                       
                                      </label>
                                    </div>
                                    
                                    <div class="spprt-box">
                                      <label class="spprt-label">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="none" class="spprt-svgicon selectNo add2">
                                          <circle cx="8" cy="8" r="7.5" stroke="currentColor"></circle>
                                          <circle cx="8" cy="8" r="4" fill="currentColor" style="display:none"></circle>
                                        </svg>
                                        <div class="spprt-inpt_div">No, I haven’t <input hidden="" type="radio"  value="0" style="clip: rect(0px, 0px, 0px, 0px); position: absolute;">
                                        </div>
                                      </label>
                                    </div>
                                </div>
                                 
                               </div>
                             </div>
                           </div>
                           <div class="_mb-40px" id="idYes" style="display:none">
                             <div class="_border_box">
                               <div class="_mb-16px">
                                 <div class="_des_heading">Please add the name of the Key Account Manager here</div>
                                  <div class="form-floating mt-3 mb-3">
                                 <input type="text" class="form-control" id="accountkey" name="accountkey" value="{{old('accountkey')}}" placeholder="Please add the name ...."/>
                                 <label for="floatingInput">name of the Key Account Manager here.....</label>
                                 </div>
                                 
                                 </div>
                                 </div>
                           </div>
                           
                           <div class="_mb-40px" id="ifNo" style="display:none">
                             <div class="_border_box">
                               <div class="_mb-16px">
                                 <div class="_des_heading">Please provide us with your most recent email.</div>
                                  <div class="form-floating mt-3 mb-5">
                                 <input type="text" class="form-control" id="recentmail" name="recentmail" value="{{old('recentmail')}}" placeholder="Please add the name ...."/>
                                 <label for="floatingInput">Enter your mail</label>
                                 </div>
                                 
                                 
                                 <span class="fs-6 mt-1 text-secondary">You can also take the initiative and get in touch with us via</span>
                                 <span class="helpmail">help@wealthmark.io</span>
                                <input type="hidden" name="_token" id="token" value="{{ csrf_token() }}">
                                 </div>
                                 </div>
                           </div>
                         </div>
                         
                        
                       </div>
                     </form>
                   </div>
                    <div class="_des_box">
                           <div class="_btn_div">
                             <button type="button" class=" _btn_default" onClick="moveOn3rd();">
                               <div class="_btn_text">Previous</div>
                             </button>
                             <button type="button" class="btn-main-yellow inactive modal-trigger" id="additinalBtn" data-modal="verify_process">
                               <div class="_btn_text ">Continue</div>
                             </button>
                               
          
                           </div>
                         </div>
         </div>
       </div>
     </div>
       </div>
       
       <!------------------------------------------------------------------------------------------------------------>
      <div id="fifth" style="display:none">
        <div class="main-content-box">
              <div class="leftbox">
                <div class="left-inner">
                  <div class="border-box">
                    <div class="Main_title">
                     <div class="p-bold">Shubham</div>
                      <div class="Edit-box">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="Edit-icon">
                          <path fill-rule="evenodd" clip-rule="evenodd" d="M17.879 3.293l2.828 2.828-2.12 2.121-2.83-2.828 2.122-2.121zm-3.183 3.182l2.829 2.829-4.667 4.666H10.03v-2.828l4.666-4.667zM7 4h4v3H7v10h10v-4h3v7H4V4h3z" fill="currentColor"></path>
                        </svg>
                      </div>
                    </div>
                    <div class="opt-display">
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="left-svg-icon">
                        <path fill-rule="evenodd" clip-rule="evenodd" d="M17.534 16.32a7.826 7.826 0 10-11.068 0L12 21.854l5.534-5.534zM12 7l-4 4 4 4 4-4-4-4z" fill="currentColor"></path>
                      </svg>
                      <img src="{{asset('public/assets/img/Flag_of_India.jpg') }}" class="flag-img">
                      <div class="border-box">India</div>
                    </div>
                    <div class="opt-display">
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="left-svg-icon">
                        <path fill-rule="evenodd" clip-rule="evenodd" d="M5 3v18h14V7l-4-4H5zm3 6.5h8V12H8V9.5zm0 5h8V17H8v-2.5z" fill="currentColor"></path>
                      </svg>
                      <div class="opt-display-txt">Government Body/Agency</div>
                    </div>
                    <div class="opt-display">
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="left-svg-icon">
                        <path fill-rule="evenodd" clip-rule="evenodd" d="M4 4v12l8 5 8-5V4H4zm12 7a4 4 0 11-8 0 4 4 0 018 0zm-4-2.121L9.879 11 12 13.121 14.121 11 12 8.879z" fill="currentColor"></path>
                      </svg>
                      <div class="opt-display-txt">Sovereign Wealth Fund/ Government Investment Fund</div>
                    </div>
                  </div>
                  <div class="left-footer">
                    <div class="border-box">
                      <div class="p-bold">FAQ</div>
                      <div class="footer-optn">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="left-svg-icon">
                          <path fill-rule="evenodd" clip-rule="evenodd" d="M5 3v18h14V7l-4-4H5zm3 6.5h8V12H8V9.5zm0 5h8V17H8v-2.5z" fill="currentColor"></path>
                        </svg>
                        <a  target="_blank" href="#" class="a-txt">
                          <div class="css-1cjl26j">How to Apply for Entity Verification</div>
                        </a>
                      </div>
                      <div class="checklist">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="left-svg-icon">
                          <path fill-rule="evenodd" clip-rule="evenodd" d="M5 3v18h14V7l-4-4H5zm3 6.5h8V12H8V9.5zm0 5h8V17H8v-2.5z" fill="currentColor"></path>
                        </svg>
                        <a  target="_blank" href="#" class="a-txt">
                          <div class="css-1cjl26j">How to Manage Sub-Account Functions and Frequently Asked Questions</div>
                        </a>
                      </div>
                    </div>
                    <div class="checklist">
                      <div class="checklist-inner">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="checklist-svg">
                          <path fill-rule="evenodd" clip-rule="evenodd" d="M20 3v19H4V3h16z" fill="url(#whitelist-g_svg__paint0_linear)"></path>
                          <path d="M16 3h-3V1h-2v2H8v2h8V3zM6.498 13.492l4 4.01 7-6.992-1.42-1.42-5.58 5.582-2.59-2.59-1.41 1.41z" fill="#76808F"></path>
                          <defs>
                            <linearGradient id="whitelist-g_svg__paint0_linear" x1="12" y1="22" x2="12" y2="3" gradientUnits="userSpaceOnUse">
                              <stop stop-color="#F0B90B"></stop>
                              <stop offset="1" stop-color="#F8D33A"></stop>
                            </linearGradient>
                          </defs>
                        </svg>Checklist
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="rightbox">
                <div class="right-inner">
                  <div class="border-box">
                    <div class="heading-box">
                      <div class="p-bold">Verify your business information</div>
                      <div class="counting">0/4</div>
                    </div>
                    <div class="optn-box" id="basic_information">
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="optn-box-svg">
                        <path fill-rule="evenodd" clip-rule="evenodd" d="M22 20H2V4h20v16zM4 7h7v6H4V7zm9 0h4v2h-4V7z" fill="url(#id-g_svg__paint0_linear)"></path>
                        <path d="M7.5 12a2 2 0 100-4 2 2 0 000 4zM11 17v-4H4v4h7zM13 11h7v2h-7v-2zM20 15h-7v2h7v-2z" fill="#76808F"></path>
                        <defs>
                          <linearGradient id="id-g_svg__paint0_linear" x1="12" y1="20" x2="12" y2="4" gradientUnits="userSpaceOnUse">
                            <stop stop-color="#F0B90B"></stop>
                            <stop offset="1" stop-color="#F8D33A"></stop>
                          </linearGradient>
                        </defs>
                      </svg>
                      <div class="optn-box-txt">
                        <div class="p-bold">Basic Information</div>
                        <div class="p-light">Fill in basic entity information</div>
                      </div>
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="optn-arrow">
                        <path fill-rule="evenodd" clip-rule="evenodd" d="M12.288 12l-3.89 3.89 1.768 1.767L15.823 12l-1.768-1.768-3.889-3.889-1.768 1.768 3.89 3.89z" fill="currentColor"></path>
                      </svg>
                    </div>
                    <div class="optn-box" id="Related-Parties">
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="optn-box-svg">
                        <path d="M17 13v3h2v-3h3v-2h-3V8h-2v3h-3v2h3zM3 18a4 4 0 014-4h4a4 4 0 014 4v3H3v-3z" fill="#76808F"></path>
                        <path fill-rule="evenodd" clip-rule="evenodd" d="M13.5 7.5a4.5 4.5 0 10-9 0 4.5 4.5 0 009 0z" fill="url(#referral-g_svg__paint0_linear)"></path>
                        <defs>
                          <linearGradient id="referral-g_svg__paint0_linear" x1="9" y1="12" x2="9" y2="3" gradientUnits="userSpaceOnUse">
                            <stop stop-color="#F0B90B"></stop>
                            <stop offset="1" stop-color="#F8D33A"></stop>
                          </linearGradient>
                        </defs>
                      </svg>
                      <div class="optn-box-txt">
                        <div class="p-bold">Related Parties</div>
                        <div class="p-light">Add related entity parties</div>
                      </div>
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="optn-arrow">
                        <path fill-rule="evenodd" clip-rule="evenodd" d="M12.288 12l-3.89 3.89 1.768 1.767L15.823 12l-1.768-1.768-3.889-3.889-1.768 1.768 3.89 3.89z" fill="currentColor"></path>
                      </svg>
                    </div>
                    <div class="optn-box">
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="optn-box-svg">
                        <path fill-rule="evenodd" clip-rule="evenodd" d="M4.014 21H20a2 2 0 002-2V3H6v15.857c0 1.179-.889 2.135-1.987 2.143zM8 11h5v6H8v-6zm12 0h-5v2h5v-2zm-5 4h5v2h-5v-2z" fill="url(#news-g_svg__paint0_linear)"></path>
                        <path d="M18 8h-8V6h8v2zM2 18.857V9h4v9.857C6 20.041 5.105 21 4 21s-2-.96-2-2.143z" fill="#76808F"></path>
                        <defs>
                          <linearGradient id="news-g_svg__paint0_linear" x1="16.5" y1="13.5" x2="16.5" y2="2" gradientUnits="userSpaceOnUse">
                            <stop stop-color="#F0B90B"></stop>
                            <stop offset="1" stop-color="#F8D33A"></stop>
                          </linearGradient>
                        </defs>
                      </svg>
                      <div class="optn-box-txt">
                        <div class="p-bold">Upload Documents</div>
                        <div class="p-light">Upload required documents</div>
                      </div>
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="optn-arrow">
                        <path fill-rule="evenodd" clip-rule="evenodd" d="M12.288 12l-3.89 3.89 1.768 1.767L15.823 12l-1.768-1.768-3.889-3.889-1.768 1.768 3.89 3.89z" fill="currentColor"></path>
                      </svg>
                    </div>
                    <div class="optn-box">
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="optn-box-svg">
                        <circle r="10" transform="matrix(1 0 0 -1 12 12)" fill="url(#payment-g_svg__paint0_linear)"></circle>
                        <path d="M13.088 20v-1.782c2.468-.408 3.62-1.949 3.62-3.768 0-1.893-1.244-2.951-3.843-3.545V7.824c.89.204 1.485.612 1.93 1.113l1.69-1.522c-.817-.928-1.912-1.503-3.397-1.67V4h-2.116v1.745c-2.395.278-3.675 1.578-3.675 3.526 0 1.8 1.132 3.026 3.916 3.601v3.341c-1.04-.148-1.912-.65-2.617-1.392l-1.67 1.522c.927 1.021 2.171 1.782 4.046 1.95V20h2.116zM9.858 9.197c0-.724.408-1.225 1.355-1.41v2.747c-.947-.26-1.355-.631-1.355-1.337zm4.288 5.457c0 .706-.409 1.281-1.281 1.522v-2.932c1.058.315 1.28.872 1.28 1.41z" fill="#76808F"></path>
                        <defs>
                          <linearGradient id="payment-g_svg__paint0_linear" x1="10" y1="0" x2="10" y2="20" gradientUnits="userSpaceOnUse">
                            <stop stop-color="#F0B90B"></stop>
                            <stop offset="1" stop-color="#F8D33A"></stop>
                          </linearGradient>
                        </defs>
                      </svg>
                      <div class="optn-box-txt">
                        <div class="p-bold">Fiat Enablement (if needed)</div>
                        <div class="p-light">If you wish to use the Fiat service, additional information is required.</div>
                      </div>
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="optn-arrow">
                        <path fill-rule="evenodd" clip-rule="evenodd" d="M12.288 12l-3.89 3.89 1.768 1.767L15.823 12l-1.768-1.768-3.889-3.889-1.768 1.768 3.89 3.89z" fill="currentColor"></path>
                      </svg>
                    </div>
                  </div>
                  <div class="btn-div">
                    <button  type="button" class="inactive btn-main-yellow">
                      <div class="_btn_text">Submit</div>
                    </button>
                  </div>
                </div>
              </div>
            </div>
        </div>
    <div id="basic_information-div" class="" style="display:none">
     <div class="main-content-box">
       <div class="leftbox">
         <div class="left-inner">
           <div class="border-box">
             
           </div>
           <div class="left-footer">
             
             
           </div>
         </div>
       </div>
       <div class="rightbox">
         <div class="right-inner">
           <div>
             <div class="h1 p-bold  mt-3 mb-5">Basic Information</div>
             <div class="accordion" id="accordionExample">
               <div class="accordion-item">
                 <h2 class="accordion-header" id="headingOne">
                   <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                     <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="threedotsvg">
                       <path fill-rule="evenodd" clip-rule="evenodd" d="M12 21a9 9 0 100-18 9 9 0 000 18zM8.75 10.75h-2.5v2.5h2.5v-2.5zm9 0h-2.5v2.5h2.5v-2.5zm-7 0h2.5v2.5h-2.5v-2.5z" fill="currentColor"></path>
                     </svg> Account Information </button>
                 </h2>
                 <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                   <div class="accordion-body">
                     <div class="row">
                       <div class="col-md-12">
                         <div class="form-floating mt-3 mb-3">
                           <input type="text" class="form-control" placeholder="Entity Name" id="eName" name="eName" value="{{ ($entity->entity_name) ? $entity->entity_name : old('eName')  }}">
                           <label for="floatingInput">Entity Name</label>
                         </div>
                       </div>
                       <div class="col">
                         <div class="form-floating mt-3 mb-3">
                           <input type="text" class="form-control" placeholder="Registration Number" id="eRegistration" name="eRegistration" value="{{ ($entity->reg_num) ?  $entity->reg_num : old('eRegistration')}}">
                           <label for="floatingInput">Registration Number</label>
                         </div>
                       </div>
                       <div class="col">
                         <div class="form-floating mt-3 mb-3">
                           <input type="date" class="form-control" placeholder="Date of Incorporation" id="eIncorpDate" name="eIncorpDate" value="{{ ($entity->DOB_incorpor) ? $entity->DOB_incorpor : old('eIncorpDate')}}">
                           <label for="floatingInput">Date of Incorporation</label>
                         </div>
                       </div>
                     </div>
                     <div class="mt-2">
                       <button class="btn-main-yellow w-auto" id="accountInfo" >
                         <div class="_btn_text">
                           Confirm
                         </div>
                       </button>
                     </div>
                   </div>
                 </div>
               </div>
               <div class="accordion-item">
                 <h2 class="accordion-header" id="headingTwo">
                   <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                     <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="threedotsvg">
                       <path fill-rule="evenodd" clip-rule="evenodd" d="M12 21a9 9 0 100-18 9 9 0 000 18zM8.75 10.75h-2.5v2.5h2.5v-2.5zm9 0h-2.5v2.5h2.5v-2.5zm-7 0h2.5v2.5h-2.5v-2.5z" fill="currentColor"></path>
                     </svg> Entity Address </button>
                 </h2>
                 <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
                   <div class="accordion-body">
                     <div class="row">
                          <div class="country_box"></div>
                          
                        
                           <div class="col" > 
                                                <div class="form-floating mt-3 mb-3">
                                               <select id="eRegCountry" name="eRegCountry" placeholder="Jurisdiction country">
                                                   @foreach($jo as $key => $value)
                                                    <img src="https://countryflagsapi.com/png/{{ $key }}" >
                                                       <option value="{{ $key }}" {{ $key == $entity->regstrd_cntry ? "selected"  : "" }} >
                                                             
                                                                   <span> {{ $value }}</span>
                                                     </option>
                                                     <img src="https://countryflagsapi.com/png/{{ $key }}" >
                                                  @endforeach
                                               </select>
                                               </div>
                            </div>
                     
                     
                       <div class="col">
                         <div class="form-floating mt-3 mb-3">
                           <input type="text" class="form-control" placeholder="City" id="eCity" name="eName" value="{{ $entity->city ? $entity->city : old('eName')}}">
                           <label for="floatingInput">City</label>
                         </div>
                       </div>
                       <div class="col-md-12">
                         <div class="form-floating mt-3 mb-3">
                           <input type="text" class="form-control" placeholder="Street Address" id="eStreet" name="eStreet" value="{{ $entity->street_add ? $entity->street_add : old('eStreet')}}">
                           <label for="floatingInput">Street Address</label>
                         </div>
                       </div>
                       <div class="col-md-12">
                         <div class="form-floating mt-3 mb-3">
                           <input type="text" class="form-control" placeholder="Zip Code" id="eZip" name="eZip" value="{{ $entity->postal_code ? $entity->postal_code : old('eZip')}}">
                           <label for="floatingInput">Zip Code</label>
                         </div>
                       </div>
                     </div>
                     <div class="mt-2 mb-5">
                       <div class="p-bold">Operating Business Address</div>
                       <div class="p-light">The operating business address is the same as the registered address.</div>
                       <div class="mt-3 mb-3">
                         <div class="spprt-box">
                           <label class="spprt-label">
                             <!--<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="none" class="spprt-svgicon  a1">-->
                             <!--  <circle cx="8" cy="8" r="7.5" stroke="currentColor"></circle>-->
                             <!--  <circle cx="8" cy="8" r="4" fill="currentColor" style="display:none"></circle>-->
                             <!--</svg>-->
                             <div class="spprt-inpt_div">Yes <input class="addressYes" type="radio"   name="hasKeyAccountManager"    value="{{ $entity->oprting_addrs_same ? $entity->oprting_addrs_same : old('hasKeyAccountManager')}}"  {{ ($entity->oprting_addrs_same == 1) ? "checked" : ""}}>
                             </div>
                           </label>
                         </div>
                         <div class="spprt-box">
                           <label class="spprt-label">
                             <!--<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="none" class="spprt-svgicon addressNo a2">-->
                             <!--  <circle cx="8" cy="8" r="7.5" stroke="currentColor"></circle>-->
                             <!--  <circle cx="8" cy="8" r="4" fill="currentColor" style="display:none"></circle>-->
                             <!--</svg>-->
                             <div class="spprt-inpt_div">No <input  class="addressNo" type="radio"  name="hasKeyAccountManager" value="{{ $entity->oprting_addrs_same ? $entity->oprting_addrs_same : old('hasKeyAccountManager')}}" >
                             </div>
                           </label>
                         </div>
                       </div>
                     
                       <div class="address_same" style="">
                         <div class="p-light">Please note that the operating business address should be the same as the address in the proof of address for your entity, which is provided on the Upload Document page.</div>
                       </div>
                      
                       <div class="address_nosame" style="display:none">
                         <div class="row">
                           <div class="col">
                             <!--<div class="disable_div d-flex form-control mt-3 mb-3">-->
                             <!--  <div class="img">-->
                             <!--    <img src="{{asset('public/assets/img/Flag_of_India.jpg') }}" class="flag">-->
                             <!--  </div>-->
                             <!--  <div class="text">-->
                             <!--    <span> </span>-->
                             <!--  </div>-->
                             <!--  <div class="iconbox">-->
                             <!--    <i class="bi bi-caret-down-fill"></i>-->
                             <!--  </div>-->
                             <!--</div>-->
                             <div class="form-floating mt-3 mb-3">
                                               <select id="eRegCountry" name="eRegCountry" placeholder="Jurisdiction country">
                                                   @foreach($jo as $key => $value)
                                                    <img src="https://countryflagsapi.com/png/{{ $key }}" >
                                                       <option value="{{ $key }}" {{ $key == $entity->oprt_juris_cntry ? "selected"  : "" }} >
                                                             
                                                                   <span> {{ $value }}</span>
                                                     </option>
                                                     <img src="https://countryflagsapi.com/png/{{ $key }}" >
                                                  @endforeach
                                               </select>
                                              </div>
                           </div>
                           <div class="col">
                             <div class="form-floating mt-3 mb-3">
                               <input type="text" class="form-control" placeholder="City" id="eOperativeCity" name="eOperativeCity" value="{{ $entity->oprt_city ? $entity->oprt_city : old('eOperativeCity')}}">
                               <label for="floatingInput">City</label>
                             </div>
                           </div>
                           <div class="col-md-12">
                             <div class="form-floating mt-3 mb-3">
                               <input type="text" class="form-control" placeholder="Street Address" id="eOperativeStreet" name="eOperativeStreet" value="{{ $entity->oprt_street_add ? $entity->oprt_street_add : old('eOperativeStreet')}}">
                               <label for="floatingInput">Street Address</label>
                             </div>
                           </div>
                           <div class="col-md-12">
                             <div class="form-floating mt-3 mb-3">
                               <input type="text" class="form-control" placeholder="Zip Code" id="eOperativeZip" name="eOperativeZip" value="{{ $entity->oprt_postal_code ? $entity->oprt_postal_code : old('eOperativeZip')}}">
                               <label for="floatingInput">Zip Code</label>
                             </div>
                           </div>
                         </div>
                       </div>
                     </div>
                     <div>
                       <button class="btn-main-yellow w-auto" id="entityAddrs">
                         <div class="_btn_text">
                        Confirm
                         </div>
                       </button>
                     </div>
                   </div>
                 </div>
               </div>
               <div class="accordion-item">
                 <h2 class="accordion-header" id="headingThree">
                   <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                     <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="threedotsvg">
                       <path fill-rule="evenodd" clip-rule="evenodd" d="M12 21a9 9 0 100-18 9 9 0 000 18zM8.75 10.75h-2.5v2.5h2.5v-2.5zm9 0h-2.5v2.5h2.5v-2.5zm-7 0h2.5v2.5h-2.5v-2.5z" fill="currentColor"></path>
                     </svg> Source Declaration </button>
                 </h2>
                 <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#accordionExample">
                   <div class="accordion-body">
                     <div class="form-floating mt-3 mb-3">
                       <input type="text" class="form-control" placeholder="Source of Capital" id="eSourceCap" name="eSourceCap" value="{{ $entity->cap_source ?  $entity->cap_source : old('eSourceCap')}}">
                       <label for="floatingInput">Source of Capital</label>
                       <p class="p-light">How your entity obtained your initial capital</p>
                     </div>
                     <div class="form-floating mt-3 mb-3">
                       <input type="text" class="form-control" placeholder="Source of Wealth" id="eSourceWealth" name="eSourceWealth" value="{{ $entity->wealth_source ?  $entity->wealth_source : old('eSourceWealth')}}">
                       <label for="floatingInput">Source of Wealth</label>
                       <p class="p-light">The origin of the entire wealth of your entity</p>
                     </div>
                     <div class="form-floating mt-3 mb-3">
                       <input type="text" class="form-control" placeholder="Source of Funds" id="eSourceFund" name="eSourceFund" value="{{ $entity->fund_source ?  $entity->fund_source : old('eSourceFund')}}">
                       <label for="floatingInput">Source of Funds</label>
                       <p class="p-light">Origin of the particular funds that are being used to fund your binance account</p>
                     </div>
                     <div>
                       <button class="btn-main-yellow w-auto" id="sourceDeclr">
                         <div class="_btn_text"> Confirm </div>
                       </button>
                     </div>
                   </div>
                 </div>
               </div>
               <div class="accordion-item">
                 <h2 class="accordion-header" id="headingThree">
                   <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapsefour" aria-expanded="false" aria-controls="collapsefour">
                     <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="threedotsvg">
                       <path fill-rule="evenodd" clip-rule="evenodd" d="M12 21a9 9 0 100-18 9 9 0 000 18zM8.75 10.75h-2.5v2.5h2.5v-2.5zm9 0h-2.5v2.5h2.5v-2.5zm-7 0h2.5v2.5h-2.5v-2.5z" fill="currentColor"></path>
                     </svg> Additional Information </button>
                    
                 </h2>
                 <div id="collapsefour" class="accordion-collapse collapse" aria-labelledby="headingfour" data-bs-parent="#accordionExample">
                   <div class="accordion-body">
                        <div class="form-floating mt-3 mb-3">
                      
                       <label for="floatingInput">Business Nature</label>
                       
                    <select class="form-control scrollabletextbox" id="ebusiNature" name="ebusiNature"  placeholder="Business Nature" class=" max-height: 280px; overflow-y: auto;">
                         
                         @foreach($businessNatures as $businessNature)
                          <option value=" {{ $businessNature->id }}" {{ $businessNature->id == $entity->entity_nature ? "selected" : "" }}> {{ $businessNature->name }}</option>
                    
                     @endforeach
                     
                      
                    </select>
                      
                        
                     </div>
                      <div class=" mt-3 mb-3">
                           <label for="appliPerpose">Purpose of Application</label> 
                      
                    <textarea  
                    class="form-control" id="appliPerpose" name="appliPerpose" value="{{ $entity->appli_purpose ? $entity->appli_purpose : old('appliPerpose')}}" placeholder="">
                        
                    </textarea>
                      
                     </div>
                     <div class="input-number-group">
                       <div class="mb-3">
                             <!--<div class="img">-->
                               
                             <!--     <img src="https://countryflagsapi.com/png/{{$entity->regstrd_cntry}}" class="flag">-->
                             <!--  </div>-->
                             <!--  <div class="text">-->
                                
                                
                             <!--  </div>-->
                             <!--  <div class="iconbox">-->
                             <!--    <i class="bi bi-caret-down-fill"></i>-->
                             <!--  </div>-->
                              <div class="form-floating mt-3 mb-3">
                                               <select id="eRegCountry" name="eRegCountry" placeholder="Jurisdiction country">
                                                   @foreach($jo as $key => $value)
                                                    <img src="https://countryflagsapi.com/png/{{ $key }}" >
                                                       <option value="{{ $key }}" {{ $key == $entity->oprt_juris_cntry ? "selected"  : "" }} >
                                                             
                                                                   <span> {{ $value }}</span>
                                                     </option>
                                                     <img src="https://countryflagsapi.com/png/{{ $key }}" >
                                                  @endforeach
                                               </select>
                                              </div>
                       
                       </div>
                       <div class="form-floating mb-3">
                         <input type="text" class="form-control" id="additnlEntityPhone" name="additnlEntityPhone" value="{{ $entity->contact_num ? $entity->contact_num : old('additnlEntityPhone')}}" placeholder="Phone Number">
                         <label for="floatingInput">Mobile Number</label>
                       </div>
                     </div>
                     <div class="form-floating mt-3 mb-3">
                       <input type="text" class="form-control" id="eCompany" name="eCompany" value="" placeholder="Company Website (if have)">
                       <label for="floatingInput">Company Website (if have)</label>
                       <p class="p-light">Ensure the website you provide is accessible. If the company doesn't have a website, please put "N/A" here</p>
                     </div>
                     <div>
                       <button class="btn-main-yellow w-auto" id="addtnlinfo">
                         <div class="_btn_text"> Confirm </div>
                       </button>
                     </div>
                   </div>
                 </div>
               </div>
             </div>
             <div class="mt-3">
               <button class="btn-main-yellow inactive">
                 <div class="_btn_text"> Complete</div>
               </button>
             </div>
           </div>
         </div>
       </div>
     </div>
   </div>
         
         
         
         
         
         
         
          <div id="Related-Parties-div" class="accordion-div" style="display:none">
     <div class="main-content-box">
       <div class="leftbox">
         <div class="left-inner">
           <div class="border-box">
             
           </div>
           <div class="left-footer">
             
             
           </div>
         </div>
       </div>
       <div class="rightbox">
         <div class="right-inner">
           <div>
             <div class="h1 p-bold  mt-3 mb-5">Related Parties</div>
            <div class="mt-2">
                <div class="accordion">
    <div class="accordion__header is-active">
        <h2><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="threedotsvg"><path fill-rule="evenodd" clip-rule="evenodd" d="M12 21a9 9 0 100-18 9 9 0 000 18zM8.75 10.75h-2.5v2.5h2.5v-2.5zm9 0h-2.5v2.5h2.5v-2.5zm-7 0h2.5v2.5h-2.5v-2.5z" fill="currentColor"></path></svg> 
       Director(s) or Equivalent Persons</h2>
       
        <span class="accordion__toggle"></span>
    </div>
    <div class="accordion__body is-active">
       <div class="mt-3">
            <div class="p-light">Please add the information of all directors here.
            </div>
            <div class="add-detail">
                <div class="add-detail-inner">
                    <div class="add-detail-inner-box">
                        <div class="add-detail-modal modal-trigger" data-modal="Add-Director">
                            
                            <div class="add-detail-plus">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="svg-plus-icon"><path d="M13.5 3h-3v7.5H3v3h7.5V21h3v-7.5H21v-3h-7.5V3z" fill="currentColor"></path></svg><div class="text">Add</div></div></div></div></div></div></div><div class="add-detail">
                <button  type="button"  class="inactive btn-main-yellow w-auto">
                    
                        <div>
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="optn-box-svg">
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M7.035 16.812l-.001.002 2.121 2.121.002-.002 2.121-2.12 9.19-9.192-2.12-2.121-9.191 9.19-3.536-3.534-2.121 2.12 3.535 3.536z" fill="currentColor"></path></svg>Confirm
                            </div>
                         
                            </button>
                            <button   type="submit" class="btn-border-yellow"><div>Save as Draft
                            </div>
                            </button>
                            </div>
                            <div class="divider-line"></div>
     </div>
   
    <div class="accordion__header">
        <h2>
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="threedotsvg"><path fill-rule="evenodd" clip-rule="evenodd" d="M12 21a9 9 0 100-18 9 9 0 000 18zM8.75 10.75h-2.5v2.5h2.5v-2.5zm9 0h-2.5v2.5h2.5v-2.5zm-7 0h2.5v2.5h-2.5v-2.5z" fill="currentColor"></path></svg>
        Ultimate Beneficial Owner(s) (if any)   </h2>
        <span class="accordion__toggle"></span>
    </div>
    <div class="accordion__body">
        <p>Shipping and returns are free for everyone, everywhere in the world :)</p>
        <p><strong>Free worldwide shipping</strong></p>
        <p>Your order will be dispatched the next day.</p>
    </div>
    <div class="accordion__header">
        <h2> <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="threedotsvg"><path fill-rule="evenodd" clip-rule="evenodd" d="M12 21a9 9 0 100-18 9 9 0 000 18zM8.75 10.75h-2.5v2.5h2.5v-2.5zm9 0h-2.5v2.5h2.5v-2.5zm-7 0h2.5v2.5h-2.5v-2.5z" fill="currentColor"></path></svg>
           Significant Controller(s)
        </h2>
        <span class="accordion__toggle"></span>
    </div>
    <div class="accordion__body">
        <p>Our exclusive AbsorbLite&trade; fabric is a durable form of microfiber (polyamide/polyester).</p>
        <p>Taken care of properly it shoud last you years. We recommend cold tumble dry.</p>        
    </div>
    <div class="accordion__header">
        
         <h2> <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="threedotsvg"><path fill-rule="evenodd" clip-rule="evenodd" d="M12 21a9 9 0 100-18 9 9 0 000 18zM8.75 10.75h-2.5v2.5h2.5v-2.5zm9 0h-2.5v2.5h2.5v-2.5zm-7 0h2.5v2.5h-2.5v-2.5z" fill="currentColor"></path></svg>
            Authorised Account Trader</h2>
        <span class="accordion__toggle"></span>
       
    </div>
    <div class="accordion__body">
    </div>
	 <div class="accordion__header">
        <h2> <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="threedotsvg"><path fill-rule="evenodd" clip-rule="evenodd" d="M12 21a9 9 0 100-18 9 9 0 000 18zM8.75 10.75h-2.5v2.5h2.5v-2.5zm9 0h-2.5v2.5h2.5v-2.5zm-7 0h2.5v2.5h-2.5v-2.5z" fill="currentColor"></path></svg>
            Main Trader Verification</h2>
        <span class="accordion__toggle"></span>
    </div>
    <div class="accordion__body">
        <p>We want you to love tyour Tesalate towel. If you don’t, return it for free even if you have used it. No questions asked.</p>
    </div>
	 <div class="accordion__header">
        <h2> <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="threedotsvg"><path fill-rule="evenodd" clip-rule="evenodd" d="M12 21a9 9 0 100-18 9 9 0 000 18zM8.75 10.75h-2.5v2.5h2.5v-2.5zm9 0h-2.5v2.5h2.5v-2.5zm-7 0h2.5v2.5h-2.5v-2.5z" fill="currentColor"></path></svg>
            Upload Letter of Authorization</h2>
        <span class="accordion__toggle"></span>
    </div>
    <div class="accordion__body">
        <p>We want you to love tyour Tesalate towel. If you don’t, return it for free even if you have used it. No questions asked.</p>
    </div>
	
</div>
            </div>
             <div class="mt-3">
               <button class="btn-main-yellow inactive">
                 <div class="_btn_text"> Complete</div>
               </button>
             </div>
           </div>
         </div>
       </div>
     </div>
   </div>
        
        
       
       
     <div class="modal custom_modal" id="verify_process">
     
         <div class="modal-sandbox"></div>
         <div class="modal-box" style="max-width:850px;">
            <div class="modal-header">
                  <div class="modal-icons">
                     <span class="btn-back" id="back_start">
                     <i class="bi bi-arrow-left"></i>
                     </span>
                     <span class="close-modal">
                     <i class="bi bi-x"></i>
                     </span>
                  </div>
                       <div id="ifdoc" class="validate_alrt"> </div>
                  <div class="modal_heading">Here is your checklist of documents </div>
               </div>
               <div class="modal-body text-start" >
               <div class="style-dialog-body checklist_box">
                     <div class="checklist_header">
                        <div  class="checklist-flex">Select the document(s) you have prepared. Please note that you see optional documents and details of the required documents by downloading the checklist.</div>
                        <div class="print-btn">
                          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="print-svg">
                            <path d="M3 5.5A2.5 2.5 0 005.5 8H21v13H6a3 3 0 01-3-3V5.5z" fill="url(#wallet-g_svg__paint0_linear)"></path>
                            <path d="M5.5 3H21v5H5.5a2.5 2.5 0 010-5zM21 12v5h-5v-5h5z" fill="#76808F"></path>
                            <defs>
                              <linearGradient id="wallet-g_svg__paint0_linear" x1="12" y1="21" x2="12" y2="5.5" gradientUnits="userSpaceOnUse">
                                <stop stop-color="#F0B90B"></stop>
                                <stop offset="1" stop-color="#F8D33A"></stop>
                              </linearGradient>
                            </defs>
                          </svg>
                          <div  class="print-text">Print Full List</div>
                        </div>
                      </div>
                      
            
                        <div class="checklist-content-box">
                             <div  class="p-bold">Entity Documents</div>
                            <input type="checkbox"  checked hidden id="docs2" class="checkAll" name="" value="entityDoc-">
                           
                             @foreach($entityDocs as $entityDoc)
                      
                                 @if($entityDoc->type == 1)
                               
                                 <div class="" style="width:50%; float:left">
                                      <div class="checklist-half-width">
                                            <input type="checkbox" id="docs_{{$entityDoc->id}}" name="docs_{{$entityDoc->id}}" value="{{$entityDoc->id}}">
                                             <label class="checklist-label" style="margin-left:10px !important"> <div  class="checklist-text"> {{ $entityDoc->name }}</div> </label>
                                  
                                      </div>
                                  </div>
                                  @endif
                             @endforeach
                        
                            
                          
                          
                  
                        <div style="clear:both"></div>
                        <div  class="p-bold">Related Parties’ Documents</div> 
                        
                         
                          <div class="mt-4">
                             <label class="checklist-fulll-width">
                                 <input type="checkbox" hidden checked id="" class="" name="" value="partiesDoc-">
                              <div class="checklist-icon">
                                
                                @foreach($entityDocs as $entityDoc)
                                    
                                    @if($entityDoc->type == 2)
                                        <input type="checkbox"  id="docs2" style="display:none" class="checkAll" name="docs[]" value="{{$entityDoc->id}}">
                                        
                                     @endif
                                     
                                @endforeach
                                
                                  <input type="checkbox"  id="docs2" class="checkAll" name="" value="0">
                                
                              </div>
                               
                               
                              <div  class="checklist-text">Identity document ( 
                              @foreach($entityDocs as $entityDoc) 
                                    @if($entityDoc->type == 2 && $entityDoc->subtype == 1) 
                                        {{ $entityDoc->name }}
                                    @endif       
                              @endforeach  
                              ) or Proof of Address  ( 
                                    @foreach($entityDocs as $entityDoc) 
                                        @if($entityDoc->type == 2 && $entityDoc->subtype == 2)  
                                          {{ $entityDoc->name }}  
                                         @endif    
                                     @endforeach   
                                ) of significant related parties.</div>
                            </label>
                          </div>
                         
                              
                  
                    </div>
                      
                      <div class="checklist-footer">
                        <div  class="color-lightgray">
                          <div  class="large-text">0</div>% of your documents prepared
                        </div>
                        <button  class="btn-main-yellow w-auto" class="checklistData" id="btn_basic_detail">
                          <div class="_btn_text">Start</div>
                        </button>
                      </div>
                    </div>
               </div>
             
            </div>
            
     </div>
     <!--------------------------------------------------------------------------------->
     <div class="modal custom_modal" id="Add-Director">
         <div class="modal-sandbox"></div>
         <div class="modal-box" style="max-width:850px;">
            <div class="modal-header">
                  <div class="modal-icons">
                     <span class="btn-back" id="back_start">
                     <i class="bi bi-arrow-left"></i>
                     </span>
                     <span class="close-modal">
                     <i class="bi bi-x"></i>
                     </span>
                  </div>
                  <div class="modal_heading">Add Director(s) or Equivalent Persons </div>
               </div>
               <div class="modal-body text-start" >
              <div class="min-height:450px">
                  <p class="p-bold"> Select Type </p>
              </div>
               </div>
             
            </div>
            
     </div>
       
      
      
        @include('template.auth_page_js') 

         <!----------------------------------- add for country dropdown box---------------------------------->
           <!-- condition for showing basic information direct  -->
       @if($entity)
               @if( ( ($entity->entity_type != NULL) && ($entity->entity_name != NULL) && ($entity->company_type != NULL) && ($entity->regstrd_cntry != NULL) ) &&  ( ($entity->keyAcount_manager != NULL) || ($entity->most_recentMail != NULL) ) )
                
                           <script type="text/javascript">
                           
                           document.getElementById('first').style.display="none";
                            document.getElementById('fifth').style.display="block";
                               //  $("#first").css({"display":"none"});
                             //    $("#fifth").css({"display":"block"});
                           </script>
              @endif
      
      @endif
        <!-- end condition for showing basic information direct  -->   
         
         
        <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.14.0-beta2/js/bootstrap-select.min.js"></script>
        
    
        <script>
        
                $(".modal-trigger").click(function(e){
                 e.preventDefault();
                 dataModal = $(this).attr("data-modal");
                 $("#" + dataModal).css({"display":"block"});
                 
                 });
                 
                 $(".close-modal, .modal-sandbox").click(function(){
                 $(".modal").css({"display":"none"});
                 });
                 
         </script>
    
         <script>
         
                $(document).ready(function () {
                  $("#verify_btn").click(function(){
                     $("#second_div").css("display", "block");
                     $("#first").css("display", "none");
                    });
            
        
        
        
                            // entity name validation     
                                     $("#btn-2").click(function(){ 
                                     entityName = $("#doccc").val();
                                     
                                        // alert($("#doccc").val());
                                         if(entityName == ""){
                                             document.getElementById("doccc_alert").innerText = "!please enter entity name";
                                           
                                         }else if( isNaN(entityName) == false){
                                             document.getElementById("doccc_alert").innerText = "!please enter valid name.";
                                         
                                         }else if (entityName.length > 255){
                                              document.getElementById("doccc_alert").innerText = "!Only 255 characters allowed.";
                                         }else{
                                            document.getElementById("doccc_alert").innerText = "";
                                             $("#second_div").css("display", "none");
                                            $("#third").css("display", "block");
                                         }
                                
                                    });
                                
                             
            
            
            
                                    $("#select_farm").click(function(){
                                      const legalfrmtype = $("#legalForm").val();
                                       const legalcmpnytype = $("#companyTpye").val();
                                        if(legalfrmtype == '' && legalcmpnytype !='') {
                                       document.getElementById("legalvalidateErr").innerText = "!please select entity type";
                                         document.getElementById("companyvalidateErr").innerText = "";
                                       
                                        }else if(legalcmpnytype =='' && legalfrmtype !=''){
                                       document.getElementById("companyvalidateErr").innerText = "!please select company type";
                                        document.getElementById("legalvalidateErr").innerText = "";
                                        }else if(legalfrmtype =='' && legalcmpnytype ==''){
                                       
                                        document.getElementById("legalvalidateErr").innerText = "!please select entity type";
                                         document.getElementById("companyvalidateErr").innerText = "!please select company type";
                                       
                                        }else{
                                       document.getElementById("legalvalidateErr").innerText = "";
                                        document.getElementById("companyvalidateErr").innerText = "";
                                        $("#fourth").css("display", "block");
                                         $("#third").css("display", "none"); 
                                   }
                            
                                 
                                });
             //  end entity name validation  
            
            
                                $('.selectpicker').change(function () {
                                var selectedItem = $('.selectpicker1').val();
                                 var selectedItem2 = $('.selectpicker2').val();
                                // alert(selectedItem);
                                //  alert(selectedItem2);
                                        if(selectedItem !="" && selectedItem2 !=""){
                                            
                                          $("#select_farm").removeClass("inactive");    
                                        }
                                });
                });
       
       
      
               function select_country(){
                        var doc=$("#doccc").val();
                        var val = $('.niceCountryInputMenuDefaultText span').text();
                         if(doc!="" && val!=""){
                        $("#btn-2").removeClass("inactive");    
                    }
                }
       </script>
    
    
        <script>
                 $(document).ready(function () {
                        $(".niceCountryInputSelector").each(function(i,e){
                            new NiceCountryInput(e).init();
                    });
                });
             
             // initialyze selectpicker
                 $('select').selectpicker();
        
                $(".modal-trigger").click(function(e){
                    e.preventDefault();
                    dataModal = $(this).attr("data-modal");
                     $("#" + dataModal).css({"display":"block"});
              
                });
            
             $(".close-modal, .modal-sandbox").click(function(){
                 $(".modal").css({"display":"none"});
                });
            
    
            $(".selectYes").click(function(){
                document.getElementById("recentmail").value = ""; 
            //    $("#recentmail").val({"display":"block"});
              $("#idYes").css({"display":"block"});
              $("#ifNo").css({"display":"none"});
              $(".add1").addClass('spprt-svgicon-active');
              $(".add2").removeClass('spprt-svgicon-active');
              
            });
            
            
             $(".selectNo").click(function(){
              document.getElementById("accountkey").value = ""; 
              $("#ifNo").css({"display":"block"});
              $("#idYes").css({"display":"none"});
               $(".add1").removeClass('spprt-svgicon-active');
              $(".add2").addClass('spprt-svgicon-active');
              
            });

             $(".addressYes").click(function(){
                      $(".address_same").css({"display":"block"});
                      $(".address_nosame").css({"display":"none"});
                     
      
                });
                
                
             $(".addressNo").click(function(){
                      $(".address_nosame").css({"display":"block"});
                      $(".address_same").css({"display":"none"});
                      
              
            });




             $("#basic_information").click(function(){
                     $("#basic_information-div").css({"display":"block"});
                     $("#fifth").css({"display":"none"});
            
            });

             $("#Related-Parties").click(function(){
                     $("#Related-Parties-div").css({"display":"block"});
                     $("#fifth").css({"display":"none"});
                    
            });

            $('.accordion__header').click(function(e) {
            	 e.preventDefault();
                var currentIsActive = $(this).hasClass('is-active');
            	$(this).parent('.accordion').find('> *').removeClass('is-active');
                    	if(currentIsActive != 1) {
                    		$(this).addClass('is-active');
                    		$(this).next('.accordion__body').addClass('is-active');
                    	}
                });
     </script>
  
  
 <!-- JS form total form submission tima--->
        <script>
        $(document).ready(function(){
           
                $("#additinalBtn").click(function(){
               
                                const entityname  = document.getElementById('doccc').value;
                               // const cntryNmae = document.querySelector('.niceCountryInputMenuCountryFlag').nextElementSibling.innerText;
                              // const cntryNmae = document.getElementsByClassName('niceCountryInputMenuCountryFlag').getAttribute('data-flagiso');
                                const cntryNmae =  $(".niceCountryInputMenuCountryFlag").attr('data-flagiso');
                 	    	    const entityType = document.getElementById('legalForm').value;
                		        const companyType = document.getElementById('companyTpye').value;
                	    	    const accountKey = document.getElementById('accountkey').value;
                		        const recentmail = document.getElementById('recentmail').value;
                		       // const user_id = "<?php // echo $_SESSION['user_id'] ?>"; 
                		        const user_id = "<?php echo Auth::user()->id ?>";
                		        const token = document.getElementById('token').value;
		        
		         alert(token+"/"+user_id+"/"+entityname +"/"+ cntryNmae +"/"+ entityType +"/"+ entityType +"/"+ accountKey +"/"+ recentmail );
               // console.log(token+"/"+user_id+"/"+entityname +"/"+ cntryNmae +"/"+ entityType +"/"+ entityType +"/"+ accountKey +"/"+ recentmail );
                
                
                
            		        if(accountKey == "" && recentmail ==""){
            		            document.getElementById("add_support").innerText = "!please select atleast one";
            		              $('#verify_process').css({"display":"none"});
            		           
            		        }else{
		                         document.getElementById("add_support").innerText = "";
		           
                        		            	$.ajax({
                                    					type: "POST",
                                                        // url: '{{ url(app()->getLocale(),'api/register-business')}}',
                                                        url: "<?php echo url('api/register-business');  ?>",
                                                        data: {
                                                            'user_id' :  user_id,
                                                            'entity_name' : entityname,
                                                            'regstrd_cntry':cntryNmae,
                                                            'entity_type':entityType,
                                                            'company_type':companyType,
                                                            'keyAcount_manager':accountKey,
                                                            'most_recentMail':recentmail,
                                                             '_token': token,
                                                            
                                                            
                                                        },
                                    					success: function(data) {
                                                            triggerAlert('Congratulations! You have successfully addded primary details in Wealthmark account.', 'success');
                                                          
                                                             return data; 
                                                            
                                                        },
                                                        error: function(xhr, status, error) {
                                                           var erroJson = JSON.parse(xhr.responseText);
                                                           //alert(erroJson.error);
                                                        }
                                    					
                                    				});
		           
		                         }
             
                 });
        
                $('.checkAll').click(function(){
                   // alert();
                         $(this).siblings().prop('checked', this.checked);
                 
                });
                
        
                $('.checklist-inner').click(function(){
                   //  $('#verify_process').css({"display":"block"});
                });
               
     
                $("#btn_basic_detail").click(function(){
               
             
                        // const chklist  = document.getElementById('docs').value;
             
                           var selectedDocs=Array(); 
                           $("input:checkbox[type=checkbox]:checked").each(function(){
                               selectedDocs.push($(this).val());
                               
                           }); 
                           
                              // return ch_list;  
                              // const user_id = "<?php // echo $_SESSION['user_id'] ?>"; 
                                const user_id = "<?php echo Auth::user()->id ?>";
                               const busidocschklist = selectedDocs.toString();
                                const token = document.getElementById('token').value;
                                
                              //  alert(busidocschklist.length+"-"+busidocschklist);
                
                                alert(user_id+"/"+token+"/"+busidocschklist);
                  
                              if(busidocschklist == "entityDoc-,partiesDoc-"){
                                    document.getElementById("ifdoc").innerText = "!please select document";
                              }else{
                      
                                    document.getElementById("ifdoc").innerText = "";
                        
                                                $.ajax({
                            					type: "POST",
                                             
                                                url: "<?php echo url('api/prepareChecklist');  ?>",
                                                data: {
                                                    'user_id' :  user_id,
                                                    'checklist' : busidocschklist,
                                                    '_token': token,
                                             
                                                },
                            					success: function(data) {
                                                    triggerAlert('Congratulations! You have added prepared checklist in Wealthmark account.', 'success');
                                                     return data; 
                                                    
                                                },
                                                error: function(xhr, status, error) {
                                                   var erroJson = JSON.parse(xhr.responseText);
                                                   //alert(erroJson.error);
                                                }
                            					
                            				});
                  
                                     $(".modal").css({"display":"none"});
                                    $("#fourth").css({"display":"none"});
                                     $("#fifth").css({"display":"block"});
                                
                                }
                         });
     
        });    
     
        
        // to add basicinformation detail
        $("#accountInfo").click(function(){
            alert();
        });
          $("#entityAddrs").click(function(){
            alert();
        });
          $("#sourceDeclr").click(function(){
            alert();
        });
          $("#addtnlinfo").click(function(){
            alert();
        });
     
          </script>
        <script>
        // function for previous button
                    function moveOn2nd(){ 
                                    $("#second_div").css("display", "block");
                                    $("#third").css("display", "none");
                                     } 
                                     
                    function moveOn3rd(){ 
                                     $("#third").css("display", "block");
                                     $("#fourth").css("display", "none");
                                } 
         // end function for previous button   
        
      
               // to direct open basicnformation form
               function basicformdirect(){
                   alert();
                   $("#first").css({"display":"none"});
                 $("#fifth").css({"display":"block"});
               }
          // end to direct open basicnformation form    
       </script>
 
 
 <!-- End JS form total form submission--->
 <script>
      function onChangeCallback(ctr){
             $(".country_box").load("{{ url('api/filter/get_country_record') }}",{'country_code':ctr});
         }
 </script>
 
 
 
 
 
 
   </body>
</html>