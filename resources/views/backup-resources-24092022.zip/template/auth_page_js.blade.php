

        @include('template.copy_right_footer')
        <a href="#" class="chat-support"><span><i class="bi-chat-dots-fill"></i></span><label for="">Support</label></a>
        @include('template.country_language')
        <script src="{{ asset('public/assets/vendor/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
        <script src="{{ asset('public/assets/vendor/swiper/swiper-bundle.min.js') }}"></script>
        <script src="{{ asset('public/assets/js/alert.js') }}"></script>
        <script src="{{ asset('public/assets/js/dark-mode-switch.js') }}"></script>
        <script type="text/javascript" src="https://code.jquery.com/jquery-3.5.1.js"></script> 
        <script src="{{ asset('public/assets/js/niceCountryInput.js') }}"></script>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/16.0.8/js/intlTelInput-jquery.min.js"></script>