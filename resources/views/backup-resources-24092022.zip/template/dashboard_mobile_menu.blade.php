
    <span class="screen-darken"></span>
<header class="mobile-header d-lg-none  bg-white shadow-sm">
    <div class="container-fluid">
        <div class="row">
            <div class="col-2">
               <a href="{{ url('') }}" class="navbar-brand">
               <img src="{{ url('public/assets/img/wealthmark-logo.svg') }}" alt="" class="wealthmark-logo mt-2" >
               </a>
            </div>
            <div class="col-10 d-flex justify-content-between align-items-center">
                <span class="bi bi-grid-3x3-gap btn-mobile-nav-left " data-trigger="right_nav"></span>
                         <span class="bi bi-list btn-mobile-nav " data-trigger="navbar_main"></span>
                   
              
            </div>
        </div>
    </div>
</header>