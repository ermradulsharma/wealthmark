        <meta content="" name="description">
        <meta content="" name="keywords">
        <meta name="theme-color" content="#287aff">
        <link href="{{ asset('public/assets/img/wealthmark-logo.svg') }}" rel="icon">
        <link href="{{ asset('public/assets/img/wealthmark-logo.svg') }}" rel="apple-touch-icon">
        <link href="{{ asset('public/assets/vendor/bootstrap/css/bootstrap.min.css') }}" rel="stylesheet">
        <link href="{{ asset('public/assets/vendor/bootstrap-icons/bootstrap-icons.css') }}" rel="stylesheet">
        <link href="{{ asset('public/assets/vendor/swiper/swiper-bundle.min.css') }}" rel="stylesheet">
        <!------------------------main theme css------------------------------->
        <link href="{{ asset('public/assets/css/style_main.css') }}" rel="stylesheet">
      
        <!------------------------alert custom box css------------------------------->
        <link rel="stylesheet" href="{{ asset('public/assets/css/alert.css') }}">
        <link rel="stylesheet" href="{{ asset('public/assets/css/dark-mode.css') }}">
        <link rel="stylesheet" href="{{ asset('public/assets/css/niceCountryInput.css') }}">