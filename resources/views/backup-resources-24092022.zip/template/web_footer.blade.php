

 @include('template.footer') 
 <!--==================================================================================================================================================================================================================-->
<div class="main-sidebar" style="display:none">
   <div class="opensidebar">
      <div class="sidebar-header">
         <div class="col"><a href="{{ url('/') }}" class="navbar-brand">
            <img src="{{ asset('public/assets/img/wealthmark-logo.svg') }}" alt="" class="wealthmark-logo">
            </a>
         </div>
         <div class="col text-right"> <i class="close-sidebar bi bi-x"></i></div>
      </div>
      <div class="sidebar-body">
          <ul class="navbar-nav ">
                <li class="nav-item right-sidebar">
                     <a href="javascript:void(0)" class="sidebar-open-onclick"> <span class="bi bi-list"> </span> </a>   
                  </li>
                  <div class="show_if_login">
             <li class="nav-item dropdown left-header-custom-nav wallet">
                        <a class="nav-link dropdown-toggle" href="javascript:void(0);" data-bs-toggle="dropdown"> 
                              <span class="">   Wallet</span>
                        </a>
      <ul class="dropdown-menu dropdown-menu-end fade-down">
         <li>
            <a class="dropdown-item" href="{{ url( app()->getLocale(), 'wealthmark-futures-overview') }}">
               <div class="d-flex align-items-center">
                 <img src="{{ asset('public/assets/img/header-icons/derivatives/wealthmark-futures-overview.svg') }}" class="header-icons" />
                  <div class="d-block">
                     <span> Overview</span>
                   
                  </div>
                
               </div>
            </a>
         </li>
         <li>
            <a class="dropdown-item" href="{{ url(app()->getLocale()) }}/user/fiat-and-spot">
               <div class="d-flex align-items-center">
                   <img src="{{ asset('public/assets/img/header-icons/derivatives/responsible-trading.svg') }}" class="header-icons" />
                  <div class="d-block">
                     <span> Fiat and Spot</span>
                     <p class="mb-0">Deposit & Widtdraw</p>
                  </div>
                </div>
            </a>
         </li>
         <li>
            <a class="dropdown-item" href="{{ url(app()->getLocale()) }}/user/funding">
               <div class="d-flex align-items-center">
                <img src="{{ asset('public/assets/img/header-icons/derivatives/coin-m-futures.svg') }}" class="header-icons" />
                  <div class="d-block">
                     <span> Funding</span>
                    </div>
                 </div>
            </a>
         </li>
         <li>
            <a class="dropdown-item" href="{{ url(app()->getLocale()) }}/user/futures">
               <div class="d-flex align-items-center">
                  <img src="{{ asset('public/assets/img/header-icons/derivatives/vanilla-option.svg') }}" class="header-icons" />
                  <div class="d-block">
                     <span> Futures </span>
                    
                  </div>
              
               </div>
            </a>
         </li>
         <li>
            <a class="dropdown-item" href="{{ url(app()->getLocale()) }}/user/earn">
               <div class="d-flex align-items-center">
                    <img src="{{ asset('public/assets/img/header-icons/derivatives/leveraged-tokens.svg') }}" class="header-icons" />
                  <div class="d-block">
                     <span> Earn</span>
                   
                  </div>
               
               </div>
            </a>
         </li>
        </ul>
   </li>
                <li class="nav-item dropdown left-header-custom-nav order">
      <a class="nav-link dropdown-toggle" href="javascript:void(0);" data-bs-toggle="dropdown"> 
    
      <span>   Order</span>
      </a>
      <ul class="dropdown-menu dropdown-menu-end fade-down">
         <li>
            <a class="dropdown-item" href="#">
               <div class="d-flex align-items-center">
                  <img src="{{ asset('public/assets/img/header-icons/derivatives/wealthmark-futures-overview.svg') }}" class="header-icons" />
                  <div class="d-block">
                     <span> Spot Order</span>
                   
                  </div>
                
               </div>
            </a>
         </li>
         <li>
            <a class="dropdown-item" href="#">
               <div class="d-flex align-items-center">
                  <img src="{{ asset('public/assets/img/header-icons/derivatives/responsible-trading.svg') }}" class="header-icons" />
                  <div class="d-block">
                     <span> Margin Order</span>
                     <p class="mb-0">Deposit & Widtdraw</p>
                  </div>
                 
               </div>
            </a>
         </li>
         <li>
            <a class="dropdown-item" href="#">
               <div class="d-flex align-items-center">
                  <img src="{{ asset('public/assets/img/header-icons/derivatives/coin-m-futures.svg') }}" class="header-icons" />
                  <div class="d-block">
                     <span> P2P Order</span>
                    
                  </div>
                 
               </div>
            </a>
         </li>
         <li>
            <a class="dropdown-item" href="#">
               <div class="d-flex align-items-center">
                  <img src="{{ asset('public/assets/img/header-icons/derivatives/vanilla-option.svg') }}" class="header-icons"/>
                  <div class="d-block">
                     <span> Earn History </span>
                    
                  </div>
                
               </div>
            </a>
         </li>
         <li>
            <a class="dropdown-item" href="#">
               <div class="d-flex align-items-center">
                  <img src="{{ asset('public/assets/img/header-icons/derivatives/leveraged-tokens.svg') }}" class="header-icons" />
                  <div class="d-block">
                     <span> Buy Crypto History</span>
                   
                  </div>
               
               </div>
            </a>
         </li>
       
         
         
      </ul>
   </li>
                <li class="nav-item dropdown left-header-custom-nav max-width-300 user">
      <a class="nav-link dropdown-toggle" href="javascript:void(0);" data-bs-toggle="dropdown"> 
     
      <span class="">   <i class="bi bi-person-circle"></i></span>
      </a>
      <ul class="dropdown-menu dropdown-menu-end fade-down">
          <li class="">
            <a class="dropdown-item" href="#">
                <div class="phone">
                     <i class="bi bi-tablet-fill me-2"></i> 99XXXXXX58
                </div>
                </a>
                </li>
           <li class="py-0-important">
            <a class="dropdown-item no-hover" href="#">
              
                
               <div class="verify-box-dropdown">
                                        <span class="user-type">
                                             <i class="bi bi-wifi me-2"></i> Regular User
                                        </span>
                                        <span class="verify-status">
                                             <i class="bi bi-wifi me-2"></i> Unverified
                                        </span>
                                    </div>
            </a>
         </li>
          
         <li>
            <a class="dropdown-item" href="{{ url(app()->getLocale()) }}/user/dashboard">
               <div class="d-flex align-items-center">
                  
                  <i class="bi bi-grid header-icons"></i>
                  <div class="d-block">
                     <span> Dashboard</span>
                   
                  </div>
                
               </div>
            </a>
         </li>
         <li>
            <a class="dropdown-item" href="{{ url(app()->getLocale()) }}/user/security">
               <div class="d-flex align-items-center">
                   <i class="bi bi-shield-check header-icons"></i>
                  <div class="d-block">
                     <span> Security</span>
                    
                  </div>
                
               </div>
            </a>
         </li>
         <li>
            <a class="dropdown-item" href="{{ url(app()->getLocale()) }}/user/identification">
               <div class="d-flex align-items-center">
                   <i class="bi bi-fingerprint header-icons"></i>
                  <div class="d-block">
                     <span> Identification</span>
                    
                  </div>
               
               </div>
            </a>
         </li>
         <li>
            <a class="dropdown-item" href="{{ url(app()->getLocale()) }}/user/payment">
               <div class="d-flex align-items-center">
                   <i class="bi bi-coin header-icons"></i>
                  <div class="d-block">
                     <span> Payment </span>
                    
                  </div>
                
               </div>
            </a>
         </li>
         <li>
            <a class="dropdown-item" href="{{ url(app()->getLocale()) }}/user/referral">
               <div class="d-flex align-items-center">
                  <i class="bi bi-person-plus header-icons"></i>
                  <div class="d-block">
                     <span> Refferal</span>
                   
                  </div>
                
               </div>
            </a>
         </li>
         <li>
            <a class="dropdown-item" href="{{ url(app()->getLocale()) }}/user/reward-center">
               <div class="d-flex align-items-center">
                  <i class="bi bi-cash-stack header-icons"></i>
                  <div class="d-block">
                     <span> Reward Center</span>
                    
                  </div>
                 
               </div>
            </a>
         </li>
         
          <li>
            <a class="dropdown-item" href="{{ url(app()->getLocale()) }}/user/task-center">
               <div class="d-flex align-items-center">
                  <i class="bi bi-cash-stack header-icons"></i>
                  <div class="d-block">
                     <span> Task Center</span>
                    
                  </div>
                 
               </div>
            </a>
         </li>
         
          <li>
            <a class="dropdown-item" href="{{ url(app()->getLocale()) }}/user/api-management">
               <div class="d-flex align-items-center">
                  <i class="bi bi-person header-icons"></i>
                  <div class="d-block">
                     <span> API Management</span>
                   
                  </div>
                
               </div>
            </a>
         </li>
          
          <li>
            <a class="dropdown-item" href="{{ url(app()->getLocale()) }}/user/settings">
               <div class="d-flex align-items-center">
                  <i class="bi bi-sliders header-icons"></i>
                  <div class="d-block">
                     <span> Settings </span>
                   
                  </div>
                
               </div>
            </a>
         </li>
         
           <li style="border-top:2px solid whitesmoke;">
            <a class="dropdown-item" href="{{ url(app()->getLocale()) }}/user/settings">
               <div class="d-flex align-items-center">
                  <i class="bi bi-box-arrow-right header-icons"></i>
                  <div class="d-block">
                     <span> Log Out </span>
                   
                  </div>
                
               </div>
            </a>
         </li>
         
         
         
         
      </ul>
   </li>
                <li class="nav-item dropdown left-header-custom-nav notification">
      <a class="nav-link dropdown-toggle" href="javascript:void(0);" data-bs-toggle="dropdown"> 
     
      <span class="">   <i class="bi bi-bell-fill"></i></span>
      </a>
      <ul class="dropdown-menu dropdown-menu-end fade-down">
         <li class="max-width-450">
            
               <div class="notification-first d-flex align-items-center">
                     <div class="notificationinner-left d-flex align-items-center">
                         <span> <i class="bi bi-1-circle header-icons"></i> pending notifications </span>
                         <span class="clear-all"><a href="#">clear all</a> </span>
                     </div>
                     <div class="notificationinner-right">
                         <a href="" class="view-all"> View All <i class="bi bi-arrow-right ml-3"></i></a>
                     </div>
                   </div>
                
           
         </li>
         <li>
            <a class="dropdown-item no-hover" href="#">
               <div class="d-flex align-items-center">
                  <img src="{{ asset('public/assets/img/header-icons/derivatives/responsible-trading.svg') }}" class="header-icons" alt="Responsible Trading" />
                  <div class="d-block">
                     <span> Fiat and Spot</span>
                     <p class="mb-0">Deposit & Widtdraw</p>
                  </div>
                </div>
            </a>
         </li>
      </ul>
   </li>
        </div>
        <div class="d-flex hide_if_login">
            <li class="dashboard-hide nav-item d-none d-sm-block"><a class="btn btn-blue  shadow " href="{{ url( app()->getLocale(), 'login') }}"><i class="bx bx-log-in-circle"></i> Login</a></li>
                <li class="dashboard-hide nav-item d-none d-sm-block"><a class="btn btn-yellow shadow" href="{{ url( app()->getLocale(), 'register') }}"><i class="bx bx-log-out-circle"></i> Register</a></li>
        </div>
        
        <div class="show-min-1300">
                <li class="nav-item">
                    <a class="nav-link" href="javascript:void(0);" data-bs-toggle="modal" data-bs-target="#currLangModal">
                     <span class="nav-img d-lg-none"><img src="{{ asset('public/assets/img/mob-nav-icon/english.svg') }}" class="img-responsive"> </span>
                     <span class="d-inline-block ">   English</span>
                     </a>
                  </li>
             <li class="nav-item dropdown">
                     <a class="nav-link dropdown-toggle" href="javascript:void(0);" data-bs-toggle="dropdown">
                     <span class="nav-img d-lg-none"><img src="{{ asset('public/assets/img/mob-nav-icon/download.svg') }}" class="img-responsive"> </span>
                     <span class="d-inline-block ">   Download</span> </a>
                     <ul class="dropdown-menu dropdown-menu-end fade-down">
                        <li> <a  href="javascript:void(0);">
                           <img src="{{ asset('public/assets/img/qr/qrcode_wealthmark.io.png') }}" class="header-download" alt="QR Code" />
                           </a>
                        </li>
                     </ul>
                  </li>
                <i class="nav-devider d-none d-sm-block"></i>
                <li class="nav-item"><a class="nav-link ps-0" href="javascript:void(0);" data-bs-toggle="modal" data-bs-target="#currLangModal">
                     <span class="nav-img d-lg-none"><img src="{{ asset('public/assets/img/mob-nav-icon/inr.svg') }}" class="img-responsive"> </span>
                     <span class="d-inline-block ">   INR</span>
                     </a>
                  </li>
                <i class="nav-devider d-none d-sm-block"></i>
                <li class="nav-item theme-change"><a class="nav-link ps-0" href="javascript:void(0);"><i class="bi-moon-stars-fill"></i></a></li>
              
        </div>
       
       
        </ul>
      </div>
       <div class="sidebar-footer">
         <ul class="social-midia-icon">
            <li>
               <a href="javascript:void(0)"> <i class="bi bi-facebook"></i> </a>
               <a href="javascript:void(0)"> <i class="bi bi-facebook"></i> </a>                
            </li>
            <li>
               <a href="javascript:void(0)"> <i class="bi bi-twitter"></i> </a> 
               <a href="javascript:void(0)"> <i class="bi bi-twitter"></i> </a> 
            </li>
            <li>
               <a href="javascript:void(0)"> <i class="bi bi-youtube"></i> </a> 
               <a href="javascript:void(0)"> <i class="bi bi-youtube"></i> </a> 
            </li>
         </ul>
      </div>
   </div>
</div>
<a href="#" class="chat-support"><span><i class="bi-chat-dots-fill"></i></span><label for="">Support</label></a>
<script src="{{ asset('public/assets/vendor/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
<script src="{{ asset('public/assets/vendor/glightbox/js/glightbox.min.js') }}"></script>
<script src="{{ asset('public/assets/vendor/swiper/swiper-bundle.min.js') }}"></script>
<script type="text/javascript" src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="{{ asset('public/assets/js/cookie_consent.js') }}"></script>
 

<script>
      $('.tabs').on('click', function(){
      $('.tabs').removeClass('active');
      $(this).addClass('active');
    });
  </script>
<script>
    $(document).ready(function(){
        $("#customizeProfile").modal('show');
        $("#securityVerification").modal('show');
    });
</script>
<script>
  var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
  return new bootstrap.Tooltip(tooltipTriggerEl)
})
</script>
<script type="text/javascript">

	function darken_screen(yesno){
		if( yesno == true ){
			document.querySelector('.screen-darken').classList.add('active');
		}
		else if(yesno == false){
			document.querySelector('.screen-darken').classList.remove('active');
		}
	}
	
	function close_offcanvas(){
		darken_screen(false);
		document.querySelector('.mobile-offcanvas.show').classList.remove('show');
		document.body.classList.remove('offcanvas-active');
	}

	function show_offcanvas(offcanvas_id){
		darken_screen(true);
		document.getElementById(offcanvas_id).classList.add('show');
		document.body.classList.add('offcanvas-active');
	}

	document.addEventListener("DOMContentLoaded", function(){
		document.querySelectorAll('[data-trigger]').forEach(function(everyelement){
			
			let offcanvas_id = everyelement.getAttribute('data-trigger');
			
			everyelement.addEventListener('click', function (e) {
				e.preventDefault();
	        	show_offcanvas(offcanvas_id);
	  			
			});
		});

		document.querySelectorAll('.btn-close').forEach(function(everybutton){
			
			everybutton.addEventListener('click', function (e) {
				e.preventDefault();
	        	close_offcanvas();
	  		});
		});

		document.querySelector('.screen-darken').addEventListener('click', function(event){
			close_offcanvas();
		});
		
    }); 
	// DOMContentLoaded  end
</script>
<script>
        $(window).on('load', function () {
            $('#imp_message_Modal').modal('show');
        });
        
        $(document).ready(function () {    
            $('#set_country').click(function () {
                    var country_code = $('#country_code').val();
                    $.ajax({
                    type: "GET",
                    url: '{{ url(app()->getLocale()."/set_country") }}',
                    data: {'country': country_code},
                    success: function(data) {
                        setTimeout(function(){
                            window.location.href = '{{ url()->current() }}';
                        });
                    }
                });
            });
        });
    </script>
    

 <script>
        // $(".close-sidebar").click(function(){
        //     $(".main-sidebar").removeClass("main-sidebar-active");
        //     $("#sidebar").css("display" , "none");
        // });
   
        // $(".sidebar-open-onclick").click(function(){
        //     $(".main-sidebar").addClass("main-sidebar-active");
        //     $("#sidebar").css("display" , "block");
        // });
        
        $(".close-sidebar").click(function(){
                $(".main-sidebar").hide();
        });
   
   
        $(".sidebar-open-onclick").click(function(){
                 $(".main-sidebar").css("display" , "flex");
        });
      
   </script>
   