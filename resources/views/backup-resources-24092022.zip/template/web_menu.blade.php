<header id="header" class="border_new header-bg-top">
   <div class="container-fluid  second_border_new">

         <div class="d-flex p-0">
           
            <a href="{{ url('/') }}" class="navbar-brand d-none d-lg-block">
            <img src="{{ asset('public/assets/img/wealthmark-logo.svg') }}" alt="" class="wealthmark-logo">
            </a>
            <!-- <a class="navbar-brand" href="javascript:void(0);">Brand</a> -->
                 
               @include('template.main_navigation')
           
         
         </div>
     
   </div>
</header>