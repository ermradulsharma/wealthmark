 <!-- ======= Sidebar ======= -->


     <aside id="sidebar" class="sidebar scrollbar-style">
        <ul class="sidebar-nav" id="sidebar-nav">
           <!--<li class="nav-item text-end">-->
           <!--     <a class="close-main-sidebar close-sidebar" href="javascript:void(0)">-->
           <!--     <i class="bi bi-x" style="background: whitesmoke;"></i>-->
           <!--     </a>-->
           <!-- </li>-->
           
           
            <li class="nav-item">
                <a class="nav-link collapsed" href="{{ url(app()->getLocale()) }}/user/dashboard">
                <i class="bi bi-grid"></i>
                <span>Dashboard</span>
                </a>
            </li>
            
            <!-- Dashboard -->
            <li class="nav-heading">User</li>
            <li class="nav-item">
                <a class="nav-link collapsed" href="{{ url(app()->getLocale()) }}/user/security">
                <i class="bi bi-shield-check"></i>
                <span>Security</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link collapsed" href="{{ url(app()->getLocale()) }}/user/identification">
                <i class="bi bi-fingerprint"></i>
                <span>Identification</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link collapsed" href="{{ url(app()->getLocale()) }}/user/payment">
                <i class="bi bi-coin"></i>
                <span>Payment</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link collapsed" href="{{ url(app()->getLocale()) }}/user/referral">
                <i class="bi bi-person-plus"></i>
                <span>Refferal</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link collapsed" href="{{ url(app()->getLocale()) }}/user/reward-center">
                <i class="bi bi-cash-stack"></i>
                <span>Reward Center</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link collapsed" href="{{ url(app()->getLocale()) }}/user/task-center">
                <i class="bi bi-cash-stack"></i>
                <span>Task Center</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link collapsed" href="{{ url(app()->getLocale()) }}/user/api-management">
                <i class="bi bi-person"></i>
                <span>API Management</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link collapsed" href="{{ url(app()->getLocale()) }}/user/settings">
                <i class="bi bi-sliders"></i>
                <span>Settings</span>
                </a>
            </li>
            
            <!-- Wallet -->
            <!--<li class="nav-heading">Wallet</li>-->
            <!--<li class="nav-item">-->
            <!--    <a class="nav-link collapsed" href="{{ url(app()->getLocale()) }}/user/overview">-->
            <!--    <i class="bi bi-shield-check"></i>-->
            <!--    <span>Overview</span>-->
            <!--    </a>-->
            <!--</li>-->
            <!--<li class="nav-item">-->
            <!--    <a class="nav-link collapsed" href="{{ url(app()->getLocale()) }}/user/fiat-and-spot">-->
            <!--    <i class="bi bi-shield-check"></i>-->
            <!--    <span>Fiat and Spot</span>-->
            <!--    </a>-->
            <!--</li>-->
            <!--<li class="nav-item">-->
            <!--    <a class="nav-link collapsed" href="{{ url(app()->getLocale()) }}/user/funding">-->
            <!--    <i class="bi bi-shield-check"></i>-->
            <!--    <span>Funding</span>-->
            <!--    </a>-->
            <!--</li>-->
            <!--<li class="nav-item">-->
            <!--    <a class="nav-link collapsed" href="{{ url(app()->getLocale()) }}/user/futures">-->
            <!--    <i class="bi bi-shield-check"></i>-->
            <!--    <span>Futures</span>-->
            <!--    </a>-->
            <!--</li>-->
            <!--<li class="nav-item">-->
            <!--    <a class="nav-link collapsed" href="{{ url(app()->getLocale()) }}/user/earn">-->
            <!--    <i class="bi bi-shield-check"></i>-->
            <!--    <span>Earn</span>-->
            <!--    </a>-->
            <!--</li>-->
            <!--<li class="nav-item">-->
            <!--    <a class="nav-link collapsed" href="#">-->
            <!--    <i class="bi bi-shield-check"></i>-->
            <!--    <span>Jex</span>-->
            <!--    </a>-->
            <!--</li>-->
            <!--<li class="nav-item">-->
            <!--    <a class="nav-link collapsed" href="#">-->
            <!--    <i class="bi bi-shield-check"></i>-->
            <!--    <span>WazirX</span>-->
            <!--    </a>-->
            <!--</li>-->
            <!--<li class="nav-item">-->
            <!--    <a class="nav-link collapsed" href="#">-->
            <!--    <i class="bi bi-shield-check"></i>-->
            <!--    <span>WealthMark TR</span>-->
            <!--    </a>-->
            <!--</li>-->
            <!--<li class="nav-item">-->
            <!--    <a class="nav-link collapsed" href="#">-->
            <!--    <i class="bi bi-shield-check"></i>-->
            <!--    <span>Tokocrypto</span>-->
            <!--    </a>-->
            <!--</li>-->
            <!--<li class="nav-item">-->
            <!--    <a class="nav-link collapsed" href="#">-->
            <!--    <i class="bi bi-shield-check"></i>-->
            <!--    <span>Pexpay</span>-->
            <!--    </a>-->
            <!--</li>-->
             <!-- Orders -->
            <!--<li class="nav-heading">Orders</li>-->
            <!--<li class="nav-item">-->
            <!--    <a class="nav-link collapsed" data-bs-target="#forms-nav" data-bs-toggle="collapse" href="#">-->
            <!--    <i class="bi bi-journal-text"></i><span>Spot Order</span><i class="bi bi-chevron-down ms-auto"></i>-->
            <!--    </a>-->
            <!--    <ul id="forms-nav" class="nav-content collapse">-->
            <!--    <li>-->
            <!--        <a href="#">-->
            <!--        <i class="bi bi-circle"></i><span>Open Orders</span>-->
            <!--        </a>-->
            <!--    </li>-->
            <!--    <li>-->
            <!--        <a href="#">-->
            <!--        <i class="bi bi-circle"></i><span>Order History</span>-->
            <!--        </a>-->
            <!--    </li>-->
            <!--    <li>-->
            <!--        <a href="#">-->
            <!--        <i class="bi bi-circle"></i><span>Trade History</span>-->
            <!--        </a>-->
            <!--    </li>-->
    
            <!--    </ul>-->
            <!--</li>-->
            <!-- End Forms Nav -->
            
        </ul>
    </aside>
