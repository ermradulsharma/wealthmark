  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="" name="description">
  <meta content="" name="keywords">
  <meta name="theme-color" content="#287aff">
  <link href="{{ asset('public/assets/img/wealthmark-logo.svg'); }}" rel="icon">
  <link href="{{ asset('public/assets/img/wealthmark-logo.svg'); }}" rel="apple-touch-icon">
  <!--=================  links here =======================-->
  <link href="{{ asset('public/assets/vendor/bootstrap/css/bootstrap.min.css'); }}" rel="stylesheet">
  <link href="{{ asset('public/assets/vendor/bootstrap-icons/bootstrap-icons.css'); }}" rel="stylesheet">
  <link href="{{ asset('public/assets/vendor/boxicons/css/boxicons.min.css'); }}" rel="stylesheet">
  <link href="{{ asset('public/assets/vendor/swiper/swiper-bundle.min.css'); }}" rel="stylesheet">
  <!--<link href="{{ asset('public/assets/vendor/glightbox/css/glightbox.min.css'); }}" rel="stylesheet">-->
  
  <!--<link href="{{ asset('public/assets/css/niceCountryInput.css'); }}" rel="stylesheet">-->
  <!--<link href="{{ asset('public/assets/css/style.css') }}" rel="stylesheet">-->
  <!--<link rel="stylesheet" href="{{ asset('public/assets/wealthmark_new/css/style.css'); }}">-->
 
  
    <link href="{{ asset('public/assets/css/style_main.css') }}" rel="stylesheet">
  <link href="{{ asset('public/assets/css/helper.css') }}" rel="stylesheet">
  <link rel="stylesheet" href="{{ asset('public/assets/wealthmark_new/css/style_index.css') }}">
   <link rel="stylesheet" href="{{ asset('public/assets/css/dark-mode.css'); }}">
  
  
 <!--============ not in use ==================-->
  <!--<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/16.0.8/css/intlTelInput.css" />-->
  <!--<link rel="stylesheet" href="https://demo.voidcoders.com/htmldemo/fitgear/main-files/assets/css/animate.css">-->
  <!--<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css">-->
  <!--<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">-->
  