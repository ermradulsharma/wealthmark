<style>
   #right_nav{
   justify-content: end !important;
   }
   .show_if_login{
   display:flex; 
   align-items: center;
   }
   .right-sidebar{
   display:none;
   }
   .show-min-1300{
   display:flex;
   }
   @media screen and (max-width: 1300px) {
   .right-sidebar {
   display:block !important;
   }
   .show-min-1300{
   display:none ;
   }
   .sidebar-body .show-min-1300{
   display:block !important;
   }
   .sidebar-body   .right-sidebar{
   display:none !important;
   }
   }
   @media screen and (max-width: 1150px) {
   .wallet{display:none;}
   .order{display:none;}
   .sidebar-body  .wallet{display:block !important;}
   .sidebar-body  .order{display:block !important;}
   }
   .sidebar-body  .wallet{display:none ;}
   .sidebar-body  .order{display:none ;}
   .sidebar-body .user {display:none ;}
   .sidebar-body .notification{display:none ;}
   .sidebar-body  .show_if_login{
   flex-direction: column;
   align-items: flex-start;
   }
   @media screen and (max-width: 992px){   
   .mobile-offcanvas .show_if_login{
   flex-direction: column;
   }
   .mobile-offcanvas .show_if_login .wallet{
   display:block;
   }
   .mobile-offcanvas .show_if_login .order{
   display:block;  
   }
   .mobile-offcanvas  .show-min-1300{
   display:block;
   }
   .mobile-offcanvas .show_if_login{
   align-items: flex-start;
   }
   .mobile-offcanvas .theme-change{
   display:none;
   }
   .mobile-offcanvas   .right-sidebar{
   display:none !important;
   }
   .mobile-offcanvas .theme-change{
   display:none;
   }
   }
   .dropdown {
   width:100%
   }
   .sidebar-body .navbar-nav .nav-item a {
   padding: 1rem !important;
   border-bottom: 1px solid whitesmoke;
   }
   .sidebar-body .dropdown-toggle::after {
   float: right;
   position: relative;
   top: 8px;
   }
   .sidebar-body .hide_if_login{
   display:none !important;
   }
</style>
<div class="main-nav-bar">
   <nav id="navbar_main" class="mobile-offcanvas navbar navbar-expand-lg py-0">
      <div class="offcanvas-header justify-content-between border-bottom">
         <a href="{{ url('/') }}" class="navbar-brand" id="find-2"> 
         <img src="{{ asset('public/assets/img/wealthmark-logo.svg') }}" alt="" class="wealthmark-logo">
         </a>
         <!--<div class="nav-mob-btn">-->
         <!--   <a class="btn btn-lg btn-blue" href="{{ url( app()->getLocale(), 'login') }}" ><i class="bx bx-log-in-circle"></i> Login</a>-->
         <!--   <a class="btn  btn-lg btn-yellow" href="{{ url( app()->getLocale(), 'register') }}"><i class="bx bx-log-in-circle"></i> Register</a>  -->
         <!--</div>-->
         <span class="btn-close m-0 p-0"></span>
         <!-- <button class="btn-close float-end m-0 p-0"></button> -->
      </div>
      <ul class="navbar-nav">
         <li class="nav-item dropdown has-megamenu">
            <a class="nav-link dropdown-toggle  icon-link" href="javascript:void(0);" data-bs-toggle="dropdown"> 
            <i class='bi bi-grid-3x3-gap d-none d-lg-inline-block' ></i>
            <span class="nav-img d-lg-none">
            <img src="{{ asset('public/assets/img/mob-nav-icon/product.svg') }}" class="img-responsive"> </span> <span class="d-inline-block d-lg-none">  Products
            </span>  
            </a>
            <div class="dropdown-menu megamenu " role="menu">
               <div class="row g-0">
                  <div class="col-lg-4 col-md-6 col-12">
                     <div class="col-megamenu">
                        <ul class="list-unstyled">
                           <li>
                              <a href="{{ url( app()->getLocale(), 'exchange') }}">
                                 <div class="d-flex align-items-center">
                                    <img src="{{ asset('public/assets/img/header-icons/mega-option/exchange.svg') }}" class="header-icons" alt="Exchange" />
                                    <div class="d-block">
                                       <span> Exchange</span>
                                       <p class="mb-0">Blockchain and crypto asset exchange</p>
                                    </div>
                                    <i class="bi bi-arrow-right dropdown-icon-effect ms-3"></i>
                                 </div>
                              </a>
                           </li>
                           <li>
                              <a href="{{ url( app()->getLocale(), 'academy') }}">
                                 <div class="d-flex align-items-center">
                                    <img src="{{ asset('public/assets/img/header-icons/mega-option/academy.svg') }}" class="header-icons" alt="Academy" />
                                    <div class="d-block">
                                       <span> Academy</span>
                                       <p class="mb-0">Blockchain and crypto education</p>
                                    </div>
                                    <i class="bi bi-arrow-right dropdown-icon-effect ms-3"></i>
                                 </div>
                              </a>
                           </li>
                           <li>
                              <a href="{{ url( app()->getLocale(), 'broker') }}">
                                 <div class="d-flex align-items-center">
                                    <img src="{{ asset('public/assets/img/header-icons/mega-option/broker.svg') }}" class="header-icons" alt="Broker" />
                                    <div class="d-block">
                                       <span> Broker</span>
                                       <p class="mb-0">Some Description About the Title</p>
                                    </div>
                                    <i class="bi bi-arrow-right dropdown-icon-effect ms-3"></i>
                                 </div>
                              </a>
                           </li>
                           <li>
                              <a href="{{ url( app()->getLocale(), 'vip-institutional-services') }}">
                                 <div class="d-flex align-items-center">
                                    <img src="{{ asset('public/assets/img/header-icons/mega-option/institutional-and-vip.svg') }}" class="header-icons" alt="Institutional Services" />
                                    <div class="d-block">
                                       <span> Institutional Services</span>
                                       <p class="mb-0">Enterprise exchange solution</p>
                                    </div>
                                    <i class="bi bi-arrow-right dropdown-icon-effect ms-3"></i>
                                 </div>
                              </a>
                           </li>
                        </ul>
                     </div>
                  </div>
                  <div class="col-lg-4 col-md-6 col-12">
                     <div class="col-megamenu">
                        <ul class="list-unstyled">
                           <li>
                              <a href="{{ url( app()->getLocale(), 'charity') }}">
                                 <div class="d-flex align-items-center">
                                    <img src="{{ asset('public/assets/img/header-icons/mega-option/charity.svg') }}" class="header-icons" alt="Charity" />
                                    <div class="d-block">
                                       <span> Charity</span>
                                       <p class="mb-0">Some Description About the Title</p>
                                    </div>
                                    <i class="bi bi-arrow-right dropdown-icon-effect ms-3"></i>
                                 </div>
                              </a>
                           </li>
                           <li>
                              <a href="{{ url( app()->getLocale(), 'cloud') }}">
                                 <div class="d-flex align-items-center">
                                    <img src="{{ asset('public/assets/img/header-icons/mega-option/cloud.svg') }}" class="header-icons" alt="Cloud" />
                                    <div class="d-block">
                                       <span> Cloud</span>
                                       <p class="mb-0">Some Description About the Title</p>
                                    </div>
                                    <i class="bi bi-arrow-right dropdown-icon-effect ms-3"></i>
                                 </div>
                              </a>
                           </li>
                           <li>
                              <a href="{{ url( app()->getLocale(), 'dex') }}">
                                 <div class="d-flex align-items-center">
                                    <img src="{{ asset('public/assets/img/header-icons/mega-option/dex.svg') }}" class="header-icons" alt="Dex" />
                                    <div class="d-block">
                                       <span> Dex</span>
                                       <p class="mb-0">Some Description About the Title</p>
                                    </div>
                                    <i class="bi bi-arrow-right dropdown-icon-effect ms-3"></i>
                                 </div>
                              </a>
                           </li>
                           <li>
                              <a href="{{ url( app()->getLocale(), 'labs') }}">
                                 <div class="d-flex align-items-center">
                                    <img src="{{ asset('public/assets/img/header-icons/mega-option/lab.svg') }}" class="header-icons" alt="Labs" />
                                    <div class="d-block">
                                       <span> Labs</span>
                                       <p class="mb-0">Some Description About the Title</p>
                                    </div>
                                    <i class="bi bi-arrow-right dropdown-icon-effect ms-3"></i>
                                 </div>
                              </a>
                           </li>
                        </ul>
                     </div>
                  </div>
                  <div class="col-lg-4 col-md-6 col-12">
                     <div class="col-megamenu">
                        <ul class="list-unstyled">
                           <li>
                              <a href="{{ url( app()->getLocale(), 'launchpad') }}">
                                 <div class="d-flex align-items-center">
                                    <img src="{{ asset('public/assets/img/header-icons/mega-option/launchpad.svg') }}" class="header-icons" alt="Launchpad" />
                                    <div class="d-block">
                                       <span> Launchpad</span>
                                       <p class="mb-0">Token Launchpad</p>
                                    </div>
                                    <i class="bi bi-arrow-right dropdown-icon-effect ms-3"></i>
                                 </div>
                              </a>
                           </li>
                           <li>
                              <a href="{{ url( app()->getLocale(), 'research') }}">
                                 <div class="d-flex align-items-center">
                                    <img src="{{ asset('public/assets/img/header-icons/mega-option/research.svg') }}" class="header-icons" alt="Research" />
                                    <div class="d-block">
                                       <span> Research</span>
                                       <p class="mb-0">Some Description About the Title</p>
                                    </div>
                                    <i class="bi bi-arrow-right dropdown-icon-effect ms-3"></i>
                                 </div>
                              </a>
                           </li>
                           <li>
                              <a href="{{ url( app()->getLocale(), 'trust-wallet') }}">
                                 <div class="d-flex align-items-center">
                                    <img src="{{ asset('public/assets/img/header-icons/mega-option/trust-wallet.svg') }}" class="header-icons" alt="Trust Wallet" />
                                    <div class="d-block">
                                       <span> Trust Wallet</span>
                                       <p class="mb-0">Some Description About the Title</p>
                                    </div>
                                    <i class="bi bi-arrow-right dropdown-icon-effect ms-3"></i>
                                 </div>
                              </a>
                           </li>
                           <li>
                              <a href="{{ url( app()->getLocale(), 'gift-card') }}">
                                 <div class="d-flex align-items-center">
                                    <img src="{{ asset('public/assets/img/header-icons/mega-option/gift-card.svg') }}" class="header-icons" alt="Gift Card" />
                                    <div class="d-block">
                                       <span> Gift Card</span>
                                       <p class="mb-0">Digital crypto gift card</p>
                                    </div>
                                    <i class="bi bi-arrow-right dropdown-icon-effect ms-3"></i>
                                 </div>
                              </a>
                           </li>
                        </ul>
                     </div>
                  </div>
               </div>
               <!-- end row --> 
            </div>
            <!-- dropdown-mega-menu. -->
         </li>
         <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="javascript:void(0);" data-bs-toggle="dropdown">
            <span class="nav-img d-lg-none"><img src="{{ asset('public/assets/img/mob-nav-icon/buy-crypto.svg') }}" class="img-responsive"> </span>
            <span class="d-inline-block ">  Buy&nbsp;Crypto</span> </a>
            <ul class="dropdown-menu dropdown-menu-end fade-down">
               <li>
                  <a class="dropdown-item" href="{{ url( app()->getLocale(), 'card-deposite') }}">
                     <div class="d-flex align-items-center">
                        <img src="{{ asset('public/assets/img/header-icons/buy-crypto/card-deposit.svg') }}" class="header-icons" alt="Card Deposit" />
                        <div class="d-block">
                           <span> Card Deposit</span>
                           <p class="mb-0">Some Description About the Title</p>
                        </div>
                        <i class="bi bi-arrow-right dropdown-icon-effect ms-3"></i>
                     </div>
                  </a>
               </li>
               <li>
                  <a class="dropdown-item" href="{{ url( app()->getLocale(), 'p2p-trading') }}">
                     <div class="d-flex align-items-center">
                        <img src="{{ asset('public/assets/img/header-icons/buy-crypto/p2p-trading.svg') }}" class="header-icons" alt="P2P Trading" />
                        <div class="d-block">
                           <span> P2P Trading</span>
                           <p class="mb-0">Some Description About the Title</p>
                        </div>
                        <i class="bi bi-arrow-right dropdown-icon-effect ms-3"></i>
                     </div>
                  </a>
               </li>
               <li>
                  <a class="dropdown-item" href="{{ url( app()->getLocale(), 'cash-balance') }}">
                     <div class="d-flex align-items-center">
                        <img src="{{ asset('public/assets/img/header-icons/buy-crypto/cash-balance.svg') }}" class="header-icons" alt="Cash Balance" />
                        <div class="d-block">
                           <span> Cash Balance</span>
                           <p class="mb-0">Some Description About the Title</p>
                        </div>
                        <i class="bi bi-arrow-right dropdown-icon-effect ms-3"></i>
                     </div>
                  </a>
               </li>
               <li>
                  <a class="dropdown-item" href="{{ url( app()->getLocale(), 'third-party-payment') }}">
                     <div class="d-flex align-items-center">
                        <img src="{{ asset('public/assets/img/header-icons/buy-crypto/third-party-payment.svg') }}" class="header-icons" alt="Third Party Payment" />
                        <div class="d-block">
                           <span> Third Party Payment</span>
                           <p class="mb-0">Some Description About the Title</p>
                        </div>
                        <i class="bi bi-arrow-right dropdown-icon-effect ms-3"></i>
                     </div>
                  </a>
               </li>
            </ul>
         </li>
         <li class="nav-item">
            <a class="nav-link" href="{{ url( app()->getLocale(), 'markets') }}">
            <span class="nav-img d-lg-none"><img src="{{ asset('public/assets/img/mob-nav-icon/market.svg') }}" class="img-responsive"> </span>
            <span class="d-inline-block">   Market</span>
            </a>
         </li>
         <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="javascript:void(0);" data-bs-toggle="dropdown">
            <span class="nav-img d-lg-none"><img src="{{ asset('public/assets/img/mob-nav-icon/trade.svg') }}" class="img-responsive"> </span>
            <span class="d-inline-block">   Trade</span>  </a>
            <ul class="dropdown-menu dropdown-menu-end fade-down">
               <li>
                  <a class="dropdown-item" href="{{ url( app()->getLocale(), 'convert') }}">
                     <div class="d-flex align-items-center">
                        <img src="{{ asset('public/assets/img/header-icons/trade/convert.svg') }}" class="header-icons" alt="Convert" />
                        <div class="d-block">
                           <span> Convert</span>
                           <p class="mb-0">Some Description About the Title</p>
                        </div>
                        <i class="bi bi-arrow-right dropdown-icon-effect ms-3"></i>
                     </div>
                  </a>
               </li>
               <li>
                  <a class="dropdown-item" href="{{ url( app()->getLocale(), 'classic') }}">
                     <div class="d-flex align-items-center">
                        <img src="{{ asset('public/assets/img/header-icons/trade/classic.svg') }}" class="header-icons" alt="Classic" />
                        <div class="d-block">
                           <span> Classic</span>
                           <p class="mb-0">Some Description About the Title</p>
                        </div>
                        <i class="bi bi-arrow-right dropdown-icon-effect ms-3"></i>
                     </div>
                  </a>
               </li>
               <li>
                  <a class="dropdown-item" href="{{ url( app()->getLocale(), 'advanced') }}">
                     <div class="d-flex align-items-center">
                        <img src="{{ asset('public/assets/img/header-icons/trade/advanced.svg') }}" class="header-icons" alt="Advanced" />
                        <div class="d-block">
                           <span> Advanced</span>
                           <p class="mb-0">Some Description About the Title</p>
                        </div>
                        <i class="bi bi-arrow-right dropdown-icon-effect ms-3"></i>
                     </div>
                  </a>
               </li>
               <li>
                  <a class="dropdown-item" href="{{ url( app()->getLocale(), 'margin') }}">
                     <div class="d-flex align-items-center">
                        <img src="{{ asset('public/assets/img/header-icons/trade/margin.svg') }}" class="header-icons" alt="Margin" />
                        <div class="d-block">
                           <span> Margin</span>
                           <p class="mb-0">Some Description About the Title</p>
                        </div>
                        <i class="bi bi-arrow-right dropdown-icon-effect ms-3"></i>
                     </div>
                  </a>
               </li>
               <li>
                  <a class="dropdown-item" href="{{ url( app()->getLocale(), 'p2p') }}">
                     <div class="d-flex align-items-center">
                        <img src="{{ asset('public/assets/img/header-icons/trade/p2p.svg') }}" class="header-icons" alt="P2P" />
                        <div class="d-block">
                           <span> P2P</span>
                           <p class="mb-0">Some Description About the Title</p>
                        </div>
                        <i class="bi bi-arrow-right dropdown-icon-effect ms-3"></i>
                     </div>
                  </a>
               </li>
               <li>
                  <a class="dropdown-item" href="{{ url( app()->getLocale(), 'strategy-trading') }}">
                     <div class="d-flex align-items-center">
                        <img src="{{ asset('public/assets/img/header-icons/trade/strategy-trading.svg') }}" class="header-icons" alt="Strategy Trading" />
                        <div class="d-block">
                           <span> Strategy Trading</span>
                           <p class="mb-0">Some Description About the Title</p>
                        </div>
                        <i class="bi bi-arrow-right dropdown-icon-effect ms-3"></i>
                     </div>
                  </a>
               </li>
               <li>
                  <a class="dropdown-item" href="{{ url( app()->getLocale(), 'swap-farming') }}">
                     <div class="d-flex align-items-center">
                        <img src="{{ asset('public/assets/img/header-icons/trade/swap-farming.svg') }}" class="header-icons" alt="Swap Farming" />
                        <div class="d-block">
                           <span> Swap Farming</span>
                           <p class="mb-0">Some Description About the Title</p>
                        </div>
                        <i class="bi bi-arrow-right dropdown-icon-effect ms-3"></i>
                     </div>
                  </a>
               </li>
               <li>
                  <a class="dropdown-item" href="{{ url( app()->getLocale(), 'fan-token') }}">
                     <div class="d-flex align-items-center">
                        <img src="{{ asset('public/assets/img/header-icons/trade/fan-token.svg') }}" class="header-icons" alt="Fan Token" />
                        <div class="d-block">
                           <span> Fan Token</span>
                           <p class="mb-0">Some Description About the Title</p>
                        </div>
                        <i class="bi bi-arrow-right dropdown-icon-effect ms-3"></i>
                     </div>
                  </a>
               </li>
            </ul>
         </li>
         <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="javascript:void(0);" data-bs-toggle="dropdown"> 
            <span class="nav-img d-lg-none"><img src="{{ asset('public/assets/img/mob-nav-icon/derivatives.svg') }}" class="img-responsive"> </span>
            <span class="d-inline-block">   Derivatives</span>
            </a>
            <ul class="dropdown-menu dropdown-menu-end fade-down">
               <li>
                  <a class="dropdown-item" href="{{ url( app()->getLocale(), 'wealthmark-futures-overview') }}">
                     <div class="d-flex align-items-center">
                        <img src="{{ asset('public/assets/img/header-icons/derivatives/wealthmark-futures-overview.svg') }}" class="header-icons" alt="WealthMark Futures Overview" />
                        <div class="d-block">
                           <span> WealthMark Futures Overview</span>
                           <p class="mb-0">Some Description About the Title</p>
                        </div>
                        <i class="bi bi-arrow-right dropdown-icon-effect ms-3"></i>
                     </div>
                  </a>
               </li>
               <li>
                  <a class="dropdown-item" href="{{ url( app()->getLocale(), 'responsible-trading') }}">
                     <div class="d-flex align-items-center">
                        <img src="{{ asset('public/assets/img/header-icons/derivatives/responsible-trading.svg') }}" class="header-icons" alt="Responsible Trading" />
                        <div class="d-block">
                           <span> Responsible Trading</span>
                           <p class="mb-0">Some Description About the Title</p>
                        </div>
                        <i class="bi bi-arrow-right dropdown-icon-effect ms-3"></i>
                     </div>
                  </a>
               </li>
               <li>
                  <a class="dropdown-item" href="{{ url( app()->getLocale(), 'coin-m-futures') }}">
                     <div class="d-flex align-items-center">
                        <img src="{{ asset('public/assets/img/header-icons/derivatives/coin-m-futures.svg') }}" class="header-icons" alt="Coin-M Futures" />
                        <div class="d-block">
                           <span> Coin-M Futures</span>
                           <p class="mb-0">Some Description About the Title</p>
                        </div>
                        <i class="bi bi-arrow-right dropdown-icon-effect ms-3"></i>
                     </div>
                  </a>
               </li>
               <li>
                  <a class="dropdown-item" href="{{ url( app()->getLocale(), 'vanilla-options') }}">
                     <div class="d-flex align-items-center">
                        <img src="{{ asset('public/assets/img/header-icons/derivatives/vanilla-option.svg') }}" class="header-icons" alt="Vanilla Options" />
                        <div class="d-block">
                           <span> Vanilla Options</span>
                           <p class="mb-0">Some Description About the Title</p>
                        </div>
                        <i class="bi bi-arrow-right dropdown-icon-effect ms-3"></i>
                     </div>
                  </a>
               </li>
               <li>
                  <a class="dropdown-item" href="{{ url( app()->getLocale(), 'leveraged-tokens') }}">
                     <div class="d-flex align-items-center">
                        <img src="{{ asset('public/assets/img/header-icons/derivatives/leveraged-tokens.svg') }}" class="header-icons" alt="Leveraged Tokens" />
                        <div class="d-block">
                           <span> Leveraged Tokens</span>
                           <p class="mb-0">Some Description About the Title</p>
                        </div>
                        <i class="bi bi-arrow-right dropdown-icon-effect ms-3"></i>
                     </div>
                  </a>
               </li>
               <li>
                  <a class="dropdown-item" href="{{ url( app()->getLocale(), 'battle') }}">
                     <div class="d-flex align-items-center">
                        <img src="{{ asset('public/assets/img/header-icons/derivatives/battle.svg') }}" class="header-icons" alt="Battle" />
                        <div class="d-block">
                           <span> Battle</span>
                           <p class="mb-0">Some Description About the Title</p>
                        </div>
                        <i class="bi bi-arrow-right dropdown-icon-effect ms-3"></i>
                     </div>
                  </a>
               </li>
            </ul>
         </li>
         <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="{{ url( app()->getLocale(), 'launchpad') }}" data-bs-toggle="dropdown"> 
            <span class="nav-img d-lg-none"><img src="{{ asset('public/assets/img/mob-nav-icon/earn.svg') }}" class="img-responsive"> </span>
            <span class="d-inline-block">   Earn</span>
            </a>
            <ul class="dropdown-menu dropdown-menu-end fade-down">
               <li>
                  <a class="dropdown-item" href="{{ url( app()->getLocale(), 'wealthmark-earn') }}">
                     <div class="d-flex align-items-center">
                        <img src="{{ asset('public/assets/img/header-icons/earn/wealthmark-earn.svg') }}" class="header-icons" alt=" WealthMark Earn" />
                        <div class="d-block">
                           <span> WealthMark Earn</span>
                           <p class="mb-0">Some Description About the Title</p>
                        </div>
                        <i class="bi bi-arrow-right dropdown-icon-effect ms-3"></i>
                     </div>
                  </a>
               </li>
               <li>
                  <a class="dropdown-item" href="{{ url( app()->getLocale(), 'launchpad') }}">
                     <div class="d-flex align-items-center">
                        <img src="{{ asset('public/assets/img/header-icons/earn/launchpad.svg') }}" class="header-icons" alt="Launchpad" />
                        <div class="d-block">
                           <span> Launchpad</span>
                           <p class="mb-0">Some Description About the Title</p>
                        </div>
                        <i class="bi bi-arrow-right dropdown-icon-effect ms-3"></i>
                     </div>
                  </a>
               </li>
               <li>
                  <a class="dropdown-item" href="{{ url( app()->getLocale(), 'savings') }}">
                     <div class="d-flex align-items-center">
                        <img src="{{ asset('public/assets/img/header-icons/earn/saving.svg') }}" class="header-icons" alt="Saving" />
                        <div class="d-block">
                           <span> Saving</span>
                           <p class="mb-0">Some Description About the Title</p>
                        </div>
                        <i class="bi bi-arrow-right dropdown-icon-effect ms-3"></i>
                     </div>
                  </a>
               </li>
               <li>
                  <a class="dropdown-item" href="{{ url( app()->getLocale(), 'staking') }}">
                     <div class="d-flex align-items-center">
                        <img src="{{ asset('public/assets/img/header-icons/earn/staking.svg') }}" class="header-icons" alt="Staking" />
                        <div class="d-block">
                           <span> Staking</span>
                           <p class="mb-0">Some Description About the Title</p>
                        </div>
                        <i class="bi bi-arrow-right dropdown-icon-effect ms-3"></i>
                     </div>
                  </a>
               </li>
               <li>
                  <a class="dropdown-item" href="{{ url( app()->getLocale(), 'bm-vault') }}">
                     <div class="d-flex align-items-center">
                        <img src="{{ asset('public/assets/img/header-icons/earn/bm-vault.svg') }}" class="header-icons" alt="BMVault" />
                        <div class="d-block">
                           <span> BMVault</span>
                           <p class="mb-0">Some Description About the Title</p>
                        </div>
                        <i class="bi bi-arrow-right dropdown-icon-effect ms-3"></i>
                     </div>
                  </a>
               </li>
               <li>
                  <a class="dropdown-item" href="{{ url( app()->getLocale(), 'dual-investment') }}">
                     <div class="d-flex align-items-center">
                        <img src="{{ asset('public/assets/img/header-icons/earn/dual-investment.svg') }}" class="header-icons" alt="Dual Investment" />
                        <div class="d-block">
                           <span> Dual Investment</span>
                           <p class="mb-0">Some Description About the Title</p>
                        </div>
                        <i class="bi bi-arrow-right dropdown-icon-effect ms-3"></i>
                     </div>
                  </a>
               </li>
               <li>
                  <a class="dropdown-item" href="{{ url( app()->getLocale(), 'liquidity-farming') }}">
                     <div class="d-flex align-items-center">
                        <img src="{{ asset('public/assets/img/header-icons/earn/liquidity-farming.svg') }}" class="header-icons" alt="Liquidity Farming" />
                        <div class="d-block">
                           <span> Liquidity Farming</span>
                           <p class="mb-0">Some Description About the Title</p>
                        </div>
                        <i class="bi bi-arrow-right dropdown-icon-effect ms-3"></i>
                     </div>
                  </a>
               </li>
               <li>
                  <a class="dropdown-item" href="{{ url( app()->getLocale(), 'auto-invest') }}">
                     <div class="d-flex align-items-center">
                        <img src="{{ asset('public/assets/img/header-icons/earn/auto-invest.svg') }}" class="header-icons" alt="Auto Invest" />
                        <div class="d-block">
                           <span> Auto Invest</span>
                           <p class="mb-0">Some Description About the Title</p>
                        </div>
                        <i class="bi bi-arrow-right dropdown-icon-effect ms-3"></i>
                     </div>
                  </a>
               </li>
               <li>
                  <a class="dropdown-item" href="{{ url( app()->getLocale(), 'wealthmark-pool') }}">
                     <div class="d-flex align-items-center">
                        <img src="{{ asset('public/assets/img/header-icons/earn/wealthmark-pool.svg') }}" class="header-icons" alt="WealthMark Pool" />
                        <div class="d-block">
                           <span> WealthMark Pool</span>
                           <p class="mb-0">Some Description About the Title</p>
                        </div>
                        <i class="bi bi-arrow-right dropdown-icon-effect ms-3"></i>
                     </div>
                  </a>
               </li>
            </ul>
         </li>
         <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="javascript:void(0);" data-bs-toggle="dropdown">
            <span class="nav-img d-lg-none"><img src="{{ asset('public/assets/img/mob-nav-icon/finance.svg') }}" class="img-responsive"> </span>
            <span class="d-inline-block">   Finance</span>
            </a>
            <ul class="dropdown-menu dropdown-menu-end fade-down">
               <li>
                  <a class="dropdown-item" href="{{ url( app()->getLocale(), 'wealthmark-visa-card') }}">
                     <div class="d-flex align-items-center">
                        <img src="{{ asset('public/assets/img/header-icons/earn/wealthmark-pool.svg') }}" class="header-icons" alt="WealthMark Visa Card" />
                        <div class="d-block">
                           <span> WealthMark Visa Card</span>
                           <p class="mb-0">Some Description About the Title</p>
                        </div>
                        <i class="bi bi-arrow-right dropdown-icon-effect ms-3"></i>
                     </div>
                  </a>
               </li>
               <li>
                  <a class="dropdown-item" href="{{ url( app()->getLocale(), 'crypto-loans') }}">
                     <div class="d-flex align-items-center">
                        <i class="bi bi-app-indicator me-3"></i>
                        <div class="d-block">
                           <span> Crypto Loans</span>
                           <p class="mb-0">Some Description About the Title</p>
                        </div>
                        <i class="bi bi-arrow-right dropdown-icon-effect ms-3"></i>
                     </div>
                  </a>
               </li>
               <li>
                  <a class="dropdown-item" href="{{ url( app()->getLocale(), 'wealthmark-pay') }}">
                     <div class="d-flex align-items-center">
                        <i class="bi bi-app-indicator me-3"></i>
                        <div class="d-block">
                           <span> WealthMark Pay</span>
                           <p class="mb-0">Some Description About the Title</p>
                        </div>
                        <i class="bi bi-arrow-right dropdown-icon-effect ms-3"></i>
                     </div>
                  </a>
               </li>
            </ul>
         </li>
         <li class="nav-item"> <a class="nav-link txtleft" href="{{ url( app()->getLocale(), 'nft') }}">   <span class="nav-img d-lg-none"><img src="{{ asset('public/assets/img/mob-nav-icon/nft.svg') }}" class="img-responsive"> </span>
            <span class="d-inline-block">   NFT</span></a>
         </li>
      </ul>
   </nav>
</div>
<div class="ms-auto w-100 hide_on_max_dashboard_992">
   <nav id="right_nav" class="mobile-offcanvas navbar navbar-expand-lg py-0">
      <div class="offcanvas-header justify-content-between border-bottom">
         <a href="{{ url('/') }}" class="navbar-brand" id="find-2"> 
         <img src="{{ asset('public/assets/img/wealthmark-logo.svg') }}" alt="" class="wealthmark-logo">
         </a>
         <span class="btn-close m-0 p-0"></span>
        
      </div>
      <ul class="navbar-nav ">
         <li class="nav-item right-sidebar">
            <a href="javascript:void(0)" class="sidebar-open-onclick"> <span class="bi bi-list"> </span> </a>   
         </li>
        @auth
        <?php
            function hideEmailAddress($email)
            {
                if(filter_var($email, FILTER_VALIDATE_EMAIL))
                {
                    list($first, $last) = explode('@', $email);
                    $first = str_replace(substr($first, '3'), str_repeat('*', strlen($first)-3), $first);
                    $last = explode('.', $last);
                    $last_domain = str_replace(substr($last['0'], '10'), str_repeat('*', strlen($last['0'])-1), $last['0']);
                    $hideEmailAddress = $first.'@'.$last_domain.'.'.$last['1'];
                    return $hideEmailAddress;
                }
            }
        ?>
         <div class="show_if_login">
            <li class="nav-item dropdown left-header-custom-nav wallet">
               <a class="nav-link dropdown-toggle" href="javascript:void(0);" data-bs-toggle="dropdown"> 
               <span class="">   Wallet</span>
               </a>
               <ul class="dropdown-menu dropdown-menu-end fade-down">
                  <li>
                     <a class="dropdown-item" href="{{ url( app()->getLocale(), 'wealthmark-futures-overview') }}">
                        <div class="d-flex align-items-center">
                           <img src="{{ asset('public/assets/img/header-icons/derivatives/wealthmark-futures-overview.svg') }}" class="header-icons" />
                           <div class="d-block">
                              <span> Overview</span>
                           </div>
                        </div>
                     </a>
                  </li>
                  <li>
                     <a class="dropdown-item" href="{{ url(app()->getLocale()) }}/user/fiat-and-spot">
                        <div class="d-flex align-items-center">
                           <img src="{{ asset('public/assets/img/header-icons/derivatives/responsible-trading.svg') }}" class="header-icons" />
                           <div class="d-block">
                              <span> Fiat and Spot</span>
                              <p class="mb-0">Deposit & Widtdraw</p>
                           </div>
                        </div>
                     </a>
                  </li>
                  <li>
                     <a class="dropdown-item" href="{{ url(app()->getLocale()) }}/user/funding">
                        <div class="d-flex align-items-center">
                           <img src="{{ asset('public/assets/img/header-icons/derivatives/coin-m-futures.svg') }}" class="header-icons" />
                           <div class="d-block">
                              <span> Funding</span>
                           </div>
                        </div>
                     </a>
                  </li>
                  <li>
                     <a class="dropdown-item" href="{{ url(app()->getLocale()) }}/user/futures">
                        <div class="d-flex align-items-center">
                           <img src="{{ asset('public/assets/img/header-icons/derivatives/vanilla-option.svg') }}" class="header-icons" />
                           <div class="d-block">
                              <span> Futures </span>
                           </div>
                        </div>
                     </a>
                  </li>
                  <li>
                     <a class="dropdown-item" href="{{ url(app()->getLocale()) }}/user/earn">
                        <div class="d-flex align-items-center">
                           <img src="{{ asset('public/assets/img/header-icons/derivatives/leveraged-tokens.svg') }}" class="header-icons" />
                           <div class="d-block">
                              <span> Earn</span>
                           </div>
                        </div>
                     </a>
                  </li>
                  <!--<li>-->
                  <!--   <a class="dropdown-item" href="{{ url( app()->getLocale(), 'battle') }}">-->
                  <!--      <div class="d-flex align-items-center">-->
                  <!--         <i class="bi bi-shield-check header-icons"></i>-->
                  <!--         <div class="d-block">-->
                  <!--            <span> Jex</span>-->
                  <!--         </div>-->
                  <!--      </div>-->
                  <!--   </a>-->
                  <!--</li>-->
                  <!-- <li>-->
                  <!--   <a class="dropdown-item" href="{{ url( app()->getLocale(), 'battle') }}">-->
                  <!--      <div class="d-flex align-items-center">-->
                  <!--         <i class="bi bi-shield-check header-icons"></i>-->
                  <!--         <div class="d-block">-->
                  <!--            <span> WazirX</span>-->
                  <!--         </div>-->
                  <!--      </div>-->
                  <!--   </a>-->
                  <!--</li>-->
                  <!-- <li>-->
                  <!--   <a class="dropdown-item" href="{{ url( app()->getLocale(), 'battle') }}">-->
                  <!--      <div class="d-flex align-items-center">-->
                  <!--          <i class="bi bi-shield-check header-icons"></i>-->
                  <!--         <div class="d-block">-->
                  <!--            <span> WealthMark TR</span>-->
                  <!--         </div>-->
                  <!--      </div>-->
                  <!--   </a>-->
                  <!--</li>-->
                  <!-- <li>-->
                  <!--   <a class="dropdown-item" href="{{ url( app()->getLocale(), 'battle') }}">-->
                  <!--      <div class="d-flex align-items-center">-->
                  <!--          <i class="bi bi-shield-check header-icons"></i>-->
                  <!--         <div class="d-block">-->
                  <!--            <span> Tokocrypto</span>-->
                  <!--         </div>-->
                  <!--      </div>-->
                  <!--   </a>-->
                  <!--</li>-->
                  <!-- <li>-->
                  <!--   <a class="dropdown-item" href="{{ url( app()->getLocale(), 'battle') }}">-->
                  <!--      <div class="d-flex align-items-center">-->
                  <!--        <i class="bi bi-shield-check header-icons"></i>-->
                  <!--         <div class="d-block">-->
                  <!--            <span> Pexpay</span>-->
                  <!--         </div>-->
                  <!--      </div>-->
                  <!--   </a>-->
                  <!--</li>-->
               </ul>
            </li>
            <li class="nav-item dropdown left-header-custom-nav order">
               <a class="nav-link dropdown-toggle" href="javascript:void(0);" data-bs-toggle="dropdown"> 
               <span>   Order</span>
               </a>
               <ul class="dropdown-menu dropdown-menu-end fade-down">
                  <li>
                     <a class="dropdown-item" href="#">
                        <div class="d-flex align-items-center">
                           <img src="{{ asset('public/assets/img/header-icons/derivatives/wealthmark-futures-overview.svg') }}" class="header-icons" />
                           <div class="d-block">
                              <span> Spot Order</span>
                           </div>
                        </div>
                     </a>
                  </li>
                  <li>
                     <a class="dropdown-item" href="#">
                        <div class="d-flex align-items-center">
                           <img src="{{ asset('public/assets/img/header-icons/derivatives/responsible-trading.svg') }}" class="header-icons" />
                           <div class="d-block">
                              <span> Margin Order</span>
                              <p class="mb-0">Deposit & Widtdraw</p>
                           </div>
                        </div>
                     </a>
                  </li>
                  <li>
                     <a class="dropdown-item" href="#">
                        <div class="d-flex align-items-center">
                           <img src="{{ asset('public/assets/img/header-icons/derivatives/coin-m-futures.svg') }}" class="header-icons" />
                           <div class="d-block">
                              <span> P2P Order</span>
                           </div>
                        </div>
                     </a>
                  </li>
                  <li>
                     <a class="dropdown-item" href="#">
                        <div class="d-flex align-items-center">
                           <img src="{{ asset('public/assets/img/header-icons/derivatives/vanilla-option.svg') }}" class="header-icons"/>
                           <div class="d-block">
                              <span> Earn History </span>
                           </div>
                        </div>
                     </a>
                  </li>
                  <li>
                     <a class="dropdown-item" href="#">
                        <div class="d-flex align-items-center">
                           <img src="{{ asset('public/assets/img/header-icons/derivatives/leveraged-tokens.svg') }}" class="header-icons" />
                           <div class="d-block">
                              <span> Buy Crypto History</span>
                           </div>
                        </div>
                     </a>
                  </li>
               </ul>
            </li>
            <li class="nav-item dropdown left-header-custom-nav max-width-300 user">
               <a class="nav-link dropdown-toggle" href="javascript:void(0);" data-bs-toggle="dropdown"> 
               <span class="">   <i class="bi bi-person-circle"></i></span>
               </a>
               <ul class="dropdown-menu dropdown-menu-end fade-down">
                  <li class="">
                     <a class="dropdown-item" href="#">
                        <div class="phone">
                           <i class="bi bi-tablet-fill me-2"></i> 
                            @if(Auth::user()->is_phone_verified==1)
                                {{ substr(Auth::user()->phone, 0, 3) . "***" . substr(Auth::user()->phone, 6, 4) }}
                            @else
                                {{ hideEmailAddress(Auth::user()->email) }}
                            @endif
                        </div>
                     </a>
                  </li>
                  <li class="py-0-important">
                     <a class="dropdown-item no-hover" href="#">
                        <div class="verify-box-dropdown">
                           <span class="user-type">
                           <i class="bi bi-wifi me-2"></i> Regular User
                           </span>
                            @if(Auth::user()->government_id_verified==0)
                               <span class="verify-status">
                               <i class="bi bi-wifi me-2"></i> Unverified
                               </span>
                            @endif
                            @if(Auth::user()->government_id_verified==1)
                               <span class="verify-status" style="background-color:green;color:white;font-size:12px;">
                               <i class="bi bi-wifi me-2" style="font-size:12px;"></i> Verified
                               </span>
                            @endif
                        </div>
                     </a>
                  </li>
                  <li>
                     <a class="dropdown-item" href="{{ url(app()->getLocale()) }}/user/dashboard">
                        <div class="d-flex align-items-center">
                           <i class="bi bi-grid header-icons"></i>
                           <div class="d-block">
                              <span> Dashboard</span>
                           </div>
                        </div>
                     </a>
                  </li>
                  <li>
                     <a class="dropdown-item" href="{{ url(app()->getLocale()) }}/user/security">
                        <div class="d-flex align-items-center">
                           <i class="bi bi-shield-check header-icons"></i>
                           <div class="d-block">
                              <span> Security</span>
                           </div>
                        </div>
                     </a>
                  </li>
                  <li>
                     <a class="dropdown-item" href="{{ url(app()->getLocale()) }}/user/identification">
                        <div class="d-flex align-items-center">
                           <i class="bi bi-fingerprint header-icons"></i>
                           <div class="d-block">
                              <span> Identification</span>
                           </div>
                        </div>
                     </a>
                  </li>
                  <li>
                     <a class="dropdown-item" href="{{ url(app()->getLocale()) }}/user/payment">
                        <div class="d-flex align-items-center">
                           <i class="bi bi-coin header-icons"></i>
                           <div class="d-block">
                              <span> Payment </span>
                           </div>
                        </div>
                     </a>
                  </li>
                  <li>
                     <a class="dropdown-item" href="{{ url(app()->getLocale()) }}/user/referral">
                        <div class="d-flex align-items-center">
                           <i class="bi bi-person-plus header-icons"></i>
                           <div class="d-block">
                              <span> Refferal</span>
                           </div>
                        </div>
                     </a>
                  </li>
                  <li>
                     <a class="dropdown-item" href="{{ url(app()->getLocale()) }}/user/reward-center">
                        <div class="d-flex align-items-center">
                           <i class="bi bi-cash-stack header-icons"></i>
                           <div class="d-block">
                              <span> Reward Center</span>
                           </div>
                        </div>
                     </a>
                  </li>
                  <li>
                     <a class="dropdown-item" href="{{ url(app()->getLocale()) }}/user/task-center">
                        <div class="d-flex align-items-center">
                           <i class="bi bi-cash-stack header-icons"></i>
                           <div class="d-block">
                              <span> Task Center</span>
                           </div>
                        </div>
                     </a>
                  </li>
                  <li>
                     <a class="dropdown-item" href="{{ url(app()->getLocale()) }}/user/api-management">
                        <div class="d-flex align-items-center">
                           <i class="bi bi-person header-icons"></i>
                           <div class="d-block">
                              <span> API Management</span>
                           </div>
                        </div>
                     </a>
                  </li>
                  <li>
                     <a class="dropdown-item" href="{{ url(app()->getLocale()) }}/user/settings">
                        <div class="d-flex align-items-center">
                           <i class="bi bi-sliders header-icons"></i>
                           <div class="d-block">
                              <span> Settings </span>
                           </div>
                        </div>
                     </a>
                  </li>
                  <li style="border-top:2px solid whitesmoke;">
                     <a class="dropdown-item" href="{{ url(app()->getLocale()) }}/user/logout">
                        <div class="d-flex align-items-center">
                           <i class="bi bi-box-arrow-right header-icons"></i>
                           <div class="d-block">
                              <span> Log Out </span>
                           </div>
                        </div>
                     </a>
                  </li>
               </ul>
            </li>
            <li class="nav-item dropdown left-header-custom-nav notification">
               <a class="nav-link dropdown-toggle" href="javascript:void(0);" data-bs-toggle="dropdown"> 
               <span class="">   <i class="bi bi-bell-fill"></i></span>
               </a>
               <ul class="dropdown-menu dropdown-menu-end fade-down">
                  <li class="max-width-450">
                     <div class="notification-first d-flex align-items-center">
                        <div class="notificationinner-left d-flex align-items-center">
                           <span> <i class="bi bi-1-circle header-icons"></i> pending notifications </span>
                           <span class="clear-all"><a href="#">clear all</a> </span>
                        </div>
                        <div class="notificationinner-right">
                           <a href="" class="view-all"> View All <i class="bi bi-arrow-right ml-3"></i></a>
                        </div>
                     </div>
                  </li>
                  <li>
                     <a class="dropdown-item no-hover" href="#">
                        <div class="d-flex align-items-center">
                           <img src="{{ asset('public/assets/img/header-icons/derivatives/responsible-trading.svg') }}" class="header-icons" alt="Responsible Trading" />
                           <div class="d-block">
                              <span> Fiat and Spot</span>
                              <p class="mb-0">Deposit & Widtdraw</p>
                           </div>
                        </div>
                     </a>
                  </li>
               </ul>
            </li>
        </div>
        @else
            <div class="d-flex hide_if_login">
                <li class="dashboard-hide nav-item d-none d-sm-block"><a class="btn btn-blue  shadow " href="{{ url( app()->getLocale(), 'login') }}"><i class="bx bx-log-in-circle"></i> Login</a></li>
                <li class="dashboard-hide nav-item d-none d-sm-block"><a class="btn btn-yellow shadow" href="{{ url( app()->getLocale(), 'register') }}"><i class="bx bx-log-out-circle"></i> Register</a></li>
            </div>
        @endauth 
         <div class="show-min-1300">
            <li class="nav-item">
               <a class="nav-link" href="javascript:void(0);" data-bs-toggle="modal" data-bs-target="#currLangModal">
               <span class="nav-img d-lg-none"><img src="{{ asset('public/assets/img/mob-nav-icon/english.svg') }}" class="img-responsive"> </span>
               <span class="d-inline-block "> English&nbsp;@if(Cookie::get('country_name')!="")({{ Cookie::get('country_name') }}) @endif</span>
               </a>
            </li>
            <li class="nav-item dropdown">
               <a class="nav-link dropdown-toggle" href="javascript:void(0);" data-bs-toggle="dropdown">
               <span class="nav-img d-lg-none"><img src="{{ asset('public/assets/img/mob-nav-icon/download.svg') }}" class="img-responsive"> </span>
               <span class="d-inline-block ">   Download</span> </a>
               <ul class="dropdown-menu dropdown-menu-end fade-down">
                  <li> <a  href="javascript:void(0);">
                     <img src="{{ asset('public/assets/img/qr/qrcode_wealthmark.io.png') }}" class="header-download" alt="QR Code" />
                     </a>
                  </li>
               </ul>
            </li>
            <i class="nav-devider d-none d-sm-block"></i>
            <li class="nav-item"><a class="nav-link ps-0" href="javascript:void(0);" data-bs-toggle="modal" data-bs-target="#currLangModal">
               <span class="nav-img d-lg-none"><img src="{{ asset('public/assets/img/mob-nav-icon/inr.svg') }}" class="img-responsive"> </span>
               <span class="d-inline-block ">   INR</span>
               </a>
            </li>
            <i class="nav-devider d-none d-sm-block"></i>
            <li class="nav-item theme-change"><a class="nav-link ps-0" href="javascript:void(0);"><i class="bi-moon-stars-fill"></i></a></li>
         </div>
      </ul>
   </nav>
</div>