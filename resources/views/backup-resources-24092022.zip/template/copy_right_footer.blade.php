<div class="copy_right text-center">
     © 2017 - <?php echo date('Y'); ?> wealthmark.io All rights reserved
</div>


<a href="#" class="chat-support"><span><i class="bi-chat-dots-fill"></i></span><label for="">Support</label></a>
 
