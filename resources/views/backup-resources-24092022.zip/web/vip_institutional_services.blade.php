
  <!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
   <head>
      <meta charset="utf-8">
      <meta content="width=device-width, initial-scale=1.0" name="viewport">
      <title>Wealth Mark | Create Entity Account</title>
  @include('template.web_css')
  <style>
      .top-heading {
    font-size: 40px;
    margin-bottom: 20px;
        color: #0b0861;
}
.top-p {
    font-size: 18px;
    margin-bottom: 30px;
}

 .action-item {
    -webkit-flex-direction: column;
    -ms-flex-direction: column;
    flex-direction: column;
    margin-bottom: 32px;
     
 }
 
 
 .text-indigo-600{
     
 }
 @media screen and (min-width: 1023px){
  .achievement-clients {
    margin-bottom: 48px;
}
}

 @media screen and (min-width: 767px){
.achievement-clients {
    margin-bottom: 24px;
}
 }
 
 .achievement-clients {
    margin-bottom: 20px;
    -webkit-flex-wrap: wrap;
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
}

.css-4cffwv {
    box-sizing: border-box;
    margin: 0;
    min-width: 0;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
}
.css-1cjl26j {
    box-sizing: border-box;
    margin: 0;
    min-width: 0;
    font-weight: 400;
    font-size: 14px;
    line-height: 20px;
}
 .achievement-clients .client-item {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-align-items: center;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    margin-bottom: 16px;
    margin-right: 24px;
    color: #707A8A;
}
 .achievement-clients .client-item::before {
    content: "";
    display: block;
    width: 6px;
    height: 6px;
    margin-right: 8px;
    border-radius: 3px;
    background-color: #F0B90B;
}

 .achievement-services .service-item {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-align-items: center;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    color: #474D57;
    margin-bottom: 16px;
}
.css-1c82c04 {
    box-sizing: border-box;
    margin: 0;
    min-width: 0;
    font-weight: 500;
    font-size: 14px;
    line-height: 20px;
}
.css-pusd03 {
    box-sizing: border-box;
    margin: 0;
    min-width: 0;
    color: #02C076;
    width: 24px;
    height: 24px;
    font-size: 24px;
    fill: #1E2329;
    fill: #02C076;
    width: 1em;
    height: 1em;
    margin-right: 4px;
}

.breadcrumbs-box{
   background:#f5f8fd; 
   background: url('{{ asset("public/assets/img/vip-institutional-services.png")}}');
       background-size: cover;
    padding: 50px 0px 400px 0px;
    margin-bottom:10px;
}

.bg-text{
    padding-top:160px !important;
}

.bg-indigo-500{
    background: #263674;
     background-color: #263674 !important;
    color: #fcba17 !important;
}
.text-indigo-600{
    color:#263674 !important;
}
  </style>
  
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/1.6.2/tailwind.min.css" />
  
  
  
</head>
<body>

    @include('template.mobile_menu')
        @include('template.web_menu')
    

                <div class="text-center mt-3 bg-light-yellow">
                <a href="{{ url( app()->getLocale(), 'register') }}">    <span class="offer-text-head">
                    Register now - Enjoy Welcome Rewards up to 1 BMK! ( for verified user) 
                    </span>
                    </a>
                </div>
           


 
      <section class="breadcrumbs-box shadow-sm">
          <div class="container mt-3">
              <div class="row">
                 <div class="col-lg-6  d-flex flex-column justify-content-center pt-lg-0 bg-text " data-aos="fade-up" data-aos-delay="200">
                 <h3 class="top-heading">Your Trusted Platform in Digital Assets for Institutions</h3>
                 <p class="top-p">Built by the world's largest digital asset exchange, Wealthmark Institutional offers unparalleled access to digital asset solutions for VIP clients and institutions.</p>
                
                 </div>
                
              </div>
           </div>
      </section>
      
      
      <div class="py-24 bg-white">
  <div class="max-w-screen-xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row justify-between">
    
    <div class="text-left mt-10 md:mr-24 md:w-6/12">
      <p class="mt-4 text-sm leading-7 text-gray-500 font-regular">
       WEALTHMARK
      </p>
      <h3 class="text-3xl sm:text-5xl leading-normal font-extrabold tracking-tight text-gray-900">
        Why Institutions <span class="text-indigo-600">  Choose Wealthmark</span>
      </h3>
      <p class="mt-2 mb-2 text-SM leading-7 text-gray-500 font-light">
        As a pioneer in the digital asset industry, Wealthmark Institutional delivers market-leading and customized solutions to all types of institutions:
       
      </p>
      <div class="achievement-clients css-4cffwv"><div data-bn-type="text" class="client-item css-1cjl26j">Asset Managers</div><div data-bn-type="text" class="client-item css-1cjl26j">Brokers</div><div data-bn-type="text" class="client-item css-1cjl26j">Hedge Funds</div><div data-bn-type="text" class="client-item css-1cjl26j">Family Offices</div><div data-bn-type="text" class="client-item css-1cjl26j">Proprietary Trading Firms</div><div data-bn-type="text" class="client-item css-1cjl26j">Liquidity Providers</div><div data-bn-type="text" class="client-item css-1cjl26j">HNWIs</div><div data-bn-type="text" class="client-item css-1cjl26j">Mining Companies</div><div data-bn-type="text" class="client-item css-1cjl26j">Corporates</div><div data-bn-type="text" class="client-item css-1cjl26j">More</div></div>
    
    
    <div class="achievement-services"><div data-bn-type="text" class="service-item css-1c82c04"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="css-pusd03"><path fill-rule="evenodd" clip-rule="evenodd" d="M7.035 16.812l-.001.002 2.121 2.121.002-.002 2.121-2.12 9.19-9.192-2.12-2.121-9.191 9.19-3.536-3.534-2.121 2.12 3.535 3.536z" fill="currentColor"></path></svg>Over 1450 pairs for various spot trading needs</div><div data-bn-type="text" class="service-item css-1c82c04"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="css-pusd03"><path fill-rule="evenodd" clip-rule="evenodd" d="M7.035 16.812l-.001.002 2.121 2.121.002-.002 2.121-2.12 9.19-9.192-2.12-2.121-9.191 9.19-3.536-3.534-2.121 2.12 3.535 3.536z" fill="currentColor"></path></svg>Largest futures trading volume with over 200 contracts</div><div data-bn-type="text" class="service-item css-1c82c04"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="css-pusd03"><path fill-rule="evenodd" clip-rule="evenodd" d="M7.035 16.812l-.001.002 2.121 2.121.002-.002 2.121-2.12 9.19-9.192-2.12-2.121-9.191 9.19-3.536-3.534-2.121 2.12 3.535 3.536z" fill="currentColor"></path></svg>Comprehensive Wealthmark blockchain ecosystem</div><div data-bn-type="text" class="service-item css-1c82c04"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="css-pusd03"><path fill-rule="evenodd" clip-rule="evenodd" d="M7.035 16.812l-.001.002 2.121 2.121.002-.002 2.121-2.12 9.19-9.192-2.12-2.121-9.191 9.19-3.536-3.534-2.121 2.12 3.535 3.536z" fill="currentColor"></path></svg>Access to the deepest cryptocurrency liquidity pool</div></div>
    
      <!--<div class="mt-5 sm:mt-8 sm:flex justify-start items-center">-->
      <!--      <div class="rounded-md shadow">-->
      <!--        <a href="#" class="w-full flex items-center justify-center px-8 py-3 border border-transparent text-base leading-6 font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-500 focus:outline-none focus:border-indigo-700 focus:shadow-outline-indigo transition duration-150 ease-in-out md:py-4 md:text-lg md:px-10">-->
      <!--          Get started-->
      <!--        </a>-->
      <!--      </div>-->
      <!--      <div class="mt-0 sm:mt-0 sm:ml-3">-->
      <!--        <a href="#" class="w-full flex items-center justify-center px-8 py-3 border border-transparent text-base leading-6 font-medium rounded-md text-indigo-700 bg-indigo-100 hover:text-indigo-600 hover:bg-indigo-50 focus:outline-none focus:shadow-outline-indigo focus:border-indigo-300 transition duration-150 ease-in-out md:py-4 md:text-lg md:px-10">-->
      <!--          Live demo-->
      <!--        </a>-->
      <!--      </div>-->
      <!--    </div>-->
      
    </div>

    <div class="md:w-6/12 mt-10 sm:mt-0">
      <ul class="grid grid-cols-2 col-gap-10 row-gap-10">
        <li class="bg-gray-100 p-5 py-10 text-center">
          <div class="flex flex-col items-center">
            <div class="flex-shrink-0">
              <div class="flex items-center justify-center h-16 w-16 rounded-full bg-indigo-500 text-white">
                <svg class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9" />
                </svg>
              </div>
            </div>
            <div class="mt-4">
              <h4 class="text-lg leading-6 font-semibold text-gray-900">1st</h4>
              <p class="mt-2 text-base leading-6 text-gray-500">
                in aggregated spot & futures trading volume
              </p>
            </div>
          </div>
        </li>
        <li class="bg-gray-100 p-5 py-10 text-center">
          <div class="flex flex-col items-center">
            <div class="flex-shrink-0">
              <div class="flex items-center justify-center h-16 w-16 rounded-full bg-indigo-500 text-white">
                <svg class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 6l3 1m0 0l-3 9a5.002 5.002 0 006.001 0M6 7l3 9M6 7l6-2m6 2l3-1m-3 1l-3 9a5.002 5.002 0 006.001 0M18 7l3 9m-3-9l-6-2m0-2v2m0 16V5m0 16H9m3 0h3" />
                </svg>
              </div>
            </div>
            <div class="mt-4">
              <h4 class="text-lg leading-6 font-semibold text-gray-900">$100 billion</h4>
              <p class="mt-2 text-base leading-6 text-gray-500">
               24 hour trading volume peak
              </p>
            </div>
          </div>
        </li>
        <li class="bg-gray-100 p-5 py-10 text-center">
          <div class="flex flex-col items-center">
            <div class="flex-shrink-0">
              <div class="flex items-center justify-center h-16 w-16 rounded-full bg-indigo-500 text-white">
                <svg class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z" />
                </svg>
              </div>
            </div>
            <div class="mt-4">
              <h4 class="text-lg leading-6 font-semibold text-gray-900">$7.7 trillion</h4>
              <p class="mt-2 text-base leading-6 text-gray-500">
               annual exchange volume
              </p>
            </div>
          </div>
        </li>
        <li class="bg-gray-100 p-5 py-10 text-center">
          <div class="flex flex-col items-center">
            <div class="flex-shrink-0">
              <div class="flex items-center justify-center h-16 w-16 rounded-full bg-indigo-500 text-white">
                <svg class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 8h10M7 12h4m1 8l-4-4H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-3l-4 4z" />
                </svg>
              </div>
            </div>
            <div class="mt-4">
              <h4 class="text-lg leading-6 font-semibold text-gray-900">90 million</h4>
              <p class="mt-2 text-base leading-6 text-gray-500">
                registed users, and increasing
              </p>
            </div>
          </div>
        </li>
        
      </ul>
    </div>
    
  </div>
</div>


      
      
      
      
      
      
      
      
      
      
      
      
    @include('template.country_language')
    @include('template.web_footer') 
      

  
</body>

</html>
