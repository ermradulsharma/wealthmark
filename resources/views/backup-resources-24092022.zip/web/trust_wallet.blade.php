<h1></h1>

<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <title>Wealth Mark | {{ Request::segment(2) }}</title>
    @include('template.web_css')
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/1.6.2/tailwind.min.css" />

    <style>

                @media (min-width: 1200px){
                    .container-xl, .container-lg, .container-md, .container-sm, .container {
                        max-width: 1040px;
                    }
                }
                @media(max-width:767px){
                    #three-offers-section .d-flex{
                        margin:10px;
                    }
                    .display-4 {
                        font-size: 1.6875rem!important;
                    }
                    .col-lg-5 {
                        flex: 0 0 80.666667%!important;
                    max-width: 100%!important;
                    }
                        .lead {
                        text-align: center;
                        }
                        #banner-section .banner-para {
                        text-align: center;
                        }
                    #banner-section .display-3 {
                    font-weight: 300;
                    line-height: 40px!important;
                    margin-bottom: 15px;
                    text-align: center;
                    }
                    .img-fluid {
                    max-width: 100%!important;
                    }

                    .display-3 {
                    font-size: 2rem!important;
                    }      
                    .lead {
                            font-size: 1rem!important;
                    }  
                    #banner-section .hero-image{
                        width:50%;
                        margin:10px;
                    } 
                    .display-4 {
                    text-align: center;
                    }
                    .hero-image{
                        width:100%;
                        margin:10px;
                    } 
                    .display-4 {
                            font-size: 1.6875rem;
                    }
                    #about-us-section.col-lg-5 {
                            flex: 0 0 90.666667%!important;
                            max-width: 90.6666666667%!important;
                            text-align: center!important;
                        }
                }
                @media(device-width:768px) and (device-height:1024px){
                    #banner-section .img-fluid {
                    max-width: 40%;
                    height: auto;
                    margin: 10px;
                    }
                    .lead {
                    font-size: 2rem;
                    font-weight: 300;
                    }
                    .display-3 {
                    font-size: 3.6rem!important;
                    }
                    #banner-section .img-fluid {
                    max-width: 50%;
                    height: auto;
                    margin: 10px;
                    }
                        #three-offers-section .mr-auto {
                        margin-right: initial;
                        margin-bottom: 25px;
                        }
                }
                @media(min-width:768) and (max-width:991px){
                        .img-fluid {
                        max-width: 50%;
                        height: auto;
                        margin: 10px;
                        }
                }
                @media(min-width:992){

                }
                .bg-gradient-primary {
                background-image: linear-gradient(to bottom right,#263674 50%,#041246 100%);
                }
               
                .display-4 {
                font-size: 2.6875rem;
                font-weight: 400;
                line-height: 1;
                }
                .font-weight-bold {
                font-weight: 700!important;
                }
                .display-3 {
                font-size: 3rem;
                }
                .display-4 {
                line-height: 1.2;
                }
                .text-md-left {
                text-align: left!important;
                }
                .mb-4, .my-4 {
                margin-bottom: 1rem!important;
                }
                .col-lg-5 {
                flex: 0 0 41.6666666667%;
                max-width: 41.6666666667%;
                }
                .crypto-download-btn{
                width: 200px;
                padding: 15px;
                color:white;
                font-size: 1.0625rem;
                }
                .list-group-item {
                position: relative;
                display: block;
                padding: 1.5rem 2rem;
                background-color: #fff;
                border: 1px solid #f1f4f8;
                }
                .font-weight-bold {
                font-weight: 700!important;
                }
                .text-gray-700 {
                color: #4a545e!important;
                }
                h3 {
                font-size: 1.75rem;
                }
                #three-offers-section img{
                width: 24px;
                }
                #three-offers-section .icon {
                display: flex;
                justify-content: center;
                align-items: center;
                background-color: white;
                width: 50px;
                height: 50px;
                border-radius: 30px;
                }
                #three-offers-section {
                padding: 0px 0!important;
                background-color: #d5ab08;
                }
                #three-offers-section .ml-4 {
                margin-left: 1rem;
                line-height: 50px;
                color: white;
                }
                #crypto-info-section .btn-primary{
                color: #fff!important;
                background-color: #263674!important;
                border-color: #263674!important;
                }
                #steps-section  .btn-primary{
                color: #fff!important;
                background-color: #263674!important;
                border-color: #263674!important;
                }
                #steps-section img.hero-image.mx-auto.d-block.img-fluid {
                width: 50%;
                }
                .step-row{
                margin-bottom: 40px!important;
                }
                #crypto-info-section span.check-icon:before {
                content: '\2713';
                padding-right: 10px;
                }
                .list-group-item.d-flex:hover {
                background-color: #263674;
                color: white;
                }
                #banner-section .banner-para {
                margin-bottom: 1rem!important;
                font-weight: 500!important;
                }
                #banner-section .display-3 {
                    font-weight: 300;
                    line-height: 55px;
                    margin-bottom: 15px;
                    }
                    #crypto-info-section .list-group-item {
                border: 1px solid #f1f4f8;
                box-shadow: 0px -1px 3px 1px #dfdfdf;
                margin-bottom: 5px;
                }
                .btn{
                    transition: transform 250ms;
                }
                .btn:hover{
                    transform: translateY(-10px);
                }

                figure {
                
                margin: 0;
                padding: 0;
                overflow: hidden;
                }
                /* Zoom In #1 */
                .img-hover figure img {
                transition: .3s ease-in-out;
                }
                .img-hover figure:hover img {
                -webkit-transform: translateX(20px);
                transform: translateX(20px);
                }
                .img-hover2 figure img {
                transition: .3s ease-in-out;
                }
                .img-hover2 figure:hover img {
                -webkit-transform: translateX(-20px);
                transform: translateX(-20px);
                }

                .img-hover3 figure img {
                transition: .3s ease-in-out;
                }
                .img-hover3 figure:hover img {
                -webkit-transform: translateX(20px);
                transform: translateX(20px);
                }

                .img-hover4 figure img {
                transition: .3s ease-in-out;
                }
                .img-hover4 figure:hover img {
                -webkit-transform: translateX(-20px);
                transform: translateX(-20px);
                }
                .img-hover5 figure img {
                transition: .3s ease-in-out;
                }
                .img-hover5 figure:hover img {
                -webkit-transform: translateX(20px);
                transform: translateX(20px);
                cursor: pointer;
                }
                #banner-section .hero-image{
                    transition: transform 250ms;
                }
                    img{
                        cursor: pointer;
                    }
                #banner-section .hero-image:hover{
                    transform: translateY(-10px);
                    cursor: pointer;
                }
                #steps-section .hero-image:hover {
                filter: opacity(0.7);
                }
                #three-offers-section .d-flex-1{
                    transition: transform 250ms;
                }
                #three-offers-section .d-flex-1:hover{
                    transform: translatex(-15px);
                    cursor: pointer;
                }

                #three-offers-section .d-flex-2{
                    transition: transform 250ms;
                }
                #three-offers-section .d-flex-2:hover{
                    transform: translateY(-15px);
                    cursor: pointer;
                }


                #three-offers-section .d-flex-3{
                    transition: transform 250ms;
                }
                #three-offers-section .d-flex-3:hover{
                    transform: translateX(15px);
                    cursor: pointer;
                }
                #banner-section .banner-main-img:hover {
                    filter: grayscale(1);
                    cursor: pointer;
                }
    </style>
</head>

<body>
    @include('template.mobile_menu')
    @include('template.web_menu')
    <div class="text-center mt-3 bg-light-yellow" id="register-row">
        <a href="{{ url( app()->getLocale(), 'register') }}"> <span class="offer-text-head">
                Register now - Enjoy Welcome Rewards up to 1 BMK! ( for verified user)
            </span>
        </a>
    </div>

    <!-- banner section started -->
    <section class="pt-8 pb-8 bg-gradient-primary" id="banner-section">
        <div class="container">
            <div class="row align-items-center justify-content-center justify-content-md-between">
                <div class="col-12 col-lg-6 mb-8 text-center text-md-left text-white">
                    <h1 class="display-3 font-weight-bold">The most trusted &amp; secure crypto wallet</h1>
                    <p class="text-white-90 lead mb-4 banner-para">Buy, store, collect NFTs, exchange &amp; earn crypto.<br/>
                         Join 25 million+ people using Trust Wallet.</p>
                    <div class="download-button">
                        <div class="row download-button-group">
                            <div class="col-12 col-lg-4 apple-button">
                            <a href="#"><img loading="lazy" class="hero-image mx-auto d-block img-fluid" src="{{ asset('public/assets/img/app-store.svg') }}"
                        alt="Trust Wallet app">
                                </a>
                            </div>
                            <div class="col-12 col-lg-4 googleplay-button">
                            <a href="#"><img loading="lazy" class="hero-image mx-auto d-block img-fluid" src="{{ asset('public/assets/img/google_play.svg') }}"
                        alt="Trust Wallet app">
                                </a>
                            </div>
                            <div class="col-12 col-lg-4 androidapk-button">
                            <a href="#"><img loading="lazy" class="hero-image mx-auto d-block img-fluid" src="{{ asset('public/assets/img/window-10.svg') }}"
                        alt="Trust Wallet app">
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-lg-6 text-center">
                <img loading="lazy" class="mx-auto d-block img-fluid banner-main-img" src="{{ asset('public/assets/img/home_hero.png') }}"
                        alt="Trust Wallet app">
                </div>
            </div>
        </div>
    </section>
    <!-- banner section End -->

    <!-- three offers block start -->

    <section class="three-offers-block" id="three-offers-section">
        <div class="container">
            <div class="row border-bottom justify-content-center pt-4 pb-4">
                <div class="col-12 col-md-auto mr-auto d-flex d-flex-1 justify-content-center">
                    <div class="icon icon-xs">
                    <img loading="lazy" class="hero-image mx-auto d-block img-fluid" src="{{ asset('public/assets/img/buy-card.png') }}"
                        alt="Trust Wallet app">
                    </div>
                    <div class="ml-4">
                        <span class="font-weight-bold lead">
                            Buy Crypto With a Card
                        </span>
                    </div>
                </div>
                <div class="col-12 col-md-auto d-flex d-flex-2 justify-content-center">
                    <div class="icon icon-xs">
                    <img loading="lazy" class="hero-image mx-auto d-block  img-fluid" src="{{ asset('public/assets/img/exchange-icon.png') }}"
                        alt="Trust Wallet app">
                    </div>
                    <div class="ml-4">
                        <span class="font-weight-bold lead">
                            Exchange Instantly
                        </span>
                    </div>
                </div>
                <div class="col-12 col-md-auto ml-auto d-flex d-flex-3 justify-content-center">
                    <div class="icon icon-xs">
                    <img loading="lazy" class="hero-image mx-auto d-block img-fluid" src="{{ asset('public/assets/img/trust-secure-icon.png') }}"
                        alt="Trust Wallet app">
                    </div>
                    <div class="ml-4">
                        <span class="font-weight-bold lead">
                            Private &amp; Secure
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- three offers block end -->


    <!-- basic crypto info block start -->
    <section class="pt-8" id="crypto-info-section">
        <div class="container">
            <div class="row align-items-center justify-content-center justify-content-md-between">
                <div class="col-12 text-center mt-4 mt-md-0 order-md-2">
                    <h2 class="display-4 font-weight-bold mb-4">You Deserve Easy Access to Cryptocurrencies</h2>
                    <p class="lead text-gray-700">Trust Wallet is for you if you want to</p>
                </div>
            </div>
            <div class="row align-items-center justify-content-center justify-content-md-between pt-4 pb-4 text-center">
                <div class="col-12 col-lg-6">
                    <div class="list-group-item d-flex"><span class="check-icon"> </span>Buy Bitcoin in
                        under five minutes</div>
                    <div class="list-group-item d-flex"><span class="check-icon"></span>Easily earn
                        interest on the crypto in your wallet</div>
                    <div class="list-group-item d-flex"><span class="check-icon"></span>See your
                        collectibles. Art &amp; NFTs in one place</div>
                </div>
                <div class="col-12 col-lg-6">
                    <div class="list-group-item d-flex"><span class="check-icon"></span>Exchange your
                        crypto without leaving the app</div>
                    <div class="list-group-item d-flex"><span class="check-icon"></span>Track charts
                        and prices within the app</div>
                    <div class="list-group-item d-flex"><span class="check-icon"></span>Keep your
                        crypto safe from hackers &amp; scammers</div>
                </div>
                <a href="/download" class="btn btn-primary mt-6 mx-auto info-button crypto-download-btn">
                    Download Now
                </a>
            </div>
        </div>
    </section>
    <!-- basic crypto info block end -->

    <!-- About us  block start -->
    <section class="pt-8" id="about-us-section">
        <div class="container">
            <div class="row align-items-center justify-content-center justify-content-md-between">
                <div class="col-12 col-md-6 col-lg-5 text-center text-md-left mb-4 order-sm-first order-md-2">
                    <h2 class="display-4 font-weight-bold mt-4">Buy Crypto With a Card</h2>
                    <p class="lead text-gray-700">Get your first $50 of Bitcoin, Ethereum, Binance Coin and many other
                        cryptocurrencies.</p>
                </div>
                <div class="col-12 col-md-6 col-lg-7 img-hover2">
                <figure><img loading="lazy" class="hero-image mx-auto d-block img-fluid" src="{{ asset('public/assets/img/home_cards.png') }}"
                        alt="Trust Wallet app"> <figure>
                </div>
            </div>
            <div class="row align-items-center justify-content-center justify-content-md-between">
                <div class="col-12 col-md-6 col-lg-5 text-center text-md-left mb-4">
                    <h2 class="display-4 font-weight-bold mt-8">Exchange Instantly</h2>
                    <p class="lead text-gray-700">No forms, no selfies. Trade crypto anytime with ease.</p>
                </div>
                <div class="col-12 col-md-6 col-lg-7 img-hover3">
                <figure><img loading="lazy" class="hero-image mx-auto d-block img-fluid" src="{{ asset('public/assets/img/home_dex.png') }}"
                        alt="Trust Wallet app"></figure>
                </div>
            </div>
            <div class="row align-items-center justify-content-center justify-content-md-between">
                <div class="col-12 col-md-6 col-lg-5 order-sm-2 text-center text-md-left mb-4 order-md-2">
                    <h2 class="display-4 font-weight-bold mt-8">Private &amp; Secure</h2>
                    <p class="lead text-gray-700">Only you can access your wallet. We don’t collect any personal data.
                    </p>
                </div>
                <div class="col-12 col-md-6 col-lg-7 img-hover4">
                <figure> <img loading="lazy" class="hero-image mx-auto d-block img-fluid" src="{{ asset('public/assets/img/home_security.png') }}"
                        alt="Trust Wallet app"><figure>
                </div>
            </div>
            <div class="row align-items-center justify-content-center justify-content-md-between">
                <div class="col-12 col-md-6 col-lg-5 text-center text-md-left">
                    <h2 class="display-4 font-weight-bold mt-8">Browser for Apps</h2>
                    <p class="lead text-gray-700">Use your favourite decentralized apps &amp; find new ones, without
                        leaving your wallet.</p>
                </div>
                <div class="col-12 col-md-6 col-lg-7 img-hover5">
                <figure><img loading="lazy" class="hero-image mx-auto d-block img-fluid" src="{{ asset('public/assets/img/home_dapps.png') }}"
                        alt="Trust Wallet app"><figure>
                </div>
            </div>
        </div>
    </section>
    <!-- About us  block end -->


    <!-- Get Started in three steps start -->

    <section class="pt-8 pb-8 pt-sm-10 pb-sm-10" id="steps-section">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center mb-2">
                    <h3 class="display-4 font-weight-bold">
                        Get started in 3 simple steps
                    </h3>
                    <p class="lead text-gray-700">It only takes a few minutes</p>
                </div>
            </div>
            <div class="row no-gutters mt-8 mb-6 mb-md-7">
            <div class="col-12 col-md-4 text-center">
                    <div class="row step-row">
                    <a href="#"><img loading="lazy" class="hero-image mx-auto d-block img-fluid" src="{{ asset('public/assets/img/get-started-icon-1.png') }}"
                        alt="Trust Wallet app">
                                </a>

                    </div>
                    <h3 class="font-weight-bold">
                    Download Trust Wallet
                    </h3>
                </div>
                <div class="col-12 col-md-4 text-center">
                    <div class="row step-row">
                    <a href="#"><img loading="lazy" class="hero-image mx-auto d-block img-fluid" src="{{ asset('public/assets/img/get-started-icon-2.png') }}"
                        alt="Trust Wallet app">
                                </a>

                    </div>
                    <h3 class="font-weight-bold">
                        Create a new wallet
                    </h3>
                </div>
                <div class="col-12 col-md-4 text-center">
                    <div class="row step-row">
                    <a href="#"><img loading="lazy" class="hero-image mx-auto d-block img-fluid" src="{{ asset('public/assets/img/get-started-icon-3.png') }}"
                        alt="Trust Wallet app">
                                </a>
                    </div>
                    <h3 class="font-weight-bold">
                        Get some crypto
                    </h3>
                </div>
            </div>
            <div class="row">
                <div class="col-12 text-center">
                <a href="/download" class="btn btn-primary mt-6 mx-auto info-button crypto-download-btn">
                    Download Now
                </a>
                </div>
            </div>
        </div>
    </section>
    <!-- Get Started in three steps end -->

    <!-- Get the trust wallet app now section start -->
    <!-- <section class="bg-light" id="get-trust-app-section">
        <div class="container pt-8 pb-8">
            <div class="row align-items-center">
                <div class="col-12 col-md text-lg-left mt-2">
                    <h3 class="font-weight-bold mb-1">
                        Get the Trust Wallet app now!
                    </h3>
                    <p class="text-gray-700 mb-6 mb-md-0 no-whitespace">
                        The most trusted &amp; secure crypto wallet
                    </p>
                </div>
                <div class="col-12 col-lg-7">
                    <div class="download-button">
                        <div class="row download">
                        <div class="col-12 col-lg-4 appleapp">
                            <a href="#"><img loading="lazy" class="hero-image mx-auto d-block img-fluid" src="{{ asset('public/assets/img/app-store.svg') }}"
                        alt="Trust Wallet app">
                                </a>
                            </div>
                            <div class="col-12 col-lg-4 googleplay">
                            <a href="#"><img loading="lazy" class="hero-image mx-auto d-block img-fluid" src="{{ asset('public/assets/img/google_play.svg') }}"
                        alt="Trust Wallet app">
                                </a>
                            </div>
                            <div class="col-12 col-lg-4 androidapk">
                            <a href="#"><img loading="lazy" class="hero-image mx-auto d-block img-fluid" src="{{ asset('public/assets/img/window-10.svg') }}"
                        alt="Trust Wallet app">
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section> -->
    <!-- Get the trust wallet app now section end -->

    @include('template.country_language')
    @include('template.web_footer')
</body>

</html>