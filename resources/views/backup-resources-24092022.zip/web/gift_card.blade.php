<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <title>Wealth Mark | {{ Request::segment(2) }}</title>
    @include('template.web_css')
    <link rel='stylesheet' type='text/css' href="{{('public/assets/css/deepak_custom.css') }}">
    <style>
                .btn{
                    transition: transform 250ms;
                }
                .btn:hover{
                    transform: translateY(-05px);
                }
                /* Above is media query  for mobile device*/
                    @media(max-width:768px) {
                                        .gift-banner-section {
                                    padding: 81px 0!important;
                                }
                                #gift-section .position-relative {
                                position: relative!important;
                                }

                                #gift-section  .next-slide {
                                height: 65px!important;
                                width: 100%!important;
                                background-color: #263674;
                                text-align: center;
                                justify-content: center;
                                align-items: center;
                                display: flex;
                                color: white;
                                top: -80px!important;
                                right: 0!important;
                                z-index: 999;
                                }
                                #gift-section  .next-slide-2 {
                                height: 65px!important;
                                width: 100%!important;
                                background-color: #263674;
                                text-align: center;
                                justify-content: center;
                                align-items: center;
                                display: flex;
                                color: white;
                                top: -80px!important;
                                right: 0!important;
                                z-index: 99;
                                }
                                #gift-section  .next-slide-3 {
                                height: 65px!important;
                                width: 100%!important;
                                background-color: #263674;
                                text-align: center;
                                justify-content: center;
                                align-items: center;
                                display: flex;
                                color: white;
                                top: -80px!important;
                                right: 0!important;
                                z-index: 9;
                                }
                        
                            #gift-section .right-content-block {
                                margin: 20px!important;
                            }

                        #popular-card-section .col-md-3 {
                            margin-bottom: 10px;
                        }

                        #grow-business .left-content {
                            padding-top: 19.6%;
                            padding-left: 25px;
                            padding-right: 25px;
                        }

                        .popular-card-section .col-md-6 {
                            width: 50%;
                            float: none;
                        }

                        #My-card-section .col-md-6 {
                            width: 50%;
                            float: none;
                        }

                        #My-card-section h3 {
                            font-size: 1.75rem;
                        }

                        .available-gift-card img {
                            text-align: center;
                            max-width: 40%;
                            height: auto;
                            border-radius: 100px;
                            display: block;
                            margin: auto;
                        }

                        .available-gift-card h5 {
                            text-align: center;
                        }

                        #gift-section .nav-pills {
                            margin-bottom: 1rem !important;
                            margin: 0px!important;
                            padding: 17px 17px!important;
                        }
                        #banner-one h1{
                        font-size: 1.8rem!important;
                        }
                        #register-row {
                            background: #ffffff00 !important;
                            padding: 0px 15px;
                        }

                        #grow-business img {
                            max-width: 60%;
                            height: auto;
                            filter: sepia(1);
                            display: block;
                            margin: auto;
                        }
                            #banner-two h1 {
                            font-size: 1.8rem!important;
                            }
                        #banner-three h1 {
                        font-size: 1.8rem!important;
                        }

                        #banner-two  .position-absolute {
                        position: unset!important;
                        }
                        #banner-two .img-fluid {
                        max-width: 75%;
                        height: auto;
                        display: block;
                        margin: auto;
                        }
                        #banner-three .img-fluid {
                        max-width: 90%;
                        height: auto;
                        display: block;
                        margin: auto;
                        }
                    }
                    
                    @media(max-width:576px) {
                        #popular-card-section h3 {
                            font-size: 1rem!important;
                        }

                        #popular-card-section h4 {
                            font-size: 1rem!important;
                        }

                        #grow-business .left-content h1{
                            font-size: 1.5rem!important;
                            font-weight: bolder!important;
                        }
                        #My-card-section h3 {
                            font-size: 1rem;
                        }

                        #My-card-section h4 {
                            font-size: 1rem;
                        }

                        #faq-section h3 {
                            font-size: 1rem;
                        }

                        h1 {
                            font-size: 2rem !important;
                        }

                        #grow-business img {
                            max-width: 60%;
                            height: auto;
                            filter: sepia(1);
                            display: block;
                            margin: auto;
                        }

                    }

                    @media(device-width:1024px) and (device-height:1366px) {
                        #grow-business .left-content {
                            padding-top: 19.6%;
                            padding: 45px;
                        }

                        #grow-business img {
                            max-width: 60%;
                            height: auto;
                            filter: sepia(1);
                            display: block;
                            margin: auto;
                        }

                    }

                    @media(device-width:1024px) and (device-height:1366px) {
                        .col-md-6 {
                            width: 50%;
                            float: left !important
                        }

                        #grow-business img {
                            max-width: 60%;
                            height: auto;
                            filter: sepia(1);
                            display: block;
                            margin: auto;
                        }

                    }

                /* Above is media query  for mobile device*/



                #gift-section .col-md-6 {
                float: left;
                }

                h1 {
                font-size: 3rem !important;
                }

                #gift-section .gift-tabing-section {
                background-color: white;
                border-radius: 10px;
                }

                .gift-banner-section {
                padding: 60px 0;
                overflow: hidden;
                background-color: #fdcb0863;
                min-height: 680px;
                }

                #pills-tabContent .input-group-text {
                display: flex;
                align-items: center;
                padding: 0.375rem 0.75rem;
                font-size: 1rem;
                font-weight: 400;
                line-height: 1.5;
                color: #212529;
                text-align: center;
                white-space: nowrap;
                background-color: #263674;
                border: 1px solid #ced4da;
                border-radius: 0.25rem;
                color: white;
                }

                #gift-section .right-content-block {
                margin: 86px 40px;
                }

                .right-content-block img {
                border-radius: 10px;
                }

                #gift-section .nav-pills .nav-link.active,
                .nav-pills .show>.nav-link {
                color: #3e3e3e;
                background-color: #ffcb00a3;
                border: 1px solid #80808054;
                box-shadow: 0px 0px 1px 0.1px #4e4e4e;
                }

                #gift-section .nav-pills {
                margin-bottom: 1rem !important;
                margin: 15px;
                padding: 20px;
                }

                #gift-section div#pills-tabContent {
                margin: 0px 15px;
                padding: 0px 20px 20px 20px;
                }

                #gift-section .btn-primary {
                color: #fff;
                background-color: #263674;
                border-color: #263674;
                }

                .tab-pane p {
                font-size: 15px;
                }

                #gift-section .btn:hover {
                color: #c3c3c3 !important;
                }

                #popular-card-section h3 {
                font-size: 1.75rem;
                }

                #popular-card-section h4 {
                font-size: 1.5rem;
                }

                #popular-card-section h6 {
                text-align: center;
                padding: 5px;
                background-color: #fdcb0878;
                color: black;
                }

                .arrow-right {
                color: white;
                background-color: #e3bd31;
                border-radius: 40px;
                padding: 3px;
                font-weight: bold;
                cursor: pointer;
                }

                .view-all-btn {
                cursor: pointer;
                }

                #popular-card-section h5 {
                text-align: center;
                }

                #popular-card-section img {
                display: block;
                margin: auto;
                }

                .available-gift-card img {
                max-width: 35%;
                height: auto;
                border-radius: 100px;
                display: block;
                margin: auto;
                }

                div#added-gift-card {
                border: 1px dotted #dfdfdf;
                padding: 70px;
                border-radius: 20px;
                background-color: whitesmoke;
                }

                #grow-business .col-md-6 {
                float: left;
                }

                .faq-inner-block .col-md-6 {
                float: left;
                }

                #faq-section button.accordion-button:before {
                content: '\1F4B0 ';
                padding-right: 10px;
                }

                #faq-section .accordion-button:not(.collapsed) {
                color: #0c63e4;
                background-color: #f5be1557;
                box-shadow: inset 0 -1px 0 rgb(0 0 0 / 13%);
                color: #5e5e5e;
                }

                .accordion-item {
                border-top: 0px;
                border-left: 0px;
                border-right: 0px;
                margin: 10px 10px 10px 0px;
                }
                #faq-section .accordion-item {
                background-color: #fff;
                border-bottom: 1px dotted rgba(0,0,0,.125);
                }

                #faq-section .accordion-body {
                padding: 1rem 7px;
                }

                #faq-section h3 {
                font-size: 1.75rem;
                }

                #grow-business {
                padding: 0px;
                }

                .accordion-button:focus {
                border-color: #f58c33;
                }

                .accordion-button:focus {
                border-color: #f58c33;
                box-shadow: 0 0 0 0.25rem rgb(249 167 18 / 26%);
                }

                #added-gift-card h5 {
                text-align: center;
                }

                #grow-business img {
                max-width: 100%;
                height: auto;
                filter: sepia(1);
                }

                section#business-grow {
                background-color: #fdcb08;
                }

                #grow-business .left-content {
                padding-top: 9.6%;
                }

                #grow-business .learn-more-btn {
                color: white;
                background-color: #263674 !important;
                border-color: #263674 !important;
                }

                #grow-business .learn-more-btn:hover {
                color: #c3c3c3 !important;
                background-color: #263674 !important;
                border-color: #263674 !important;
                }

                .nav-pills .nav-link:hover {
                color: #3c3c3cd9 !important;
                }

                #grow-business img {
                max-width: 60%;
                height: auto;
                filter: sepia(1);
                display: block;
                margin: auto;
                }

                .next-slide {
                height: 700px;
                width: 150px;
                background-color: #263674;
                text-align: center;
                justify-content: center;
                align-items: center;
                display: flex;
                color: white;
                top: -60px;
                right: -312px;
                z-index: 999;
                }

                .next-slide-2 {
                height: 700px;
                width: 150px;
                background-color: #263674;
                text-align: center;
                justify-content: center;
                align-items: center;
                display: flex;
                color: white;
                top: -60px;
                right: -312px;
                z-index: 99;
                cursor: pointer;
                }
                .next-slide-3{
                height: 700px;
                width: 150px;
                background-color: #263674;
                text-align: center;
                justify-content: center;
                align-items: center;
                display: flex;
                color: white;
                top: -60px;
                right: -312px;
                z-index: 9;
                cursor: pointer;
                }
                .next-slide p {
                font-size: 16px;
                cursor: pointer;
                }

                .next-slide-2 p {
                font-size: 16px;
                cursor: pointer;
                }

                #banner-two{
                display:none;
                }
                #banner-three{
                display:none;
                }
                #banner-two .img-fluid {
                max-width: 75%;
                height: auto;
                }
                #banner-three .img-fluid {
                max-width: 90%;
                height: auto;
                }
                #banner-one .img-fluid {
                max-width: 80%;
                height: auto;
                display: block;
                margin: auto;
                }

                .next-slide-2{
                cursor: pointer;
                }
                .next-slide-3{
                cursor: pointer;
                }
                #gift-section #banner-three .right-content-block {
                margin: 86px 40px;
                }

                #My-card-section h3 {
                font-size: 1.75rem;
                }
                .available-gift-card img {
                max-width: 10%;
                height: auto;
                border-radius: 100px;
                display: block;
                margin: auto;
                }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/1.6.2/tailwind.min.css" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<script>
    $(document).ready(function(){
    $(".next-slide").click(function(){
        $("#banner-one").hide(1000);
        $(".next-slide-2").show(1000);
        $("#banner-two").show(1000);
        $(".next-slide").addClass("next-slide-2");
    });
    });
</script>

<script>
    $(document).ready(function(){
    $(".next-slide-2").click(function(){
    $(".next-slide-2").removeClass(".next-slide-2");
    $(".next-slide-2").addClass("next-slide-3");
    $("#banner-two").hide(1000);
    $("#banner-three").show(1000);
    });
    });
</script>

</head>
<body>
    @include('template.mobile_menu')
    @include('template.web_menu')
    <div class="text-center mt-3 bg-light-yellow" id="register-row">
        <a href="{{ url( app()->getLocale(), 'register') }}"> <span class="offer-text-head">
                Register now - Enjoy Welcome Rewards up to 1 BMK! ( for verified user)
            </span>
        </a>
    </div>
    <!-- gift banner section  start-->
    <section class="gift-banner-section" id="gift-section">
               <div class="container">

                     <div class="row">
                        <div class="col-md-12 position-relative">
                           <div class="next-slide position-absolute">
                                 <p> &#x2039; Send a Gift</p>
                           </div>
                           <div class="next-slide-2 position-absolute">
                                 <p> &#x2039; Transfer Crypto</p>
                           </div>
                           <div class="next-slide-3 position-absolute">
                                 <p> &#x2039; Binance Gift Card</p>
                           </div>
                        </div>
                     </div>

                     <div class="row">

                        <div class="banner-1" id="banner-one" >
                           <div class="col-md-6">
                                 <div class="left-content-block">
                                    <h1>Transfer Crypto <br />with Binance Gift Card </h1>
                                    <span>Send and receive crypto at zero fees </span><br />
                                    <a href="#" class="btn btn-primary mt-2">Transfer Crypto &#x2192; </a>
                                 </div>
                                 <div class="gift-tabing-section mt-5">
                                    <ul class="nav nav-pills" id="pills-tab" role="tablist">
                                       <li class="nav-item" role="presentation">
                                             <button class="nav-link active" id="pills-home-tab" data-bs-toggle="pill"
                                                data-bs-target="#pills-home" type="button" role="tab" aria-controls="pills-home"
                                                aria-selected="true">Redeem</button>
                                       </li>
                                       <li class="nav-item" role="presentation">
                                             <button class="nav-link" id="pills-profile-tab" data-bs-toggle="pill"
                                                data-bs-target="#pills-profile" type="button" role="tab"
                                                aria-controls="pills-profile" aria-selected="false">Add Card</button>
                                       </li>
                                       <li class="nav-item" role="presentation">
                                             <button class="nav-link" id="pills-contact-tab" data-bs-toggle="pill"
                                                data-bs-target="#pills-contact" type="button" role="tab"
                                                aria-controls="pills-contact" aria-selected="false">Check Card</button>
                                       </li>
                                    </ul>
                                    <div class="tab-content" id="pills-tabContent">
                                       <div class="tab-pane fade show active" id="pills-home" role="tabpanel"
                                             aria-labelledby="pills-home-tab">
                                             <div class="input-group mb-3">
                                                <input type="text" class="form-control"
                                                   placeholder="16 characters in digits and letters"
                                                   aria-label="Recipient's username" aria-describedby="basic-addon2">
                                                <a href="#" class="input-group-text" id="basic-addon2">Redeem</a>
                                             </div>
                                             <p>Binance is not responsible for, and assumes no liability to you for, any unlawful
                                                conduct or fraud by any third party associated with any Gift Card.<a href="#"
                                                   class="text-warning">View more </a></p>
                                       </div>
                                       <div class="tab-pane fade" id="pills-profile" role="tabpanel"
                                             aria-labelledby="pills-profile-tab">
                                             <div class="input-group mb-3">
                                                <input type="text" class="form-control"
                                                   placeholder="16 characters in digits and letters"
                                                   aria-label="Recipient's username" aria-describedby="basic-addon2">
                                                <a href="#" class="input-group-text" id="basic-addon2">Add Card</a>
                                             </div>
                                             <p>Binance is not responsible for, and assumes no liability to you for, any unlawful
                                                conduct or fraud by any third party associated with any Gift Card.<a href="#"
                                                   class="text-warning">View more </a></p>
                                       </div>
                                       <div class="tab-pane fade" id="pills-contact" role="tabpanel"
                                             aria-labelledby="pills-contact-tab">
                                             <div class="input-group mb-3">
                                                <input type="text" class="form-control"
                                                   placeholder="16 characters in digits and letters"
                                                   aria-label="Recipient's username" aria-describedby="basic-addon2">
                                                <a href="#" class="input-group-text" id="basic-addon2">Check Card</a>
                                             </div>
                                       </div>
                                    </div>
                                 </div>
                           </div>
                           <div class="col-md-6">
                                 <div class="right-content-block">
                                    <img src="{{ asset('public/assets/img/banner-img-1.png') }}" class="img-fluid" />
                                 </div>
                           </div>
                        </div>
                     
                           <div class="banner-2" id="banner-two">
                              <div class="col-md-6">
                                 <div class="left-content-block">
                                       <h1>Transfer Crypto <br />with Binance Gift Card </h1>
                                       <span>Send and receive crypto at zero fees </span><br />
                                       <a href="#" class="btn btn-primary mt-2">Transfer Crypto &#x2192; </a>
                                 </div>
                                 <div class="gift-tabing-section mt-5">
                                       <ul class="nav nav-pills" id="pills-tab" role="tablist">
                                          <li class="nav-item" role="presentation">
                                             <button class="nav-link active" id="pills-home-tab" data-bs-toggle="pill"
                                                   data-bs-target="#pills-home" type="button" role="tab" aria-controls="pills-home"
                                                   aria-selected="true">Redeem</button>
                                          </li>
                                          <li class="nav-item" role="presentation">
                                             <button class="nav-link" id="pills-profile-tab" data-bs-toggle="pill"
                                                   data-bs-target="#pills-profile" type="button" role="tab"
                                                   aria-controls="pills-profile" aria-selected="false">Add Card</button>
                                          </li>
                                          <li class="nav-item" role="presentation">
                                             <button class="nav-link" id="pills-contact-tab" data-bs-toggle="pill"
                                                   data-bs-target="#pills-contact" type="button" role="tab"
                                                   aria-controls="pills-contact" aria-selected="false">Check Card</button>
                                          </li>
                                       </ul>
                                       <div class="tab-content" id="pills-tabContent">
                                          <div class="tab-pane fade show active" id="pills-home" role="tabpanel"
                                             aria-labelledby="pills-home-tab">
                                             <div class="input-group mb-3">
                                                   <input type="text" class="form-control"
                                                      placeholder="16 characters in digits and letters"
                                                      aria-label="Recipient's username" aria-describedby="basic-addon2">
                                                   <a href="#" class="input-group-text" id="basic-addon2">Redeem</a>
                                             </div>
                                             <p>Binance is not responsible for, and assumes no liability to you for, any unlawful
                                                   conduct or fraud by any third party associated with any Gift Card.<a href="#"
                                                      class="text-warning">View more </a></p>
                                          </div>
                                          <div class="tab-pane fade" id="pills-profile" role="tabpanel"
                                             aria-labelledby="pills-profile-tab">
                                             <div class="input-group mb-3">
                                                   <input type="text" class="form-control"
                                                      placeholder="16 characters in digits and letters"
                                                      aria-label="Recipient's username" aria-describedby="basic-addon2">
                                                   <a href="#" class="input-group-text" id="basic-addon2">Add Card</a>
                                             </div>
                                             <p>Binance is not responsible for, and assumes no liability to you for, any unlawful
                                                   conduct or fraud by any third party associated with any Gift Card.<a href="#"
                                                      class="text-warning">View more </a></p>
                                          </div>
                                          <div class="tab-pane fade" id="pills-contact" role="tabpanel"
                                             aria-labelledby="pills-contact-tab">
                                             <div class="input-group mb-3">
                                                   <input type="text" class="form-control"
                                                      placeholder="16 characters in digits and letters"
                                                      aria-label="Recipient's username" aria-describedby="basic-addon2">
                                                   <a href="#" class="input-group-text" id="basic-addon2">Check Card</a>
                                             </div>
                                          </div>
                                       </div>
                                 </div>
                              </div>
                              <div class="col-md-6">
                                 <div class="right-content-block position-absolute top-25">
                                       <img src="{{ asset('public/assets/img/banner-img-2.png') }}" class="img-fluid mt-5" />
                                 </div>
                              </div>
                           </div>

                           <div class="banner-3" id="banner-three">
                              <div class="col-md-6">
                                 <div class="left-content-block">
                                       <h1>Transfer Crypto <br />with Binance Gift Card </h1>
                                       <span>Send and receive crypto at zero fees </span><br />
                                       <a href="#" class="btn btn-primary mt-2">Transfer Crypto &#x2192; </a>
                                 </div>
                                 <div class="gift-tabing-section mt-5">
                                       <ul class="nav nav-pills" id="pills-tab" role="tablist">
                                          <li class="nav-item" role="presentation">
                                             <button class="nav-link active" id="pills-home-tab" data-bs-toggle="pill"
                                                   data-bs-target="#pills-home" type="button" role="tab" aria-controls="pills-home"
                                                   aria-selected="true">Redeem</button>
                                          </li>
                                          <li class="nav-item" role="presentation">
                                             <button class="nav-link" id="pills-profile-tab" data-bs-toggle="pill"
                                                   data-bs-target="#pills-profile" type="button" role="tab"
                                                   aria-controls="pills-profile" aria-selected="false">Add Card</button>
                                          </li>
                                          <li class="nav-item" role="presentation">
                                             <button class="nav-link" id="pills-contact-tab" data-bs-toggle="pill"
                                                   data-bs-target="#pills-contact" type="button" role="tab"
                                                   aria-controls="pills-contact" aria-selected="false">Check Card</button>
                                          </li>
                                       </ul>
                                       <div class="tab-content" id="pills-tabContent">
                                          <div class="tab-pane fade show active" id="pills-home" role="tabpanel"
                                             aria-labelledby="pills-home-tab">
                                             <div class="input-group mb-3">
                                                   <input type="text" class="form-control"
                                                      placeholder="16 characters in digits and letters"
                                                      aria-label="Recipient's username" aria-describedby="basic-addon2">
                                                   <a href="#" class="input-group-text" id="basic-addon2">Redeem</a>
                                             </div>
                                             <p>Binance is not responsible for, and assumes no liability to you for, any unlawful
                                                   conduct or fraud by any third party associated with any Gift Card.<a href="#"
                                                      class="text-warning">View more </a></p>
                                          </div>
                                          <div class="tab-pane fade" id="pills-profile" role="tabpanel"
                                             aria-labelledby="pills-profile-tab">
                                             <div class="input-group mb-3">
                                                   <input type="text" class="form-control"
                                                      placeholder="16 characters in digits and letters"
                                                      aria-label="Recipient's username" aria-describedby="basic-addon2">
                                                   <a href="#" class="input-group-text" id="basic-addon2">Add Card</a>
                                             </div>
                                             <p>Binance is not responsible for, and assumes no liability to you for, any unlawful
                                                   conduct or fraud by any third party associated with any Gift Card.<a href="#"
                                                      class="text-warning">View more </a></p>
                                          </div>
                                          <div class="tab-pane fade" id="pills-contact" role="tabpanel"
                                             aria-labelledby="pills-contact-tab">
                                             <div class="input-group mb-3">
                                                   <input type="text" class="form-control"
                                                      placeholder="16 characters in digits and letters"
                                                      aria-label="Recipient's username" aria-describedby="basic-addon2">
                                                   <a href="#" class="input-group-text" id="basic-addon2">Check Card</a>
                                             </div>
                                          </div>
                                       </div>
                                 </div>
                              </div>
                              <div class="col-md-6">
                                 <div class="right-content-block pt-5 align-item-center">
                                       <img src="{{ asset('public/assets/img/banner-img-3.png') }}" class="img-fluid" />
                                 </div>
                              </div>
                           </div>
                     </div>
               </div>
    </section>
    <!-- gift banner section end -->


    <!-- popular cards section start -->
    <section class="popular-card-section" id="popular-card-section">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h3>Popular Cards </h3>
                </div>
                <div class="col-md-6">
                    <h4 class="float-right view-all-btn">View all cards &#x2192;</h4>
                </div>
            </div>
            <div class="row mt-3">
                <div class="col-md-3">
                    <img src="{{ asset('public/assets/img/popular-card-1.gif') }}"
                        class="img-fluid">
                    <h6>Popular Cards </h6>
                </div>
                <div class="col-md-3">
                    <img src="{{ asset('public/assets/img/popular-card-2.png') }}"
                        class="img-fluid">
                    <h6>Popular Cards </h6>
                </div>
                <div class="col-md-3">
                    <img src="{{ asset('public/assets/img/popular-card-3.png') }}"
                        class="img-fluid">
                    <h6>Popular Cards </h6>
                </div>
                <div class="col-md-3">
                    <img src="{{ asset('public/assets/img/popular-card-4.png') }}"
                        class="img-fluid">
                    <h6>Popular Cards </h6>
                </div>
            </div>
            <div class="row mt-4">
                <div class="col-md-3">
                    <img src="{{ asset('public/assets/img/popular-card-5.png') }}"
                        class="img-fluid">
                    <h6>Popular Cards </h6>
                </div>
                <div class="col-md-3">
                    <img src="{{ asset('public/assets/img/popular-card-6.png') }}"
                        class="img-fluid">
                    <h6>Popular Cards </h6>
                </div>
                <div class="col-md-3">
                    <img src="{{ asset('public/assets/img/popular-card-7.gif') }}"
                        class="img-fluid">
                    <h6>Popular Cards </h6>
                </div>
                <div class="col-md-3">
                    <img src="{{ asset('public/assets/img/popular-card-8.png') }}"
                        class="img-fluid">
                    <h6>Popular Cards </h6>
                </div>
            </div>
        </div>
    </section>
    <!-- popular cards section end -->


    <!-- My card Section -->
    <section class="My-card-section" id="My-card-section">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h3>My Cards</h3>
                </div>
                <div class="col-md-6">
                    <h3 class="float-right view-all-btn">All(0)&#x2192;</h3>
                </div>
            </div>
            <div class="row mt-3">
                <div class="col-md-12">
                    <div class="available-gift-card" id="added-gift-card">
                        <img src="{{ asset('public/assets/img/added-card-icon.jpg') }}" class="img-fluid">
                        <h5>No gift card availableCreate Gift Card</h5>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- My card Section -->


    <!-- grow-your-business section  start-->
    <section class="grow-your-business" id="business-grow">
        <div class="container">
            <div class="row">
                <div class="banner-1" id="grow-business">
                    <div class="col-md-6">
                        <div class="left-content">
                            <h1 class="mb-3">Grow your business with versatile crypto solutions</h1>
                            <span>Binance Code is a prepaid crypto voucher that enables your business to transfer and
                                exchange crypto outside of Binance, supported by API. Use cases include: Gift Card
                                reselling, loyalty and game rewards, e-commerce purchases and more. </span><br />
                            <a href="#" class="btn learn-more-btn mt-2">Learn More &#x2192; </a>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <img src="{{ asset('public/assets/img/grow-business-img.png') }}"class="img-fluid" />
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- grow-your-business section end -->


    <!-- FAQ section  start-->
    <section class="faq-block" id="faq-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h3>FAQ</h3>
                </div>
            </div>
            <div class="row">
                <div class="faq-inner-block" id="faq-inner-section">
                    <div class="col-md-6">
                        <div class="accordion" id="accordionPanelsStayOpenExample">

                            <div class="accordion-item">
                                <h2 class="accordion-header" id="panelsStayOpen-headingOne">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#panelsStayOpen-collapseOne" aria-expanded="false"
                                        aria-controls="panelsStayOpen-collapseOne">
                                        What is Binance GHow do I redeem a gift card?ift Card?
                                    </button>
                                </h2>
                                <div id="panelsStayOpen-collapseOne" class="accordion-collapse collapse"
                                    aria-labelledby="panelsStayOpen-headingOne">
                                    <div class="accordion-body">
                                        <strong>This is the second item's accordion body.</strong> It is hidden by
                                        default, until the collapse plugin adds the appropriate classes that we use to
                                        style each element. These classes control the overall appearance, as well as the
                                        showing and hiding via CSS transitions. You can modify any of this with custom
                                        CSS or overriding our default variables. It's also worth noting that just about
                                        any HTML can go within the <code>.accordion-body</code>, though the transition
                                        does limit overflow.
                                    </div>
                                </div>
                            </div>

                            <div class="accordion-item">
                                <h2 class="accordion-header" id="panelsStayOpen-headingTwo">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#panelsStayOpen-collapseTwo" aria-expanded="false"
                                        aria-controls="panelsStayOpen-collapseTwo">
                                        What is Binance GHow do I redeem a gift card?ift Card?
                                    </button>
                                </h2>
                                <div id="panelsStayOpen-collapseTwo" class="accordion-collapse collapse"
                                    aria-labelledby="panelsStayOpen-headingTwo">
                                    <div class="accordion-body">
                                        <strong>This is the second item's accordion body.</strong> It is hidden by
                                        default, until the collapse plugin adds the appropriate classes that we use to
                                        style each element. These classes control the overall appearance, as well as the
                                        showing and hiding via CSS transitions. You can modify any of this with custom
                                        CSS or overriding our default variables. It's also worth noting that just about
                                        any HTML can go within the <code>.accordion-body</code>, though the transition
                                        does limit overflow.
                                    </div>
                                </div>
                            </div>

                            <div class="accordion-item">
                                <h2 class="accordion-header" id="panelsStayOpen-headingThree">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#panelsStayOpen-collapseThree" aria-expanded="false"
                                        aria-controls="panelsStayOpen-collapseThree">
                                        Is there a Bitcoin gift card?
                                    </button>
                                </h2>
                                <div id="panelsStayOpen-collapseThree" class="accordion-collapse collapse"
                                    aria-labelledby="panelsStayOpen-headingThree">
                                    <div class="accordion-body">
                                        <strong>This is the third item's accordion body.</strong> It is hidden by
                                        default, until the collapse plugin adds the appropriate classes that we use to
                                        style each element. These classes control the overall appearance, as well as the
                                        showing and hiding via CSS transitions. You can modify any of this with custom
                                        CSS or overriding our default variables. It's also worth noting that just about
                                        any HTML can go within the <code>.accordion-body</code>, though the transition
                                        does limit overflow.
                                    </div>
                                </div>
                            </div>

                            <div class="accordion-item">
                                <h2 class="accordion-header" id="panelsStayOpen-headingfour">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#panelsStayOpen-collapseFour" aria-expanded="false"
                                        aria-controls="panelsStayOpen-collapseFour">
                                        Is there a Bitcoin gift card?
                                    </button>
                                </h2>
                                <div id="panelsStayOpen-collapseFour" class="accordion-collapse collapse"
                                    aria-labelledby="panelsStayOpen-headingFour">
                                    <div class="accordion-body">
                                        <strong>This is the third item's accordion body.</strong> It is hidden by
                                        default, until the collapse plugin adds the appropriate classes that we use to
                                        style each element. These classes control the overall appearance, as well as the
                                        showing and hiding via CSS transitions. You can modify any of this with custom
                                        CSS or overriding our default variables. It's also worth noting that just about
                                        any HTML can go within the <code>.accordion-body</code>, though the transition
                                        does limit overflow.
                                    </div>
                                </div>
                            </div>

                            <div class="accordion-item">
                                <h2 class="accordion-header" id="panelsStayOpen-headingfive">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#panelsStayOpen-collapseFive" aria-expanded="false"
                                        aria-controls="panelsStayOpen-collapseFive">
                                        What is Binance GHow do I redeem a gift card?ift Card?
                                    </button>
                                </h2>
                                <div id="panelsStayOpen-collapseFive" class="accordion-collapse collapse"
                                    aria-labelledby="panelsStayOpen-headingFive">
                                    <div class="accordion-body">
                                        <strong>This is the second item's accordion body.</strong> It is hidden by
                                        default, until the collapse plugin adds the appropriate classes that we use to
                                        style each element. These classes control the overall appearance, as well as the
                                        showing and hiding via CSS transitions. You can modify any of this with custom
                                        CSS or overriding our default variables. It's also worth noting that just about
                                        any HTML can go within the <code>.accordion-body</code>, though the transition
                                        does limit overflow.
                                    </div>
                                </div>
                            </div>

                            <div class="accordion-item">
                                <h2 class="accordion-header" id="panelsStayOpen-headingSix">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#panelsStayOpen-collapseSix" aria-expanded="false"
                                        aria-controls="panelsStayOpen-collapseSix">
                                        Is there a Bitcoin gift card?
                                    </button>
                                </h2>
                                <div id="panelsStayOpen-collapseSix" class="accordion-collapse collapse"
                                    aria-labelledby="panelsStayOpen-headingSix">
                                    <div class="accordion-body">
                                        <strong>This is the third item's accordion body.</strong> It is hidden by
                                        default, until the collapse plugin adds the appropriate classes that we use to
                                        style each element. These classes control the overall appearance, as well as the
                                        showing and hiding via CSS transitions. You can modify any of this with custom
                                        CSS or overriding our default variables. It's also worth noting that just about
                                        any HTML can go within the <code>.accordion-body</code>, though the transition
                                        does limit overflow.
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>


                    <div class="col-md-6">
                        <div class="accordion" id="accordionPanelsStayOpenExample">

                            <div class="accordion-item">
                                <h2 class="accordion-header" id="panelsStayOpen-headingTwo1">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#panelsStayOpen-collapseTwo1" aria-expanded="false"
                                        aria-controls="panelsStayOpen-collapseTwo1">
                                        What is Binance GHow do I redeem a gift card?ift Card?
                                    </button>
                                </h2>
                                <div id="panelsStayOpen-collapseTwo1" class="accordion-collapse collapse"
                                    aria-labelledby="panelsStayOpen-headingTwo1">
                                    <div class="accordion-body">
                                        <strong>This is the second item's accordion body.</strong> It is hidden by
                                        default, until the collapse plugin adds the appropriate classes that we use to
                                        style each element. These classes control the overall appearance, as well as the
                                        showing and hiding via CSS transitions. You can modify any of this with custom
                                        CSS or overriding our default variables. It's also worth noting that just about
                                        any HTML can go within the <code>.accordion-body</code>, though the transition
                                        does limit overflow.
                                    </div>
                                </div>
                            </div>

                            <div class="accordion-item">
                                <h2 class="accordion-header" id="panelsStayOpen-headingTwo2">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#panelsStayOpen-collapseTwo2" aria-expanded="false"
                                        aria-controls="panelsStayOpen-collapseTwo2">
                                        What is Binance GHow do I redeem a gift card?ift Card?
                                    </button>
                                </h2>
                                <div id="panelsStayOpen-collapseTwo2" class="accordion-collapse collapse"
                                    aria-labelledby="panelsStayOpen-headingTwo2">
                                    <div class="accordion-body">
                                        <strong>This is the second item's accordion body.</strong> It is hidden by
                                        default, until the collapse plugin adds the appropriate classes that we use to
                                        style each element. These classes control the overall appearance, as well as the
                                        showing and hiding via CSS transitions. You can modify any of this with custom
                                        CSS or overriding our default variables. It's also worth noting that just about
                                        any HTML can go within the <code>.accordion-body</code>, though the transition
                                        does limit overflow.
                                    </div>
                                </div>
                            </div>


                            <div class="accordion-item">
                                <h2 class="accordion-header" id="panelsStayOpen-headingThree3">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#panelsStayOpen-collapseThree3" aria-expanded="false"
                                        aria-controls="panelsStayOpen-collapseThree3">
                                        Is there a Bitcoin gift card?
                                    </button>
                                </h2>
                                <div id="panelsStayOpen-collapseThree3" class="accordion-collapse collapse"
                                    aria-labelledby="panelsStayOpen-headingThree3">
                                    <div class="accordion-body">
                                        <strong>This is the third item's accordion body.</strong> It is hidden by
                                        default, until the collapse plugin adds the appropriate classes that we use to
                                        style each element. These classes control the overall appearance, as well as the
                                        showing and hiding via CSS transitions. You can modify any of this with custom
                                        CSS or overriding our default variables. It's also worth noting that just about
                                        any HTML can go within the <code>.accordion-body</code>, though the transition
                                        does limit overflow.
                                    </div>
                                </div>
                            </div>

                            <div class="accordion-item">
                                <h2 class="accordion-header" id="panelsStayOpen-headingThree4">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#panelsStayOpen-collapseThree4" aria-expanded="false"
                                        aria-controls="panelsStayOpen-collapseThree4">
                                        Is there a Bitcoin gift card?
                                    </button>
                                </h2>
                                <div id="panelsStayOpen-collapseThree4" class="accordion-collapse collapse"
                                    aria-labelledby="panelsStayOpen-headingThree4">
                                    <div class="accordion-body">
                                        <strong>This is the third item's accordion body.</strong> It is hidden by
                                        default, until the collapse plugin adds the appropriate classes that we use to
                                        style each element. These classes control the overall appearance, as well as the
                                        showing and hiding via CSS transitions. You can modify any of this with custom
                                        CSS or overriding our default variables. It's also worth noting that just about
                                        any HTML can go within the <code>.accordion-body</code>, though the transition
                                        does limit overflow.
                                    </div>
                                </div>
                            </div>


                            <div class="accordion-item">
                                <h2 class="accordion-header" id="panelsStayOpen-headingTwo5">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#panelsStayOpen-collapseTwo5" aria-expanded="false"
                                        aria-controls="panelsStayOpen-collapseTwo5">
                                        What is Binance GHow do I redeem a gift card?ift Card?
                                    </button>
                                </h2>
                                <div id="panelsStayOpen-collapseTwo5" class="accordion-collapse collapse"
                                    aria-labelledby="panelsStayOpen-headingTwo5">
                                    <div class="accordion-body">
                                        <strong>This is the second item's accordion body.</strong> It is hidden by
                                        default, until the collapse plugin adds the appropriate classes that we use to
                                        style each element. These classes control the overall appearance, as well as the
                                        showing and hiding via CSS transitions. You can modify any of this with custom
                                        CSS or overriding our default variables. It's also worth noting that just about
                                        any HTML can go within the <code>.accordion-body</code>, though the transition
                                        does limit overflow.
                                    </div>
                                </div>
                            </div>


                            <div class="accordion-item">
                                <h2 class="accordion-header" id="panelsStayOpen-headingThree6">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#panelsStayOpen-collapseThree6" aria-expanded="false"
                                        aria-controls="panelsStayOpen-collapseThree6">
                                        Is there a Bitcoin gift card?
                                    </button>
                                </h2>
                                <div id="panelsStayOpen-collapseThree6" class="accordion-collapse collapse"
                                    aria-labelledby="panelsStayOpen-headingThree6">
                                    <div class="accordion-body">
                                        <strong>This is the third item's accordion body.</strong> It is hidden by
                                        default, until the collapse plugin adds the appropriate classes that we use to
                                        style each element. These classes control the overall appearance, as well as the
                                        showing and hiding via CSS transitions. You can modify any of this with custom
                                        CSS or overriding our default variables. It's also worth noting that just about
                                        any HTML can go within the <code>.accordion-body</code>, though the transition
                                        does limit overflow.
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- FAQ section end -->
    
    @include('template.country_language')
    @include('template.web_footer')
</body>

</html>