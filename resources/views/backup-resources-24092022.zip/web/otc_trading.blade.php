  <!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
   <head>
      <meta charset="utf-8">
      <meta content="width=device-width, initial-scale=1.0" name="viewport">
      <title>Wealth Mark | Create Entity Account</title>
  @include('template.web_css')
      
  
 <style>
     #header{
         background:white;
         
     }


.otc-trading-top{
    background:url('https://wealthmark.io/beta-dlp/public/assets/img/bg-8.png') !important;
}


 </style>
  
  
   </head>
   
 <body class="bg-white">
     
     @include('template.mobile_menu')
        @include('template.web_menu')
    
      <section id="hero" class="breadcrumbs shadow otc-trading-top">
          <div class="container-fluid mt-3">
              <div class="row">
                 <div class="col-lg-4 offset-lg-1 d-flex flex-column justify-content-center pt-lg-0 order-2 order-lg-1" data-aos="fade-up" data-aos-delay="200">
                 <h3 class="top-heading">Buy, trade, and hold 100+ cryptocurrencies</h3>
                 <p class="top-p">Sign up now to build your own portfolio</p>
                 <div>
                     <a href="#" class="btn btn-blue shadow"> Sign up</a>
                 </div>
                 </div>
                 <div class="col-lg-5 offset-lg-1 order-1 order-lg-2 hero-img" data-aos="zoom-in" data-aos-delay="200">
                    <img src="{{ asset('public/assets/img/graphic-1-01.svg') }}" class="img-fluid animated" alt="" style="width:100%">
                 </div>
              </div>
           </div>
      </section>
      
      <!-- Demo header-->
<section class="py-5 otc-trading">
    <div class="container py-4">
       
        <div class="row">
            <div class="col-md-12  col-sm-12">
                <div class="sec-title text-center">
                            <span class="title">Welcome to Wealthmark</span>
                            <h2 class="heading-h2">OTC Trading Terms</h2>
                        </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-3">
                <!-- Tabs nav -->
                <div class="nav flex-column nav-pills nav-pills-custom" id="v-pills-tab" role="tablist" aria-orientation="vertical">
                    <a class="nav-link mb-3 p-3  active" id="v-pills-home-tab" data-toggle="pill" href="#v-pills-home" role="tab" aria-controls="v-pills-home" aria-selected="true">
                        <i class="fa fa-user-circle-o mr-2"></i>
                        <span class="font-weight-bold small text-uppercase">Acceptance of Wealthmark OTC Terms</span></a>

                    <a class="nav-link mb-3 p-3 " id="v-pills-profile-tab" data-toggle="pill" href="#v-pills-profile" role="tab" aria-controls="v-pills-profile" aria-selected="false">
                        <i class="fa fa-calendar-minus-o mr-2"></i>
                        <span class="font-weight-bold small text-uppercase">Wealthmark OTC Services in General</span></a>

                    <a class="nav-link mb-3 p-3 " id="v-pills-messages-tab" data-toggle="pill" href="#v-pills-messages" role="tab" aria-controls="v-pills-messages" aria-selected="false">
                        <i class="fa fa-star mr-2"></i>
                        <span class="font-weight-bold small text-uppercase">OTC Services</span></a>

                    <a class="nav-link mb-3 p-3 " id="v-pills-settings-tab" data-toggle="pill" href="#v-pills-settings" role="tab" aria-controls="v-pills-settings" aria-selected="false">
                        <i class="fa fa-check mr-2"></i>
                        <span class="font-weight-bold small text-uppercase">Fees</span>
                    </a>
                    <a class="nav-link mb-3 p-3 " id="v-pills-Representations-and-Warranties-tab" data-toggle="pill" href="#v-pills-Representations-and-Warranties" role="tab" aria-controls="v-pills-Representations-and-Warranties" aria-selected="false">
                        <i class="fa fa-check mr-2"></i>
                        <span class="font-weight-bold small text-uppercase">Representations and Warranties</span>
                    </a>
                    <a class="nav-link mb-3 p-3 " id="v-pills-Limitation-tab" data-toggle="pill" href="#v-pills-Limitation" role="tab" aria-controls="v-pills-Limitation" aria-selected="false">
                        <i class="fa fa-check mr-2"></i>
                        <span class="font-weight-bold small text-uppercase">Limitation of Liability</span>
                    </a>
                    
                    
                    </div>
            </div>


            <div class="col-md-9">
                <!-- Tabs content -->
                <div class="tab-content" id="v-pills-tabContent">
                    
                    <div class="tab-pane fade  rounded bg-white show active p-5 scrollbar-style" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab">
                        <h4 class="mb-4">1. Acceptance of Wealthmark OTC Terms</h4>
                       <div class="text">By accessing and using the OTC services provided by Wealthmark (“OTC Services”) you agree to accept and comply with the terms and conditions stated below (“OTC Terms”). You further agree and understand that these OTC Terms are subject to the terms and conditions set forth in the Wealthmark Terms of Use. You should read the entire OTC Terms, together with the Wealthmark Terms of Use, carefully before accessing and using the OTC Services. In case of discrepancies between Wealthmark Terms of Use and these OTC Terms, these OTC Terms shall prevail. These OTC Terms govern your use of the OTC services provided by Wealthmark, which are described in greater detail herein. These OTC Terms are a prerequisite for your access to the OTC Services and you agree that you have read, understood, and accepted all of these OTC Terms contained herein.</div>
                    
          <div class="text">          As used in these OTC Terms, “Wealthmark” may refer to its owners, directors, investors, affiliates and employees.
     </div><div class="text">“Wealthmark” in each case refers to the entity which you are the customer of. Depending upon the context, “Wealthmark” may also refer to the services, products, website, content or other materials (collectively “Wealthmark Services”) provided by each respective entity listed above to you as its customer.
     </div><div class="text">Depending on your place of residence, you may not be able to use OTC Services, or your use may be limited. It is your responsibility to follow the rules and regulations applicable in your place of residence and/or place from which you access OTC Services. As long as you agree to and comply with the present OTC Terms as well as the Wealthmark Terms of Use, Wealthmark grants you a personal, non-exclusive, non-transferable, non-sub licensable and limited right to enter the Wealthmark platform and use OTC Services.
     </div><div class="text">Wealthmark reserves the right to change, add or remove parts of these OTC Terms at any time and at its sole discretion. You will be notified of any changes in advance through your Account. Upon such notification, it is your responsibility to review the amended OTC Terms. Your continued usage of OTC Services following the posting of a notice of changes to the OTC Terms signifies that you accept and agree to the changes, and that all subsequent actions by you will be subject to the amended OTC Terms.
     </div><div class="text">All capitalized terms in these OTC Terms shall have the same meaning as ascribed to them in the relevant Wealthmark Terms of Use.
     </div><div class="text">THIS OTC TERMS ARE A LEGAL CONTRACT BETWEEN YOU AND WEALTHMARK. YOU SHOULD TREAT IT AS ANY OTHER LEGAL CONTRACT BY READING ITS PROVISIONS CAREFULLY, AS THEY WILL AFFECT YOUR LEGAL RIGHTS. BY USING THE OTC SERVICES IN ANY MANNER, YOU ARE DEEMED TO HAVE READ, UNDERSTOOD AND AGREED TO BE BOUND BY ALL OF THE TERMS CONTAINED IN THESE OTC TERMS. YOU MAY NOT PICK AND CHOOSE WHICH TERMS APPLY TO YOU. IF YOU DO NOT AGREE WITH ALL OF THE TERMS IN THESE OTC TERMS, YOU MUST CEASE ALL ACCESS AND USE OF THE OTC SERVICES. NOTHING IN THESE OTC TERMS IS INTENDED TO CREATE ANY ENFORCEMENT RIGHTS BY THIRD PARTIES. IF YOU DO NOT UNDERSTAND ALL OF THE TERMS AND CONDITIONS IN THESE OTC TERMS, YOU SHOULD CONSULT WITH A LAWYER BEFORE USING THE OTC SERVICES.
     </div>
                    
                    </div>
                    
                    <div class="tab-pane fade  rounded bg-white p-5 scrollbar-style" id="v-pills-profile" role="tabpanel" aria-labelledby="v-pills-profile-tab">
                        <h4 class=" mb-4">Wealthmark OTC Services in General</h4>
                   
                        <div class="text">    Wealthmark OTC Services are part of the Wealthmark platform that enables you to enter into over-the-counter Virtual Assets or Digital Assets purchase and sale transactions (“OTC Transaction”) without being subject to the trading rules of Wealthmark exchange and its central limit order book.
    </div> <div class="text"> OTC Services are provided to you on a request for quote basis (“OTC RFQ”) through a third-party software provider by entering into a transaction with Wealthmark’s liquidity providers (“OTC Counterparty”). You can access the OTC Services through your Account within the Wealthmark platform (“OTC Interface”).
     </div><div class="text">Wealthmark does not operate an OTC trading desk but is partnering up with OTC Counterparties to offer a self-service OTC product to Wealthmark clients. Wealthmark is solely providing the OTC Interface in order to enable OTC Services and facilitate Transactions between the Wealthmark clients and OTC Counterparties.
   </div>
                    </div>
                    
                    
                    
                    <div class="tab-pane fade  rounded bg-white p-5 scrollbar-style" id="v-pills-messages" role="tabpanel" aria-labelledby="v-pills-messages-tab">
                        <h4 class=" mb-4">OTC Services</h4>
                  
                <div class="text">     OTC Services will be available to you by default for Virtual Assets or Digital Assets where OTC trading functionality is available. OTC Services are provided on a pre-trade basis and require the full amount of relevant Virtual Assets or Digital Assets and/or fiat currency before requesting the quote for buying and/or selling Virtual Assets or Digital Assets over-the-counter (“Quote”). OTC Services may be subject to limitations and the minimum amount to be able to access OTC Services may apply.
</div> <div class="text">  Trading through the OTC Services will be anonymous, and Wealthmark has policies and procedures reasonably designed to prevent the disclosure of your identity to any OTC Counterparty and vice versa. However, if ever Wealthmark or an affiliate of Wealthmark is the OTC Counterparty in a Transaction, disclosure that Wealthmark is acting as a principal in the Transaction will be made to you.
 </div><div class="text">  All communications related to the OTC Services (e.g., response to a Quote, Quote status, Transaction confirmation) is provided using the OTC Interface. Any other methods of communications used for OTC Services (e.g., instant message conversation, oral communications, emails) may be mutually agreed upon between you and Wealthmark
</div>
                  
                  <h4 class="mb-4">a) Quote</h4>
                  <div class="text">You may submit a request for a Quote (“Quote Request”) through the OTC Interface. In response to your Quote Request, Wealthmark will request a Quote from one or more OTC Counterparties and provide you with a Quote. A Quote received is valid for a specific amount of time as shown in the OTC Interface. You may accept or reject the Quote. Any negotiation about the specific Quote is not possible.</div>
                  <div class="text">When you accept the Quote (“Accepted Quote”), the Transaction is pending until the terms of the Transaction are confirmed by the OTC Counterparty. Your Accepted Quote does not constitute any binding agreement and can be rejected by Wealthmark or the OTC Counterparty. The Transaction status is provided through the OTC Interface</div>
                  <div class="text">You agree that Wealthmark may, in its sole and absolute discretion, determine whether to process or decline to process a Quote Request, Quote, Accepted Quote or any other response to a Quote.</div>
                    <h4 class="mb-4">b) Execution</h4>
                  <div class="text">When the Accepted Quote is confirmed by the OTC Counterparty (“Confirmed Quote”), the Transaction is confirmed and becomes binding and final (the “Execution”). A Transaction for which Execution has occurred is an executed Transaction (the “Executed Transaction”) and may not be unwound unless all parties of the Transaction agree in writing otherwise and/or explicitly stated otherwise in these OTC Terms. Upon Execution, the terms of the Executed Transaction shall constitute a binding contract between you and the other relevant OTC Counterparty.</div>
                  <div class="text">However, if Wealthmark determines in its sole and absolute discretion that 
               <ul class="docx-ul">
                   <li> (i) a Quote provided to you by Wealthmark, </li>
                    <li>(ii) Accepted Quote communicated to an OTC Counterparty and/or</li>
                     <li> (iii) Confirmed Quote contained an obvious error with respect to the terms, including but not limited to the price or amount of Virtual Assets or Digital Assets, set forth in that Quote, Accepted Quote and/or Confirmed Quote, Wealthmark shall have the right to cancel the Transaction by delivering notice of the cancellation to you and the OTC Counterparty at any time prior to Settlement (as defined in point 3.c) (“Transaction Cancellation”). In the absence of such an obvious error, the terms of a Quote accepted by you (Accepted Quote) and confirmed by the OTC Counterparty (Confirmed Quote) shall be conclusive
                </li>
               </ul>  
                   
                   </div>
                  
                     <h4 class="mb-4">c) Settlement</h4>
                    
                    <div class="text">Wealthmark will settle an Executed Transaction with you after the Execution by delivering the Virtual Assets or Digital Assets and/or fiat currencies owed to you under the Executed Transaction to your Account/wallet (“Settlement”) on Wealthmark website as the circumstances warrant. The Settlement depends on the settlement of the OTC Counterparty and it occurs when the OTC Counterparty settle the Executed Transaction. In such capacity Wealthmark is acting as an agent and reserves the right to delay the Settlement. You will be notified of the approximate but non-binding settlement time through the OTC Interface before you accept the Quote. However, Wealthmark has a right to directly settle the Executed Transaction from time to time and in that case Wealthmark is acting as a principal.</div>
                    <div class="text">OTC Counterparty settles the Executed Transaction in accordance with the terms agreed with Wealthmark. If OTC Counterparty fails to settle the Executed Transaction, Wealthmark reserves the right to reverse the Executed Transaction and you bear the risk of the settlement failure. When Wealthmark is acting as a principal, Wealthmark bears the risk of settlement failure.</div>
                    <div class="text">You shall not withdraw, attempt to withdraw, transfer, alienate or provide a lien to any third party on any Virtual Assets or Digital Asset or fiat currency held on your Account to satisfy your obligation under any Executed Transaction. Wealthmark will not be responsible for any failure to settle in accordance with the timing set out above as a result of technological failures such as the internet going down and being unavailable.</div>
                    <div class="text">You acknowledge and accept that in case of the Transaction Cancellation the Settlement does not occur and neither Wealthmark, a Wealthmark affiliate nor a respective OTC Counterparty is liable for any losses incurred as a result of the failure to settle the Executed Transaction.</div>
                    <div class="text">Notwithstanding the foregoing, Wealthmark reserves the right to reasonably determine whether an extraordinary event occurred that results in Wealthmark’s inability to honor the Executed Transaction. These events include, but are not limited to identified system failure, data feed error, interruption, delay, non-settlement by the OTC Counterparty, force majeure, or other circumstances. Wealthmark undertakes to immediately notify you about the extraordinary event resulting in the inability to honor the Executed Transaction. After such notification has been sent by Wealthmark, you agree that Wealthmark will not be required to honor the Executed Transaction and that any Executed Transaction affected by the extraordinary event is null and void. In case of extraordinary event from this paragraph, Wealthmark acts as an agent toward you, and you bear the risk of the settlement failure.</div>
                    
                    
                    
                    
                    
                    
                    
                    </div>
                    
                    <div class="tab-pane fade  rounded bg-white p-5 scrollbar-style" id="v-pills-settings" role="tabpanel" aria-labelledby="v-pills-settings-tab">
                        <h4 class=" mb-4">4. Fees </h4>
                       <div class="text">OTC Services and specifically the Quotes are offered on the basis of a variable spread. Due to the volatile nature of Virtual Assets or Digital Assets, a typical spread cannot be determined in these OTC Terms, the OTC Interface or on the Wealthmark platform.</div>
                    </div>
                    
                    <div class="tab-pane fade  rounded bg-white p-5" id="v-pills-Representations-and-Warranties" role="tabpanel" aria-labelledby="v-pills-Representations-and-Warranties-tab">
                        <h4 class=" mb-4">5. Representations and Warranties </h4>
                       <div class="text">You acknowledge and agree that when entering Transactions, you will be transacting for your own account, and in an arm’s-length role in relation to Wealthmark </div>
                       <div class="text">Wealthmark employs measures to ensure that OTC Services are accessible at all times without interruption. Notwithstanding this, Wealthmark cannot guarantee uninterrupted or error-free operation of OTC Services, or that Wealthmark will correct all defects or prevent third-party disruptions or unauthorized third-party access. In the event of such disruptions, OTC Services may not be accessible in part or in full. </div>
                       <div class="text">Wealthmark makes no representations and warranties and makes no guarantees that any particular Virtual Assets or Digital Assets will be available for OTC trading on a continuous basis. Wealthmark reserves the right, at any time, with or without cause or prior notice, at its sole discretion to limit, suspend, or terminate all or part of the OTC Services or your access to the OTC Services and/or OTC Interface. </div>
                       <div class="text">For the avoidance of doubt, Wealthmark shall not have any obligation to send any received Quote Request and/or Accepted Quote to prospective OTC Counterparties. You understand that you are solely responsible for maintaining any alternative arrangements that may be needed or desirable if any or all of the OTC Services becomes unavailable or disrupted </div>
                       <div class="text"><b>WEALTHMARK MAKES NO REPRESENTATION OR WARRANTY THAT OTC SERVICES AS SUCH ARE APPROPRIATE FOR USE IN ALL LOCATIONS, OR THAT THE TRANSACTIONS AND SERVICES DESCRIBED HEREIN ARE AVAILABLE OR APPROPRIATE FOR ENTRY INTO OR USE IN ALL JURISDICTIONS OR BY ALL PARTIES. YOU SHOULD INFORM YOURSELF AS TO THE LEGAL REQUIREMENTS AND TAX CONSEQUENCES OF USING OTC SERVICES WITHIN ALL JURISDICTIONS APPLICABLE TO YOU. WEALTHMARK IS NOT RESPONSIBLE FOR TAX CONSEQUENCES TO YOU THAT ARISE BECAUSE OF USING OTC SERVICES PROVIDED BY WEALTHMARK</b> </div>
                       
                    </div>
                    <div class="tab-pane fade  rounded bg-white p-5 scrollbar-style" id="v-pills-Limitation" role="tabpanel" aria-labelledby="v-pills-Limitation-tab">
                        <h4 class=" mb-4">Limitation of Liability </h4>
                       <div class="text">For the avoidance of doubt, the disclaimers of warranty, limitation of liability and indemnification and releases set out in the Wealthmark Terms of Use shall cover the OTC Services, and these OTC Terms and the Wealthmark Terms of Use shall be interpreted accordingly</div>
                       
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

      
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/js/bootstrap.bundle.min.js"></script>
      
  @include('template.country_language')
    @include('template.web_footer') 
      

  
    </body>
</html>