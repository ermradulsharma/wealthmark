
<!DOCTYPE html><html lang="en">
<head>
<meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>Buy, trade, and hold 100+ cryptocurrencies on Wealthmark</title>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css">
     @include('template.web_css')
</head>
<body>

    @include('template.top_header')
    <section id="hero" class="align-items-center">
        @include('template.mobile_menu')
        @include('template.web_menu')

      
      
      
        <div class="container-fluid">
            <div class="row justify-content-between">
                <div class="col-lg-12 text-center mt-3">
                <a href="{{ url( app()->getLocale(), 'register') }}">    <span class="offer-text-head">
                    Register now - Enjoy Welcome Rewards up to 1 BMK! ( for verified user) 
                    </span>
                    </a>
                </div>
            </div>
        </div>
        
        <div class="container-fluid mt-3">
          <div class="row">
            <div class="col-lg-4 offset-lg-1 d-flex flex-column justify-content-center pt-lg-0 order-2 order-lg-1" data-aos="fade-up" data-aos-delay="200">
         
        			<div class="testimonial_slider_2">
        				<input type="radio" name="slider_2" id="slide_2_1" checked />
        				<input type="radio" name="slider_2" id="slide_2_2" />
        				<input type="radio" name="slider_2" id="slide_2_3" />
        				<input type="radio" name="slider_2" id="slide_2_4" />
        				<div class="boo_inner clearfix">
        					<div class="slide_content">
        						<div class="testimonial_2">
        							<div class="content_2">
        						    <h1> Buy, trade, and hold 100+ cryptocurrencies</h1>
                             <h2>Sign up now to build your own portfolio</h2>	</div>
        						
        						</div>
        					</div>
        					<div class="slide_content">
        						<div class="testimonial_2">
        							<div class="content_2">
        						    <h1> WealthMark is most Trusted Crypto Exchange</h1>
                                    <h2>Investing in crypto will be easier than ever</h2>	</div>
        						
        						</div>
        					</div>
        					<div class="slide_content">
        						<div class="testimonial_2">
        							<div class="content_2">
        						    <h1> WealthMark is an easy and secure digital wallet trusted by millions</h1>
                             <h2>Digital assets under your control</h2>	</div>
        						
        						</div>
        					</div>
        					<div class="slide_content">
        						<div class="testimonial_2">
        							<div class="content_2">
        						    <h1> Trusted by customers from more than 100 countries</h1>
                                     <h2>The easiest way to start your crypto Lifestyle</h2>	</div>
        							<!--<div class="author_2">-->
        							<!--	<h3>Lee Barker</h3>-->
        							<!--	<h4>President and Professor of Ministry, Meadville Lombard Theological School</h4>-->
        							<!--</div>-->
        						</div>
        					</div>
        				</div>
        				<div id="controls">
        					<label class="myslider" for="slide_2_1"></label>
        					<label class="myslider"  for="slide_2_2"></label>
        					<label class="myslider"  for="slide_2_3"></label>
        					<label class="myslider"  for="slide_2_4"></label>
        				</div>
        			</div>
                 </div>
        
            <div class="col-lg-5 offset-lg-1 order-1 order-lg-2 hero-img" data-aos="zoom-in" data-aos-delay="200">
              <img src="{{ asset('public/assets/img/graphic-1-01.svg') }}" class="img-fluid animated w-100" alt="" >
            </div>
          </div>
        </div>
    </section><!-- End Hero -->








<section id="features" class="features-area item-full  cell-items default-padding">
   <div class="container-fluid">
      <div class="row features-items">
         <div class="col-md-4 col-sm-6 equal-height">
            <div class="item">
               <div class="icon">
                  <img src="{{ asset('public/assets/wealthmark_new/img/create-an-account.svg') }}">
               </div>
               <div class="info">
                  <h4>Create an account</h4>
                  <p>Sign up with your email and mobile in just 5 minutes
                  </p>
               </div>
            </div>
         </div>
         <div class="col-md-4 col-sm-6 equal-height">
            <div class="item">
               <div class="icon">
                  <img src="{{ asset('public/assets/wealthmark_new/img/add-funds.svg') }}">
               </div>
               <div class="info">
                  <h4>Add funds to wallet</h4>
                  <p>Quick add money to your WealthMark investment wallet
                  </p>
               </div>
            </div>
         </div>
         <div class="col-md-4 col-sm-6 equal-height">
            <div class="item">
               <div class="icon">
                  <img src="{{ asset('public/assets/wealthmark_new/img/investing-in-crypto.svg') }}">
               </div>
               <div class="info">
                  <h4>Investing in crypto</h4>
                  <p>Buy & Sell a variety of top coin at the best prices
                  </p>
               </div>
            </div>
         </div>
         <div class="col-md-4 col-sm-6 equal-height border-bottom-none">
            <div class="item">
               <div class="icon">
                  <img src="{{ asset('public/assets/wealthmark_new/img/insured-by-bitgo.svg') }}">
               </div>
               <div class="info">
                  <h4>Safe & Secure</h4>
                  <p>Offline signature is more secure with WealthMark hardware wallet
                  </p>
               </div>
            </div>
         </div>
         <div class="col-md-4 col-sm-6 equal-height border-bottom-none">
            <div class="item">
               <div class="icon">
                  <img src="{{ asset('public/assets/wealthmark_new/img/deep-encryption.svg') }}">
               </div>
               <div class="info">
                  <h4>Deep encryption</h4>
                  <p>All data is encrypted to secure your password & personal data
                  </p>
               </div>
            </div>
         </div>
         <div class="col-md-4 col-sm-6 equal-height border-bottom-none">
            <div class="item">
               <div class="icon">
                  <img src="{{ asset('public/assets/wealthmark_new/img/safe-security.svg') }}">
               </div>
               <div class="info">
                  <h4>Identity verification</h4>
                  <p>Complete identity verification to protect your accounts and transactions.
                  </p>
               </div>
            </div>
         </div>
      </div>
      <div class="row">
         <div class="col-md-12">
         </div>
      </div>
   </div>
   <div class="container-fluid  text-center">
      <div class="sign-up-block mt-2">
         <ul class="list-inline">
            <li class="list-inline-item">
               <h4 class="text-white mb-0 font-weight-normal">Take the first step towards building your crypto portfolio</h4>
            </li>
            <li class="list-inline-item"><a href="javascript:void(0);" class="btn btn-yellow"><span>Get Started</span></a></li>
         </ul>
      </div>
   </div>
   <div class="live-summary">
      <div class="container-fluid " data-aos="fade-up">
         <div class="swiper summarySwiper">
            <div class="swiper-wrapper">
               <div class="swiper-slide">
                  <div class="card-body">
                     <div class="d-flex align-items-center mb-3">
                        <h5 class="coin-name">SHIB/BUSD</h5>
                        <h5 class="coin-price-changes-percentage ms-auto">2.02%</h5>
                     </div>
                     <span class="coin-price-changes">543.7</span>
                     <div class="d-flex align-items-center">
                        <p class="coin-price">₹ 41,245</p>
                        <span class="ms-auto summary-arrow"><i class="bx bx-right-arrow-alt "></i></span>
                     </div>
                  </div>
               </div>
               <div class="swiper-slide">
                  <div class="card-body">
                     <div class="d-flex align-items-center mb-3">
                        <h5 class="coin-name">SHIB/BUSD</h5>
                        <h5 class="coin-price-changes-percentage ms-auto">2.02%</h5>
                     </div>
                     <span class="coin-price-changes">543.7</span>
                     <div class="d-flex align-items-center">
                        <p class="coin-price">₹ 41,245</p>
                        <span class="ms-auto summary-arrow"><i class="bx bx-right-arrow-alt "></i></span>
                     </div>
                  </div>
               </div>
               <div class="swiper-slide">
                  <div class="card-body">
                     <div class="d-flex align-items-center mb-3">
                        <h5 class="coin-name">SHIB/BUSD</h5>
                        <h5 class="coin-price-changes-percentage ms-auto">2.02%</h5>
                     </div>
                     <span class="coin-price-changes">543.7</span>
                     <div class="d-flex align-items-center">
                        <p class="coin-price">₹ 41,245</p>
                        <span class="ms-auto summary-arrow"><i class="bx bx-right-arrow-alt "></i></span>
                     </div>
                  </div>
               </div>
               <div class="swiper-slide">
                  <div class="card-body">
                     <div class="d-flex align-items-center mb-3">
                        <h5 class="coin-name">SHIB/BUSD</h5>
                        <h5 class="coin-price-changes-percentage-up ms-auto">2.02%</h5>
                     </div>
                     <span class="coin-price-changes">543.7</span>
                     <div class="d-flex align-items-center">
                        <p class="coin-price">₹ 41,245</p>
                        <span class="ms-auto summary-arrow"><i class="bx bx-right-arrow-alt "></i></span>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
   <!-- End Clients Section -->
   <div class="market-trend">
      <div class="container-fluid ">
         <div class="row">
            <div class="card bg-white shadow-lg">
               <div class="card-body">
                  <div class="row">
                     <div class="col-lg-10 col-md-10 col-sm-9 col-xs-12 btn-box-main">
                        <ul class="tabs">
                           <li class="tab-link btn-blue current" data-tab="tab-1"> Weekly Stars </li>
                           <li class="tab-link btn-blue" data-tab="tab-2"> 24h Gainers </li>
                           <li class="tab-link btn-blue" data-tab="tab-3"> ETF Gainers </li>
                           <!--<li class="tab-link btn-blue" data-tab="tab-4">Tab Four</li>-->
                        </ul>
                     </div>
                     <div class="col-lg-2 col-md-2 col-sm-3 col-xs-12 more-box">
                        <a class="btn view_more" href="javascript:void(0);">View  More  <span> <i class="bi-chevron-right"></i> </span> </a>
                     </div>
                  </div>
               </div>
            </div>
            <div class="card shadow bg-white">
               <div class="card-body">
                  <div id="tab-1" class="table-content current">
                     <div class="table-responsive">
                        <table class="table table-hover table-borderless" id="table">
                           <tbody>
                              <tr class="head" id="t_title1">
                                 <th></th>
                                 <th class="g-text-left">
                                    <span class="arrow" type="trans"> Pairs </span>
                                 </th>
                                 <th class="g-text-left">
                                    <span class="arrow" type="new"> Last Price </span>
                                 </th>
                                 <th class="g-text-left">
                                    <span class="arrow" type="weex"> Weekly Change </span>
                                 </th>
                                 <th class="g-text-left">
                                    <span class="arrow" type="high"> Weekly Highest </span>
                                 </th>
                                 <th class="g-text-left">
                                    <span class="arrow" type="low"> Weekly Lowest </span>
                                 </th>
                                 <th class="g-text-left">
                                    <span class="arrow" type="deal"> Weekly Volume </span>
                                 </th>
                                 <th>Action</th>
                              </tr>
                              <tr class="body">
                                 <td class="g-text-right star-icon">
                                    <i class="bi-star-fill"></i> 
                                 </td>
                                 <td class="g-text-left asset-code g-pointer">
                                    <img src="{{ asset('public/assets/img/Bitcoin-BTC-icon.png') }}" class="coin-icon-img" alt=""> SANTOS/USDT
                                 </td>
                                 <td class="g-text-left">
                                    <span class="g-light-green">13.484</span>
                                    <span class="g-grey g-font12"> / $ 13.484 </span>
                                 </td>
                                 <td class="g-text-left g-light-green"> 126.05% <i class="bi-arrow-up"></i>
                                 </td>
                                 <td class="g-text-left">21.399</td>
                                 <td class="g-text-left">5.741</td>
                                 <td class="g-text-left">6.38M</td>
                                 <td class="g-text-center g-pointer left-right-icon" symbolold="santos/usdt">
                                    <a href="javascript:void(0);" target="_blank">
                                    <i class="bi bi-arrow-left-right"></i>
                                    </a>
                                 </td>
                              </tr>
                              <tr class="body">
                                 <td class="g-text-right star-icon">
                                    <i class="bi-star-fill"></i> 
                                 </td>
                                 <td class="g-text-left asset-code g-pointer">
                                    <img src="{{ asset('public/assets/img/Bitcoin-BTC-icon.png') }}" class="coin-icon-img" alt=""> PORTO/USDT
                                 </td>
                                 <td class="g-text-left">
                                    <span class="g-light-green">5.8335</span>
                                    <span class="g-grey g-font12"> / $ 5.8335 </span>
                                 </td>
                                 <td class="g-text-left g-light-green"> 56.83% <i class="bi-arrow-up"></i>
                                 </td>
                                 <td class="g-text-left">8.3626</td>
                                 <td class="g-text-left">3.6706</td>
                                 <td class="g-text-left">5.92M</td>
                                 <td class="g-text-center g-pointer left-right-icon" symbolold="porto/usdt">
                                    <a href="javascript:void(0);" target="_blank">
                                    <i class="bi bi-arrow-left-right"></i>
                                    </a>
                                 </td>
                              </tr>
                              <tr class="body">
                                 <td class="g-text-right star-icon">
                                    <i class="bi-star-fill"></i> 
                                 </td>
                                 <td class="g-text-left asset-code g-pointer">
                                    <img src="{{ asset('public/assets/img/Bitcoin-BTC-icon.png') }}" class="coin-icon-img" alt=""> LAZIO/USDT
                                 </td>
                                 <td class="g-text-left">
                                    <span class="g-light-green">5.7747</span>
                                    <span class="g-grey g-font12"> / $ 5.7747 </span>
                                 </td>
                                 <td class="g-text-left g-light-green"> 130.99% <i class="bi-arrow-up"></i>
                                 </td>
                                 <td class="g-text-left">6.8307</td>
                                 <td class="g-text-left">2.5000</td>
                                 <td class="g-text-left">4.68M</td>
                                 <td class="g-text-center g-pointer left-right-icon" symbolold="lazio/usdt">
                                    <a href="javascript:void(0);" target="_blank">
                                    <i class="bi bi-arrow-left-right"></i>
                                    </a>
                                 </td>
                              </tr>
                              <tr class="body">
                                 <td class="g-text-right star-icon">
                                    <i class="bi-star-fill"></i> 
                                 </td>
                                 <td class="g-text-left asset-code g-pointer">
                                    <img src="{{ asset('public/assets/img/Bitcoin-BTC-icon.png') }}" class="coin-icon-img" alt=""> STG/USDT
                                 </td>
                                 <td class="g-text-left">
                                    <span class="g-light-green">0.8409</span>
                                    <span class="g-grey g-font12"> / $ 0.8409 </span>
                                 </td>
                                 <td class="g-text-left g-light-green"> 150.27% <i class="bi-arrow-up"></i>
                                 </td>
                                 <td class="g-text-left">0.9995</td>
                                 <td class="g-text-left">0.3350</td>
                                 <td class="g-text-left">600.14K</td>
                                 <td class="g-text-center g-pointer left-right-icon" symbolold="stg/usdt">
                                    <a href="javascript:void(0);" target="_blank">
                                    <i class="bi bi-arrow-left-right"></i>
                                    </a>
                                 </td>
                              </tr>
                              <tr class="body">
                                 <td class="g-text-right star-icon">
                                    <i class="bi-star-fill"></i> 
                                 </td>
                                 <td class="g-text-left asset-code g-pointer">
                                    <img src="{{ asset('public/assets/img/Bitcoin-BTC-icon.png') }}" class="coin-icon-img" alt="">  INJ/USDT
                                 </td>
                                 <td class="g-text-left">
                                    <span class="g-light-green">1.800</span>
                                    <span class="g-grey g-font12"> / $ 1.8 </span>
                                 </td>
                                 <td class="g-text-left g-light-green"> 50.00% <i class="bi-arrow-up"></i>
                                 </td>
                                 <td class="g-text-left">2.013</td>
                                 <td class="g-text-left">1.200</td>
                                 <td class="g-text-left">5.50M</td>
                                 <td class="g-text-center g-pointer left-right-icon" symbolold="inj/usdt">
                                    <a href="javascript:void(0);" target="_blank">
                                    <i class="bi bi-arrow-left-right"></i>
                                    </a>
                                 </td>
                              </tr>
                              <tr class="body">
                                 <td class="g-text-right star-icon">
                                    <i class="bi-star-fill"></i> 
                                 </td>
                                 <td class="g-text-left asset-code g-pointer">
                                    <img src="{{ asset('public/assets/img/Bitcoin-BTC-icon.png') }}" class="coin-icon-img" alt=""> GM/USDT
                                 </td>
                                 <td class="g-text-left">
                                    <span class="g-light-green">0.00000973</span>
                                    <span class="g-grey g-font12"> / $ 0 </span>
                                 </td>
                                 <td class="g-text-left g-light-green"> 13.54% <i class="bi-arrow-up"></i>
                                 </td>
                                 <td class="g-text-left">0.00001553</td>
                                 <td class="g-text-left">0.00000831</td>
                                 <td class="g-text-left">6.07M</td>
                                 <td class="g-text-center g-pointer left-right-icon" symbolold="gm/usdt">
                                    <a href="javascript:void(0);" target="_blank">
                                    <i class="bi bi-arrow-left-right"></i>
                                    </a>
                                 </td>
                              </tr>
                              <tr class="body">
                                 <td class="g-text-right star-icon">
                                    <i class="bi-star-fill"></i> 
                                 </td>
                                 <td class="g-text-left asset-code g-pointer">
                                    <img src="{{ asset('public/assets/img/Bitcoin-BTC-icon.png') }}" class="coin-icon-img" alt=""> MELOS/USDT
                                 </td>
                                 <td class="g-text-left">
                                    <span class="g-light-red">0.0284</span>
                                    <span class="g-grey g-font12"> / $ 0.0284 </span>
                                 </td>
                                 <td class="g-text-left g-light-red"> -1.73% <i class="bi-arrow-down"></i>
                                 </td>
                                 <td class="g-text-left">0.0528</td>
                                 <td class="g-text-left">0.0250</td>
                                 <td class="g-text-left">3.37M</td>
                                 <td class="g-text-center g-pointer left-right-icon" symbolold="melos/usdt">
                                    <a href="javascript:void(0);" target="_blank">
                                    <i class="bi bi-arrow-left-right"></i>
                                    </a>
                                 </td>
                              </tr>
                              <tr class="body">
                                 <td class="g-text-right star-icon">
                                    <i class="bi-star-fill"></i> 
                                 </td>
                                 <td class="g-text-left asset-code g-pointer">
                                    <img src="{{ asset('public/assets/img/Bitcoin-BTC-icon.png') }}" class="coin-icon-img" alt=""> ZBC/USDT
                                 </td>
                                 <td class="g-text-left">
                                    <span class="g-light-red">0.025087</span>
                                    <span class="g-grey g-font12"> / $ 0.0250 </span>
                                 </td>
                                 <td class="g-text-left g-light-red"> -0.36% <i class="bi-arrow-down"></i>
                                 </td>
                                 <td class="g-text-left">0.039708</td>
                                 <td class="g-text-left">0.022381</td>
                                 <td class="g-text-left">6.02M</td>
                                 <td class="g-text-center g-pointer left-right-icon" symbolold="zbc/usdt">
                                    <a href="javascript:void(0);" target="_blank">
                                    <i class="bi bi-arrow-left-right"></i>
                                    </a>
                                 </td>
                              </tr>
                              <tr class="body">
                                 <td class="g-text-right star-icon">
                                    <i class="bi-star-fill"></i>    
                                 </td>
                                 <td class="g-text-left asset-code g-pointer">
                                    <img src="{{ asset('public/assets/img/Bitcoin-BTC-icon.png') }}" class="coin-icon-img" alt=""> PMON/USDT
                                 </td>
                                 <td class="g-text-left">
                                    <span class="g-light-green">1.3796</span>
                                    <span class="g-grey g-font12"> / $ 1.3796 </span>
                                 </td>
                                 <td class="g-text-left g-light-green"> 3.33% <i class="bi-arrow-up"></i>
                                 </td>
                                 <td class="g-text-left">2.2001</td>
                                 <td class="g-text-left">1.2268</td>
                                 <td class="g-text-left">1.20M</td>
                                 <td class="g-text-center g-pointer left-right-icon" symbolold="pmon/usdt">
                                    <a href="javascript:void(0);" target="_blank">
                                    <i class="bi bi-arrow-left-right"></i>
                                    </a>
                                 </td>
                              </tr>
                              <tr class="body">
                                 <td class="g-text-right star-icon">
                                    <i class="bi-star-fill"></i> 
                                 </td>
                                 <td class="g-text-left asset-code g-pointer">
                                    <img src="{{ asset('public/assets/img/Bitcoin-BTC-icon.png') }}" class="coin-icon-img" alt=""> MAGIC/USDT
                                 </td>
                                 <td class="g-text-left">
                                    <span class="g-light-green">0.6642</span>
                                    <span class="g-grey g-font12"> / $ 0.6642 </span>
                                 </td>
                                 <td class="g-text-left g-light-green"> 15.49% <i class="bi-arrow-up"></i>
                                 </td>
                                 <td class="g-text-left">0.7721</td>
                                 <td class="g-text-left">0.4552</td>
                                 <td class="g-text-left">12.11M</td>
                                 <td class="g-text-center g-pointer left-right-icon" symbolold="magic/usdt">
                                    <a href="javascript:void(0);" target="_blank">
                                    <i class="bi bi-arrow-left-right"></i>
                                    </a>
                                 </td>
                              </tr>
                           </tbody>
                        </table>
                     </div>
                  </div>
                  <div id="tab-2" class="table-content">
                     <table class="table table-hover table-borderless" id="table">
                        <tbody>
                           <tr class="head" id="t_title1">
                              <th></th>
                              <th class="g-text-left">
                                 <span class="arrow" type="trans"> Pairs </span>
                              </th>
                              <th class="g-text-left">
                                 <span class="arrow" type="new"> Last Price </span>
                              </th>
                              <th class="g-text-left">
                                 <span class="arrow" type="weex"> Weekly Change </span>
                              </th>
                              <th class="g-text-left">
                                 <span class="arrow" type="high"> Weekly Highest </span>
                              </th>
                              <th class="g-text-left">
                                 <span class="arrow" type="low"> Weekly Lowest </span>
                              </th>
                              <th class="g-text-left">
                                 <span class="arrow" type="deal"> Weekly Volume </span>
                              </th>
                              <th>Action</th>
                           </tr>
                           <tr class="body">
                              <td class="g-text-right star-icon">
                                 <i class="bi-star-fill"></i> 
                              </td>
                              <td class="g-text-left asset-code g-pointer">
                                 <img src="{{ asset('public/assets/img/Bitcoin-BTC-icon.png') }}" class="coin-icon-img" alt=""> SANTOS/USDT
                              </td>
                              <td class="g-text-left">
                                 <span class="g-light-green">13.484</span>
                                 <span class="g-grey g-font12"> / $ 13.484 </span>
                              </td>
                              <td class="g-text-left g-light-green"> 126.05% <i class="bi-arrow-up"></i>
                              </td>
                              <td class="g-text-left">21.399</td>
                              <td class="g-text-left">5.741</td>
                              <td class="g-text-left">6.38M</td>
                              <td class="g-text-center g-pointer left-right-icon" symbolold="santos/usdt">
                                 <a href="javascript:void(0);" target="_blank">
                                 <i class="bi bi-arrow-left-right"></i>
                                 </a>
                              </td>
                           </tr>
                           <tr class="body">
                              <td class="g-text-right star-icon">
                                 <i class="bi-star-fill"></i> 
                              </td>
                              <td class="g-text-left asset-code g-pointer">
                                 <img src="{{ asset('public/assets/img/Bitcoin-BTC-icon.png') }}" class="coin-icon-img" alt=""> PORTO/USDT
                              </td>
                              <td class="g-text-left">
                                 <span class="g-light-green">5.8335</span>
                                 <span class="g-grey g-font12"> / $ 5.8335 </span>
                              </td>
                              <td class="g-text-left g-light-green"> 56.83% <i class="bi-arrow-up"></i>
                              </td>
                              <td class="g-text-left">8.3626</td>
                              <td class="g-text-left">3.6706</td>
                              <td class="g-text-left">5.92M</td>
                              <td class="g-text-center g-pointer left-right-icon" symbolold="porto/usdt">
                                 <a href="javascript:void(0);" target="_blank">
                                 <i class="bi bi-arrow-left-right"></i>
                                 </a>
                              </td>
                           </tr>
                           <tr class="body">
                              <td class="g-text-right star-icon">
                                 <i class="bi-star-fill"></i> 
                              </td>
                              <td class="g-text-left asset-code g-pointer">
                                 <img src="{{ asset('public/assets/img/Bitcoin-BTC-icon.png') }}" class="coin-icon-img" alt=""> LAZIO/USDT
                              </td>
                              <td class="g-text-left">
                                 <span class="g-light-green">5.7747</span>
                                 <span class="g-grey g-font12"> / $ 5.7747 </span>
                              </td>
                              <td class="g-text-left g-light-green"> 130.99% <i class="bi-arrow-up"></i>
                              </td>
                              <td class="g-text-left">6.8307</td>
                              <td class="g-text-left">2.5000</td>
                              <td class="g-text-left">4.68M</td>
                              <td class="g-text-center g-pointer left-right-icon" symbolold="lazio/usdt">
                                 <a href="javascript:void(0);" target="_blank">
                                 <i class="bi bi-arrow-left-right"></i>
                                 </a>
                              </td>
                           </tr>
                           <tr class="body">
                              <td class="g-text-right star-icon">
                                 <i class="bi-star-fill"></i> 
                              </td>
                              <td class="g-text-left asset-code g-pointer">
                                 <img src="{{ asset('public/assets/img/Bitcoin-BTC-icon.png') }}" class="coin-icon-img" alt=""> STG/USDT
                              </td>
                              <td class="g-text-left">
                                 <span class="g-light-green">0.8409</span>
                                 <span class="g-grey g-font12"> / $ 0.8409 </span>
                              </td>
                              <td class="g-text-left g-light-green"> 150.27% <i class="bi-arrow-up"></i>
                              </td>
                              <td class="g-text-left">0.9995</td>
                              <td class="g-text-left">0.3350</td>
                              <td class="g-text-left">600.14K</td>
                              <td class="g-text-center g-pointer left-right-icon" symbolold="stg/usdt">
                                 <a href="javascript:void(0);" target="_blank">
                                 <i class="bi bi-arrow-left-right"></i>
                                 </a>
                              </td>
                           </tr>
                           <tr class="body">
                              <td class="g-text-right star-icon">
                                 <i class="bi-star-fill"></i> 
                              </td>
                              <td class="g-text-left asset-code g-pointer">
                                 <img src="{{ asset('public/assets/img/Bitcoin-BTC-icon.png') }}" class="coin-icon-img" alt="">  INJ/USDT
                              </td>
                              <td class="g-text-left">
                                 <span class="g-light-green">1.800</span>
                                 <span class="g-grey g-font12"> / $ 1.8 </span>
                              </td>
                              <td class="g-text-left g-light-green"> 50.00% <i class="bi-arrow-up"></i>
                              </td>
                              <td class="g-text-left">2.013</td>
                              <td class="g-text-left">1.200</td>
                              <td class="g-text-left">5.50M</td>
                              <td class="g-text-center g-pointer left-right-icon" symbolold="inj/usdt">
                                 <a href="javascript:void(0);" target="_blank">
                                 <i class="bi bi-arrow-left-right"></i>
                                 </a>
                              </td>
                           </tr>
                           <tr class="body">
                              <td class="g-text-right star-icon">
                                 <i class="bi-star-fill"></i> 
                              </td>
                              <td class="g-text-left asset-code g-pointer">
                                 <img src="{{ asset('public/assets/img/Bitcoin-BTC-icon.png') }}" class="coin-icon-img" alt=""> GM/USDT
                              </td>
                              <td class="g-text-left">
                                 <span class="g-light-green">0.00000973</span>
                                 <span class="g-grey g-font12"> / $ 0 </span>
                              </td>
                              <td class="g-text-left g-light-green"> 13.54% <i class="bi-arrow-up"></i>
                              </td>
                              <td class="g-text-left">0.00001553</td>
                              <td class="g-text-left">0.00000831</td>
                              <td class="g-text-left">6.07M</td>
                              <td class="g-text-center g-pointer left-right-icon" symbolold="gm/usdt">
                                 <a href="javascript:void(0);" target="_blank">
                                 <i class="bi bi-arrow-left-right"></i>
                                 </a>
                              </td>
                           </tr>
                           <tr class="body">
                              <td class="g-text-right star-icon">
                                 <i class="bi-star-fill"></i> 
                              </td>
                              <td class="g-text-left asset-code g-pointer">
                                 <img src="{{ asset('public/assets/img/Bitcoin-BTC-icon.png') }}" class="coin-icon-img" alt=""> MELOS/USDT
                              </td>
                              <td class="g-text-left">
                                 <span class="g-light-red">0.0284</span>
                                 <span class="g-grey g-font12"> / $ 0.0284 </span>
                              </td>
                              <td class="g-text-left g-light-red"> -1.73% <i class="bi-arrow-down"></i>
                              </td>
                              <td class="g-text-left">0.0528</td>
                              <td class="g-text-left">0.0250</td>
                              <td class="g-text-left">3.37M</td>
                              <td class="g-text-center g-pointer left-right-icon" symbolold="melos/usdt">
                                 <a href="javascript:void(0);" target="_blank">
                                 <i class="bi bi-arrow-left-right"></i>
                                 </a>
                              </td>
                           </tr>
                           <tr class="body">
                              <td class="g-text-right star-icon">
                                 <i class="bi-star-fill"></i> 
                              </td>
                              <td class="g-text-left asset-code g-pointer">
                                 <img src="{{ asset('public/assets/img/Bitcoin-BTC-icon.png') }}" class="coin-icon-img" alt=""> ZBC/USDT
                              </td>
                              <td class="g-text-left">
                                 <span class="g-light-red">0.025087</span>
                                 <span class="g-grey g-font12"> / $ 0.0250 </span>
                              </td>
                              <td class="g-text-left g-light-red"> -0.36% <i class="bi-arrow-down"></i>
                              </td>
                              <td class="g-text-left">0.039708</td>
                              <td class="g-text-left">0.022381</td>
                              <td class="g-text-left">6.02M</td>
                              <td class="g-text-center g-pointer left-right-icon" symbolold="zbc/usdt">
                                 <a href="javascript:void(0);" target="_blank">
                                 <i class="bi bi-arrow-left-right"></i>
                                 </a>
                              </td>
                           </tr>
                           <tr class="body">
                              <td class="g-text-right star-icon">
                                 <i class="bi-star-fill"></i>    
                              </td>
                              <td class="g-text-left asset-code g-pointer">
                                 <img src="{{ asset('public/assets/img/Bitcoin-BTC-icon.png') }}" class="coin-icon-img" alt=""> PMON/USDT
                              </td>
                              <td class="g-text-left">
                                 <span class="g-light-green">1.3796</span>
                                 <span class="g-grey g-font12"> / $ 1.3796 </span>
                              </td>
                              <td class="g-text-left g-light-green"> 3.33% <i class="bi-arrow-up"></i>
                              </td>
                              <td class="g-text-left">2.2001</td>
                              <td class="g-text-left">1.2268</td>
                              <td class="g-text-left">1.20M</td>
                              <td class="g-text-center g-pointer left-right-icon" symbolold="pmon/usdt">
                                 <a href="javascript:void(0);" target="_blank">
                                 <i class="bi bi-arrow-left-right"></i>
                                 </a>
                              </td>
                           </tr>
                           <tr class="body">
                              <td class="g-text-right star-icon">
                                 <i class="bi-star-fill"></i> 
                              </td>
                              <td class="g-text-left asset-code g-pointer">
                                 <img src="{{ asset('public//assets/img/Bitcoin-BTC-icon.png') }}" class="coin-icon-img" alt=""> MAGIC/USDT
                              </td>
                              <td class="g-text-left">
                                 <span class="g-light-green">0.6642</span>
                                 <span class="g-grey g-font12"> / $ 0.6642 </span>
                              </td>
                              <td class="g-text-left g-light-green"> 15.49% <i class="bi-arrow-up"></i>
                              </td>
                              <td class="g-text-left">0.7721</td>
                              <td class="g-text-left">0.4552</td>
                              <td class="g-text-left">12.11M</td>
                              <td class="g-text-center g-pointer left-right-icon" symbolold="magic/usdt">
                                 <a href="javascript:void(0);" target="_blank">
                                 <i class="bi bi-arrow-left-right"></i>
                                 </a>
                              </td>
                           </tr>
                        </tbody>
                     </table>
                  </div>
                  <div id="tab-3" class="table-content">
                     <table class="table table-hover table-borderless" id="table">
                        <tbody>
                           <tr class="head" id="t_title1">
                              <th></th>
                              <th class="g-text-left">
                                 <span class="arrow" type="trans"> Pairs </span>
                              </th>
                              <th class="g-text-left">
                                 <span class="arrow" type="new"> Last Price </span>
                              </th>
                              <th class="g-text-left">
                                 <span class="arrow" type="weex"> Weekly Change </span>
                              </th>
                              <th class="g-text-left">
                                 <span class="arrow" type="high"> Weekly Highest </span>
                              </th>
                              <th class="g-text-left">
                                 <span class="arrow" type="low"> Weekly Lowest </span>
                              </th>
                              <th class="g-text-left">
                                 <span class="arrow" type="deal"> Weekly Volume </span>
                              </th>
                              <th>Action</th>
                           </tr>
                           <tr class="body">
                              <td class="g-text-right star-icon">
                                 <i class="bi-star-fill"></i> 
                              </td>
                              <td class="g-text-left asset-code g-pointer">
                                 <img src="{{ asset('public/assets/img/Bitcoin-BTC-icon.png') }}" class="coin-icon-img" alt=""> SANTOS/USDT
                              </td>
                              <td class="g-text-left">
                                 <span class="g-light-green">13.484</span>
                                 <span class="g-grey g-font12"> / $ 13.484 </span>
                              </td>
                              <td class="g-text-left g-light-green"> 126.05% <i class="bi-arrow-up"></i>
                              </td>
                              <td class="g-text-left">21.399</td>
                              <td class="g-text-left">5.741</td>
                              <td class="g-text-left">6.38M</td>
                              <td class="g-text-center g-pointer left-right-icon" symbolold="santos/usdt">
                                 <a href="javascript:void(0);" target="_blank">
                                 <i class="bi bi-arrow-left-right"></i>
                                 </a>
                              </td>
                           </tr>
                           <tr class="body">
                              <td class="g-text-right star-icon">
                                 <i class="bi-star-fill"></i> 
                              </td>
                              <td class="g-text-left asset-code g-pointer">
                                 <img src="{{ asset('public/assets/img/Bitcoin-BTC-icon.png') }}" class="coin-icon-img" alt=""> PORTO/USDT
                              </td>
                              <td class="g-text-left">
                                 <span class="g-light-green">5.8335</span>
                                 <span class="g-grey g-font12"> / $ 5.8335 </span>
                              </td>
                              <td class="g-text-left g-light-green"> 56.83% <i class="bi-arrow-up"></i>
                              </td>
                              <td class="g-text-left">8.3626</td>
                              <td class="g-text-left">3.6706</td>
                              <td class="g-text-left">5.92M</td>
                              <td class="g-text-center g-pointer left-right-icon" symbolold="porto/usdt">
                                 <a href="javascript:void(0);" target="_blank">
                                 <i class="bi bi-arrow-left-right"></i>
                                 </a>
                              </td>
                           </tr>
                           <tr class="body">
                              <td class="g-text-right star-icon">
                                 <i class="bi-star-fill"></i> 
                              </td>
                              <td class="g-text-left asset-code g-pointer">
                                 <img src="{{ asset('public/assets/img/Bitcoin-BTC-icon.png') }}" class="coin-icon-img" alt=""> LAZIO/USDT
                              </td>
                              <td class="g-text-left">
                                 <span class="g-light-green">5.7747</span>
                                 <span class="g-grey g-font12"> / $ 5.7747 </span>
                              </td>
                              <td class="g-text-left g-light-green"> 130.99% <i class="bi-arrow-up"></i>
                              </td>
                              <td class="g-text-left">6.8307</td>
                              <td class="g-text-left">2.5000</td>
                              <td class="g-text-left">4.68M</td>
                              <td class="g-text-center g-pointer left-right-icon" symbolold="lazio/usdt">
                                 <a href="javascript:void(0);" target="_blank">
                                 <i class="bi bi-arrow-left-right"></i>
                                 </a>
                              </td>
                           </tr>
                           <tr class="body">
                              <td class="g-text-right star-icon">
                                 <i class="bi-star-fill"></i> 
                              </td>
                              <td class="g-text-left asset-code g-pointer">
                                 <img src="{{ asset('public/assets/img/Bitcoin-BTC-icon.png') }}" class="coin-icon-img" alt=""> STG/USDT
                              </td>
                              <td class="g-text-left">
                                 <span class="g-light-green">0.8409</span>
                                 <span class="g-grey g-font12"> / $ 0.8409 </span>
                              </td>
                              <td class="g-text-left g-light-green"> 150.27% <i class="bi-arrow-up"></i>
                              </td>
                              <td class="g-text-left">0.9995</td>
                              <td class="g-text-left">0.3350</td>
                              <td class="g-text-left">600.14K</td>
                              <td class="g-text-center g-pointer left-right-icon" symbolold="stg/usdt">
                                 <a href="javascript:void(0);" target="_blank">
                                 <i class="bi bi-arrow-left-right"></i>
                                 </a>
                              </td>
                           </tr>
                           <tr class="body">
                              <td class="g-text-right star-icon">
                                 <i class="bi-star-fill"></i> 
                              </td>
                              <td class="g-text-left asset-code g-pointer">
                                 <img src="{{ asset('public/assets/img/Bitcoin-BTC-icon.png') }}" class="coin-icon-img" alt="">  INJ/USDT
                              </td>
                              <td class="g-text-left">
                                 <span class="g-light-green">1.800</span>
                                 <span class="g-grey g-font12"> / $ 1.8 </span>
                              </td>
                              <td class="g-text-left g-light-green"> 50.00% <i class="bi-arrow-up"></i>
                              </td>
                              <td class="g-text-left">2.013</td>
                              <td class="g-text-left">1.200</td>
                              <td class="g-text-left">5.50M</td>
                              <td class="g-text-center g-pointer left-right-icon" symbolold="inj/usdt">
                                 <a href="javascript:void(0);" target="_blank">
                                 <i class="bi bi-arrow-left-right"></i>
                                 </a>
                              </td>
                           </tr>
                           <tr class="body">
                              <td class="g-text-right star-icon">
                                 <i class="bi-star-fill"></i> 
                              </td>
                              <td class="g-text-left asset-code g-pointer">
                                 <img src="{{ asset('public/assets/img/Bitcoin-BTC-icon.png') }}" class="coin-icon-img" alt=""> GM/USDT
                              </td>
                              <td class="g-text-left">
                                 <span class="g-light-green">0.00000973</span>
                                 <span class="g-grey g-font12"> / $ 0 </span>
                              </td>
                              <td class="g-text-left g-light-green"> 13.54% <i class="bi-arrow-up"></i>
                              </td>
                              <td class="g-text-left">0.00001553</td>
                              <td class="g-text-left">0.00000831</td>
                              <td class="g-text-left">6.07M</td>
                              <td class="g-text-center g-pointer left-right-icon" symbolold="gm/usdt">
                                 <a href="javascript:void(0);" target="_blank">
                                 <i class="bi bi-arrow-left-right"></i>
                                 </a>
                              </td>
                           </tr>
                           <tr class="body">
                              <td class="g-text-right star-icon">
                                 <i class="bi-star-fill"></i> 
                              </td>
                              <td class="g-text-left asset-code g-pointer">
                                 <img src="{{ asset('public/assets/img/Bitcoin-BTC-icon.png') }}" class="coin-icon-img" alt=""> MELOS/USDT
                              </td>
                              <td class="g-text-left">
                                 <span class="g-light-red">0.0284</span>
                                 <span class="g-grey g-font12"> / $ 0.0284 </span>
                              </td>
                              <td class="g-text-left g-light-red"> -1.73% <i class="bi-arrow-down"></i>
                              </td>
                              <td class="g-text-left">0.0528</td>
                              <td class="g-text-left">0.0250</td>
                              <td class="g-text-left">3.37M</td>
                              <td class="g-text-center g-pointer left-right-icon" symbolold="melos/usdt">
                                 <a href="javascript:void(0);" target="_blank">
                                 <i class="bi bi-arrow-left-right"></i>
                                 </a>
                              </td>
                           </tr>
                           <tr class="body">
                              <td class="g-text-right star-icon">
                                 <i class="bi-star-fill"></i> 
                              </td>
                              <td class="g-text-left asset-code g-pointer">
                                 <img src="{{ asset('public/assets/img/Bitcoin-BTC-icon.png') }}" class="coin-icon-img" alt=""> ZBC/USDT
                              </td>
                              <td class="g-text-left">
                                 <span class="g-light-red">0.025087</span>
                                 <span class="g-grey g-font12"> / $ 0.0250 </span>
                              </td>
                              <td class="g-text-left g-light-red"> -0.36% <i class="bi-arrow-down"></i>
                              </td>
                              <td class="g-text-left">0.039708</td>
                              <td class="g-text-left">0.022381</td>
                              <td class="g-text-left">6.02M</td>
                              <td class="g-text-center g-pointer left-right-icon" symbolold="zbc/usdt">
                                 <a href="javascript:void(0);" target="_blank">
                                 <i class="bi bi-arrow-left-right"></i>
                                 </a>
                              </td>
                           </tr>
                           <tr class="body">
                              <td class="g-text-right star-icon">
                                 <i class="bi-star-fill"></i>    
                              </td>
                              <td class="g-text-left asset-code g-pointer">
                                 <img src="{{ asset('public/assets/img/Bitcoin-BTC-icon.png') }}" class="coin-icon-img" alt=""> PMON/USDT
                              </td>
                              <td class="g-text-left">
                                 <span class="g-light-green">1.3796</span>
                                 <span class="g-grey g-font12"> / $ 1.3796 </span>
                              </td>
                              <td class="g-text-left g-light-green"> 3.33% <i class="bi-arrow-up"></i>
                              </td>
                              <td class="g-text-left">2.2001</td>
                              <td class="g-text-left">1.2268</td>
                              <td class="g-text-left">1.20M</td>
                              <td class="g-text-center g-pointer left-right-icon" symbolold="pmon/usdt">
                                 <a href="javascript:void(0);" target="_blank">
                                 <i class="bi bi-arrow-left-right"></i>
                                 </a>
                              </td>
                           </tr>
                           <tr class="body">
                              <td class="g-text-right star-icon">
                                 <i class="bi-star-fill"></i> 
                              </td>
                              <td class="g-text-left asset-code g-pointer">
                                 <img src="{{ asset('public/assets/img/Bitcoin-BTC-icon.png') }}" class="coin-icon-img" alt=""> MAGIC/USDT
                              </td>
                              <td class="g-text-left">
                                 <span class="g-light-green">0.6642</span>
                                 <span class="g-grey g-font12"> / $ 0.6642 </span>
                              </td>
                              <td class="g-text-left g-light-green"> 15.49% <i class="bi-arrow-up"></i>
                              </td>
                              <td class="g-text-left">0.7721</td>
                              <td class="g-text-left">0.4552</td>
                              <td class="g-text-left">12.11M</td>
                              <td class="g-text-center g-pointer left-right-icon" symbolold="magic/usdt">
                                 <a href="javascript:void(0);" target="_blank">
                                 <i class="bi bi-arrow-left-right"></i>
                                 </a>
                              </td>
                           </tr>
                        </tbody>
                     </table>
                  </div>
                  <div id="tab-4" class="table-content">
                     <table class="table table-hover table-borderless" id="table">
                        <tbody>
                           <tr class="head" id="t_title1">
                              <th></th>
                              <th class="g-text-left">
                                 <span class="arrow" type="trans"> Pairs </span>
                              </th>
                              <th class="g-text-left">
                                 <span class="arrow" type="new"> Last Price </span>
                              </th>
                              <th class="g-text-left">
                                 <span class="arrow" type="weex"> Weekly Change </span>
                              </th>
                              <th class="g-text-left">
                                 <span class="arrow" type="high"> Weekly Highest </span>
                              </th>
                              <th class="g-text-left">
                                 <span class="arrow" type="low"> Weekly Lowest </span>
                              </th>
                              <th class="g-text-left">
                                 <span class="arrow" type="deal"> Weekly Volume </span>
                              </th>
                              <th>Action</th>
                           </tr>
                           <tr class="body">
                              <td class="g-text-right star-icon">
                                 <i class="bi-star-fill"></i> 
                              </td>
                              <td class="g-text-left asset-code g-pointer">
                                 <img src="{{ asset('public/assets/img/Bitcoin-BTC-icon.png') }}" class="coin-icon-img" alt=""> SANTOS/USDT
                              </td>
                              <td class="g-text-left">
                                 <span class="g-light-green">13.484</span>
                                 <span class="g-grey g-font12"> / $ 13.484 </span>
                              </td>
                              <td class="g-text-left g-light-green"> 126.05% <i class="bi-arrow-up"></i>
                              </td>
                              <td class="g-text-left">21.399</td>
                              <td class="g-text-left">5.741</td>
                              <td class="g-text-left">6.38M</td>
                              <td class="g-text-center g-pointer left-right-icon" symbolold="santos/usdt">
                                 <a href="javascript:void(0);" target="_blank">
                                 <i class="bi bi-arrow-left-right"></i>
                                 </a>
                              </td>
                           </tr>
                           <tr class="body">
                              <td class="g-text-right star-icon">
                                 <i class="bi-star-fill"></i> 
                              </td>
                              <td class="g-text-left asset-code g-pointer">
                                 <img src="{{ asset('public/assets/img/Bitcoin-BTC-icon.png') }}" class="coin-icon-img" alt=""> PORTO/USDT
                              </td>
                              <td class="g-text-left">
                                 <span class="g-light-green">5.8335</span>
                                 <span class="g-grey g-font12"> / $ 5.8335 </span>
                              </td>
                              <td class="g-text-left g-light-green"> 56.83% <i class="bi-arrow-up"></i>
                              </td>
                              <td class="g-text-left">8.3626</td>
                              <td class="g-text-left">3.6706</td>
                              <td class="g-text-left">5.92M</td>
                              <td class="g-text-center g-pointer left-right-icon" symbolold="porto/usdt">
                                 <a href="javascript:void(0);" target="_blank">
                                 <i class="bi bi-arrow-left-right"></i>
                                 </a>
                              </td>
                           </tr>
                           <tr class="body">
                              <td class="g-text-right star-icon">
                                 <i class="bi-star-fill"></i> 
                              </td>
                              <td class="g-text-left asset-code g-pointer">
                                 <img src="{{ asset('public/assets/img/Bitcoin-BTC-icon.png') }}" class="coin-icon-img" alt=""> LAZIO/USDT
                              </td>
                              <td class="g-text-left">
                                 <span class="g-light-green">5.7747</span>
                                 <span class="g-grey g-font12"> / $ 5.7747 </span>
                              </td>
                              <td class="g-text-left g-light-green"> 130.99% <i class="bi-arrow-up"></i>
                              </td>
                              <td class="g-text-left">6.8307</td>
                              <td class="g-text-left">2.5000</td>
                              <td class="g-text-left">4.68M</td>
                              <td class="g-text-center g-pointer left-right-icon" symbolold="lazio/usdt">
                                 <a href="javascript:void(0);" target="_blank">
                                 <i class="bi bi-arrow-left-right"></i>
                                 </a>
                              </td>
                           </tr>
                           <tr class="body">
                              <td class="g-text-right star-icon">
                                 <i class="bi-star-fill"></i> 
                              </td>
                              <td class="g-text-left asset-code g-pointer">
                                 <img src="{{ asset('public/assets/img/Bitcoin-BTC-icon.png') }}" class="coin-icon-img" alt=""> STG/USDT
                              </td>
                              <td class="g-text-left">
                                 <span class="g-light-green">0.8409</span>
                                 <span class="g-grey g-font12"> / $ 0.8409 </span>
                              </td>
                              <td class="g-text-left g-light-green"> 150.27% <i class="bi-arrow-up"></i>
                              </td>
                              <td class="g-text-left">0.9995</td>
                              <td class="g-text-left">0.3350</td>
                              <td class="g-text-left">600.14K</td>
                              <td class="g-text-center g-pointer left-right-icon" symbolold="stg/usdt">
                                 <a href="javascript:void(0);" target="_blank">
                                 <i class="bi bi-arrow-left-right"></i>
                                 </a>
                              </td>
                           </tr>
                           <tr class="body">
                              <td class="g-text-right star-icon">
                                 <i class="bi-star-fill"></i> 
                              </td>
                              <td class="g-text-left asset-code g-pointer">
                                 <img src="{{ asset('public/assets/img/Bitcoin-BTC-icon.png') }}" class="coin-icon-img" alt="">  INJ/USDT
                              </td>
                              <td class="g-text-left">
                                 <span class="g-light-green">1.800</span>
                                 <span class="g-grey g-font12"> / $ 1.8 </span>
                              </td>
                              <td class="g-text-left g-light-green"> 50.00% <i class="bi-arrow-up"></i>
                              </td>
                              <td class="g-text-left">2.013</td>
                              <td class="g-text-left">1.200</td>
                              <td class="g-text-left">5.50M</td>
                              <td class="g-text-center g-pointer left-right-icon" symbolold="inj/usdt">
                                 <a href="javascript:void(0);" target="_blank">
                                 <i class="bi bi-arrow-left-right"></i>
                                 </a>
                              </td>
                           </tr>
                           <tr class="body">
                              <td class="g-text-right star-icon">
                                 <i class="bi-star-fill"></i> 
                              </td>
                              <td class="g-text-left asset-code g-pointer">
                                 <img src="{{ asset('public/assets/img/Bitcoin-BTC-icon.png') }}" class="coin-icon-img" alt=""> GM/USDT
                              </td>
                              <td class="g-text-left">
                                 <span class="g-light-green">0.00000973</span>
                                 <span class="g-grey g-font12"> / $ 0 </span>
                              </td>
                              <td class="g-text-left g-light-green"> 13.54% <i class="bi-arrow-up"></i>
                              </td>
                              <td class="g-text-left">0.00001553</td>
                              <td class="g-text-left">0.00000831</td>
                              <td class="g-text-left">6.07M</td>
                              <td class="g-text-center g-pointer left-right-icon" symbolold="gm/usdt">
                                 <a href="javascript:void(0);" target="_blank">
                                 <i class="bi bi-arrow-left-right"></i>
                                 </a>
                              </td>
                           </tr>
                           <tr class="body">
                              <td class="g-text-right star-icon">
                                 <i class="bi-star-fill"></i> 
                              </td>
                              <td class="g-text-left asset-code g-pointer">
                                 <img src="{{ asset('public/assets/img/Bitcoin-BTC-icon.png') }}" class="coin-icon-img" alt=""> MELOS/USDT
                              </td>
                              <td class="g-text-left">
                                 <span class="g-light-red">0.0284</span>
                                 <span class="g-grey g-font12"> / $ 0.0284 </span>
                              </td>
                              <td class="g-text-left g-light-red"> -1.73% <i class="bi-arrow-down"></i>
                              </td>
                              <td class="g-text-left">0.0528</td>
                              <td class="g-text-left">0.0250</td>
                              <td class="g-text-left">3.37M</td>
                              <td class="g-text-center g-pointer left-right-icon" symbolold="melos/usdt">
                                 <a href="javascript:void(0);" target="_blank">
                                 <i class="bi bi-arrow-left-right"></i>
                                 </a>
                              </td>
                           </tr>
                           <tr class="body">
                              <td class="g-text-right star-icon">
                                 <i class="bi-star-fill"></i> 
                              </td>
                              <td class="g-text-left asset-code g-pointer">
                                 <img src="{{ asset('public/assets/img/Bitcoin-BTC-icon.png') }}" class="coin-icon-img" alt=""> ZBC/USDT
                              </td>
                              <td class="g-text-left">
                                 <span class="g-light-red">0.025087</span>
                                 <span class="g-grey g-font12"> / $ 0.0250 </span>
                              </td>
                              <td class="g-text-left g-light-red"> -0.36% <i class="bi-arrow-down"></i>
                              </td>
                              <td class="g-text-left">0.039708</td>
                              <td class="g-text-left">0.022381</td>
                              <td class="g-text-left">6.02M</td>
                              <td class="g-text-center g-pointer left-right-icon" symbolold="zbc/usdt">
                                 <a href="javascript:void(0);" target="_blank">
                                 <i class="bi bi-arrow-left-right"></i>
                                 </a>
                              </td>
                           </tr>
                           <tr class="body">
                              <td class="g-text-right star-icon">
                                 <i class="bi-star-fill"></i>    
                              </td>
                              <td class="g-text-left asset-code g-pointer">
                                 <img src="{{ asset('public/assets/img/Bitcoin-BTC-icon.png') }}" class="coin-icon-img" alt=""> PMON/USDT
                              </td>
                              <td class="g-text-left">
                                 <span class="g-light-green">1.3796</span>
                                 <span class="g-grey g-font12"> / $ 1.3796 </span>
                              </td>
                              <td class="g-text-left g-light-green"> 3.33% <i class="bi-arrow-up"></i>
                              </td>
                              <td class="g-text-left">2.2001</td>
                              <td class="g-text-left">1.2268</td>
                              <td class="g-text-left">1.20M</td>
                              <td class="g-text-center g-pointer left-right-icon" symbolold="pmon/usdt">
                                 <a href="javascript:void(0);" target="_blank">
                                 <i class="bi bi-arrow-left-right"></i>
                                 </a>
                              </td>
                           </tr>
                           <tr class="body">
                              <td class="g-text-right star-icon">
                                 <i class="bi-star-fill"></i> 
                              </td>
                              <td class="g-text-left asset-code g-pointer">
                                 <img src="{{ asset('public/assets/img/Bitcoin-BTC-icon.png') }}" class="coin-icon-img" alt=""> MAGIC/USDT
                              </td>
                              <td class="g-text-left">
                                 <span class="g-light-green">0.6642</span>
                                 <span class="g-grey g-font12"> / $ 0.6642 </span>
                              </td>
                              <td class="g-text-left g-light-green"> 15.49% <i class="bi-arrow-up"></i>
                              </td>
                              <td class="g-text-left">0.7721</td>
                              <td class="g-text-left">0.4552</td>
                              <td class="g-text-left">12.11M</td>
                              <td class="g-text-center g-pointer left-right-icon" symbolold="magic/usdt">
                                 <a href="javascript:void(0);" target="_blank">
                                 <i class="bi bi-arrow-left-right"></i>
                                 </a>
                              </td>
                           </tr>
                        </tbody>
                     </table>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
   <div class="bg-overlay"></div>
</section>
<!--==================================================================================================================================================================================================================-->

<section class="needhelp">
   <div class="need_title text-center">
      <h4>Need help</h4>
   </div>
   <div class="container-fluid">
      <div class="row">
         <div class="col-lg-4">
            <div class="needhelp_inner">
               <div class="need_thumb">
                  <img src="{{ asset('public/assets/wealthmark_new/img/icon-chat-support.svg') }}" class="img-fluid" alt="icon_chat_support">
               </div>
               <div class="needhelp_box">
                  <h5>24/7 Chat Support</h5>
                  <p>Get 24/7 chat support with our friendly customer service agents at your service.</p>
               </div>
            </div>
         </div>
         <div class="col-lg-4">
            <div class="needhelp_inner">
               <div class="need_thumb">
                  <img src="{{ asset('public/assets/wealthmark_new/img/faqs.svg') }}" class="img-fluid" alt="faqs">
               </div>
               <div class="needhelp_box">
                  <h5>FAQS</h5>
                  <p>View FAQs for detailed instructions on
                     specific features.
                  </p>
               </div>
            </div>
         </div>
         <div class="col-lg-4">
            <div class="needhelp_inner">
               <div class="need_thumb">
                  <img src="{{ asset('public/assets/wealthmark_new/img/blog.svg') }}" class="img-fluid" alt="blog">
               </div>
               <div class="needhelp_box">
                  <h5>BLOG</h5>
                  <p>Stay up to date with the latest
                     stories and commentary.
                  </p>
               </div>
            </div>
         </div>
      </div>
   </div>
   <div class="more_market">
      <a href="javascript:void(0);" class="btn btn-yellow">View more</a>
   </div>
   <div class="container-fluid ">
      <div class="bottom-box">
      </div>
   </div>
</section>

<!--==================================================================================================================================================================================================================-->

<section class="mob-app p-5">
   <div class="container">
      <div class="row">
         <div class="col-md-6 col-sm-6 col-xs-12 text-center">
            <h3 class="app-heading">  Wealthmark Official API
            </h3>
            <span>Make trading more efficient </span>
         </div>
         <div class="col-md-6 col-sm-6 col-xs-12 text-center pt-4">
            <a href="javascript:void(0);" class="api-doc">
            API Documentation
            </a>
         </div>
      </div>
   </div>
</section>
<!--==================================================================================================================================================================================================================-->
<section class="sign-up p-5">
   <div class="container">
      <div class="row">
         <div class="col-md-12 col-sm-12 col-xs-12 text-center">
            <h3 class="app-heading">  Newsletter
            </h3>
            <span>You deserve easy access to cryptocurrencies Join our newsletter & stay up-to-date with WealthMark</span>
         </div>
      </div>
      <div class="row">
         <div class="col-md-12 col-lg-12 col-sm-12 pt-4 ">
            <div class="subscribe">
               <form>
                  <div class=""> 
                     <input type="email" name="email" id="email" placeholder="Enter your email address" autocomplete="off">
                  </div>
                  &nbsp;   &nbsp;
                  <div class="">
                     <a href="javascript:void(0)" class="btn-yellow"> <span> <i class="bi-arrow-right"> </i> </span><span> Subscribe </span></a>
                  </div>
               </form>
            </div>
         </div>
      </div>
   </div>
</section>

<!--==================================================================================================================================================================================================================-->
<p style="font-size: 16px;color: #095CFA;display: none;" id="acceptNoti"></p>

<div class="cookies" id="cookieNotice">
   <div class="cookie-text">
      <p class="pt-2">We use cookies to offer you a better browsing experience, analyze site traffic, personalize content, and serve targeted advertisements. Read about how we use cookies and how you can control them on our Privacy Policy. If you continue to use this site, you consent to our use of cookies.</p>
   </div>
   <div class="cookie-btn-box">
      <a href="javascript:void(0)" class="customize_cookie btn">Cookies Settings</a>
      <a href="javascript:void(0)" class="cookies_btn all_cookie btn" onclick="acceptCookieConsent();">Accept All Cookies</a>
   </div>
</div>



<!--==================================================================================================================================================================================================================-->
<main class="cookies_discription" style="display:none">
   <section class="container">
      <div class="container__heading">
         <h2>Our Cookies Policy</h2>
      </div>
      <div class="container__content">
         <h3>Cookies Policy</h3>
         <p>At WealtMark, we’re strongly committed to protecting and respecting your privacy</p>
         <p>  This Privacy Policy (“Privacy Policy”) covers your access and use of this Website, wealthmark.io (the “Website”), as well as associated content, software, and mobile applications (collectively, the “Service”).</p>
         <p>This Privacy Policy explains when and why and how we collect and use personal information about people who visit our Website or use our Services, the conditions under which we may disclose your personal information to others, and how we keep your personal information secure.</p>
         <p>We may change this Privacy Policy from time to time so please check this page occasionally to ensure that you are happy with any changes. By using our Website or our Services, you are agreeing to be bound by this Privacy Policy.</p>
         <h3>What Information Do We Collect? </h3>
         <p> WealthMark (“WealthMark”, “we” or “us”) collects</p>
         <ul>
            <li>(a) the e-mail addresses of those who communicate with us via email;</li>
            <li>(b) aggregate information concerning what pages users access or visit;</li>
            <li>(c) information given by the user (such as survey information and/or site registrations); and</li>
            <li>(d) information related to your use of the Website and/or the mobile application, including IP address, Device ID, geographic location, and date and time of your request; </li>
            <li>(e) any other information that you might provide voluntarily. We might also collect your email address and your Wallet ID if you decide to participate to one of our campaigns.</li>
         </ul>
         <h3> How Do We Use the Information? </h3>
         <p> WealthMark uses collected information for the following purposes: </p>
         <ul>
            <li>i.	To fulfill a contract or take steps linked to a contract such as processing your registration on our Website or sending you information about changes to our terms or policies;</li>
            <li>
               ii.	Where it is necessary for purposes which are in WealthMark’s legitimate interests such as 
               <p><b>(a)</b> to provide the information or content you have requested;</p>
               <p><b>(b)</b> to contact you about our programs, products, features or services; </p>
               <p><b>(c)</b> to improve our services and for internal business purposes such as identification and authentication or customer service, portfolio tracking and user preference syncing between devices; </p>
               <p><b>(d)</b> to ensure the security of our Website, by trying to prevent unauthorized or malicious activities; </p>
               <p><b>(e)</b> to enforce compliance with our Terms of Use and other policies; </p>
               <p><b>(f)</b> to help other organizations (such as copyright owners) to enforce their rights; and </p>
               <p><b>(g)</b> to tailor content, advertisements, and offers for you or for other purposes disclosed at the time of collection.</p>
            </li>
            <li>If you do not wish to receive marketing information about our programs, products, features or services, you can opt-out of marketing communications.</li>
            <li>
               Where you give us consent, such as 
               <p><b>(a)</b> where you ask us to send marketing information to you via a medium where we need your consent, including alerts via mobile push notifications;</p>
               <p><b>(b)</b> where you give us consent to place cookies and to use similar technologies; and </p>
               <p><b>(c)</b> on other occasions where we ask you for consent, for any other purpose that might arise.</p>
            </li>
            <li>iii.	Where we are legally required to do so. We may also provide access to your personally identifiable information when legally required to do so, to cooperate with police investigations or other legal proceedings, to protect against misuse or unauthorized use of our Website, to limit our legal liability and protect our rights, or to protect the rights, property or safety of visitors of the Website or the public. In those instances, the information is provided only for that purpose.</li>
         </ul>
         <h3> How Do We Share Your Information? </h3>
         <p> We do not sell your personal data to other organizations for commercial purposes. We also only share your personal information to provide products or services you’ve requested, when we have your permission, or under the following circumstances: </p>
         <ul>
            <li>I.	It is necessary to share information in order to investigate, prevent, or take action regarding illegal activities, suspected fraud, situations involving potential threats to the physical safety of any person, violations of Terms of Service, or as otherwise required by law.</li>
            <li>II.	We provide personal information to trusted businesses or persons for the sole purpose of processing personally identifying information on our behalf and provide us with services. When this is done, it is subject to agreements that oblige those parties to process such information only on our instructions and in compliance with this Privacy Policy and appropriate confidentiality and security measures.</li>
            <li>III.	We provide such information to third parties who have entered into non-disclosure agreements with us.</li>
            <li>IV.	We provide such information to a company controlled by, or under common control with, WealthMark for any purpose permitted by this Privacy Policy.</li>
            <li>V.	We may aggregate, anonymize, and publish data for statistical and research purposes only. For example, we may compile and share information related to the popularity of certain products tracked by users. In any such instance, the information will not be able to be traced back to any individual.</li>
         </ul>
         <h3>Security</h3>
         <p> We take precautions to ensure the security of your personal information. We ensure that our Website is protected by reasonable security measures afforded by current technology, and that all our data hosts and servers are similarly protected by such security measures, including but not limited to firewalls. We strongly advise you to change your password frequently and not to use the same password for different websites. </p>
         <p> We cannot protect, nor does this Privacy Policy apply to, any information that you transmit to other users. You should never transmit personal or identifying information to other users. </p>
         <h3>Retention of Your Personal Information</h3>
         <p> We retain information as long as it is necessary to provide the Services requested by you and others, subject to any legal obligations to further retain such information. Information associated with your account will generally be kept until it is no longer necessary to provide the Services or until you ask us to delete it or your account is deleted, whichever comes first. Additionally, we may retain information from deleted accounts to comply with the law, prevent fraud, resolve disputes, troubleshoot problems, assist with investigations, enforce the Terms of Use, and take other actions permitted by law. The information we retain will be handled in accordance with this Privacy Policy. </p>
         <h3>Children</h3>
         <p>  We do not knowingly collect information from children under the age of 18. Children aged 17 or younger should not submit any personal information without the permission of their parents or guardians. By using the WealthMark service, you are representing that you are at least 18 years old. </p>
         <h3>EU and EEA Users’ Rights</h3>
         <p> If you are a resident of the European Economic Area, you generally have the right to access, rectify, download or erase your information, as well as the right to restrict and object to certain processing of your information. While some of these rights apply generally, certain rights apply only in certain limited circumstances. We briefly describe these rights below: </p>
         <p>  You have the right to access your personal data and, if necessary, have it amended, deleted or restricted. In certain instances, you may have the right to the portability of your data. You can also ask us not to send marketing communications and not to use your personal data when we carry out profiling for direct marketing purposes. You can opt out of receiving e-mail newsletters and other marketing communications by following the opt-out instructions provided to you in those e-mails. Transactional account messages will be unaffected even if you opt out from marketing communications. </p>
         <h3>Complaints</h3>
         <p>  Should you wish to raise a concern about our use of your information (and without prejudice to any other rights you may have), you have the right to do so with your local supervisory authority, although we hope that we can assist with any queries or concerns you may have about our use of your personal data. </p>
         <h3>Your California Privacy Rights</h3>
         <p>  WealthMark may have collected, used, and shared, for business purposes, personal information about you as described in this Privacy Policy. Each category of data may be used by WealthMark or shared with third parties also as described in this Privacy Policy. Residents of California have the right to request access to and deletion of the information WealthMark holds about them. Such requests may be submitted by email to legal@wealthmark.io or by mail to WealthMark LLC. WealthMark will not sell your personal information without your consent. WealthMark will not discriminate against you for exercising your rights under CCPA. Specifically, we will not: </p>
         <ul>
            <li>Deny access to our Services;</li>
            <li>Charge a different rate for the use of our Services; or</li>
            <li>Provide a different quality of service.</li>
         </ul>
         <h3>Changes</h3>
         <p>  WealthMark may periodically update this policy as deemed necessary. You may access this Policy at any time through our website. </p>
         <h3>Questions</h3>
         <p>  Any questions about this Privacy Policy should be addressed to this e-mail address: <b>legal@wealthmark.io.</b> </p>
         <p>  Effective Date: January 01, 2022. </p>
      </div>
      <div class="container__nav">
         <small>By clicking 'Accept' you are agreeing to our Privacy Policy.</small>
         <a class="button custom_cookie_Accept" href="javascript:void(0)" onclick="acceptCookieConsent();">Accept</a>
      </div>
   </section>
</main>

<!--===================================================================================================================================================================================-->

<div class="modal fade" id="exampleModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog" style="max-width:400px;margin:10% auto;">
    <div class="modal-content pt-3 pb-3 p-3">
        <div class="modal-header" style="border:none;padding:0px;margin-bottom:10px;">
            <img class="warning-img" src="{{ asset('public/assets/img/warning.svg') }}" >
        </div>
        <div class="modal-body">
            <div class="warning-notes">
                <p>Beware of new scams. Under no circumstances will Wealthmark call you directly. Learn more</p>
                <p class="icon"> <span class="does" ><i class="bi bi-check-circle-fill"></i> </span><span class="text"> Participate in activities only on the <span class="wealthmark-text">「official」Wealthmark website</span> </span></p>
                <p class="icon"> <span class="does" ><i class="bi bi-check-circle-fill"></i></span> <span class="text">Verify sources via <span class="wealthmark-text"> Wealthmark </span>  Verify to check if it is official </span></p>
                <p class="icon"> <span class="dont" ><i class="bi bi-x-circle-fill"></i></span> <span class="text">Ignore unrealistic high ROI investments </span></p>
                <p class="icon"> <span class="dont" ><i class="bi bi-x-circle-fill"></i></span> <span class="text"> Ignore requests from government impersonators </span></p>
                <p class="icon"> <span class="dont" ><i class="bi bi-x-circle-fill"></i></span> <span class="text">Do not withdraw to unofficial addresses or platforms </span></p>
                <p class="icon"> <span class="dont" ><i class="bi bi-x-circle-fill"></i></span> <span class="text">Do not disclose your verification code or account information to anyone </span></p>
            </div>
        </div>
        <div class="modal-footer"  style="border:none;padding:0px;margin-top:20px;">
            <button type="button" class="btn btn-yellow w-100 got-it" data-bs-dismiss="modal">GOT IT</button>
        </div>
    </div>
  </div>
</div>




 
 

    @include('template.country_language')
    @include('template.web_footer') 
  
 
  

   <script>
   
//   <!--=================text slider top =============================-->
  
  $(document).ready(function(){
		pagenum = 1;
		function AutoRotate() {
		   var myele = null;
		   var allElements = document.getElementsByClassName('myslider');
		   for (var i = 0, n = allElements.length; i < n; i++) {
			   var myfor = allElements[i].getAttribute('for');
			   if ((myfor !== null) && (myfor == ('slide_2_' + pagenum))) {
				   allElements[i].click();
				   break;
			   }
		   }
		   if (pagenum == 4) {
			   pagenum = 1;
		   } else {
			   pagenum++;
		   }
		}
// 		setInterval(AutoRotate, 5000);
	});
// <!--=================text slider top =============================-->
   
         $(".close").click(function(){
             $(".select_country").hide();
        });
    
        $(".app-down-close").click(function(){
             $(".download_mob_app").hide();
        })
      
      
   //   =========================	tab pills js=========================

	    $(document).ready(function(){
	
	        $('ul.tabs li').click(function(){
		        var tab_id = $(this).attr('data-tab');
		        $('ul.tabs li').removeClass('current');
		        $('.table-content').removeClass('current');

		        $(this).addClass('current');
		        $("#"+tab_id).addClass('current');
	       })

        })
   //   =========================	tab pills js=========================
        $(window).on('load', function () {
            $('#exampleModal').modal('show');
         }); 

        $(document).ready(function(){
	
            $(".btn-mobile-nav").click(function(){
                $("#btn-mobile-nav").show();
            });

        })
           
      
        //   cookies_btn
        $(".cookies_btn").click(function(){
             $(".cookies").hide();
        })
      
        $(".customize_cookie").click(function(){
            $(".cookies_discription").css("display" , "block");
             $(".cookies").css("display" , "none");
        });   
      
        $(".custom_cookie_Accept").click(function(){
            $(".cookies_discription").css("display" , "none");
        }); 
      
   </script>

 

  <!-- market page filter tab -->
  <script>
      $('.tabs').on('click', function(){
      $('.tabs').removeClass('active');
      $(this).addClass('active');
    });
  </script>

  <!-- Home Page small Banners Slider -->
  <script>
    new Swiper('.mySwiper', {
      speed: 400,
      loop: true,
      navigation: {
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev",
          },
      autoplay: {
        delay: 5000,
        disableOnInteraction: false
      },
      slidesPerView: 'auto',
      pagination: {
        el: '.swiper-pagination',
        type: 'bullets',
        clickable: true
      },
    
      breakpoints: {
        320: {
          slidesPerView: 1,
          spaceBetween: 10
        },
        480: {
          slidesPerView: 1,
          spaceBetween: 10
        },
        640: {
          slidesPerView: 2,
          spaceBetween: 80
        },
        992: {
          slidesPerView: 4,
          spaceBetween: 15
        }
      }
      
    });
  </script>

  <!-- Home Page Summary Card Slider -->
  <script>
    var swiper = new Swiper(".summarySwiper", {
      speed: 400,
      loop: true,
      autoplay: {
        delay: 3000,
        disableOnInteraction: true
      },
  
      breakpoints: {
        320: {
          slidesPerView: 1,
          slidesPerGroup: 1,
          spaceBetween: 10
        },
        480: {
          slidesPerView: 1,
          slidesPerGroup: 1,
          spaceBetween: 10
        },
        640: {
          slidesPerView: 2,
          slidesPerGroup: 2,
          spaceBetween: 80
        },
        992: {
          slidesPerView: 6,
          slidesPerGroup: 6,
          spaceBetween: 15
        }
      }
      
    });

  </script>


</body>

</html>
