<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <title>Wealth Mark | {{ Request::segment(2) }}</title>
    @include('template.web_css')
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/1.6.2/tailwind.min.css" />
    <style>
        #banner-section {
        background-color: #1b2742;
        }

        .display-3 {
        font-size: 4rem;
        text-align: left;
        }

        .mb-4 {
        margin-bottom: 1.5rem !important;
        text-align: left;
        }

        #project-report h4 {
        color: black;
        text-align: center;
        }

        #project-report .project-icon {
        width: 50px;
        }

        #project-report h4 {
        font-weight: bold;
        }

        #project-report .row:first-child {
        border-bottom: 1px solid #d9d9d9;
        }

        img {
        cursor: pointer;
        }

        .container {
        width: 1040px;
        }



        h3 {
        font-size: 1.75rem;
        }

        a {
        cursor: pointer;
        }

        section#project-report {
        background-color: #f1f1f1;
        }

        #project-analysis-tab {
        display: none;
        }

        .col-md-4 {
        float: left;
        justify-content: center;
        align-items: center;
        display: flex;
        }

        .col-md-8 {
        float: left;
        }

        .active-project-tab h4 {
        width: 150px;
        display: block;
        margin: auto;
        border-bottom: 6px solid #f0b907;
        padding-bottom: 8px;
        }



        #project-report .h5,
        h5 {
        font-size: 1.1rem;
        color: black;
        }

        #heading-insight h4 {
        font-size: 1.2em;
        margin: 10px;
        font-weight: bold !important;
        }

        #heading-latest-project h4 {
        font-size: 1.2em;
        margin: 10px;
        font-weight: bold !important;
        }

        #heading-latest-project .h5,
        h5 {
        font-size: 1.1rem;
        color: black;
        }


        #latest-insight .card img {
        border-top-right-radius: 8px !important;
        border-top-left-radius: 8px;
        }

        .clients-logo img{
        width: 125px;
        margin: 10px 15px 10px 15px;
        }
        #our-collaboration-section  h4 {
        font-size: 1.2em;
        margin: 10px;
        font-weight: bold !important;
        }
        #our-collaboration-section  .h5,
        h5 {
        font-size: 1.1rem;
        color: black;
        }
        #our-collaboration-section .col-md-2 {
        flex: 0 0 auto;
        width: 11.666667%;
        justify-content: center;
        align-items: center;
        display: flex;
        }
        #our-collaboration-section .container{
        padding:0px;
        }
        #our-collaboration-section img{
		transition: transform 250ms;
		}
        #our-collaboration-section img:hover{
		transform: translateY(-10px);
		}

        #latest-insight img{
		transition: transform 250ms;
		}
        #latest-insight img:hover{
		transform: translateY(-10px);
		}

        #banner-section img{
		transition: transform 250ms;
		}
        #banner-section img:hover {
        transform: translate(10px, 10px);
        }

        #latest-project img {
        border-radius: 8px !important;
        }
        #latest-project img:hover {
        border-radius: 8px !important;
        }


        #latest-project .card {
        border-radius: 8px !important;
        box-shadow: rgb(90 102 124 / 10%) 0px 2px 10px 0px !important;
        }
        #latest-project .card:hover {
        box-shadow: rgb(90 102 124 / 50%) 0px 1px 20px 0px !important;
        border-radius: 8px !important;
        }
      
     
        @media(max-width:768px){
            #latest-project .card {
    border-radius: 8px !important;
    box-shadow: rgb(90 102 124 / 10%) 0px 2px 10px 0px !important;
    margin: 10px;
}

            #latest-insight .card{
                margin: 10px;
            }
            #latest-insight .mt-2{
                justify-content: center!important;
            }
            #latest-project .mt-2{
                justify-content: center!important;
            }
            .row {
                --bs-gutter-x: 0rem!important;
            }
        #our-collaboration-section .col-md-2 {
        flex: 0 0 auto;
        width: 32.666667%;
        justify-content: center;
        align-items: center;
        display: flex;
        }
      
        div#collaboration-row{
            justify-content:center;
        }
        #project-analysis-tab {
            align-items: center;
            justify-content: center;
            display: flex;
        }
        #project-analysis-tab .col-sm-8{
            padding: 0px 21px;
        }
        #project-report-tab{
            align-items: center;
            justify-content: center;
            display: flex;
        }
        #project-report-tab .col-sm-8{
            padding: 0px 21px;
        }
        #project-analysis-tab {
        display: none;
        }
      
      #project-analysis-tab img{
        margin-top: 28px;
      }
        .display-3 {
        font-size: 2rem;
        text-align: left;
        }
      
            #banner-section .mb-4 {
            margin-bottom: 1.5rem !important;
            text-align: left;
            font-weight: 300!important;
            }
    }
    @media(min-width:768px) and (max-width:992px){
        #project-analysis-tab img{
            margin-top:28px;
        }
        #project-report-tab img{
            margin-top:28px;
        }
    }

    @media(max-width:576px){
                  #project-report  .col-sm-12 {
                flex: 0 0 auto;
                width: 50%!important;
            }
    }
    </style>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script>
    $(document).ready(function() {
        $("#project-1").click(function() {
            $("#project-1").addClass("active-project-tab");
            $("#project-2").removeClass("active-project-tab");
            $("#project-report-tab").show();
            $("#project-analysis-tab").hide();
        });
        $("#project-2").click(function() {
            $("#project-2").addClass("active-project-tab");
            $("#project-1").removeClass("active-project-tab");
            $("#project-report-tab").hide();
            $("#project-analysis-tab").show();
        });
    });
    </script>

</head>

<body>
    @include('template.mobile_menu')
    @include('template.web_menu')
    <div class="text-center mt-3 bg-light-yellow" id="register-row">
        <a href="{{ url( app()->getLocale(), 'register') }}"> <span class="offer-text-head">
                Register now - Enjoy Welcome Rewards up to 1 BMK! ( for verified user)
            </span>
        </a>
    </div>

    <!-- banner section started -->
    <section class="pt-8 pb-8 bg-gradient-primary" id="banner-section">
        <div class="container">
            <div class="row align-items-center justify-content-center justify-content-md-between">
                <div class="col-12 col-lg-6 col-xs-12 col-sm-12 text-center text-md-left text-white">
                    <h1 class="display-3 font-weight-bold">Wealth Mark</h1>
                    <p class="text-white-90 lead mb-4 banner-para">Wealth Mark Research provides institutional-grade
                        analysis, in-depth insights, and unbiased information to all participants in the digital asset
                        industry.</p>
                </div>
                <div class="col-12 col-lg-6 col-xs-12 col-sm-12 text-center">
                    <img loading="lazy" class="d-block img-fluid banner-main-img"
                        src="{{ asset('public/assets/img/research-banner.png') }}" alt="Trust Wallet app">
                </div>
            </div>
        </div>
    </section>
    <!-- banner section End -->



    <!-- project-report section started -->
    <section class="pt-8 pb-8" id="project-report">
        <div class="container">
            <div class="row align-items-center justify-content-center justify-content-md-between">
                <div class="col-sm-6 col-xs-6 col-md-6 col-lg-6 text-center">
                    <a href="javascript:void(0);" class="project-1 active-project-tab" id="project-1">
                        <img loading="lazy" class="mx-auto d-block project-icon"
                            src="{{ asset('public/assets/img/project-report-icon.png') }}" alt="Trust Wallet app">
                        <h4>Project Reports</h4>
                    </a>
                </div>
                <div class="col-sm-6 col-xs-6 col-md-6 col-lg-6 text-center">
                    <a href="javascript:void(0);" class="project-1" id="project-2">
                        <img loading="lazy" class="mx-auto d-block project-icon"
                            src="{{ asset('public/assets/img/project-report-icon.png') }}" alt="Trust Wallet app">
                        <h4>Analysis Reports</h4>
                    </a>
                </div>
            </div>

            <div class="row mt-2" id="project-report-tab">
                <div class="col-md-4 col-sm-4 col-xs-4">
                    <img loading="lazy" src="{{ asset('public/assets/img/card1.jpg') }}" alt="Trust Wallet app">
                </div>
                <div class="col-12 col-lg-6 col-md-8 col-xs-8 col-sm-8">
                    <h3 class="text-left mb-3 mt-4">Project Reports</h3>
                    <p class="mb-3">"Lorem Ipsum is simply dummy text of the printing and typesetting industry". </p>
                    <span class="text-warning">Read our latest report </span>
                </div>
            </div>

            <div class="row mt-2" id="project-analysis-tab">
                <div class="col-md-4 col-sm-4 col-xs-4">
                    <img loading="lazy" src="{{ asset('public/assets/img/project-analysis.png') }}"
                        alt="Trust Wallet app">
                </div>
                <div class="col-12 col-lg-6 col-md-8 col-xs-8 col-sm-8">
                    <h3 class="text-left mb-3 mt-4">Analysis Reports</h3>
                    <p class="mb-3">"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor".</p>
                    <span class="text-warning">Read our latest report </span>
                </div>
            </div>


        </div>
    </section>
    <!-- project report section End -->


    <!-- latest insight and analytics -->
    <section class="pt-8 pb-8" id="latest-insight">
        <div class="container">

            <div class="row mt-2" id="heading-insight">
                <div class="col-md-6 col-xs-6 col-sm-5">
                    <h4 class="text-left">Latest Insights & Analysis </h4>
                </div>
                <div class="col-md-6 col-xs-6 col-sm-5">
                    <h4 class="text-right"><a href="javascript:void(0);">View All </a></h4>
                </div>
            </div>
            <div class="row mt-2" id="project-report-tab">
                <div class="col-md-3 col-xs-6 col-sm-5">
                    <div class="card">
                        <img loading="lazy" src="{{ asset('public/assets/img/insight-1.png') }}" alt="Trust Wallet app">
                        <div class="card-body">
                            <h5 class="card-title">Latest Insights & Analysis</h5>
                            <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
                            <a href="" class="text-warning">View More</a>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 col-xs-6 col-sm-5">
                    <div class="card">
                        <img loading="lazy" src="{{ asset('public/assets/img/project-analysis.png') }}"
                            alt="Trust Wallet app">
                        <div class="card-body">
                            <h5 class="card-title">Latest Insights & Analysis</h5>
                            <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
                            <a href="" class="text-warning">View More</a>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 col-xs-6 col-sm-5">
                    <div class="card">
                        <img loading="lazy" src="{{ asset('public/assets/img/insight-1.png') }}" alt="Trust Wallet app">
                        <div class="card-body">
                            <h5 class="card-title">Latest Insights & Analysis</h5>
                            <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
                            <a href="" class="text-warning">View More</a>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 col-xs-6 col-sm-5">
                    <div class="card">
                        <img loading="lazy" src="{{ asset('public/assets/img/project-tabing-img1.png') }}"
                            alt="Trust Wallet app">
                        <div class="card-body">
                            <h5 class="card-title">Latest Insights & Analysis</h5>
                            <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
                            <a href="" class="text-warning">View More</a>
                        </div>
                    </div>
                </div>

            </div>




        </div>
    </section>
    <!-- latest insight and analystics end -->


    <!-- latest project section -->
    <section class="pt-8 pb-8" id="latest-project">
        <div class="container">
            <div class="row mt-2" id="heading-latest-project">
                <div class="col-md-6 col-xs-6 col-sm-5">
                    <h4 class="text-left">Latest Project Reports</h4>
                </div>
                <div class="col-md-6 col-xs-6 col-sm-5">
                    <h4 class="text-right"><a href="javascript:void(0);">View All </a></h4>
                </div>
            </div>
            <div class="row mt-2" id="latest-project-inner-block-1">
                <div class="col-md-3 col-xs-6 col-sm-5">
                    <div class="card">
                        <img loading="lazy" src="{{ asset('public/assets/img/card1.jpg') }}" alt="Trust Wallet app" class="img-fluid">
                        <div class="card-body">
                            <h5 class="card-title">Latest Project Reports-1</h5>
                            <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
                            <a href="" class="text-warning">View More</a>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 col-xs-6 col-sm-5" id="latest-project-inner-block-2">
                    <div class="card">
                        <img loading="lazy" src="{{ asset('public/assets/img/card2.jpg') }}" alt="Trust Wallet app" class="img-fluid">
                        <div class="card-body">
                            <h5 class="card-title">Latest Project Reports-2</h5>
                            <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
                            <a href="" class="text-warning">View More</a>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 col-xs-6 col-sm-5" id="latest-project-inner-block-3">
                    <div class="card">
                        <img loading="lazy" src="{{ asset('public/assets/img/card3.jpg') }}" alt="Trust Wallet app" class="img-fluid">
                        <div class="card-body">
                            <h5 class="card-title">Latest Project Reports-3</h5>
                            <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
                            <a href="" class="text-warning">View More</a>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 col-xs-6 col-sm-5" id="latest-project-inner-block-4">
                    <div class="card">
                        <img loading="lazy" src="{{ asset('public/assets/img/card4.jpg') }}" alt="Trust Wallet app" class="img-fluid">
                        <div class="card-body">
                            <h5 class="card-title">Latest Project Reports-4</h5>
                            <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
                            <a href="" class="text-warning">View More</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- latest insight and analystics end -->




       <!-- our collaboratoins with clienets sections -->
       <section class="pt-8 pb-8" id="our-collaboration-section">
        <div class="container">
            <div class="row mt-2" id="collaboration-heading-insight">
                <div class="col-md-12">
                    <h4 class="text-center">Wealth Mark Research was quoted by</h4>
                </div>
            </div>
            <div class="row mt-2" id="collaboration-row">
                <div class="col-md-2">
                    <div class="clients-logo">
                        <img loading="lazy" src="{{ asset('public/assets/img/logo-1.png') }}" alt="Trust Wallet app" class="img-fluid">
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="clients-logo">
                        <img loading="lazy" src="{{ asset('public/assets/img/logo-2.png') }}" alt="Trust Wallet app" class="img-fluid">
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="clients-logo">
                        <img loading="lazy" src="{{ asset('public/assets/img/logo-3.png') }}" alt="Trust Wallet app" class="img-fluid">
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="clients-logo">
                        <img loading="lazy" src="{{ asset('public/assets/img/logo-4.png') }}" alt="Trust Wallet app" class="img-fluid">
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="clients-logo">
                        <img loading="lazy" src="{{ asset('public/assets/img/logo-5.png') }}" alt="Trust Wallet app" class="img-fluid">
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="clients-logo">
                        <img loading="lazy" src="{{ asset('public/assets/img/logo-6.png') }}" alt="Trust Wallet app" class="img-fluid">
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="clients-logo">
                        <img loading="lazy" src="{{ asset('public/assets/img/logo-7.png') }}" alt="Trust Wallet app" class="img-fluid">
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="clients-logo">
                        <img loading="lazy" src="{{ asset('public/assets/img/logo-8.png') }}" alt="Trust Wallet app" class="img-fluid">
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- our collaboratoins with clienets sections end -->

    @include('template.country_language')
    @include('template.web_footer')
</body>

</html>