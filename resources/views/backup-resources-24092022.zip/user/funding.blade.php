<!DOCTYPE html><html lang="en">
<head>
<meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>Buy, trade, and hold 100+ cryptocurrencies on Wealthmark</title>
  <meta content="" name="description">
  <meta content="" name="keywords">
  <meta name="theme-color" content="#287aff">
  <link href="{{ asset('public/assets/img/wealthmark-logo.svg') }}" rel="icon">
  <link href="{{ asset('public/assets/img/wealthmark-logo.svg') }}" rel="apple-touch-icon">
  <link rel="stylesheet" href="{{ asset('public/assets/css/dashboard.css') }}">
  @include('template.web_css') 
    <style>
  .sidebar-nav{
      display:block;
  }
  #preloader{
      display:none !important;
  }
  
  @media (max-width: 450px){

  .balance-details .dashboard-card-header{
      display:block;
      
  }
  .dashboard-card-heading{
      margin-bottom:10px;
      display:block;
  }
  .balance-details .dashboard-card-header .btn-theme-sm{
      margin-left:0px;
  }
 #progressbar li{
     width:33% !important;
 }
      
  }
  
  
  
  
  
  
  /*----------------------------------------------------------- for side bar css only-----------------------------------------------------------*/
  
 
   @media (max-width: 992px){
 .hide_on_max_dashboard_992{
     display:none !important;
 } 
   }
  .dashboard-main{
      margin-top:10px !important;
  }
.hide_on_dashboard{
    display:none !important;
} 
header{
    box-shadow:0 .125rem .25rem rgba(0,0,0,.075)!important;
    background:white;
   z-index:9999999999 !important;
 
}
  .sidebar-btn-open{
      font-size: 30px;
    color: #242424;
  }
  @media (max-width: 992px){
     .sidebar.active {
    display: block;
    top: 0px !important;
    position: fixed !important;
    right: 0 !important;
    left:auto !important;
      }
      
.dashboard-sidebar {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    position: fixed;
    inset: 0px;
    z-index: 9999;
    flex-direction: row-reverse;
    background-color: rgba(0, 0, 0, 0.1);
    display: none;
    transition: all 0.5s ease;
}
.dashboard-sidebar-flex{
    display:flex !important;
}
  }
    /*----------------------------------------------------------- for side bar css only-----------------------------------------------------------*/
  
  
  
  </style>
</head>
<body>
     @include('template.dashboard_mobile_menu')  
    @include('template.web_menu') 
    <div class="dashboard-main">
    @include('template.sidebar')
    <div class="container-fluid">
      <section class="dashboard-breadcrumb">
         <div class="container">
            <div class="row gap-y-3 align-items-center justify-content-md-between">
               <div class="col-md-3">
                  <h2 class="fw-bold mb-0">Funding</h2>
               </div>
               <div class="col-md-9 text-md-end">
                   <div class="theme-tab-list justify-content-md-end">
                        <a href="#" class="btn-theme">Deposit</a>
                        <a href="#" class="btn-theme-light">Withdraw</a>
                        <a href="#" class="btn-theme-light">Send</a>
                        <a href="#" class="btn-theme-light">Transfer</a>
                        <a href="#" class="btn-theme-light">History</a>
                   </div>
                  
               </div>
            </div>
         </div>
      </section>
      <div class="container my-assets py-2rem">  
         <div class="row gap-y-3 align-items-center justify-content-between">
            <div class="col-lg-8 col-md-6">
                <div class="d-flex align-items-center ">
                    <h5 class="mb-0">Estimated Balance <a href="#" class="bi bi-eye eye-btn text-theme-yellow ms-2"></a></h5>
                </div>
                <div class="d-flex align-items-center mt-4 hide-when-astix ">
                    <span class="h4 mb-0 me-2 fw-bold est-balance">0.00000000 </span><span class="h4 mb-0 fw-bold est-balance"> BTC &nbsp;</span><span class="h4 mb-0 est-balance fw-bold text-muted">≈ &nbsp; ₹0.000000</span>
                </div>
                <div class="d-none astix mt-4">
                    <div class="text-dark h4">********</div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 text-right">
                <div class="row">
                    <div class="col">
                        <div class="fund-icon-contain">
                        <img src="{{asset('public/assets/img/header-icons/mega-option/gift-card.svg') }}" alt="" class="fund-icon">
                        </div>
                        <div class="text-muted mt-2">Buy/Sell</div>
                    </div>
                    <div class="col">
                        <div class="fund-icon-contain">
                        <img src="{{asset('public/assets/img/header-icons/mega-option/gift-card.svg') }}" alt="" class="fund-icon">
                        </div>
                        <div class="text-muted mt-2">Buy/Sell</div>
                    </div>
                    <div class="col">
                        <div class="fund-icon-contain">
                        <img src="{{asset('public/assets/img/header-icons/mega-option/gift-card.svg') }}" alt="" class="fund-icon">
                        </div>
                        <div class="text-muted mt-2">Buy/Sell</div>
                    </div>
                </div>
            </div>
            
         </div>
      </div>

    <div class="container ">
        <div class="row align-items-center gap-y-3 py-2rem border-top">
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
                <input type="text" class="form-control" placeholder="Search" />
            </div>
            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                <div class="form-check">
                <input class="form-check-input" type="checkbox" value="" id="defaultCheck1">
                <label class="form-check-label" for="defaultCheck1">
                    Hide 0 balance assets
                </label>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12 table-theme table-responsive">
                <table id="example" class="table table-hover w-100" >
                    <thead class="table-light">
                        <tr>
                            <th>Assets</th>
                            <th>Total Amount</th>
                            <th>Available</th>
                            <th>Frozen</th>
                            <th>BTC Value</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><img src="{{asset('public/assets/img/Bitcoin-BTC-icon.png') }}" class="coin-icon-img" alt=""> BTC <span class="text-muted">Bitcoin</span> </td>
                            <td>0.00000000</td>
                            <td>0.00000000</td>
                            <td>0.00000000</td>
                            <td>0.00000000</td>
                            <td>
                                <a href="#" class="text-theme-yellow me-2">Buy</a>
                                <a href="#" class="text-theme-yellow me-2" >Sell</a>
                                <a href="#" class="text-theme-yellow me-2" >Deposit</a>
                                <a href="#" class="text-theme-yellow me-2" >Withdraw</a>
                                <a href="#" class="text-theme-yellow me-2" >Trade</a>
                                <a href="#" class="text-theme-yellow me-2" >Earn</a>
                                <a href="#" class="text-theme-yellow" >Convert</a>
                            </td>
                        </tr>
                        <tr>
                            <td><img src="{{asset('public/assets/img/Bitcoin-BTC-icon.png') }}" class="coin-icon-img" alt=""> BTC <span class="text-muted">Bitcoin</span> </td>
                            <td>0.00000000</td>
                            <td>0.00000000</td>
                            <td>0.00000000</td>
                            <td>0.00000000</td>
                            <td>
                                <a href="#" class="text-theme-yellow me-2">Buy</a>
                                <a href="#" class="text-theme-yellow me-2" >Sell</a>
                                <a href="#" class="text-theme-yellow me-2" >Deposit</a>
                                <a href="#" class="text-theme-yellow me-2" >Withdraw</a>
                                <a href="#" class="text-theme-yellow me-2" >Trade</a>
                                <a href="#" class="text-theme-yellow me-2" >Earn</a>
                                <a href="#" class="text-theme-yellow" >Convert</a>
                            </td>
                        </tr>
                        <tr>
                            <td><img src="{{asset('public/assets/img/Bitcoin-BTC-icon.png') }}" class="coin-icon-img" alt=""> BTC <span class="text-muted">Bitcoin</span> </td>
                            <td>0.00000000</td>
                            <td>0.00000000</td>
                            <td>0.00000000</td>
                            <td>0.00000000</td>
                            <td>
                                <a href="#" class="text-theme-yellow me-2">Buy</a>
                                <a href="#" class="text-theme-yellow me-2" >Sell</a>
                                <a href="#" class="text-theme-yellow me-2" >Deposit</a>
                                <a href="#" class="text-theme-yellow me-2" >Withdraw</a>
                                <a href="#" class="text-theme-yellow me-2" >Trade</a>
                                <a href="#" class="text-theme-yellow me-2" >Earn</a>
                                <a href="#" class="text-theme-yellow" >Convert</a>
                            </td>
                        </tr>
                        
                    </tbody>
                    
                </table>
             </div>
        </div>
    </div>

   </div>
    </div>
    

   @include('template.web_footer') 	
</body>
</html>

