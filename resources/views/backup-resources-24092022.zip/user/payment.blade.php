<!DOCTYPE html><html lang="en">
<head>
<meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>Buy, trade, and hold 100+ cryptocurrencies on Wealthmark</title>
  <meta content="" name="description">
  <meta content="" name="keywords">
  <meta name="theme-color" content="#287aff">
  <link href="{{ asset('public/assets/img/wealthmark-logo.svg') }}" rel="icon">
  <link href="{{ asset('public/assets/img/wealthmark-logo.svg') }}" rel="apple-touch-icon">
  <link rel="stylesheet" href="{{ asset('public/assets/css/dashboard.css') }}">
  @include('template.web_css') 
  
   <style>
  .sidebar-nav{
      display:block;
  }
  #preloader{
      display:none !important;
  }
  
  @media (max-width: 450px){

  .balance-details .dashboard-card-header{
      display:block;
      
  }
  .dashboard-card-heading{
      margin-bottom:10px;
      display:block;
  }
  .balance-details .dashboard-card-header .btn-theme-sm{
      margin-left:0px;
  }
 #progressbar li{
     width:33% !important;
 }
      
  }
  
  
  
  
  
  
  /*----------------------------------------------------------- for side bar css only-----------------------------------------------------------*/
  
 
   @media (max-width: 992px){
 .hide_on_max_dashboard_992{
     display:none !important;
 } 
   }
  .dashboard-main{
      margin-top:10px !important;
  }
.hide_on_dashboard{
    display:none !important;
} 
header{
    box-shadow:0 .125rem .25rem rgba(0,0,0,.075)!important;
    background:white;
   z-index:9999999999 !important;
 
}
  .sidebar-btn-open{
      font-size: 30px;
    color: #242424;
  }
  @media (max-width: 992px){
     .sidebar.active {
    display: block;
    top: 0px !important;
    position: fixed !important;
    right: 0 !important;
    left:auto !important;
      }
      
.dashboard-sidebar {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    position: fixed;
    inset: 0px;
    z-index: 9999;
    flex-direction: row-reverse;
    background-color: rgba(0, 0, 0, 0.1);
    display: none;
    transition: all 0.5s ease;
}
.dashboard-sidebar-flex{
    display:flex !important;
}
  }
    /*----------------------------------------------------------- for side bar css only-----------------------------------------------------------*/
  
  
  
  </style>
    <style>
   .dashboard-card-body .nav-link{
    font-size: 16px;
}
.dashboard-card-body .nav-pills .nav-link.active{
    font-size: 16px;
}
.btn-theme-gray{
   font-family: "Jost", sans-serif;
    font-weight: 500;
    font-size: 16px;
    letter-spacing: 1px;
    display: inline-block;
    padding: 10px 20px 10px 20px;
    border-radius: 5px;
    color: #222222;
    background-color: #b8b6b6;
}
.btn-theme-gray:hover{
   background: linear-gradient(180deg, rgba(254, 192, 15, 1) 0%, rgba(248, 165, 50, 1) 100%);
   color: #222222;
}
.pay-method-text{
   color: #222222;
   font-size: 14px;
}
.pay-method-text:hover{
   color: #d5a419;
}
.pay-method-icon{
   box-sizing: border-box;
    margin: 0px 8px 0px 0px;
    min-width: 0px;
    width: 4px;
    height: 14px;
    border-radius: 4px;
    background: linear-gradient( 180deg, rgba(254,192,15,1) 0%, rgba(248,165,50,1) 100%);
    display: inline-block;
}

.form-control.no-border-field{
    padding: 0rem;
    border-top: none;
    border-left: none;
    border-right: none;
    border-radius: 0px;
}
.atoz-filter{
   background-color: #fff;
   padding: 2px;
   border-radius: 2px;
   transition: 0.1s;
   margin-right: 2px;
   color: gray;
   display: inline-block;
   font-size: 14px;
}
.atoz-filter:hover{
   background-color: #eee;
}
.atoz-filter.active{
   background: linear-gradient( 180deg, rgba(254,192,15,1) 0%, rgba(248,165,50,1) 100%);
   color: #fff;
}
@media  only screen and (max-width: 600px) {
   .pay-method-mobile{
      display: flex;
    flex-basis: 100%;
   }
   .pay-method-mobile p, .pay-method-mobile span{
      font-size: 14px;
   }
   .pay-method-mobile span{
      text-align: right;
      flex: 1 1 0%;
   }
}
.card{
   border: 1px solid rgb(230, 232, 234);
}
.card-header {
    border-bottom: 1px solid rgb(230, 232, 234);
    background-color: #fafafa;
}
</style> 
  
  
</head>
<body>
    @include('template.dashboard_mobile_menu')  
    @include('template.web_menu')    
    <div class="dashboard-main">
        @include('template.sidebar')
        <div class="container-fluid">
            <section class="dashboard-breadcrumb mb-2rem">
                <div class="container">
                    <h2 class="fw-bold mb-0">Payment</h2>
                </div>
            </section>
            
            <div class="container">
                 <div class="row">
                    <div class="col-12">
                       <div class="dashboard-card-body">
                             <ul class="nav nav-pills mb-4 border-bottom" id="pills-tab" role="tablist">
                                <li class="nav-item " role="presentation">
                                      <button class="nav-link active ps-0" id="pills-ptop-tab" data-bs-toggle="pill" data-bs-target="#pills-ptop" type="button" role="tab" aria-controls="pills-ptop" aria-selected="true">P2P</button>
                                </li>
                                <li class="nav-item" role="presentation">
                                      <button class="nav-link" id="pills-buy-tab" data-bs-toggle="pill" data-bs-target="#pills-buy" type="button" role="tab" aria-controls="pills-buy" aria-selected="false">Buy Crypto</button>
                                </li>
                                <li class="nav-item" role="presentation">
                                      <button class="nav-link" id="pills-withdraw-tab" data-bs-toggle="pill" data-bs-target="#pills-withdraw" type="button" role="tab" aria-controls="pills-withdraw" aria-selected="false">Withdraw</button>
                                </li>
                             </ul>
                             <div class="tab-content" id="pills-tabContent">
                                <div class="tab-pane fade show active" id="pills-ptop" role="tabpanel" aria-labelledby="pills-ptop-tab">
                                   <div class="row justify-content-between">
                                      <div class="col-lg-8 col-md-7">
                                         <p class="para">
                                         Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus pulvinar mauris in semper porttitor. Pellentesque nec dapibus purus. Duis accumsan sem quis ligula pellentesque, nec ullamcorper erat porta. Nunc tincidunt sem vitae odio laoreet, nec tempor elit sagittis. Proin tristique, justo ut eleifend hendrerit, arcu nunc ultrices velit, quis lacinia elit nisl nec enim. Suspendisse potenti. Praesent ex magna, tincidunt ac turpis ac, tincidunt 
                                         </p>
                                      </div>
                                      <div class="col-lg-4 col-md-5 text-end">
                                         <a href="#" class="btn-theme-gray" data-bs-toggle="modal" data-bs-target="#payMethod"><span class="bi bi-plus-lg"></span> Add a payment method</a>
                                      </div>
        
                                      <div class="col-12 mt-5">
                                         <div class="card ">
                                            <div class="card-header dashboard-card-header ">
                                               <span class="dashboard-card-heading">Bank Transfer (India)</span>
                                               <div class="ms-auto">
                                                  <a href="#" class="me-3">Edit</a>  
                                                  <a href="#">Delete</a>
                                               </div> 
                                            </div>
                                            <div class="card-body">
                                               <div class="row ">
                                                  <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 mb-3 pay-method-mobile">
                                                     <p class="mb-2 text-muted">Account holder name</p>
                                                     <span>Testing</span>
                                                  </div>
                                                  <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 mb-3 pay-method-mobile">
                                                     <p class="mb-2 text-muted">Account no.</p>
                                                     <span>1234567890</span>
                                                  </div>
                                                  <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 mb-3 pay-method-mobile">
                                                     <p class="mb-2 text-muted">IFSC code</p>
                                                     <span>IDIB0000010</span>
                                                  </div>
                                                  <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 mb-3 pay-method-mobile">
                                                     <p class="mb-2 text-muted">Account Type</p>
                                                     <span>saving</span>
                                                  </div>
                                                  <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 mb-3 pay-method-mobile">
                                                     <p class="mb-2 text-muted">Bank name</p>
                                                     <span>Indian Bank</span>
                                                  </div>
                                                  <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 mb-3 pay-method-mobile">
                                                     <p class="mb-2 text-muted">Account opening branch</p>
                                                     <span>India</span>
                                                  </div>
                                               </div>
                                            </div>
                                         </div>
                                         
                                      </div>
        
                                      <div class="col-12 mt-5 text-center">
                                         <img src="{{ asset('public/assets/img/not-found-icons/no-payment-method.svg') }}" class="no-record-icon" alt="">
                                         <p class="mt-3">You have not added any payment methods</p>
                                      </div>
                                   </div>
                                
                                </div>
                                <div class="tab-pane fade" id="pills-buy" role="tabpanel" aria-labelledby="pills-buy-tab">
                                      <div class="row justify-content-between">
                                         <div class="col-lg-8 col-md-7">
                                            <p class="para">
                                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus pulvinar mauris in semper porttitor. Pellentesque nec dapibus purus. Duis
                                            </p>
                                         </div>
                                      
                                         <div class="col-12">
                                            <div class="text-center mt-5 py-5">
                                               <img src="{{ asset('public/assets/img/not-found-icons/no-card.svg') }}" class="no-record-icon" alt="">
                                               <p class="mt-3">You don't have any cards</p>
                                            </div>
                                         </div>
                                      </div>
                                   </div>
                                <div class="tab-pane fade" id="pills-withdraw" role="tabpanel" aria-labelledby="pills-withdraw-tab">
                                   <div class="table-responsive">
                                      <table class="table table-hover table-borderless">
                                         <thead class="bg-light">
                                            <tr>
                                               <th scope="col">Bank Country</th>
                                               <th scope="col">Currency</th>
                                               <th scope="col">Bank Name</th>
                                               <th scope="col">Branch Code</th>
                                               <th scope="col">Account Number</th>
                                               <th scope="col">Account Status</th>
                                            </tr>
                                         </thead>
                                         <tbody>
                                            <tr>
                                               <td scope="row">Demo</td>
                                               <td>Demo</td>
                                               <td>Demo</td>
                                               <td>Demo</td>
                                               <td>Demo</td>
                                               <td>Demo</td>
                                            </tr>
                                            
                                         </tbody>
                                      </table>
                                   </div>
        
                                   <div class="col-12">
                                         <div class="text-center mt-5 py-5">
                                            <img src="{{ asset('public/assets/img/not-found-icons/no-card.svg') }}" class="no-record-icon" alt="">
                                            <p class="mt-3">You don't have any cards</p>
                                         </div>
                                   </div>
                                   
                                </div>
                             </div>
                          </div>
                    </div>
                    
                 </div>
              </div>
              
              
              
              <div class="modal fade" id="payMethod" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="payMethodLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
    <div class="modal-content">
         <div class="modal-header">
         <h5 class="modal-title" id="payMethodLabel">Select a Payment Method</h5>
         <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
         </div>
         <div class="modal-body">
               <h5 class="mb-3">Recommended</h5>
               <div class="row gx-1">
                  <div class="col-6 mb-3">
                     <a href="{{ url('user/payment/add-payment-method') }}" class="pay-method-text"><span class="pay-method-icon"></span><span>Bank Transfer (India)</span></a>
                  </div>
                  <div class="col-6 mb-3">
                     <a href="#" class="pay-method-text"><span class="pay-method-icon"></span><span>IMPS</span></a>
                  </div>
                  <div class="col-6 mb-3">
                     <a href="#" class="pay-method-text"><span class="pay-method-icon"></span><span>Paytm</span></a>
                  </div>
                  <div class="col-6 mb-3">
                     <a href="#" class="pay-method-text"><span class="pay-method-icon"></span><span>UPI</span></a>
                  </div>
               </div>
               <hr>
                  <div class="my-4">
                     <div class="row g-0 align-items-start my-3">
                           <div class="col-7">
                           <h5 class="mb-0">All Payment Methods</h5>
                           </div>
                           <div class="col-5">
                              <input type="text" class="form-control no-border-field" id="filterPaymentMethod" placeholder="Search">
                           </div>
                     </div>
                     <div class="row g-0">
                           <div class="col-12">
                              <a href="#" class="atoz-filter active">All</a>
                              <a href="#" class="atoz-filter">A</a><a href="#" class="atoz-filter">B</a><a href="#" class="atoz-filter">C</a><a href="#" class="atoz-filter">D</a><a href="#" class="atoz-filter">E</a><a href="#" class="atoz-filter">F</a><a href="#" class="atoz-filter">G</a><a href="#" class="atoz-filter">H</a><a href="#" class="atoz-filter">I</a><a href="#" class="atoz-filter">J</a><a href="#" class="atoz-filter">K</a><a href="#" class="atoz-filter">L</a><a href="#" class="atoz-filter">M</a><a href="#" class="atoz-filter">N</a><a href="#" class="atoz-filter">O</a><a href="#" class="atoz-filter">P</a><a href="#" class="atoz-filter">Q</a><a href="#" class="atoz-filter">R</a><a href="#" class="atoz-filter">S</a><a href="#" class="atoz-filter">T</a><a href="#" class="atoz-filter">U</a><a href="#" class="atoz-filter">V</a><a href="#" class="atoz-filter">W</a><a href="#" class="atoz-filter">X</a><a href="#" class="atoz-filter">Y</a><a href="#" class="atoz-filter">Z</a>                           </div>
                     </div>
               </div>
                  
                  <div class="row gx-1 payment-methods">
                     <div class="col-6 mb-3 pay-method">
                        <a href="#" class="pay-method-text"><span class="pay-method-icon"></span><span>7-Eleven</span></a>
                     </div>
                     <div class="col-6 mb-3 pay-method">
                        <a href="#" class="pay-method-text"><span class="pay-method-icon"></span><span>A-Bank</span></a>
                     </div>
                     <div class="col-6 mb-3 pay-method">
                        <a href="#" class="pay-method-text"><span class="pay-method-icon"></span><span>ABA</span></a>
                     </div>
                     <div class="col-6 mb-3 pay-method">
                        <a href="#" class="pay-method-text"><span class="pay-method-icon"></span><span>ABN AMRO</span></a>
                     </div>
                  </div>
         </div>

      </div>
      
    </div>
</div>
              
              
              
              
           </div>
    </div>
   @include('template.web_footer') 	
   @include('template.web_js') 
</body>
</html>
