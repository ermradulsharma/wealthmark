<!DOCTYPE html><html lang="en">
<head>
<meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>Buy, trade, and hold 100+ cryptocurrencies on Wealthmark</title>
  <meta content="" name="description">
  <meta content="" name="keywords">
  <meta name="theme-color" content="#287aff">
  <link href="{{ asset('public/assets/img/wealthmark-logo.svg') }}" rel="icon">
  <link href="{{ asset('public/assets/img/wealthmark-logo.svg') }}" rel="apple-touch-icon">
  <link rel="stylesheet" href="{{ asset('public/assets/css/dashboard.css') }}">
  @include('template.web_css') 

    <style>
  .sidebar-nav{
      display:block;
  }
  #preloader{
      display:none !important;
  }
  
  @media (max-width: 450px){

  .balance-details .dashboard-card-header{
      display:block;
      
  }
  .dashboard-card-heading{
      margin-bottom:10px;
      display:block;
  }
  .balance-details .dashboard-card-header .btn-theme-sm{
      margin-left:0px;
  }
 #progressbar li{
     width:33% !important;
 }
      
  }
  
  
  
  
  
  
  /*----------------------------------------------------------- for side bar css only-----------------------------------------------------------*/
  
 
   @media (max-width: 992px){
 .hide_on_max_dashboard_992{
     display:none !important;
 } 
   }
  .dashboard-main{
      margin-top:10px !important;
  }
.hide_on_dashboard{
    display:none !important;
} 
header{
    box-shadow:0 .125rem .25rem rgba(0,0,0,.075)!important;
    background:white;
   z-index:9999999999 !important;
 
}
  .sidebar-btn-open{
      font-size: 30px;
    color: #242424;
  }
  @media (max-width: 992px){
     .sidebar.active {
    display: block;
    top: 0px !important;
    position: fixed !important;
    right: 0 !important;
    left:auto !important;
      }
      
.dashboard-sidebar {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    position: fixed;
    inset: 0px;
    z-index: 9999;
    flex-direction: row-reverse;
    background-color: rgba(0, 0, 0, 0.1);
    display: none;
    transition: all 0.5s ease;
}
.dashboard-sidebar-flex{
    display:flex !important;
}
  }
    /*----------------------------------------------------------- for side bar css only-----------------------------------------------------------*/
  
  
  
  </style>
  
</head>
<body>
    @include('template.dashboard_mobile_menu')  
    @include('template.web_menu')  
    <div class="dashboard-main">
        @include('template.sidebar')
        <div class="container-fluid">
            <section class="dashboard-breadcrumb">
                 <div class="container">
                    <div class="row g-0 align-items-center justify-content-between">
                          <div class="col-8">
                             <h2 class="fw-bold">Security</h2>
                             <div class="security-tabs">
                             <div class="d-flex align-items-center">
                                <span class="bx bx-x"></span>
                                <a href="#" class="text-theme-yellow">Two-Factor Authentication (2FA)</a>
                             </div>
                             <div class="d-flex align-items-center">
                                <span class="bx bx-x"></span>
                                <a href="#" class="text-theme-yellow">Identity Verification</a>
                             </div>
                             <div class="d-flex align-items-center">
                                <span class="bx bx-x"></span>
                                <a href="#" class="text-theme-yellow">Anti-Phishing Code</a>
                             </div>
                             <div class="d-flex align-items-center">
                                <span class="bx bx-x"></span>
                                <a href="#" class="text-theme-yellow">Withdrawal Whitelist</a>
                             </div>
                             </div>
                       </div>
                       <div class="col-4 text-end">
                          <img src="{{ asset('public/assets/img/dashboard-icons/Security-Icon.svg') }}" class="breadcrumb-icon" alt="">
                       </div>
                    </div>
                 </div>
            </section>
              
              
            <div class="container">
                <div class=" security-content">
                    <div class="alert-warning p-3">
                       <div>
                          <span>To increase your account security, it is recommended that you enable 2FA, including WealthMark/Google authenticator.</span>
                       </div>
                       <div>
                          <a href="#" class="text-theme-yellow">Enable WealthMark/Google Authenticator Now <i class="bx bx-chevron-right"></i> </a>                           
                       </div>
                    </div>
                    <div class="">
                       <h4 >Two-Factor Authentication (2FA)</h4>
                    </div>
                    <div class="security-column ">
                       <div class="security-column-left">
                          <div class="security-column-icon">
                             <img src="{{ asset('public/assets/img/country-flag/India-Icon.svg') }}" alt="">
                          </div>
                          <div class="security-column-description">
                             <h5>Security Key</h5>
                             <span>Protect your account with a security key (e.g. Yubikey).</span>
                          </div>
                       </div>
                       <div class="security-column-right">
                          <div class="d-flex align-items-center">
                             <span class="bx bx-x"></span>
                             <span class="text-theme-yellow">Unset</span>
                          </div>
                          <div class="security-right-button">
                             <a href="" class="btn-theme-sm">Enable</a>
                          </div>
                       </div>
                    </div>
                    <div class="security-column ">
                       <div class="security-column-left">
                          <div class="security-column-icon">
                             <img src="{{ asset('public/assets/img/country-flag/India-Icon.svg') }}" alt="">
                          </div>
                          <div class="security-column-description">
                             <h5>Email Address Verification</h5>
                             <span>Protect your account and transactions.</span>
                          </div>
                       </div>
                       <div class="security-column-right">
                            <div class="d-flex align-items-center">
                                @if(Auth::user()->is_mail_verified==0)
                                 <span class="bx bx-x"></span>
                                 <span class="text-theme-yellow">Not linked</span>
                                @else
                                 <span class="bx bx-check"></span>
                                 <span class="text-theme-green">{{$email_data}}</span>
                                @endif
                            </div>
                            <div class="security-right-button">
                                @if(Auth::user()->is_mail_verified==0)
                                    <a href="" class="btn-theme-sm">Enable</a>
                                @else
                                    <a href="" class="btn-theme-sm">Change</a>
                                    <a href="" class="btn-theme-sm">Remove</a>
                                @endif
                            </div>
                       </div>
                    </div>
                    <div class="security-column ">
                       <div class="security-column-left">
                          <div class="security-column-icon">
                             <img src="{{ asset('public/assets/img/dashboard-icons/settings/authenticator.svg') }}" alt="">
                          </div>
                          <div class="security-column-description">
                             <h5>WealthMark/Google Authenticator (Recommended)</h5>
                             <span>Protect your account with a security key (e.g. Yubikey).</span>
                          </div>
                       </div>
                       <div class="security-column-right">
                          <div class="d-flex align-items-center">
                             <span class="bx bx-x"></span>
                             <span class="text-theme-yellow">Unset</span>
                          </div>
                          <div class="security-right-button">
                             <a href="" class="btn-theme-sm">Enable</a>
                          </div>
                       </div>
                    </div>
                    <div class="security-column ">
                       <div class="security-column-left">
                          <div class="security-column-icon">
                             <img src="{{ asset('public/assets/img/dashboard-icons/settings/phone-verification.svg') }}" alt="">
                          </div>
                          <div class="security-column-description">
                             <h5>Phone Number Verification</h5>
                             <span>Protect your account and transactions.</span>
                          </div>
                       </div>
                       <div class="security-column-right">
                          <div class="d-flex align-items-center">
                                @if(Auth::user()->is_phone_verified==0)
                                 <span class="bx bx-x"></span>
                                 <span class="text-theme-yellow">Not linked</span>
                                @else
                                 <span class="bx bx-check"></span>
                                 <span class="text-theme-green">{{ substr(Auth::user()->phone, 0, 3) . "***" . substr(Auth::user()->phone, 6, 4) }}</span>
                                @endif
                          </div>
                          <div class="security-right-button">
                            @if(Auth::user()->is_phone_verified==0)
                                <a href="" class="btn-theme-sm">Enable</a>
                            @else
                                <a href="" class="btn-theme-sm">Change</a>
                                <a href="" class="btn-theme-sm">Remove</a>
                            @endif
                          </div>
                       </div>
                    </div>
                    <div class="pt-5 pb-3 ">
                       <h4 >Devices and Activities</h4>
                    </div>
                    <div class="security-column ">
                       <div class="security-column-left">
                          <div class="security-column-icon">
                             <img src="{{ asset('public/assets/img/country-flag/India-Icon.svg') }}" alt="">
                          </div>
                          <div class="security-column-description">
                             <h5>Login Password</h5>
                             <span>Login password is used to log in to your account.</span>
                          </div>
                       </div>
                       <div class="security-column-right">
                          <div class="d-flex align-items-center">
                             <span class="bx bx-x"></span>
                             <span class="text-theme-yellow">Unset</span>
                          </div>
                          <div class="security-right-button">
                             <a href="" class="btn-theme-sm">Enable</a>
                          </div>
                       </div>
                    </div>
                    <div class="security-column ">
                       <div class="security-column-left">
                          <div class="security-column-icon">
                             <img src="{{ asset('public/assets/img/country-flag/India-Icon.svg') }}" alt="">
                          </div>
                          <div class="security-column-description">
                             <h5>Withdrawal Whitelist</h5>
                             <span>When this function is turned on, your account will only be able to withdraw to whitelisted withdrawal addresses.</span>
                          </div>
                       </div>
                       <div class="security-column-right">
                          <div class="d-flex align-items-center">
                             <span class="bx bx-x"></span>
                             <span class="text-theme-yellow">Unset</span>
                          </div>
                          <div class="security-right-button">
                             <a href="" class="btn-theme-sm">Enable</a>
                          </div>
                       </div>
                    </div>
                    <div class="security-column ">
                        <div class="security-column-left">
                          <div class="security-column-icon">
                             <img src="{{ asset('public/assets/img/country-flag/India-Icon.svg') }}" alt="">
                          </div>
                          <div class="security-column-description">
                             <h5>Anti-Phishing Code</h5>
                             <span>Protect your account from phishing attempts and ensure that your notification emails are from WealthMark only.</span>
                          </div>
                        </div>
                        <div class="security-column-right">
                          <div class="d-flex align-items-center">
                             <span class="bx bx-x"></span>
                             <span class="text-theme-yellow">Unset</span>
                          </div>
                          <div class="security-right-button">
                             <a href="" class="btn-theme-sm">Enable</a>
                          </div>
                        </div>
                    </div>
                </div>
            </div>


              
        </div>
    </div>
   @include('template.web_footer') 	
   @include('template.web_js') 
</body>
</html>

