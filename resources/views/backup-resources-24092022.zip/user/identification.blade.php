<!DOCTYPE html><html lang="en">
<head>
<meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>Buy, trade, and hold 100+ cryptocurrencies on Wealthmark</title>
  <meta content="" name="description">
  <meta content="" name="keywords">
  <meta name="theme-color" content="#287aff">
  <link href="{{ asset('public/assets/img/wealthmark-logo.svg') }}" rel="icon">
  <link href="{{ asset('public/assets/img/wealthmark-logo.svg') }}" rel="apple-touch-icon">
  <link rel="stylesheet" href="{{ asset('public/assets/css/dashboard.css') }}">
  @include('template.web_css') 
     <style>
  .sidebar-nav{
      display:block;
  }
  #preloader{
      display:none !important;
  }
  
  @media (max-width: 450px){

  .balance-details .dashboard-card-header{
      display:block;
      
  }
  .dashboard-card-heading{
      margin-bottom:10px;
      display:block;
  }
  .balance-details .dashboard-card-header .btn-theme-sm{
      margin-left:0px;
  }
 #progressbar li{
     width:33% !important;
 }
      
  }
  
  
  
  
  
  
  /*----------------------------------------------------------- for side bar css only-----------------------------------------------------------*/
  
 
   @media (max-width: 992px){
 .hide_on_max_dashboard_992{
     display:none !important;
 } 
   }
  .dashboard-main{
      margin-top:10px !important;
  }
.hide_on_dashboard{
    display:none !important;
} 
header{
    box-shadow:0 .125rem .25rem rgba(0,0,0,.075)!important;
    background:white;
   z-index:9999999999 !important;
 
}
  .sidebar-btn-open{
      font-size: 30px;
    color: #242424;
  }
  @media (max-width: 992px){
     .sidebar.active {
    display: block;
    top: 0px !important;
    position: fixed !important;
    right: 0 !important;
    left:auto !important;
      }
      
.dashboard-sidebar {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    position: fixed;
    inset: 0px;
    z-index: 9999;
    flex-direction: row-reverse;
    background-color: rgba(0, 0, 0, 0.1);
    display: none;
    transition: all 0.5s ease;
}
.dashboard-sidebar-flex{
    display:flex !important;
}
  }
    /*----------------------------------------------------------- for side bar css only-----------------------------------------------------------*/
  
  
  
  </style>
</head>
<body>
    @include('template.dashboard_mobile_menu')  
    @include('template.web_menu')     
    <div class="dashboard-main">
        @include('template.sidebar')
        <div class="container-fluid">
            <div class="container">
                 <!-- banner -->
                 <div class="verification-banner py-3" style="margin-top:62px;">
                    <div class="row">
                       <div class="col-md-9 verification-banner-left">
                          <div class="d-flex align-items-center">
                             <h2 class="fw-bold mb-0">Personal Verification</h2>
                                <a href="" class="d-flex align-items-center">
                                   <span class="bi bi-shield-plus privacy-icon"></span>
                                </a>
                                <a href="" class="d-flex align-items-center">
                                   <span class="bi bi-question-octagon guide-icon"></span><span class="guide-text">Guide</span>
                                </a>
                          </div>
                       </div>
                       <div class="col-md-3 verification-banner-right">
                          <input type="button" class="btn-theme " value="India (भारत)" disabled="">
                       </div>
                    </div>
                 </div>
                 <div class="verification-content">
                    <div class="row">
                       <div class="col-md-4">
                          <div class="card-body bg-light h-100">
                             <h3 class="fw-bold mb-0">Current Features</h3>
                             <div class="text-center curr-feature-content">
                                <img src="{{ asset('public/assets/img/Security-Icon.svg') }}" class="mb-4" alt="">
                                <h4 class="fw-bold ">Your account is currently not verified.</h4>
                                <span>Complete verification to access services on WealthMark.</span>
                             </div>                 
                          </div>
                       </div>
        
                       <div class="col-md-4">
                          <div class="card-body ">
                             <h3 class="fw-bold mb-4">Verified</h3>
                             <div class="verified-feature-content">
                                <div class="up-feature">
                                   <div class="mb-2">
                                      <span class="bi bi-person-fill text-muted me-2"></span>
                                      <span class=" text-muted">Personal information</span>
                                   </div>
                                   <div class="mb-2">
                                      <span class="bi bi-person-lines-fill text-muted me-2"></span>
                                      <span class=" text-muted">Government-issued ID</span>
                                   </div>
                                   <div class="mb-2">
                                      <span class="bi bi-person-bounding-box text-muted me-2"></span>
                                      <span class=" text-muted">Facial recognition</span>
                                   </div>
                                   <div class="mb-2">
                                      <span class="bi bi-hourglass-split text-muted me-2"></span>
                                      <span class=" text-muted">Review time: 10 days</span>
                                   </div>
                                </div>
        
                                <div class="my-4 text-center">
                                   <a href="#" class="btn-theme w-100">Start Now</a>
                                </div>
        
                                <div class="mb-2">
                                   <span class="text-muted">Fiat Deposit &amp; Withdrawal Limits</span>
                                   <p>$50K Daily</p>
                                </div>
                                <div class="mb-2">
                                   <span class="text-muted">Crypto Withdrawal Limit</span>
                                   <p>8M BUSD Daily</p>
                                </div>
                                <div class="mb-2">
                                   <span class="text-muted">P2P Transaction Limits</span>
                                   <p>Unlimited</p>
                                </div>
                                <div class="mb-2">
                                   <span class="text-muted">Other Features</span>
                                   <p>LPD/OTC/WealthMark card</p>
                                </div>
                             </div>
                          </div>
                       </div>
                       <div class="col-md-4">
                          <div class="card-body ">
                             <h3 class="fw-bold mb-4">Verified Plus</h3>
                             <div class="verified-feature-content">
                                <div class="up-feature">
                                   <div class="mb-2">
                                      <span class="bi bi-geo-fill text-muted me-2"></span>
                                      <span class=" text-muted">Proof of address</span>
                                   </div>
                                   <div class="mb-2">
                                      <span class="bi bi-hourglass-split text-muted me-2"></span>
                                      <span class=" text-muted">Review time: 10 days</span>
                                   </div>
                                </div>
                                
                                
                                <div class="my-4 text-center">
                                   <input type="button" class="btn-theme w-100" value="Unavailable" disabled="">
                                </div>
        
                                <div class="mb-2">
                                   <span class="text-muted">Fiat Deposit &amp; Withdrawal Limits</span>
                                   <p>$200K Daily Daily</p>
                                </div>
                                <div class="mb-2">
                                   <span class="text-muted">Crypto Withdrawal Limit</span>
                                   <p>8M BUSD Daily</p>
                                </div>
                                <div class="mb-2">
                                   <span class="text-muted">P2P Transaction Limits</span>
                                   <p>Unlimited</p>
                                </div>
                                <div class="mb-2">
                                   <span class="text-muted">Other Features</span>
                                   <p>LPD/OTC/WealthMark card</p>
                                </div>
                             </div>
                          </div>
                       </div>
                    </div>
                 </div>
            </div>
        </div>
    </div>
   @include('template.web_footer') 	
   @include('template.web_js') 
</body>
</html>

