<!DOCTYPE html><html lang="en">
<head>
<meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>Buy, trade, and hold 100+ cryptocurrencies on Wealthmark</title>
  <meta content="" name="description">
  <meta content="" name="keywords">
  <meta name="theme-color" content="#287aff">
  <link href="{{ asset('public/assets/img/wealthmark-logo.svg') }}" rel="icon">
  <link href="{{ asset('public/assets/img/wealthmark-logo.svg') }}" rel="apple-touch-icon">
  <link rel="stylesheet" href="{{ asset('public/assets/css/dashboard.css') }}">
  @include('template.web_css') 
  
     <style>
  .sidebar-nav{
      display:block;
  }
  #preloader{
      display:none !important;
  }
  
  @media (max-width: 450px){

  .balance-details .dashboard-card-header{
      display:block;
      
  }
  .dashboard-card-heading{
      margin-bottom:10px;
      display:block;
  }
  .balance-details .dashboard-card-header .btn-theme-sm{
      margin-left:0px;
  }
 #progressbar li{
     width:33% !important;
 }
      
  }
  
  
  
  
  
  
  /*----------------------------------------------------------- for side bar css only-----------------------------------------------------------*/
  
 
   @media (max-width: 992px){
 .hide_on_max_dashboard_992{
     display:none !important;
 } 
   }
  .dashboard-main{
      margin-top:10px !important;
  }
.hide_on_dashboard{
    display:none !important;
} 
header{
    box-shadow:0 .125rem .25rem rgba(0,0,0,.075)!important;
    background:white;
   z-index:9999999999 !important;
 
}
  .sidebar-btn-open{
      font-size: 30px;
    color: #242424;
  }
  @media (max-width: 992px){
     .sidebar.active {
    display: block;
    top: 0px !important;
    position: fixed !important;
    right: 0 !important;
    left:auto !important;
      }
      
.dashboard-sidebar {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    position: fixed;
    inset: 0px;
    z-index: 9999;
    flex-direction: row-reverse;
    background-color: rgba(0, 0, 0, 0.1);
    display: none;
    transition: all 0.5s ease;
}
.dashboard-sidebar-flex{
    display:flex !important;
}
  }
    /*----------------------------------------------------------- for side bar css only-----------------------------------------------------------*/
  
  
  
  </style>
  
  
  
</head>
<body>
     @include('template.dashboard_mobile_menu')  
    @include('template.web_menu') 
    <div class="dashboard-main">
    @include('template.sidebar')
        
        <div class="container-fluid">
          <section class="dashboard-breadcrumb mb-2rem">
             <div class="container">
                <div class="row gap-y-3 align-items-center justify-content-md-between">
                   <div class="col-md-3">
                      <h2 class="fw-bold mb-0">Overview</h2>
                   </div>
                   <div class="col-md-9 text-md-end">
                       <div class="theme-tab-list justify-content-md-end">
                            <a href="#" class="btn-theme">Deposit</a>
                            <a href="#" class="btn-theme-light">Withdraw</a>
                            <a href="#" class="btn-theme-light">Send</a>
                            <a href="#" class="btn-theme-light">Transfer</a>
                            <a href="#" class="btn-theme-light">Transaction History</a>
                       </div>
                      
                   </div>
                </div>
             </div>
          </section>
          <div class="container my-assets">  
             <div class="row justify-content-between gap-y-3">
                <div class="col-xl-7 col-lg-7 col-md-6">
                    <div class="d-flex align-items-center ">
                        <h5 class="mb-0">Estimated Balance &nbsp;<a href="#" class="bi bi-eye eye-btn text-theme-yellow"></a></h5>
                    </div>
                    <div class="d-flex align-items-center mt-4 hide-when-astix ">
                        <span class="h4 mb-0 me-2 fw-bold est-balance">0.00000000 </span><span class="h4 mb-0 fw-bold est-balance"> BTC &nbsp;</span><span class="h4 mb-0 est-balance fw-bold text-muted">≈ &nbsp; ₹0.000000</span>
                    </div>
                    <div class="d-none astix mt-4">
                        <div class="text-dark h4">***Balance hidden***</div>
                        <div class="alert-warning p-2 fs-12 rounded my-3">Your assets are hidden, tap the eye icon to show your assets.</div>
                    </div>
    
                    <div class="row mt-4 gap-y-3 align-items-md-center justify-content-md-between">
                        <div class="col-lg-3 col-md-4">
                            <h5 class="mb-0">My Assets</h5>
                        </div>
                        <div class="col-lg-9 col-md-8 text-md-end">
                            <div class="form-check asset-check">
                                <input class="form-check-input" type="checkbox" value="" id="defaultCheck2">
                                <label class="form-check-label" for="defaultCheck2">
                                    <span class="text-muted">Hide 0 Balance Wallets</span>
                                </label>
                            </div>
                        </div>
                    </div>
    
                    <div class="row mt-3 gap-y-3 align-items-center justify-content-between asset">
                        <div class="col p-2">
                            <a class="text-dark" href="#">
                                <div class="d-flex">
                                    <img src="{{asset('public/assets/img/header-icons/mega-option/exchange.svg') }}" class="header-icons" alt="Exchange" />
                                    <span class="fw-bold fs-16">Fiat and Spot</span>
                                </div>
                            </a>
                        </div>
                        <div class="col p-2">
                            <a class="col d-flex align-items-center justify-content-end">
                                <span class="text-dark fw-bold fs-16 hide-when-astix">0.00000000 BTC</span>
                                <div class="d-none astix text-dark">
                                    <span class="bi bi-asterisk fs-13"></span>
                                    <span class="bi bi-asterisk fs-13"></span>
                                    <span class="bi bi-asterisk fs-13"></span>
                                    <span class="bi bi-asterisk fs-13"></span>
                                    <span class="bi bi-asterisk fs-13"></span>
                                </div>
                                <span class="bi bi-chevron-right fs-12 fw-bold text-theme-yellow ps-2"></span>
                            </a>
                        </div>
                    </div>
    
                    <div class="row mt-3 gap-y-3 align-items-center justify-content-between asset">
                        <div class="col p-2">
                            <a class="text-dark" href="#">
                                <div class="d-flex">
                                    <img src="{{asset('public/assets/img/header-icons/mega-option/exchange.svg') }}" class="header-icons" alt="Exchange" />
                                    <span class="fw-bold fs-16">Funding</span>
                                </div>
                            </a>
                        </div>
                        <div class="col p-2">
                            <a class="col d-flex align-items-center justify-content-end">
                                <span class="text-dark fw-bold fs-16 hide-when-astix">0.00000000 BTC</span>
                                <div class="d-none astix text-dark">
                                    <span class="bi bi-asterisk fs-13"></span>
                                    <span class="bi bi-asterisk fs-13"></span>
                                    <span class="bi bi-asterisk fs-13"></span>
                                    <span class="bi bi-asterisk fs-13"></span>
                                    <span class="bi bi-asterisk fs-13"></span>
                                </div>
                                <span class="bi bi-chevron-right fs-12 fw-bold text-theme-yellow ps-2"></span>
                            </a>
                        </div>
                    </div>
    
                    <div class="row mt-3 gap-y-3 align-items-center justify-content-between asset">
                        <div class="col p-2">
                            <a class="text-dark" href="#">
                                <div class="d-flex">
                                    <img src="{{asset('public/assets/img/header-icons/mega-option/exchange.svg') }}" class="header-icons" alt="Exchange" />
                                    <span class="fw-bold fs-16">Cross Margin</span>
                                </div>
                            </a>
                        </div>
                        <div class="col p-2">
                            <a class="col d-flex align-items-center justify-content-end">
                                <span class="text-dark fw-bold fs-16 hide-when-astix">0.00000000 BTC</span>
                                <div class="d-none astix text-dark">
                                    <span class="bi bi-asterisk fs-13"></span>
                                    <span class="bi bi-asterisk fs-13"></span>
                                    <span class="bi bi-asterisk fs-13"></span>
                                    <span class="bi bi-asterisk fs-13"></span>
                                    <span class="bi bi-asterisk fs-13"></span>
                                </div>
                                <span class="bi bi-chevron-right fs-12 fw-bold text-theme-yellow ps-2"></span>
                            </a>
                        </div>
                    </div>
    
                    <div class="row mt-3 gap-y-3 align-items-center justify-content-between asset">
                        <div class="col p-2">
                            <a class="text-dark" href="#">
                                <div class="d-flex">
                                    <img src="{{asset('public/assets/img/header-icons/mega-option/exchange.svg') }}" class="header-icons" alt="Exchange" />
                                    <span class="fw-bold fs-16">Isolated Margin</span>
                                </div>
                            </a>
                        </div>
                        <div class="col p-2">
                            <a class="col d-flex align-items-center justify-content-end">
                                <span class="text-dark fw-bold fs-16 hide-when-astix">0.00000000 BTC</span>
                                <div class="d-none astix text-dark">
                                    <span class="bi bi-asterisk fs-13"></span>
                                    <span class="bi bi-asterisk fs-13"></span>
                                    <span class="bi bi-asterisk fs-13"></span>
                                    <span class="bi bi-asterisk fs-13"></span>
                                    <span class="bi bi-asterisk fs-13"></span>
                                </div>
                                <span class="bi bi-chevron-right fs-12 fw-bold text-theme-yellow ps-2"></span>
                            </a>
                        </div>
                    </div>
    
                    <div class="row mt-3 gap-y-3 align-items-center justify-content-between asset">
                        <div class="col p-2">
                            <a class="text-dark" href="#">
                                <div class="d-flex">
                                    <img src="{{asset('public/assets/img/header-icons/mega-option/exchange.svg') }}" class="header-icons" alt="Exchange" />
                                    <span class="fw-bold fs-16">USDⓈ-M Futures</span>
                                </div>
                            </a>
                        </div>
                        <div class="col p-2 text-end">
                            <a href="" class="btn-theme-sm">Deposit</a>
                        </div>
                    </div>
    
                </div>
    
                <div class="col-xl-4 col-lg-5 col-md-6">
                    <h5 class="mb-3">Video Tutorials</h5>
                        <a href="" class="text-theme-yellow" data-bs-toggle="modal" data-bs-target="#videoPlayer">
                            <div class="row gap-y-3 g-2 pb-3 mb-3 border-bottom">
                                <div class="col-sm-4 col-6">
                                    <img src="{{asset('public/assets/img/buyCrypto.png') }}" class="w-100 rounded" alt="">
                                </div>
                                <div class="col-sm-8 col-6">
                                <span>How to buy crypto using cash</span>
                                <p class="mb-0 fs-14 text-muted">02:23</p>
                                </div>
                            </div>
                        </a>
    
                        <a href="" class="text-theme-yellow" data-bs-toggle="modal" data-bs-target="#videoPlayer">
                            <div class="row gap-y-3 g-2 pb-3 mb-3 border-bottom">
                                <div class="col-sm-4 col-6">
                                    <img src="{{asset('public/assets/img/buyCrypto.png') }}" class="w-100 rounded" alt="">
                                </div>
                                <div class="col-sm-8 col-6">
                                <span>How to deposit crypto on Binance</span>
                                <p class="mb-0 fs-14 text-muted">02:23</p>
                                </div>
                            </div>
                        </a>
    
                        <a href="" class="text-theme-yellow" data-bs-toggle="modal" data-bs-target="#videoPlayer">
                            <div class="row gap-y-3 g-2 pb-3  mb-3 border-bottom">
                                <div class="col-sm-4 col-6">
                                    <img src="{{asset('public/assets/img/buyCrypto.png') }}" class="w-100 rounded" alt="">
                                </div>
                                <div class="col-sm-8 col-6">
                                <span>How to receive crypto from other Binance user</span>
                                <p class="mb-0 fs-14 text-muted">02:23</p>
                                </div>
                            </div>
                        </a>
    
                    <div class="d-flex align-items-center justify-content-between mt-3">
                        <h5 class="mb-3">Recent Transactions</h5>
                        <a href="" class="btn-theme-sm">Deposit</a>
                    </div>
    
                    <div class="row">
                        <div class="col-12 text-center py-5">
                            <img src="{{asset('public/assets/img/not-found-icons/no-card.svg') }}" class="no-record-icon" alt="">
                            <p class="mt-3">No recent transactions</p>
                            <p class="text-muted small">Deposit hasn’t arrived? <a href="">Click here</a> </p>
                        </div>
    
                    </div>
                    
                </div>
             </div>
          </div>
       </div>
    </div>
    
    <!-- Video Player Modal -->
<div class="modal fade" id="videoPlayer" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="videoPlayerLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content">
        <div class="modal-header border-0 pb-0">
            <h5 class="modal-title" id="videoPlayerLabel">Fund Your Account</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">

        <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="pills-home-tab" data-bs-toggle="pill" data-bs-target="#pills-home" type="button" role="tab" aria-controls="pills-home" aria-selected="true">Buy Crypto</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="pills-profile-tab" data-bs-toggle="pill" data-bs-target="#pills-profile" type="button" role="tab" aria-controls="pills-profile" aria-selected="false">Deopsit Crypto</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="pills-contact-tab" data-bs-toggle="pill" data-bs-target="#pills-contact" type="button" role="tab" aria-controls="pills-contact" aria-selected="false">Receive Crypto</button>
            </li>
        </ul>
            <div class="tab-content" id="pills-tabContent">
                <div class="tab-pane fade show active text-center" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">
                    <video width="100%" height="100%" controls>
                        <source src="{{asset('public/assets/demo-video.mp4') }}" type="video/mp4">
                        Your browser does not support the video tag.
                    </video>
                    <div class="py-3">
                    <span class="text-muted">Deposit fiat currencies (e.g. EUR) from your bank account to buy crypto. </span><a class="text-theme-yellow" href="">Learn More</a>

                    </div>
                    <div class="pb-3">
                    <a href="" class="btn-theme">Buy Now</a>
                    </div>
                    
                </div>
                <div class="tab-pane text-center fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab">
                <video width="100%" height="100%" controls>
                        <source src="{{asset('public/assets/demo-video.mp4') }}" type="video/mp4">
                        Your browser does not support the video tag.
                    </video>
                    <div class="py-3">
                    <span class="text-muted">Deposit fiat currencies (e.g. EUR) from your bank account to buy crypto. </span><a class="text-theme-yellow" href="">Learn More</a>

                    </div>
                    <div class="pb-3">
                    <a href="" class="btn-theme">Deopsit Now</a>
                    </div>
                </div>
                <div class="tab-pane text-center fade" id="pills-contact" role="tabpanel" aria-labelledby="pills-contact-tab">
                <video width="100%" height="100%" controls>
                        <source src="{{asset('public/assets/demo-video.mp4') }}" type="video/mp4">
                        Your browser does not support the video tag.
                    </video>
                    <div class="py-3">
                    <span class="text-muted">Deposit fiat currencies (e.g. EUR) from your bank account to buy crypto. </span><a class="text-theme-yellow" href="">Learn More</a>

                    </div>
                    <div class="pb-3">
                    <a href="" class="btn-theme">Receive Now</a>
                    </div>
                </div>
            </div>


        
        </div>
    </div>
         
  </div>
</div>
   @include('template.web_footer') 	
</body>
</html>

