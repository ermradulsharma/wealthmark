<!DOCTYPE html><html lang="en">
<head>
<meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>Buy, trade, and hold 100+ cryptocurrencies on Wealthmark</title>
  <meta content="" name="description">
  <meta content="" name="keywords">
  <meta name="theme-color" content="#287aff">
  <link href="{{ asset('public/assets/img/wealthmark-logo.svg') }}" rel="icon">
  <link href="{{ asset('public/assets/img/wealthmark-logo.svg') }}" rel="apple-touch-icon">
  <link rel="stylesheet" href="{{ asset('public/assets/css/dashboard.css') }}">
  @include('template.web_css') 
  
   <style>
  .sidebar-nav{
      display:block;
  }
  #preloader{
      display:none !important;
  }
  
  @media (max-width: 450px){

  .balance-details .dashboard-card-header{
      display:block;
      
  }
  .dashboard-card-heading{
      margin-bottom:10px;
      display:block;
  }
  .balance-details .dashboard-card-header .btn-theme-sm{
      margin-left:0px;
  }
 #progressbar li{
     width:33% !important;
 }
      
  }
  
  
  
  
  
  
  /*----------------------------------------------------------- for side bar css only-----------------------------------------------------------*/
  
 
   @media (max-width: 992px){
 .hide_on_max_dashboard_992{
     display:none !important;
 } 
   }
  .dashboard-main{
      margin-top:10px !important;
  }
.hide_on_dashboard{
    display:none !important;
} 
header{
    box-shadow:0 .125rem .25rem rgba(0,0,0,.075)!important;
    background:white;
   z-index:9999999999 !important;
 
}
  .sidebar-btn-open{
      font-size: 30px;
    color: #242424;
  }
  @media (max-width: 992px){
     .sidebar.active {
    display: block;
    top: 0px !important;
    position: fixed !important;
    right: 0 !important;
    left:auto !important;
      }
      
.dashboard-sidebar {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    position: fixed;
    inset: 0px;
    z-index: 9999;
    flex-direction: row-reverse;
    background-color: rgba(0, 0, 0, 0.1);
    display: none;
    transition: all 0.5s ease;
}
.dashboard-sidebar-flex{
    display:flex !important;
}
  }
    /*----------------------------------------------------------- for side bar css only-----------------------------------------------------------*/
  
  
  
  </style>
</head>
<body>
    @include('template.dashboard_mobile_menu')  
    @include('template.web_menu')   
    <div class="dashboard-main">
        @include('template.sidebar')
        <div class="container-fluid">
            <section class="dashboard-breadcrumb">
                 <div class="container">
                    <div class="row align-items-center justify-content-between">
                       <div class="col-8">
                          <h2 class="fw-bold mb-0">Settings</h2>
                       </div>
                       <div class="col-4 text-end">
                          <img src="{{ asset('public/assets/img/dashboard-icons/settings/setting.svg') }}" class="breadcrumb-icon" alt="">
                       </div>
                    </div>
                 </div>
            </section>
            
            <div class="container mt-3">
              <div class="security-content mt-2rem">
                  <h4>My Profile</h4>
                 <div class="security-column ">
                    <div class="security-column-left">
                       <div class="security-column-icon">
                          <img src="{{ asset('public/assets/img/dashboard-icons/settings/my-profile.svg') }}" alt="">
                       </div>
                       <div class="security-column-description">
                          <h5>Nickname</h5>
                          <span>Set a customized nickname for your profile.</span>
                       </div>
                    </div>
                    <div class="security-column-right">
                       <div class="d-flex align-items-center">
                          <span class="bx bx-check"></span>
                          <!--<span class="text-theme-yellow"></span>-->
                        <span class="text-theme-yellow"></span>
                       </div>
                       <div class="security-right-button">
                          <a href="" data-bs-toggle="modal" data-bs-target="#nickNameEdit" class="btn-theme-sm">Edit</a>
                       </div>
                    </div>
                 </div>
                 <div class="security-column ">
                    <div class="security-column-left">
                       <div class="security-column-icon">
                          <img src="{{ asset('public/assets/img/dashboard-icons/settings/avtar.svg') }}" alt="">
                       </div>
                       <div class="security-column-description">
                          <h5>Avatar</h5>
                          <span>Select an avatar to personalize your account. You can purchase your own avatar in <a href="">NFT Marketplace</a></span>
                       </div>
                    </div>
                    <div class="security-column-right">
                       <div class="d-flex align-items-center">
                          <span class="bx bx-check"></span>
                          <span class="text-theme-yellow">Unset</span>
                       </div>
                       <div class="security-right-button">
                          <a href="" data-bs-toggle="modal" data-bs-target="#avtar" class="btn-theme-sm">Change</a>
                       </div>
                    </div>
                 </div>
                 <div class="security-column ">
                    <div class="security-column-left">
                       <div class="security-column-icon">
                          <img src="{{ asset('public/assets/img/dashboard-icons/settings/p2p.svg') }}" alt="">
                       </div>
                       <div class="security-column-description">
                          <h5>P2P Profile Settings</h5>
                          <span>Edit your P2P nickname here.</span>
                       </div>
                    </div>
                    <div class="security-column-right">
                       <div class="d-flex align-items-center">
                          <span class="bx bx-check"></span>
                          <span class="text-theme-yellow">Unset</span>
                       </div>
                       <div class="security-right-button">
                          <a href="" class="btn-theme-sm">Manage</a>
                       </div>
                    </div>
                 </div>
        
                 <div class="pt-5 pb-3 ">
                    <h4>Preferences</h4>
                 </div>
                 <div class="security-column ">
                    <div class="security-column-left">
                       <div class="security-column-icon">
                          <img src="{{ asset('public/assets/img/dashboard-icons/settings/confirmation.svg') }}" alt="">
                       </div>
                       <div class="security-column-description">
                          <h5>Order Confirmation Reminders</h5>
                          <span>If the order reminder function is enabled, it will need to be reconfirmed every time an order is submitted.</span>
                       </div>
                    </div>
                    <div class="security-column-right">
                       <div class="d-flex align-items-center">
                          <span class="bx bx-check"></span>
                          <span class="text-theme-yellow">Stop-Limit Order</span>
                       </div>
                       <div class="security-right-button">
                          <a href="" data-bs-toggle="modal" data-bs-target="#cnfReminder" class="btn-theme-sm">Manage</a>
                       </div>
                    </div>
                 </div>
                 <div class="d-block pb-3 border-bottom">
                    <div class="security-column-left mt-5">
                       <div class="security-column-icon">
                          <img src="{{ asset('public/assets/img/dashboard-icons/settings/notification.svg') }}" alt="">
                       </div>
                       <div class="security-column-description">
                          <h5>Notifications</h5>
                       </div>
                    </div>
                    <div class="notification-column">
                        <div class="notification-column-left">
                            <div class="notification-column-description" style="padding-left: 34px;">
                                <h6 class="fw-bold">Notification Language</h6>
                                <span>Email and app push notification language settings.</span>
                            </div>
                        </div>
                        <div class="notification-column-right">
                            <div class="d-flex align-items-center notification-column-right-des">
                                <span class="bx bx-check"></span>
                                <span class="text-theme-yellow">English</span>
                            </div>
                            <div class="security-right-button">
                                <a href="" data-bs-toggle="modal" data-bs-target="#notiLanguage" class="btn-theme-sm">Manage</a>
                            </div>
                        </div>
                    </div>
                    
                    <div class="notification-column">
                        <div class="notification-column-left">
                        <div class="notification-column-description" style="padding-left: 34px;">
                            <h6 class="fw-bold">On-site Notifications</h6>
                            <span>Once enabled, you will receive relevant notifications within the app and website.</span>
                        </div>
                        </div>
                        <div class="notification-column-right">
                        <div class="d-flex align-items-center">
                            <span class="bx bx-check"></span>
                            <span class="text-theme-yellow">Activities</span>
                        </div>
                        <div class="security-right-button">
                            <a href="" data-bs-toggle="modal" data-bs-target="#onSiteNotifications" class="btn-theme-sm">Manage</a>
                        </div>
                        </div>
                    </div>
                    <div class="notification-column mb-3">
                        <div class="notification-column-left">
                        <div class="notification-column-description" style="padding-left: 34px;">
                            <h6 class="fw-bold">Marketing Emails</h6>
                            <span>Select whether you want to receive marketing emails from us.</span>
                        </div>
                        </div>
                        <div class="notification-column-right">
                            <div class="d-flex align-items-center">
                                <span class="bx bx-check"></span>
                                <span class="text-theme-yellow">On</span>
                            </div>
                            <div class="security-right-button">
                                <a href="" class="btn-theme-sm">Disable</a>
                            </div>
                        </div>
                    </div>
        
                 </div>
        
        
                 <div class="pt-5 pb-3 ">
                    <h4>Marketing and Analytics</h4>
                 </div>
                 <div class="security-column ">
                    <div class="security-column-left">
                       <div class="security-column-icon">
                          <img src="{{ asset('public/assets/img/dashboard-icons/settings/analytics.svg') }}" alt="">
                       </div>
                       <div class="security-column-description">
                          <h5>Analytics</h5>
                          <span>WealthMark may share usage data to 3rd party analytics platforms to help improve our products and marketing.</span>
                       </div>
                    </div>
                    <div class="security-column-right">
                       <div class="d-flex align-items-center">
                          <span class="bx bx-check"></span>
                          <span class="text-theme-yellow">On</span>
                       </div>
                       <div class="security-right-button">
                          <a href="" class="btn-theme-sm">Disable</a>
                       </div>
                    </div>
                 </div>
        
                 <div class="security-column ">
                    <div class="security-column-left">
                       <div class="security-column-icon">
                          <img src="{{ asset('public/assets/img/dashboard-icons/settings/advertising.svg') }}" alt=""> 
                       </div>
                       <div class="security-column-description">
                          <h5>Advertising</h5>
                          <span>WealthMark may share usage data to 3rd party ad platforms to help improve our targeting and marketing quality.</span>
                       </div>
                    </div>
                    <div class="security-column-right">
                       <div class="d-flex align-items-center">
                          <span class="bx bx-check"></span>
                          <span class="text-theme-yellow">On</span>
                       </div>
                       <div class="security-right-button">
                          <a href="" class="btn-theme-sm">Disable</a>
                       </div>
                    </div>
                 </div>
        
              </div>
            </div>
        </div>
    </div>
   @include('template.web_footer') 	
   @include('template.web_js') 
</body>
</html>

