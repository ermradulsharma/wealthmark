<!DOCTYPE html><html lang="en">
<head>
<meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>Buy, trade, and hold 100+ cryptocurrencies on Wealthmark</title>
  <meta content="" name="description">
  <meta content="" name="keywords">
  <meta name="theme-color" content="#287aff">
  <link href="{{ asset('public/assets/img/wealthmark-logo.svg') }}" rel="icon">
  <link href="{{ asset('public/assets/img/wealthmark-logo.svg') }}" rel="apple-touch-icon">
  <link rel="stylesheet" href="{{ asset('public/assets/css/dashboard.css') }}">
  @include('template.web_css') 
  
  <style>
  .sidebar-nav{
      display:block;
  }
  #preloader{
      display:none !important;
  }
  
  @media (max-width: 450px){

  .balance-details .dashboard-card-header{
      display:block;
      
  }
  .dashboard-card-heading{
      margin-bottom:10px;
      display:block;
  }
  .balance-details .dashboard-card-header .btn-theme-sm{
      margin-left:0px;
  }
 #progressbar li{
     width:33% !important;
 }
      
  }
  </style>
  
  
  
</head>
<body>
    @include('template.dashboard_mobile_menu')  
    @include('template.web_menu')    
    <main id="main">
   <!-- ======= Breadcrumbs ======= -->
   <section id="breadcrumbs" class="breadcrumbs">
      <div class="container">
        <ol>
          <li><a href="index.php">Home</a></li>
          <li>Referral</li>
        </ol>
        
        <h2 class="mb-0">Referral</h2>

        
      </div>
    </section>
    <!-- End Breadcrumbs -->

    <section class="refferal-banner">
        <div class="container inner-referal">
           <div class="row gap-y-3 justify-content-md-between align-items-md-center">
             <div class="col-xl-6 col-lg-6 col-md-6">
                <h1 class="refferal-heading"><span>Refer Friends.</span>&nbsp;<span>Earn Crypto Together.</span></h1>
                <div class="referral-description">Earn up to 40% commission on every trade across Binance Spot, Futures, and Pool.</div>
                <a href="#" class="text-theme-yellow">View referral rules</a>
             </div>
             <div class="col-xl-4 col-lg-5  col-md-6">
                <div class="card refferal-card">
                  <div class="card-body">
                    <div class="row g-0 mb-3">
                      <div class="col-5">
                        <span class="fs-15 fw-bold">Default Referral</span>
                      </div>
                      <div class="col-7 text-end">
                        <a href="#" class="fs-15 text-theme-yellow">Change referral settings</a>
                      </div>
                    </div>

                    <div class="row g-0 px-3 py-2 alert-warning mb-3 rounded">
                      <div class="col-6">
                        <span class="fs-14">You Receive</span>
                        <h4 class="fw-bold">20%</h4>
                      </div>
                      <div class="col-6">
                        <span class="fs-14">Friends Receive</span>
                        <h4 class="fw-bold">0%</h4>
                      </div>
                    </div>

                    <div class="row g-0 p-2 bg-light mb-3 rounded">
                      <div class="col-6">
                        <span class="fs-14">Referral ID</span>
                      </div>
                      <div class="col-6 text-end">
                        <span class="fs-14 fw-bold mr-2">372573211</span>&nbsp;<a href="#" class="bx bx-copy text-theme-yellow"></a>
                      </div>
                    </div>

                    <div class="row g-0 p-2 bg-light mb-3 rounded">
                      <div class="col-4">
                        <span class="fs-14">Referral Link</span>
                      </div>
                      <div class="col-8 text-end">
                        <span class="fs-14 fw-bold mr-2">https://accou...=372573211</span>&nbsp;<a href="#" class="bx bx-copy text-theme-yellow"></a>
                      </div>
                    </div>

                    <a href="#" class="btn-theme w-100 text-center mt-2">Invite Friends</a>
                  </div>
                </div>
             </div>
           </div>
        </div>
    </section>


<!-- ======= banners Section ======= -->
<section id="banners" class="banners inner-page">
  <div class="container ">
    <div class="swiper referralSwiper swiper-initialized swiper-horizontal">
      <div class="swiper-wrapper" id="swiper-wrapper-e2a66709994e877e" aria-live="off" style="transform: translate3d(-1508px, 0px, 0px); transition-duration: 0ms;"><div class="swiper-slide swiper-slide-duplicate swiper-slide-duplicate-active" data-swiper-slide-index="1" role="group" aria-label="2 / 4" style="width: 362px; margin-right: 15px;">
          <a href="#" class="text-theme-blue">
            <img src="{{ asset('public/assets/img/crypto.png') }}" class="img-fluid" alt="">
            <div class="mt-2 mb-1">
              <span>Refer and share $600,000 in Mystery Boxes</span>
            </div>
            <div class="fs-14 text-muted mb-2">
              <span class="bi bi-calendar-event mr-2">&nbsp;&nbsp;</span><span>Offer ends: 2021-12-16 03:59 (UTC)</span>
            </div>
            <div>
                <span class="badge bg-warning">ACTIVE</span>
            </div>
          </a>
        </div><div class="swiper-slide swiper-slide-duplicate swiper-slide-duplicate-next" data-swiper-slide-index="2" role="group" aria-label="3 / 4" style="width: 362px; margin-right: 15px;">
          <a href="#" class="text-theme-blue">
            <img src="{{ asset('public/assets/img/crypto.png') }}" class="img-fluid" alt="">
            <div class="mt-2 mb-1">
              <span>Refer and share $600,000 in Mystery Boxes</span>
            </div>
            <div class="fs-14 text-muted mb-2">
              <span class="bi bi-calendar-event mr-2">&nbsp;&nbsp;</span><span>Offer ends: 2021-12-16 03:59 (UTC)</span>
            </div>
            <div>
                <span class="badge bg-secondary">FINISHED</span>
            </div>
          </a>
        </div><div class="swiper-slide swiper-slide-duplicate" data-swiper-slide-index="3" role="group" aria-label="4 / 4" style="width: 362px; margin-right: 15px;">
          <a href="#" class="text-theme-blue">
            <img src="{{ asset('public/assets/img/crypto.png') }}" class="img-fluid" alt="">
            <div class="mt-2 mb-1">
              <span>Refer and share $600,000 in Mystery Boxes</span>
            </div>
            <div class="fs-14 text-muted mb-2">
              <span class="bi bi-calendar-event mr-2">&nbsp;&nbsp;</span><span>Offer ends: 2021-12-16 03:59 (UTC)</span>
            </div>
            <div>
                <span class="badge bg-warning">ACTIVE</span>
            </div>
          </a>
        </div>
        <div class="swiper-slide swiper-slide-prev" data-swiper-slide-index="0" role="group" aria-label="1 / 4" style="width: 362px; margin-right: 15px;">
          <a href="#" class="text-theme-blue">
            <img src="{{ asset('public/assets/img/crypto.png') }}" class="img-fluid" alt="">
            <div class="mt-2 mb-1">
              <span>Refer and share $600,000 in Mystery Boxes</span>
            </div>
            <div class="fs-14 text-muted mb-2">
              <span class="bi bi-calendar-event mr-2">&nbsp;&nbsp;</span><span>Offer ends: 2021-12-16 03:59 (UTC)</span>
            </div>
            <div>
                <span class="badge bg-secondary">FINISHED</span>
            </div>
          </a>
        </div>
        <div class="swiper-slide swiper-slide-active" data-swiper-slide-index="1" role="group" aria-label="2 / 4" style="width: 362px; margin-right: 15px;">
          <a href="#" class="text-theme-blue">
            <img src="{{ asset('public/assets/img/crypto.png') }}" class="img-fluid" alt="">
            <div class="mt-2 mb-1">
              <span>Refer and share $600,000 in Mystery Boxes</span>
            </div>
            <div class="fs-14 text-muted mb-2">
              <span class="bi bi-calendar-event mr-2">&nbsp;&nbsp;</span><span>Offer ends: 2021-12-16 03:59 (UTC)</span>
            </div>
            <div>
                <span class="badge bg-warning">ACTIVE</span>
            </div>
          </a>
        </div>
        <div class="swiper-slide swiper-slide-next" data-swiper-slide-index="2" role="group" aria-label="3 / 4" style="width: 362px; margin-right: 15px;">
          <a href="#" class="text-theme-blue">
            <img src="{{ asset('public/assets/img/crypto.png') }}" class="img-fluid" alt="">
            <div class="mt-2 mb-1">
              <span>Refer and share $600,000 in Mystery Boxes</span>
            </div>
            <div class="fs-14 text-muted mb-2">
              <span class="bi bi-calendar-event mr-2">&nbsp;&nbsp;</span><span>Offer ends: 2021-12-16 03:59 (UTC)</span>
            </div>
            <div>
                <span class="badge bg-secondary">FINISHED</span>
            </div>
          </a>
        </div>
        <div class="swiper-slide" data-swiper-slide-index="3" role="group" aria-label="4 / 4" style="width: 362px; margin-right: 15px;">
          <a href="#" class="text-theme-blue">
            <img src="{{ asset('public/assets/img/crypto.png') }}" class="img-fluid" alt="">
            <div class="mt-2 mb-1">
              <span>Refer and share $600,000 in Mystery Boxes</span>
            </div>
            <div class="fs-14 text-muted mb-2">
              <span class="bi bi-calendar-event mr-2">&nbsp;&nbsp;</span><span>Offer ends: 2021-12-16 03:59 (UTC)</span>
            </div>
            <div>
                <span class="badge bg-warning">ACTIVE</span>
            </div>
          </a>
        </div>

      <div class="swiper-slide swiper-slide-duplicate swiper-slide-duplicate-prev" data-swiper-slide-index="0" role="group" aria-label="1 / 4" style="width: 362px; margin-right: 15px;">
          <a href="#" class="text-theme-blue">
            <img src="{{ asset('public/assets/img/crypto.png') }}" class="img-fluid" alt="">
            <div class="mt-2 mb-1">
              <span>Refer and share $600,000 in Mystery Boxes</span>
            </div>
            <div class="fs-14 text-muted mb-2">
              <span class="bi bi-calendar-event mr-2">&nbsp;&nbsp;</span><span>Offer ends: 2021-12-16 03:59 (UTC)</span>
            </div>
            <div>
                <span class="badge bg-secondary">FINISHED</span>
            </div>
          </a>
        </div><div class="swiper-slide swiper-slide-duplicate swiper-slide-duplicate-active" data-swiper-slide-index="1" role="group" aria-label="2 / 4" style="width: 362px; margin-right: 15px;">
          <a href="#" class="text-theme-blue">
            <img src="{{ asset('public/assets/img/crypto.png') }}" class="img-fluid" alt="">
            <div class="mt-2 mb-1">
              <span>Refer and share $600,000 in Mystery Boxes</span>
            </div>
            <div class="fs-14 text-muted mb-2">
              <span class="bi bi-calendar-event mr-2">&nbsp;&nbsp;</span><span>Offer ends: 2021-12-16 03:59 (UTC)</span>
            </div>
            <div>
                <span class="badge bg-warning">ACTIVE</span>
            </div>
          </a>
        </div><div class="swiper-slide swiper-slide-duplicate swiper-slide-duplicate-next" data-swiper-slide-index="2" role="group" aria-label="3 / 4" style="width: 362px; margin-right: 15px;">
          <a href="#" class="text-theme-blue">
            <img src="{{ asset('public/assets/img/crypto.png') }}" class="img-fluid" alt="">
            <div class="mt-2 mb-1">
              <span>Refer and share $600,000 in Mystery Boxes</span>
            </div>
            <div class="fs-14 text-muted mb-2">
              <span class="bi bi-calendar-event mr-2">&nbsp;&nbsp;</span><span>Offer ends: 2021-12-16 03:59 (UTC)</span>
            </div>
            <div>
                <span class="badge bg-secondary">FINISHED</span>
            </div>
          </a>
        </div></div>
      <div class="swiper-button-next d-none d-lg-block" tabindex="0" role="button" aria-label="Next slide" aria-controls="swiper-wrapper-e2a66709994e877e"></div>
      <div class="swiper-button-prev d-none d-lg-block" tabindex="0" role="button" aria-label="Previous slide" aria-controls="swiper-wrapper-e2a66709994e877e"></div>
      <div class="swiper-pagination d-md-block d-lg-none swiper-pagination-clickable swiper-pagination-bullets swiper-pagination-horizontal"><span class="swiper-pagination-bullet" tabindex="0" role="button" aria-label="Go to slide 1"></span><span class="swiper-pagination-bullet swiper-pagination-bullet-active" tabindex="0" role="button" aria-label="Go to slide 2"></span><span class="swiper-pagination-bullet" tabindex="0" role="button" aria-label="Go to slide 3"></span><span class="swiper-pagination-bullet" tabindex="0" role="button" aria-label="Go to slide 4"></span></div>
    <span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span></div>

  </div>
</section>
<!-- End Clients Section -->


<!-- ======= Referral Navs ======= -->
<section class="buy-crypto">
  <div class="container">
   
    <div class="row ">
      <div class="col-md-12 my-auto">
        <ul class="nav nav-pills referral-navs" id="pills-tab" role="tablist">
          <li class="nav-item" role="presentation">
            <button class="nav-link" id="pills-dashboard-tab" data-bs-toggle="pill" data-bs-target="#pills-dashboard" type="button" role="tab" aria-controls="pills-dashboard" aria-selected="false">Dashboard</button>
          </li>
          <li class="nav-item" role="presentation">
            <button class="nav-link" id="pills-referrals-tab" data-bs-toggle="pill" data-bs-target="#pills-referrals" type="button" role="tab" aria-controls="pills-referrals" aria-selected="false">Referrals</button>
          </li>
          <li class="nav-item" role="presentation">
            <button class="nav-link" id="pills-commission-tab" data-bs-toggle="pill" data-bs-target="#pills-commission" type="button" role="tab" aria-controls="pills-commission" aria-selected="false">Commission Rebate</button>
          </li>
          <li class="nav-item" role="presentation">
            <button class="nav-link active" id="pills-referral-kickback-tab" data-bs-toggle="pill" data-bs-target="#pills-referral-kickback" type="button" role="tab" aria-controls="pills-referral-kickback" aria-selected="true">Referral Kickback</button>
          </li>
        </ul>
        <div class="tab-content" id="pills-tabContent">
            <div class="tab-pane fade" id="pills-dashboard" role="tabpanel" aria-labelledby="pills-dashboard-tab">
              <p class="referral-titles">Dashboard</p>

              <div class="col-12 filter-tabs ">
                <!-- <div class="d-flex align-items-center justify-content-between mb-2rem"> -->
                    <div class="row gap-y-3">
                      <div class="col-lg-3 col-xl-2 col-md-3 col-sm-5">
                        <div class="dropdown-theme">
                          <div class="dropdown bootstrap-select w-100"><select class="selectpicker w-100">
                              <option>All Accounts</option>
                              <option>Spot</option>
                              <option>Futures</option>
                              <option>Mining</option>
                          </select><button type="button" tabindex="-1" class="btn dropdown-toggle btn-light" data-bs-toggle="dropdown" role="combobox" aria-owns="bs-select-1" aria-haspopup="listbox" aria-expanded="false" title="All Accounts"><div class="filter-option"><div class="filter-option-inner"><div class="filter-option-inner-inner">All Accounts</div></div> </div></button><div class="dropdown-menu "><div class="inner show" role="listbox" id="bs-select-1" tabindex="-1"><ul class="dropdown-menu inner show" role="presentation"></ul></div></div></div>
                        </div>
                      </div>

                      <div class="col-lg-9 col-xl-10 col-md-9 col-sm-7 d-flex align-items-center filters ">
                        <div class="tabs"><span>All</span></div>
                        <div class="tabs">Yesterday</div>
                        <div class="tabs">This Week</div>
                        <div class="tabs">This Month</div>
                        <div class="tabs">New Listing</div>
                      </div>
                    
                    </div>
                    
                <!-- </div> -->
              </div>
              

              <div class="alert-warning p-3 rounded mb-2rem">
                <div class="row">
                  <div class="col-lg-4 col-md-6 mb-3">
                    <div class="d-flex align-items-center">
                      <span class="fs-14">Your Earnings &nbsp; </span>
                      <span class="bi bi-info-circle" data-bs-toggle="tooltip" data-bs-placement="top" title="" data-bs-original-title="Your commissions from referrals who have completed Spot, Futures, or Mining transactions." aria-label="Your commissions from referrals who have completed Spot, Futures, or Mining transactions."></span>
                    </div>
                    <div class="py-1">
                      <h1 class="mb-0"> 0 BTC </h1>
                    </div>
                    <div class="pb-2">
                      <span class="fs-14 text-success fw-bold">+0 BTC </span>
                    </div>
                  </div>

                  <div class="col-lg-4 col-md-6 mb-3">
                    <div class="d-flex align-items-center">
                      <span class="fs-14">Friends Who Started Trading &nbsp; </span>
                      <span class="bi bi-info-circle" data-bs-toggle="tooltip" data-bs-placement="top" title="" data-bs-original-title="Your commissions from referrals who have completed Spot, Futures, or Mining transactions." aria-label="Your commissions from referrals who have completed Spot, Futures, or Mining transactions."></span>
                    </div>
                    <div class="py-1">
                      <h1 class="mb-0"> 0</h1>
                    </div>
                    <div class="pb-2">
                      <span class="fs-14 text-success fw-bold">+0</span>
                    </div>
                  </div>

                  <div class="col-lg-4 col-md-6 mb-3">
                    <div class="d-flex align-items-center">
                      <span class="fs-14">Friends &nbsp; </span>
                      <span class="bi bi-info-circle" data-bs-toggle="tooltip" data-bs-placement="top" title="" data-bs-original-title="Your commissions from referrals who have completed Spot, Futures, or Mining transactions." aria-label="Your commissions from referrals who have completed Spot, Futures, or Mining transactions."></span>
                    </div>
                    <div class="py-1">
                      <h1 class="mb-0"> 0</h1>
                    </div>
                    <div class="pb-2">
                      <span class="fs-14 text-success fw-bold">+0 </span>
                    </div>
                  </div>

                  <div class="col-lg-4 col-md-6 mb-3">
                    <div class="d-flex align-items-center">
                      <span class="fs-14">Top Referrer Bonus &nbsp; </span>
                      <span class="bi bi-info-circle" data-bs-toggle="tooltip" data-bs-placement="top" title="" data-bs-original-title="Your commissions from referrals who have completed Spot, Futures, or Mining transactions." aria-label="Your commissions from referrals who have completed Spot, Futures, or Mining transactions."></span>
                    </div>
                    <div class="py-1">
                      <h1 class="mb-0"> 11.31449898 BTC</h1>
                    </div>
                    <div class="pb-2">
                      <span class="fs-14 fw-bold">ID 185070150</span>
                    </div>
                  </div>

                </div>
              </div>

                <div class="small text-muted mb-3">* Feugiat pretium nibh ipsum consequat. Tempus iaculis urna id volutpat lacus laoreet non curabitur gravida. Venenatis lectus magna fringilla urna porttitor rhoncus dolor purus non porttitor rhoncus dolor purus non rhoncus dolor purus non porttitor rhoncus dolor purus non.</div>
                <div class="small text-muted mb-3">* Feugiat pretium nibh ipsum consequat. Tempus iaculis urna id volutpat lacus laoreet non curabitur gravida. Venenatis lectus magna fringilla urna porttitor rhoncus dolor purus non porttitor rhoncus dolor purus non.</div>
            </div>

            <div class="tab-pane fade" id="pills-referrals" role="tabpanel" aria-labelledby="pills-referrals-tab">
              <p class="referral-titles">Referrals</p>
            
              <div class="filter-tabs ">
                <div class="d-flex align-items-center justify-content-between mb-2rem">
                  <div class="col-12 d-flex align-items-center filters">
                      <div class="tabs"><span>All Accounts</span></div>
                      <div class="tabs">Spot</div>
                      <div class="tabs">Futures</div>
                      <div class="tabs">Mining</div>
                  </div>
                </div> 
              </div>
              <div class="row">
                <div class="col-12 table-theme table-responsive">
                  <div id="referrals_wrapper" class="dataTables_wrapper dt-bootstrap5 no-footer"><div class="row"><div class="col-sm-12 col-md-6"></div><div class="col-sm-12 col-md-6"></div></div><div class="row"><div class="col-sm-12"><table id="referrals" class="datatable table table-hover w-100 dataTable no-footer">
                      <thead class="table-light">
                          <tr><th class="sorting sorting_asc" tabindex="0" aria-controls="referrals" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Friend's User Id: activate to sort column descending" style="width: 0px;">Friend's User Id</th><th class="sorting" tabindex="0" aria-controls="referrals" rowspan="1" colspan="1" aria-label="Referral Bonus Earned (BTC): activate to sort column ascending" style="width: 0px;">Referral Bonus Earned (BTC)</th><th class="sorting" tabindex="0" aria-controls="referrals" rowspan="1" colspan="1" aria-label="Trade Initiated: activate to sort column ascending" style="width: 0px;">Trade Initiated</th><th class="sorting" tabindex="0" aria-controls="referrals" rowspan="1" colspan="1" aria-label="Date: activate to sort column ascending" style="width: 0px;">Date</th></tr>
                      </thead>
                      <tbody>
                          
                          
                          
                      <tr class="odd">
                              <td class="sorting_1">Some Data</td>
                              <td>Some Data</td>
                              <td>Some Data</td>
                              <td>Some Data</td>
                          </tr><tr class="even">
                              <td class="sorting_1">Some Data</td>
                              <td>Some Data</td>
                              <td>Some Data</td>
                              <td>Some Data</td>
                          </tr></tbody>
                  </table></div></div><div class="row"><div class="col-sm-12 col-md-5"></div><div class="col-sm-12 col-md-7"></div></div></div>
                </div>
              </div>
              <div class="row">
                <div class="col-12">
                      <div class="text-center py-5">
                        <img src="{{ asset('public/assets/img/not-found-icons/no-record-found.svg') }}" class="no-record-icon" alt="">
                        <p class="mt-3 mb-0">No Record Found.</p>
                      </div>
                </div>
              </div>
              <div class="row alert-light mb-3 align-items-center g-0 rounded">
                <div class="col-xl-11 col-lg-10 col-md-10 p-2">
                    <div class="small text-muted">Feugiat pretium nibh ipsum consequat. Tempus iaculis urna id volutpat lacus laoreet non curabitur gravida. Venenatis lectus magna </div>
                </div>
                <div class="col-xl-1 col-lg-2 col-md-2 p-2 text-md-end">
                  <a href="#" class="text-theme-yellow"><span class="bi bi-box-arrow-in-up-right me-2 small"></span><span class="small">Export</span></a>
                </div>
              </div>
              
            </div>

            <div class="tab-pane fade" id="pills-commission" role="tabpanel" aria-labelledby="pills-commission-tab">
            
                  <p class="referral-titles">Commission Rebate</p>
                <div class="filter-tabs ">
                  <div class="d-flex align-items-center justify-content-between mb-2rem">
                    <div class="col-12 d-flex align-items-center filters">
                        <div class="tabs"><span>Summary</span></div>
                        <div class="tabs">Spot (Margin Included)</div>
                        <div class="tabs">Futures</div>
                        <div class="tabs active">Mining</div>
                    </div>
                  </div> 
                </div>
                <div class="row">
                  <div class="col-12 table-theme table-responsive">
                    <div id="commissionRebate_wrapper" class="dataTables_wrapper dt-bootstrap5 no-footer"><div class="row"><div class="col-sm-12 col-md-6"></div><div class="col-sm-12 col-md-6"></div></div><div class="row"><div class="col-sm-12"><table id="commissionRebate" class="datatable table table-hover w-100 dataTable no-footer">
                        <thead class="table-light">
                            <tr><th class="sorting sorting_asc" tabindex="0" aria-controls="commissionRebate" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Friend's User Id: activate to sort column descending" style="width: 0px;">Friend's User Id</th><th class="sorting" tabindex="0" aria-controls="commissionRebate" rowspan="1" colspan="1" aria-label="Referral Bonus Earned (BTC): activate to sort column ascending" style="width: 0px;">Referral Bonus Earned (BTC)</th><th class="sorting" tabindex="0" aria-controls="commissionRebate" rowspan="1" colspan="1" aria-label="Trade Initiated: activate to sort column ascending" style="width: 0px;">Trade Initiated</th><th class="sorting" tabindex="0" aria-controls="commissionRebate" rowspan="1" colspan="1" aria-label="Date: activate to sort column ascending" style="width: 0px;">Date</th></tr>
                        </thead>
                        <tbody>
                            
                            
                            
                        <tr class="odd">
                                <td class="sorting_1">Some Data</td>
                                <td>Some Data</td>
                                <td>Some Data</td>
                                <td>Some Data</td>
                            </tr><tr class="even">
                                <td class="sorting_1">Some Data</td>
                                <td>Some Data</td>
                                <td>Some Data</td>
                                <td>Some Data</td>
                            </tr></tbody>
                    </table></div></div><div class="row"><div class="col-sm-12 col-md-5"></div><div class="col-sm-12 col-md-7"></div></div></div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-12">
                        <div class="text-center py-5">
                          <img src="{{ asset('public/assets/img/not-found-icons/no-record-found.svg') }}" class="no-record-icon" alt="">
                          <p class="mt-3 mb-0">No Record Found.</p>
                        </div>
                  </div>
                </div>
                <div class="row alert-light mb-3 align-items-center g-0 rounded">
                  <div class="col-xl-11 col-lg-10 col-md-10 p-2">
                      <div class="small text-muted">Feugiat pretium nibh ipsum consequat. Tempus iaculis urna id volutpat lacus laoreet non curabitur gravida. Venenatis lectus magna </div>
                  </div>
                  <div class="col-xl-1 col-lg-2 col-md-2 p-2 text-md-end">
                    <a href="#" class="text-theme-yellow"><span class="bi bi-box-arrow-in-up-right me-2 small"></span><span class="small">Export</span></a>
                  </div>
                </div>
            </div>





            <div class="tab-pane fade active show" id="pills-referral-kickback" role="tabpanel" aria-labelledby="pills-referral-kickback-tab">
                  <p class="referral-titles">Referral Kickback</p>

                <div class="filter-tabs ">
                  <div class="d-flex align-items-center justify-content-between mb-2rem">
                    <div class="col-12 d-flex align-items-center filters">
                        <div class="tabs"><span>Summary</span></div>
                        <div class="tabs">Spot</div>
                        <div class="tabs">Margin</div>
                        <div class="tabs">Futures</div>
                        <div class="tabs">Mining</div>
                    </div>
                  </div> 
                </div>
                <div class="row">
                  <div class="col-12 table-theme table-responsive">
                    <div id="commissionRebate_wrapper" class="dataTables_wrapper dt-bootstrap5 no-footer"><div class="row"><div class="col-sm-12 col-md-6"></div><div class="col-sm-12 col-md-6"></div></div><div class="row"><div class="col-sm-12"><table id="commissionRebate" class="datatable table table-hover w-100 dataTable no-footer">
                        <thead class="table-light">
                            <tr><th class="sorting sorting_asc" tabindex="0" aria-controls="commissionRebate" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Friend's User Id: activate to sort column descending" style="width: 0px;">Friend's User Id</th><th class="sorting" tabindex="0" aria-controls="commissionRebate" rowspan="1" colspan="1" aria-label="Referral Bonus Earned (BTC): activate to sort column ascending" style="width: 0px;">Referral Bonus Earned (BTC)</th><th class="sorting" tabindex="0" aria-controls="commissionRebate" rowspan="1" colspan="1" aria-label="Trade Initiated: activate to sort column ascending" style="width: 0px;">Trade Initiated</th><th class="sorting" tabindex="0" aria-controls="commissionRebate" rowspan="1" colspan="1" aria-label="Date: activate to sort column ascending" style="width: 0px;">Date</th></tr>
                        </thead>
                        <tbody>
                            
                            
                            
                        <tr class="odd">
                                <td class="sorting_1">Some Data</td>
                                <td>Some Data</td>
                                <td>Some Data</td>
                                <td>Some Data</td>
                            </tr><tr class="even">
                                <td class="sorting_1">Some Data</td>
                                <td>Some Data</td>
                                <td>Some Data</td>
                                <td>Some Data</td>
                            </tr></tbody>
                    </table></div></div><div class="row"><div class="col-sm-12 col-md-5"></div><div class="col-sm-12 col-md-7"></div></div></div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-12">
                        <div class="text-center py-5">
                          <img src="{{ asset('public/assets/img/not-found-icons/no-record-found.svg') }}" class="no-record-icon" alt="">
                          <p class="mt-3 mb-0">No Record Found.</p>
                        </div>
                  </div>
                </div>
                <div class="row alert-light mb-3 align-items-center g-0 rounded">
                  <div class="col-xl-11 col-lg-10 col-md-10 p-2">
                      <div class="small text-muted">Feugiat pretium nibh ipsum consequat. Tempus iaculis urna id volutpat lacus laoreet non curabitur gravida. Venenatis lectus magna </div>
                  </div>
                  <div class="col-xl-1 col-lg-2 col-md-2 p-2 text-md-end">
                    <a href="#" class="text-theme-yellow"><span class="bi bi-box-arrow-in-up-right me-2 small"></span><span class="small">Export</span></a>
                  </div>
                </div>
            </div>
        </div>
      </div>

    </div>
  </div>
</section><!-- End Clients Section -->

  </main>
   @include('template.web_footer') 	
   @include('template.web_js') 
</body>
</html>
