<!DOCTYPE html><html lang="en">
<head>
<meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>Buy, trade, and hold 100+ cryptocurrencies on Wealthmark</title>
  <meta content="" name="description">
  <meta content="" name="keywords">
  <meta name="theme-color" content="#287aff">
  <link href="{{ asset('public/assets/img/wealthmark-logo.svg') }}" rel="icon">
  <link href="{{ asset('public/assets/img/wealthmark-logo.svg') }}" rel="apple-touch-icon">
  <link rel="stylesheet" href="{{ asset('public/assets/css/dashboard.css') }}">
   @include('template.web_css') 
 <style>
 .popup-img{
   height: 100px;
   width: 200px;
   margin-bottom: 1rem;
}
.input-icon{
   height: 20px;
}
.transfer .form-control:disabled, .form-control[readonly] {
    background-color: #fff;
    opacity: 1;
}
.input-icon-contain{
   position: absolute;
   top: 31px;
    left: 20px;
    color: #707a8a;
    font-weight: bold;
}

.btn-check:focus+.btn-outline-warning, .btn-outline-warning:focus {
    box-shadow: none;
}
.transfer .btn-outline-warning {
    color: #222222;
    border-color: #ffc107;
    margin-right: 1rem;
    border-radius: 2rem !important;
}
.transfer .btn-check:active+.btn-outline-warning, .btn-check:checked+.btn-outline-warning, .btn-outline-warning.active, .btn-outline-warning.dropdown-toggle.show, .btn-outline-warning:active {
    color: #222222;
    background: linear-gradient(180deg, rgba(254,192,15,1) 0%, rgba(248,165,50,1) 100%);
    border-color: #ffc107;
}

  </style>
  
    <style>
  .sidebar-nav{
      display:block;
  }
  #preloader{
      display:none !important;
  }
  
  @media (max-width: 450px){

  .balance-details .dashboard-card-header{
      display:block;
      
  }
  .dashboard-card-heading{
      margin-bottom:10px;
      display:block;
  }
  .balance-details .dashboard-card-header .btn-theme-sm{
      margin-left:0px;
  }
 #progressbar li{
     width:33% !important;
 }
      
  }
  
  
  
  
  
  
  /*----------------------------------------------------------- for side bar css only-----------------------------------------------------------*/
  
 
   @media (max-width: 992px){
 .hide_on_max_dashboard_992{
     display:none !important;
 } 
   }
  .dashboard-main{
      margin-top:10px !important;
  }
.hide_on_dashboard{
    display:none !important;
} 
header{
    box-shadow:0 .125rem .25rem rgba(0,0,0,.075)!important;
    background:white;
   z-index:9999999999 !important;
 
}
  .sidebar-btn-open{
      font-size: 30px;
    color: #242424;
  }
  @media (max-width: 992px){
     .sidebar.active {
    display: block;
    top: 0px !important;
    position: fixed !important;
    right: 0 !important;
    left:auto !important;
      }
      
.dashboard-sidebar {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    position: fixed;
    inset: 0px;
    z-index: 9999;
    flex-direction: row-reverse;
    background-color: rgba(0, 0, 0, 0.1);
    display: none;
    transition: all 0.5s ease;
}
.dashboard-sidebar-flex{
    display:flex !important;
}
  }
    /*----------------------------------------------------------- for side bar css only-----------------------------------------------------------*/
  
  
  
  </style>
</head>
<body>
     @include('template.dashboard_mobile_menu')  
    @include('template.web_menu') 
    <div class="dashboard-main">
    @include('template.sidebar')
            <div class="container-fluid">
      <section class="dashboard-breadcrumb mb-2rem">
         <div class="container">
            <h2 class="fw-bold mb-0">Transfer</h2>
         </div>
      </section>
      <div class="container">
         <div class="row justify-content-center">
            <div class="col-xl-4 col-lg-6 col-md-8">
               <div class="card">
                  <div class="card-body transfer">
                     <div class="row g-0 gap-y-3">
                        <div class="col-6">
                           <h5 class="fw-bold">Transfer to JEX</h5>
                        </div>
                        <div class="col-6 text-end">
                           <a href="" class="text-theme-yellow"> Transfer History</a>
                        </div>
                     </div>
                     <hr>
                     <div class="row gap-y-3">
                        <div class="col-lg-6 position-relative">
                           <label for="">From</label>
                           <input type="text" class="form-control" disabled/>
                           <div class="input-icon-contain">
                              <img src="{{asset('public/assets/img/header-icons/buy-crypto/card-deposit.svg')}}" alt="" class="input-icon" />
                              <span class="fs-14">Spot Wallet</span>
                           </div>
                        </div>
                        <div class="col-lg-6 position-relative">
                           <label for="">To</label>
                           <input type="text" class="form-control" disabled/>
                           <div class="input-icon-contain">
                              <img src="{{asset('public/assets/img/dashboard-icons/jex.png') }}" alt="" class="input-icon" />
                              <span class="fs-14">Spot Wallet</span>
                           </div>
                        </div>
                        
                        <div class="col-12">
                           <div class="dropdown-theme">
                              <label for="" class="form-label">Coin</label>
                              <select class="selectpicker w-100">
                                 <option data-icon="bi-heart" data-subtext="1 INCH">1 INCH</option>
                                 <option data-icon="bi-heart" data-subtext="Aave">AAVE</option>
                                 <option data-icon="bi-heart" data-subtext="Alchemy Pay">ACH</option>
                              </select>
                           </div>
                        </div>
                        <div class="col-12">
                           <label for="" class="form-label">Amount</label>
                           <input type="text" placeholder="0" class="form-control" />
                        </div>

                        <div class="col-12">
                           <label for="" class="form-label">24h Withdraw Limit: <span class="text-theme-yellow">0</span>/10000 USDT</label><br>
                           <div class="btn-group" role="group" aria-label="Basic radio toggle button group">
                              <input type="radio" class="btn-check" name="btnradio" id="btnradio1" autocomplete="off" checked>
                              <label class="btn btn-outline-warning" for="btnradio1">25%</label>

                              <input type="radio" class="btn-check" name="btnradio" id="btnradio2" autocomplete="off">
                              <label class="btn btn-outline-warning" for="btnradio2">50%</label>

                              <input type="radio" class="btn-check" name="btnradio" id="btnradio3" autocomplete="off">
                              <label class="btn btn-outline-warning" for="btnradio3">75%</label>

                              <input type="radio" class="btn-check" name="btnradio" id="btnradio4" autocomplete="off">
                              <label class="btn btn-outline-warning" for="btnradio4">100%</label>
                           </div>
                        </div>
                        <div class="col-12 pt-3">
                           <a type="button" class="btn-theme text-center w-100" href="">Connect JEX</a>
                        </div>
                        
                     </div>
                    
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>

    <!-- Payment Method Modal -->
    <div class="modal fade" id="jex" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="jexLabel" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content">
             <div class="modal-header">
                <h5 class="modal-title" id="jexLabel">WealthMark Jex</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
             </div>
             <div class="modal-body">
                <div class="text-center">
                   <img src="{{asset('public/assets/img/not-found-icons/no-card.svg') }}" class="popup-img" alt="">
                </div>
    
                <p class="para">
                "WealthMark JEX provides our users with a variety of innovative financial products, such as options, futures and spot trading, as well as insurance. You can now quickly transfer your funds between WealthMark and WealthMark JEX. Log in to WealthMark JEX by simply using your existing WealthMark account and experience a whole new platform of innovative derivative products now!"
                </p>
                <a type="button" class="btn-theme text-center w-100" href="">Connect JEX</a>
             </div>
          </div>
          
        </div>
    </div>

    </div>

   @include('template.web_footer') 
    <script type="text/javascript">
        window.onload = () => {
          //   $('#jex').modal('show');
        }
    </script>
</body>
</html>