<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
   <head>
      <meta charset="utf-8">
      <meta content="width=device-width, initial-scale=1.0" name="viewport">
      <title>Wealth Mark | Login</title>
      <meta content="" name="description">
      <meta content="" name="keywords">
      <meta name="theme-color" content="#287aff">
      <link href="{{ asset('public/assets/img/wealthmark-logo.svg') }}" rel="icon">
      <link href="{{ asset('public/assets/img/wealthmark-logo.svg') }}" rel="apple-touch-icon">
      <link href="{{ asset('public/assets/vendor/bootstrap/css/bootstrap.min.css') }}" rel="stylesheet">
      <link href="{{ asset('public/assets/vendor/bootstrap-icons/bootstrap-icons.css') }}" rel="stylesheet">
      <link href="{{ asset('public/assets/vendor/boxicons/css/boxicons.min.css') }}" rel="stylesheet">
      <link href="{{ asset('public/assets/vendor/swiper/swiper-bundle.min.css') }}" rel="stylesheet">
      <link href="{{ asset('public/assets/css/niceCountryInput.css') }}" rel="stylesheet">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/16.0.8/css/intlTelInput.css" />
      <link href="{{ asset('public/assets/css/style.css') }}" rel="stylesheet">
      <link href="{{ asset('public/assets/css/helper.css') }}" rel="stylesheet">
      <link href="{{ asset('public/assets/vendor/remixicon/remixicon.css') }}" rel="stylesheet">
      <link rel="stylesheet" href="{{ asset('public/assets/wealthmark_new/css/style.css') }}">
      <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css">
      <link rel="stylesheet" href="{{ asset('public/assets/css/alert.css') }}">
      <link rel="stylesheet" href="{{ asset('public/assets/css/dark-mode.css') }}">
      <link rel="stylesheet" href="{{ asset('public/assets/css/QapTcha.jquery.css') }}" type="text/css" />
      <style>
        .error_border{border:1px solid red!important;}
        
        .error input {
            border-color: red;
            border-width: 2px;
        }
        
        .success input {
            border-color: green;
            border-width: 2px;
        }
        
        .error span {
            
            color: red;
        }
        
        .success span {
            color: green;
        }
        
        span.error {
            font-size: 14px;
            color: red;
        }
    </style>
   </head>
   <body class="bg-white">
      @include('template.custom_header')
      <main id="main">
         <section class="inner-page register">
            <div class="container">
               <div class="row">
                  <div class="col-lg-4 col-md-6 offset-md-1 offset-lg-1">
                     <div class="">
                        <div class="text-danger" id="error" style="display: none;">Incorrect Username Or Password</div>
                        <h5 class="mb-4">WealthMark Account Login</h5>
                        <ul class="nav nav-pills mb-4" id="pills-tab" role="tablist">
                           <li class="nav-item" role="presentation">
                              <button class="nav-link active" id="pills-home-tab" data-bs-toggle="pill" data-bs-target="#pills-home" type="button" role="tab" aria-controls="pills-home" aria-selected="true">Email</button>
                           </li>
                           <li class="nav-item" role="presentation">
                              <button class="nav-link" id="pills-profile-tab" data-bs-toggle="pill" data-bs-target="#pills-profile" type="button" role="tab" aria-controls="pills-profile" aria-selected="false">Mobile</button>
                           </li>
                        </ul>
                        <?php print_r($_SESSION); ?>
                        <div class="tab-content" id="pills-tabContent">
                           <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">
                              <form action="" method="post" id='myform'>
                                 <div class="form-floating mb-3">
                                    <input type="email" class="form-control" id="email" name="email" placeholder="name@example.com" required>
                                    <label for="email">Email address</label>
                                    <span class="error" id="email_err"> </span>
                                 </div>
                                 <div class="form-floating mb-3">
                                    <input type="password" class="form-control" name="password" id="password" placeholder="Password" required>
                                    <label for="floatingPassword">Password</label>
                                    <span class="error" id="password_err"> </span>
                                 </div>
                                 <div class="QapTcha mb-3"></div>
                                 <div class="form-button mb-3">
                                    <input Type="button" id="pbtnSubmit" class="btn-theme w-100 text-center" value="Login">
                                 </div>
                                 <div class="alt-text">
                                    <div class="half-line"></div>
                                    <div class="alt-text-main">or continue with</div>
                                    <div class="half-line"></div>
                                 </div>
                                 <div class="other-login-option">
                                    <div class="google-login">
                                       <div class="google">
                                          <div class="google-div">
                                             <img src="{{ asset('public/assets/img/google-icon.png') }}" class="other-login-img">
                                          </div>
                                          <div class="text">Google</div>
                                       </div>
                                    </div>
                                    <div class="apple-login">
                                       <div class="apple">
                                          <div class="apple-div">
                                             <img src="{{ asset('public/assets/img/apple-icon.png') }}" class="other-login-img">
                                          </div>
                                          <div class="text">Apple</div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="pt-3 pb-3">
                                    <p class="mb-2"> <a href="forgot-password" class="text-theme-yellow"> Forgot Password</a></p>
                                    <p> <span class="text-muted">Don't have an account?<a href="register" class="text-theme-yellow"> Register Now</a></span></p>
                                 </div>
                              </form>
                           </div>
                           <div class="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab">
                               <span class="error" id="default_err"> </span>
                              <form action="" method="post" id='myform1'>
                                 <div class="input-number-group">
                                    <div class="mb-3">
                                       <input type="tel" id="txtPhone" class="form-control" name="mobile"  placeholder="Mobile No" />
                                    </div>
                                    <div class="form-floating mb-3">
                                       <input type="text" class="form-control" id="mobile" pattern="\d*" maxlength="10" oninput="this.value=this.value.replace(/[^0-9]/g,'');"  placeholder="Phone Number">
                                       <label for="floatingInput">Mobile Number</label>
                                       <span class="error" id="phone_err"> </span>
                                    </div>
                                 </div>
                                 <div class="form-floating mb-3">
                                    <input type="password" class="form-control" id="password1" name="password" placeholder="Password">
                                    <label for="floatingPassword">Password</label>
                                    <span class="error" id="password1_err"> </span>
                                 </div>
                                 <div class="QapTcha mb-3"></div>
                                 
                                 <div class="form-button mb-3">
                                    <input Type="button" id="btnSubmit"  class="btn-theme w-100 text-center" value="Login">
                                    <a href="#" ></a>
                                 </div>
                                 <div class="alt-text">
                                    <div class="half-line"></div>
                                    <div class="alt-text-main">or continue with</div>
                                    <div class="half-line"></div>
                                 </div>
                                 <div class="other-login-option">
                                    <div class="google-login">
                                       <div class="google">
                                          <div class="google-div">
                                             <img src="{{ asset('public/assets/img/google-icon.png') }}" class="other-login-img">
                                          </div>
                                          <div class="text">Google</div>
                                       </div>
                                    </div>
                                    <div class="apple-login">
                                       <div class="apple">
                                          <div class="apple-div">
                                             <img src="{{ asset('public/assets/img/apple-icon.png') }}" class="other-login-img">
                                          </div>
                                          <div class="text">Apple</div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="pt-3 pb-3">
                                    <p class="mb-2"> <a href="forgot-password" class="text-theme-yellow"> Forgot Password</a></p>
                                    <p> <span class="text-muted">Don't have an account?<a href="register" class="text-theme-yellow"> Register Now</a></span></p>
                                 </div>
                              </form>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-lg-4 col-md-6 offset-lg-1">
                     <div class="login_scan">
                        <div class="qr_code">
                           <img src="{{ asset('public/assets/img/qr-code.png') }}" class="img-responsive" />
                        </div>
                        <div class="mob_login">
                           <h2>Log in with QR code</h2>
                           <p>Scan this code with the <span class="wealthmark-text"> Weathmark mobile app</span> to log in instantly.</p>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </section>
      </main>
      <!-- End #main -->
      @include('template.country_language')
      <div class="copy_right text-center">
         © 2017 - 2022 wealthmark.io All rights reserved
      </div>
      <a href="#" class="chat-support"><span><i class="bi-chat-dots-fill"></i></span><label for="">Support</label></a>
      <script src="{{ asset('public/assets/vendor/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
      <script src="{{ asset('public/assets/vendor/swiper/swiper-bundle.min.js') }}"></script>
      <script src="{{ asset('public/assets/js/niceCountryInput.js') }}"></script>
      <script type="text/javascript" src="https://code.jquery.com/jquery-3.5.1.js"></script> 
      <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/16.0.8/js/intlTelInput-jquery.min.js"></script>
      <script src="{{ asset('public/assets/js/dark-mode-switch.js') }}"></script>
      <script src="{{ asset('public/assets/js/alert.js') }}"></script>
      <script src="https://code.jquery.com/ui/1.13.2/jquery-ui.js"></script>
      <script type="text/javascript" src="{{ asset('public/assets/js/jquery.ui.touch.js') }}"></script>
      <script type="text/javascript" src="{{ asset('public/assets/js/QapTcha.jquery.js') }}"></script>
      <script type="text/javascript">
        $(document).ready(function(){
        	$('.QapTcha').QapTcha({disabledSubmit:false,autoRevert:true,autoSubmit:false});
        });
      </script>
      <script>
            $(document).ready(function () {
                $('#txtPhone').intlTelInput({
                     autoHideDialCode: true,
                     autoPlaceholder: "ON",
                     dropdownContainer: document.body,
                     formatOnDisplay: true,
                     hiddenInput: "full_number",
                     initialCountry: "auto",
                     nationalMode: true,
                     placeholderNumberType: "MOBILE",
                     geoIpLookup: function(callback) {
                            $.get("https://ipinfo.io", function() {}, "jsonp").always(function(resp) {
                                var countryCode = (resp && resp.country) ? resp.country : "";
                                callback(countryCode);
                            });
                        },
                     separateDialCode: true
                 });
                 
                $('#email').on('input', function () {
                    checkemail();
                });
                // $('#password').on('input', function () {
                //     checkpass();
                // });
                $('#mobile').on('input', function () {
                    checkmobile();
                });
                $('#pbtnSubmit').click(function () {
                    if (!checkemail()) {
                        //triggerAlert('Please fill all required field', 'error');
                    }
                    else{
                        $("#message").html("");
                        var form = $('#myform')[0];
                        var frmdata = new FormData(form);
                        var email = $('#email').val();
                        var password = $('#password').val();
                        var capp =$('#myform .cap').val();
                        var cap = $('#myform .cap').attr('name');
                        let datas = {};
                        datas[cap] = capp;
                        datas['email'] = email;
                        datas['password'] = password;
                        $.ajax({
                            type: "POST",
                            url: '<?php echo url('api/email_login');  ?>',
                            data: datas,
                            success: function(data) {
                                $('#myform').trigger("reset");
                                window.location.href = '<?php echo url( app()->getLocale(), 'request_login_email_otp');  ?>';
                            },
                            error: function(xhr, status, error) {
                                var erroJson = JSON.parse(xhr.responseText);
                                var email_error=erroJson.error.email;
                                var password_error=erroJson.error.password;
                                if(email_error){
                                    $('#email_err').html(email_error);
                                    $('#email').addClass('error_border');
                                }
                                if(password_error){
                                  $('#password_err').html(password_error);
                                  $('#password').addClass('error_border');
                                }
                                if(erroJson.error=="mismatch Captcha" || erroJson.error=="Invalid Captcha"){
                                    $('#myform .bgSlider').addClass('error_border');
                                    $('#myform .TxtStatus').html("Captcha Invalid");
                                }
                            }
                        });
                    }
                });
                
                $('#btnSubmit').click(function () {
                    var country_name = $("#txtPhone").intlTelInput("getSelectedCountryData").name;
                    var dialCode = $("#txtPhone").intlTelInput("getSelectedCountryData").dialCode;
                    $("#message").html("");
                    var form = $('#myform1')[0];
                    var frmdata = new FormData(form);
                    var mobile = $('#mobile').val();
                    var password = $('#password1').val();
                    var capp =$('#myform1 .cap').val();
                    var cap = $('#myform1 .cap').attr('name');
                    let datas = {};
                    datas[cap] = capp;
                    datas['phone'] = mobile;
                    datas['password'] = password;
                    datas['country_phone_code'] = dialCode;
                    $.ajax({
                        type: "POST",
                        url: '<?php echo url('api/phone_login');  ?>',
                        data: datas,
                       success: function(data) {
                           $('#myform1').trigger("reset");
                           window.location.href = '<?php echo url( app()->getLocale(), 'request_login_phone_otp');  ?>?step=2';
                       },
                       error: function(xhr, status, error) {
                           var erroJson = JSON.parse(xhr.responseText);
                           var phone_error=erroJson.error.phone;
                           var password_error=erroJson.error.password;
                            if(phone_error){
                               $('#phone_err').html(phone_error);
                                $('#mobile').addClass('error_border');
                            }
                            if(password_error){
                               $('#password1_err').html(password_error);
                                $('#password1').addClass('error_border');
                            }
                            if(erroJson.error=="mismatch Captcha" || erroJson.error=="Invalid Captcha"){
                                $('#myform1 .bgSlider').addClass('error_border');
                                $('#myform1 .TxtStatus').html("Captcha Invalid");
                            }
                        }
                    });
                });
            });
    
            function checkemail() {
                var pattern1 = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
                var email = $('#email').val();
                var validemail = pattern1.test(email);
                if (email == "") {
                    $('#email_err').html('Please enter your email');
                    $('#email').addClass('error_border');
                    return false;
                } else 
                if (!validemail) {
                    $('#email_err').html('Please enter a correct email address');
                    $('#email').addClass('error_border');
                    return false;
                } else {
                    $('#email_err').html('');
                    $('#email').removeClass('error_border');
                    return true;
                }
            }
            
            function checkmobile() {
                if (!$.isNumeric($("#mobile").val())) {
                    $("#mobile_err").html("only number is allowed");
                    return false;
                } else if ($("#mobile").val().length != 10) {
                    $("#mobile_err").html("10 digit required");
                    return false;
                }
                else {
                    $("#mobile_err").html("");
                    return true;
                }
            }
        </script>
   </body>
</html>