<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta content="width=device-width, initial-scale=1.0" name="viewport">
        <title>Wealth Mark | OTP</title>
        <meta content="" name="description">
        <meta content="" name="keywords">
        <meta name="theme-color" content="#287aff">
        <link href="{{ asset('public/assets/img/wealthmark-logo.svg') }}" rel="icon">
        <link href="{{ asset('public/assets/img/wealthmark-logo.svg') }}" rel="apple-touch-icon">
        <link href="{{ asset('public/assets/vendor/bootstrap/css/bootstrap.min.css') }}" rel="stylesheet">
        <link href="{{ asset('public/assets/vendor/bootstrap-icons/bootstrap-icons.css') }}" rel="stylesheet">
        <link href="{{ asset('public/assets/vendor/boxicons/css/boxicons.min.css') }}" rel="stylesheet">
        <link href="{{ asset('public/assets/vendor/swiper/swiper-bundle.min.css') }}" rel="stylesheet">
        <link href="{{ asset('public/assets/css/niceCountryInput.css') }}" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/16.0.8/css/intlTelInput.css" />
        <link href="{{ asset('public/assets/css/style.css') }}" rel="stylesheet">
        <link href="{{ asset('public/assets/css/helper.css') }}" rel="stylesheet">
        <link href="{{ asset('public/assets/vendor/remixicon/remixicon.css') }}" rel="stylesheet">
        <link rel="stylesheet" href="{{ asset('public/assets/wealthmark_new/css/style.css') }}">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css">
        <link rel="stylesheet" href="{{ asset('public/assets/css/alert.css') }}">
        <link rel="stylesheet" href="{{ asset('public/assets/css/login_register.css') }}">
        <link rel="stylesheet" href="{{ asset('public/assets/css/dark-mode.css') }}">
        <style>
             .error_border{border:1px solid red;}
             .error input {
             border-color: red;
             border-width: 2px;
             }
             .success input {
             border-color: green;
             border-width: 2px;
             }
             .error span {
             color: red;
             }
             .success span {
             color: green;
             }
             span.error {
             font-size: 14px;
             color: red;
             }
        </style>
        <style>
             .tooltip {
             position: relative;
             display: inline-block;
             border-bottom: 1px dotted black;
             opacity:1;
             }
             .tooltip .tooltiptext {
             visibility: hidden;
             width: 250px;
             background-color: black;
             color: #fff;
             text-align: center;
             border-radius: 6px;
             padding: 5px 10px;
             position: absolute;
             z-index: 999999;
             right: 29px;
             left: -50px;
             bottom: 30px;
             }
             .tooltip:hover .tooltiptext {
             visibility: visible;
             }		
             .toolLeft {
             top: -5px;
             right: 105%;
             }					
             .toolRight {
             top: -5px;
             left: 105%;
             }
             .toolTop {
             bottom: 100%;
             left: 50%;
             margin-left: -60px;
             }
             .toolBottom {
             top: 100%;
             left: 50%;
             margin-left: -60px;
             }
             .timer-counter{
             color:#fec00f;
             }
        </style>
   </head>
   <body class="bg-white">
      @include('template.custom_header')
      <main id="main" >
         <section class="inner-page register">
            <div class="container">
               <div class="container step-2">
                    <div class="row">
                        <div class="col-lg-4 col-md-6 offset-md-1 offset-lg-2">
                            <h4 class="form-heading mb-4">
                               New Phone Number Verification
                            </h4>
                            <?php //print_r($_SESSION); ?>
                            <p class="mt-2 mb-4">To secure your account, please complete the following verification.</p>
                            <div class="row">
                               <div class="col-md-12">
                                    <form action="" method="post" id="email_otp_frm">
                                    <div class="input-number-group">
                                        <div class="mb-3">
                                           <input type="tel" id="txtPhone" class="form-control" name="mobile"  placeholder="Mobile No" />
                                        </div>
                                        <div class="form-floating mb-3">
                                           <input type="text" class="form-control" id="mobile" pattern="\d*" maxlength="10" oninput="this.value=this.value.replace(/[^0-9]/g,'');"  placeholder="Phone Number">
                                           <label for="floatingInput">Mobile Number</label>
                                        </div>
                                    </div>
                                    <span class="error" id="phone_err"> </span>
                                    <div class="verification_div">
                                        <div class="verification_main">
                                           <div class="verification_inner inner-css phone_otp">
                                              <input type="input" pattern="\d*" maxlength="6"  oninput="this.value=this.value.replace(/[^0-9]/g,'');" aria-label="Phone Number Verification Code" id="phone_otp" class="verification_textbox" value="">
                                              <div class="getCode_outer getCode_outer1">
                                                 <div class="getCode_inner phone_get_code" style="display:block" onclick="start()">Get Code</div>
                                                 <div class="getCode_inner phone_code_sent" style="display:none" >
                                                    Verification Code Sent 
                                                    <span class="tooltip txt_info">
                                                    <i class="bi bi-info-circle-fill"></i> 
                                                    <span class="tooltiptext toolTop">
                                                    Haven’t received code? Request new code in  
                                                    <span class="timer-counter" id="phone_count">5</span> 
                                                    <span id="text">seconds</span>
                                                    The code will expire after 30 mins.
                                                    </span>
                                                    </span>
                                                 </div>
                                              </div>
                                              <label class="wm_label wm_label_error">New Phone Verification Code</label>
                                              <label class="wm_label wm_label_error">New Phone Verification Code</label>
                                           </div>
                                        </div>
                                        <span class="error" id="phone_otp_err"> </span>
                                        <div class="verification_innerInfo my-2 error_text">Enter the 6-digit code sent to <span  dir="ltr" id="getCode_phone" class="getCode_outer1"></span>
                                        </div>
                                    </div>
                                    <h5 class="my-2">Security Verification</h5>
                                    
                                     <div class="verification_div">
                                        <div class="verification_main">
                                           <div class="verification_inner inner-css email_otp">
                                              <input type="input" pattern="\d*" maxlength="6"  oninput="this.value=this.value.replace(/[^0-9]/g,'');" aria-label="Email Verification Code" id="email_otp" class="verification_textbox" value="">
                                              <div class="getCode_outer getCode_outer1">
                                                 <div class="getCode_inner email_get_code" style="display:block" onclick="e_start()">Get Code</div>
                                                 <div class="getCode_inner email_code_sent" style="display:none" >
                                                    Verification Code Sent 
                                                    <span class="tooltip txt_info">
                                                    <i class="bi bi-info-circle-fill"></i> 
                                                    <span class="tooltiptext toolTop">
                                                    Haven’t received code? Request new code in  
                                                    <span class="timer-counter" id="email_count">5</span> 
                                                    <span id="text">seconds</span>
                                                    The code will expire after 30 mins.
                                                    </span>
                                                    </span>
                                                 </div>
                                              </div>
                                              <label class="wm_label wm_label_error">E-mail Verification Code</label>
                                              <label class="wm_label wm_label_error">E-mail Verification Code</label>
                                           </div>
                                        </div>
                                        <span class="error" id="email_otp_err"> </span>
                                        <div class="verification_innerInfo my-2 error_text">Enter the 6-digit code sent to <span  dir="ltr" class="getCode_outer1">{{$data}}</span>
                                        </div>
                                    </div>
                                    @csrf
                                    <div class="btn-div">
                                        <button type="button" class="submit_code" id="verify_enable_phone">
                                           <div class="inner_text">Submit</div>
                                        </button>
                                    </div>
                                    </form>
                               </div>
                            </div>
                        </div>
                    </div>
               </div>
            </div>
         </section>
    </main>
    @include('template.copy_right_footer')
    <a href="#" class="chat-support"><span><i class="bi-chat-dots-fill"></i></span><label for="">Support</label></a>
    @include('template.country_language')
    <script src="{{ asset('public/assets/vendor/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
    <script src="{{ asset('public/assets/vendor/swiper/swiper-bundle.min.js') }}"></script>
    <script src="{{ asset('public/assets/js/niceCountryInput.js') }}"></script>
    <script type="text/javascript" src="https://code.jquery.com/jquery-3.5.1.js"></script> 
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/16.0.8/js/intlTelInput-jquery.min.js"></script>
    <script src="{{ asset('public/assets/js/alert.js') }}"></script>
    <script src="{{ asset('public/assets/js/dark-mode-switch.js') }}"></script>
    <script src="{{ asset('public/assets/js/login_register.js') }}"></script>
    <script>
        $('#txtPhone').intlTelInput({
             autoHideDialCode: true,
             autoPlaceholder: "ON",
             dropdownContainer: document.body,
             formatOnDisplay: true,
             hiddenInput: "full_number",
             initialCountry: "auto",
             nationalMode: true,
             placeholderNumberType: "MOBILE",
             geoIpLookup: function(callback) {
                    $.get("https://ipinfo.io", function() {}, "jsonp").always(function(resp) {
                        var countryCode = (resp && resp.country) ? resp.country : "";
                        callback(countryCode);
                    });
                },
             separateDialCode: true
        });
            
        $(".email_get_code").click(function(){
            if (!checkPhone()) {
        	    return true;    
            }
            var phone = $('#mobile').val();
            var _token = $("input[name=_token]").val();
            $.ajax({
                type:'POST',
                url:"{{ url( app()->getLocale(), 'send_otp_enable_secure_mail') }}",
                data:{ 'phone': phone,'_token':_token},
                success:function(data,status){
                    if(status=="success"){
                        $(".email_get_code").css("display", "none");
                        $(".email_code_sent").css("display", "block");
                        triggerAlert('OTP sent on your email address', 'success');
                    }else{
                      triggerAlert(status, 'error');
                    }
                },error: function(xhr, status, error) {
                    var erroJson = JSON.parse(xhr.responseText);
                    $('#phone_err').html(erroJson.error);
                    $('#mobile').addClass('error_border');
                }
            });
        });
        
        
        $(".phone_get_code").click(function(){
            if (!checkPhone()) {
        	    return true;    
            }
            var mobile = $('#mobile').val();
            var _token = $("input[name=_token]").val();
            $.ajax({
                type:'POST',
                url:"{{ url( app()->getLocale(), 'send_otp_enable_secure_phone') }}",
                data:{ 'mobile': mobile,'_token':_token},
                success:function(data,status){
                       if(status=="success"){
                        $("#getCode_phone").html(data.phone_data);
                        $(".phone_get_code").css("display", "none");
                        $(".phone_code_sent").css("display", "block");
                        
                        triggerAlert('OTP sent on your phone number', 'success');
                    }else{
                      triggerAlert(status, 'error');
                    }
                },error: function(xhr, status, error) {
                    var erroJson = JSON.parse(xhr.responseText);
                    $('#phone_err').html(erroJson.error);
                    $('#mobile').addClass('error_border');
                }
            });
        });
        
        function e_start(){
          var counter = 120;
          setInterval(function() {
            counter--;
            if (counter >= 0) {
              span = document.getElementById("email_count");
              span.innerHTML = counter;
            }
            if (counter === 0) {
                clearInterval(counter);
              $(".email_code_sent").css("display", "none");
              $(".email_get_code").css("display", "block");
            }
          }, 1000);
        };
        
        function start(){
          var counter = 120;
          setInterval(function() {
            counter--;
            if (counter >= 0) {
              span = document.getElementById("phone_count");
              span.innerHTML = counter;
            }
            if (counter === 0) {
                clearInterval(counter);
              $(".phone_code_sent").css("display", "none");
              $(".phone_get_code").css("display", "block");
            }
          }, 1000);
        };
         

    	$("#verify_enable_phone").click(function() {
			if (!checkPhone()|| !check_email_otp() || !check_phone_otp()) {
        	    return true;    
            }
            var phone = $('#mobile').val();
            var _token = $("input[name=_token]").val();
            var phone_otp = $("#phone_otp").val();
            var email_otp = $("#email_otp").val();
            $.ajax({
                type:'POST',
                url:"{{ url( app()->getLocale(), 'verify_enable_phone') }}",
                data:{ 'phone': phone,'_token':_token,'phone_otp':phone_otp,'email_otp':email_otp},
                success:function(data,status){
                    if(status=="success"){
                        triggerAlert('Phone number authentication successfully enabled.', 'success');
                        setTimeout(function(){
                            window.location.href = '{{ url( app()->getLocale()) }}/user/dashboard';
                        }, 2000);
                    }else{
                      triggerAlert(status, 'error');
                    }
                },error: function(xhr, status, error) {
                    var erroJson = JSON.parse(xhr.responseText);
                    $('#phone_err').html(erroJson.error);
                    $('#mobile').addClass('error_border');
                }
            });
		});
        	
    	function checkPhone() {
            var phone = $('#mobile').val();
            if (phone == "") {
                $('#phone_err').html('Please enter your phone number');
                $('#mobile').addClass('error_border');
                return false;
            } else {
                $('#phone_err').html('');
                $('#mobile').removeClass('error_border');
                return true;
        	}
        }
        
        function check_phone_otp(){
            var phone_otp = $('#phone_otp').val();
            if (phone_otp == "") {
                $('#phone_otp_err').html('Please enter phone otp');
                $('.phone_otp').addClass('error_border');
                return false;
            }else {
                $('#phone_otp_err').html('');
                $('.phone_otp').removeClass('error_border');
                return true;
            }
        }
        
        function check_email_otp(){
            var email_otp = $('#email_otp').val();
            if (email_otp == "") {
                $('#email_otp_err').html('Please enter email otp');
                $('.email_otp').addClass('error_border');
                return false;
            }else {
                $('#email_otp_err').html('');
                $('.email_otp').removeClass('error_border');
                return true;
            }
        }
    </script>
   </body>
</html>
