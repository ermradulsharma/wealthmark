<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <title>Wealth Mark | {{ Request::segment(2) }}</title>
    @include('template.web_css')
    <link rel='stylesheet' href="{{('../public/assets/css/deepak_custom.css') }}">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>
    @include('template.mobile_menu')
    @include('template.web_menu')

    <!-- first section -->
    <section class="lab d-flex justify-content-center align-content-center" id="lab-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="banner-box">
                        <div class="container dark py-5 py-md-0">
                            <div class="row justify-content-between col-mb-50">
                                <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
                                    <h2 class="fw-bold display-2 mb-0 main-headinig-lab mb-4">Wealth Mark's Empowering
                                        Strategy.</h2>
                                    <span class="gradient-underline h4 mt-5">Lorem ipsum dolor sit amet, consectetur
                                        adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna
                                        aliqua.</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- second section -->
    <section class="about-us-section" id="about-us">
        <div id="lab-section-about" class="lab-section-about clearfix">
            <div class="container clearfix">
                <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                        <div class="sec-title text-left">
                            <span class="title">Know About</span>
                            <h2 class="heading-h2">Wealthmark</h2>
                        </div>
                        <p>Wealth Mark Labs identifies, invests, and empowers viable blockchain entrepreneurs,
                            startups, and communities, providing financing to industry projects that help grow the wider
                            blockchain ecosystem.</p><br />

                        <p>Wealth Mark Labs is committed to supporting fast-executing, technical teams who
                            positively impact the crypto space and build the decentralised web.</p>
                        <div class="row mt-4 counter-row">
                            <div class="col-6 col-sm-3">
                                <div class="counter gradient-text"><span>3+</span></div>
                                <h5 class="font-body">Years</h5>
                            </div>

                            <div class="col-6 col-sm-3">
                                <div class="counter gradient-text"><span>5+</span></div>
                                <h5 class="font-body">Continents</h5>
                            </div>

                            <div class="col-6 col-sm-3">
                                <div class="counter gradient-text"><span>25+</span></div>
                                <h5 class="font-body">Countries</h5>
                            </div>

                            <div class="col-6 col-sm-3">
                                <div class="counter gradient-text"><span>180+</span></div>
                                <h5 class="font-body">Projects</h5>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                        <div class="about-img">
                            <img src="{{ asset('public/assets/img/lab-1.png') }}" alt="About Image" class="img-fluid">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- third section -->
    <section class="blogs-section" id="labs-blogs-section">
        <div class="container">
            <div class="row blogs-heading-row">
                <div class="col-md-8 col-xs-6 col-sm-6 sec-title text-left popular-head-block">
                    <span class="title">Know About</span>
                    <h2 class="heading-h2">Blogs & Press Releases</h2>
                </div>
                <div class="col-md-4 col-xs-6 col-sm-6 sec-title text-right view-all-block popular-head-block">
                    <h2 class="float-right view-all-btn text-right">View all→</h2>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="card labs-blogs-card">
                        <img loading="lazy" src="{{ asset('public/assets/img/latest-insight-img.png') }}"
                            alt="Labs Image" class="img-fluid">
                        <div class="card-body">
                            <h5 class="card-title">Lorem Ipsum</h5>
                            <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="card labs-blogs-card">
                        <img loading="lazy" src="{{ asset('public/assets/img/latest-insight-img.png') }}"
                            alt="Labs Image" class="img-fluid">
                        <div class="card-body">
                            <h5 class="card-title">Lorem Ipsum</h5>
                            <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="card labs-blogs-card">
                        <img loading="lazy" src="{{ asset('public/assets/img/latest-insight-img.png') }}"
                            alt="Labs Image" class="img-fluid">
                        <div class="card-body">
                            <h5 class="card-title">Lorem Ipsum</h5>
                            <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="card labs-blogs-card">
                        <img loading="lazy" src="{{ asset('public/assets/img/latest-insight-img.png') }}"
                            alt="Labs Image" class="img-fluid">
                        <div class="card-body">
                            <h5 class="card-title">Lorem Ipsum</h5>
                            <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="card labs-blogs-card">
                        <img loading="lazy" src="{{ asset('public/assets/img/latest-insight-img.png') }}"
                            alt="Labs Image" class="img-fluid">
                        <div class="card-body">
                            <h5 class="card-title">Lorem Ipsum</h5>
                            <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="card labs-blogs-card">
                        <img loading="lazy" src="{{ asset('public/assets/img/latest-insight-img.png') }}"
                            alt="Labs Image" class="img-fluid">
                        <div class="card-body">
                            <h5 class="card-title">Lorem Ipsum</h5>
                            <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="card labs-blogs-card">
                        <img loading="lazy" src="{{ asset('public/assets/img/latest-insight-img.png') }}"
                            alt="Labs Image" class="img-fluid">
                        <div class="card-body">
                            <h5 class="card-title">Lorem Ipsum</h5>
                            <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="card labs-blogs-card">
                        <img loading="lazy" src="{{ asset('public/assets/img/latest-insight-img.png') }}"
                            alt="Labs Image" class="img-fluid">
                        <div class="card-body">
                            <h5 class="card-title">Lorem Ipsum</h5>
                            <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="card labs-blogs-card">
                        <img loading="lazy" src="{{ asset('public/assets/img/latest-insight-img.png') }}"
                            alt="Labs Image" class="img-fluid">
                        <div class="card-body">
                            <h5 class="card-title">Lorem Ipsum</h5>
                            <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="card labs-blogs-card">
                        <img loading="lazy" src="{{ asset('public/assets/img/latest-insight-img.png') }}"
                            alt="Labs Image" class="img-fluid">
                        <div class="card-body">
                            <h5 class="card-title">Lorem Ipsum</h5>
                            <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="card labs-blogs-card">
                        <img loading="lazy" src="{{ asset('public/assets/img/latest-insight-img.png') }}"
                            alt="Labs Image" class="img-fluid">
                        <div class="card-body">
                            <h5 class="card-title">Lorem Ipsum</h5>
                            <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="card labs-blogs-card">
                        <img loading="lazy" src="{{ asset('public/assets/img/latest-insight-img.png') }}"
                            alt="Labs Image" class="img-fluid">
                        <div class="card-body">
                            <h5 class="card-title">Lorem Ipsum</h5>
                            <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="card labs-blogs-card">
                        <img loading="lazy" src="{{ asset('public/assets/img/latest-insight-img.png') }}"
                            alt="Labs Image" class="img-fluid">
                        <div class="card-body">
                            <h5 class="card-title">Lorem Ipsum</h5>
                            <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="card labs-blogs-card">
                        <img loading="lazy" src="{{ asset('public/assets/img/latest-insight-img.png') }}"
                            alt="Labs Image" class="img-fluid">
                        <div class="card-body">
                            <h5 class="card-title">Lorem Ipsum</h5>
                            <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="card labs-blogs-card">
                        <img loading="lazy" src="{{ asset('public/assets/img/latest-insight-img.png') }}"
                            alt="Labs Image" class="img-fluid">
                        <div class="card-body">
                            <h5 class="card-title">Lorem Ipsum</h5>
                            <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="card labs-blogs-card">
                        <img loading="lazy" src="{{ asset('public/assets/img/latest-insight-img.png') }}"
                            alt="Labs Image" class="img-fluid">
                        <div class="card-body">
                            <h5 class="card-title">Lorem Ipsum</h5>
                            <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="card labs-blogs-card">
                        <img loading="lazy" src="{{ asset('public/assets/img/latest-insight-img.png') }}"
                            alt="Labs Image" class="img-fluid">
                        <div class="card-body">
                            <h5 class="card-title">Lorem Ipsum</h5>
                            <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="card labs-blogs-card">
                        <img loading="lazy" src="{{ asset('public/assets/img/latest-insight-img.png') }}"
                            alt="Labs Image" class="img-fluid">
                        <div class="card-body">
                            <h5 class="card-title">Lorem Ipsum</h5>
                            <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="card labs-blogs-card">
                        <img loading="lazy" src="{{ asset('public/assets/img/latest-insight-img.png') }}"
                            alt="Labs Image" class="img-fluid">
                        <div class="card-body">
                            <h5 class="card-title">Lorem Ipsum</h5>
                            <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="card labs-blogs-card">
                        <img loading="lazy" src="{{ asset('public/assets/img/latest-insight-img.png') }}"
                            alt="Labs Image" class="img-fluid">
                        <div class="card-body">
                            <h5 class="card-title">Lorem Ipsum</h5>
                            <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </section>


    <!-- sixth section -->
    <!-- our collaboration with clients -->

    <section class="team-section" id="our-portfolio">
        <div class="container">
            <div class="row">
                <div class="sec-title text-left mb-5">
                    <span class="title">Know About</span>
                    <h2 class="heading-h2 theme-blue-color">Portfolio</h2>
                </div>
            </div>


            <div class="row collaborations-row portfolio-block">
                <div class="col-md-2 col-sm-6 col-xs-12">
                    <div class="clients-logo">
                        <img loading="lazy" src="{{ asset('public/assets/img/logo-8.png') }}" alt="client-6"
                            class="img-fluid">
                    </div>
                </div>

                <div class="col-md-2 col-sm-6 col-xs-12">
                    <div class="clients-logo">
                        <img loading="lazy" src="{{ asset('public/assets/img/logo-1.png') }}" alt="client-5"
                            class="img-fluid">
                    </div>
                </div>

                <div class="col-md-2 col-sm-6 col-xs-12">
                    <div class="clients-logo">
                        <img loading="lazy" src="{{ asset('public/assets/img/logo-2.png') }}" alt="client-6"
                            class="img-fluid">
                    </div>
                </div>

                <div class="col-md-2 col-sm-6 col-xs-12">
                    <div class="clients-logo">
                        <img loading="lazy" src="{{ asset('public/assets/img/logo-1.png') }}" alt="client-4"
                            class="img-fluid">
                    </div>
                </div>

                <div class="col-md-2 col-sm-6 col-xs-12">
                    <div class="clients-logo">
                        <img loading="lazy" src="{{ asset('public/assets/img/logo-2.png') }}" alt="client-5"
                            class="img-fluid">
                    </div>
                </div>

                <div class="col-md-2 col-sm-6 col-xs-12">
                    <div class="clients-logo">
                        <img loading="lazy" src="{{ asset('public/assets/img/logo-2.png') }}" alt="client-6"
                            class="img-fluid">
                    </div>
                </div>

            </div>

            <div class="row collaborations-row portfolio-block">
                <div class="col-md-2 col-sm-6 col-xs-12">
                    <div class="clients-logo">
                        <img loading="lazy" src="{{ asset('public/assets/img/logo-2.png') }}" alt="client-4"
                            class="img-fluid">
                    </div>
                </div>

                <div class="col-md-2 col-sm-6 col-xs-12">
                    <div class="clients-logo">
                        <img loading="lazy" src="{{ asset('public/assets/img/logo-2.png') }}" alt="client-5"
                            class="img-fluid">
                    </div>
                </div>

                <div class="col-md-2 col-sm-6 col-xs-12">
                    <div class="clients-logo">
                        <img loading="lazy" src="{{ asset('public/assets/img/logo-8.png') }}" alt="client-6"
                            class="img-fluid">
                    </div>
                </div>

                <div class="col-md-2 col-sm-6 col-xs-12">
                    <div class="clients-logo">
                        <img loading="lazy" src="{{ asset('public/assets/img/logo-1.png') }}" alt="client-4"
                            class="img-fluid">
                    </div>
                </div>

                <div class="col-md-2 col-sm-6 col-xs-12">
                    <div class="clients-logo">
                        <img loading="lazy" src="{{ asset('public/assets/img/logo-2.png') }}" alt="client-5"
                            class="img-fluid">
                    </div>
                </div>

                <div class="col-md-2 col-sm-6 col-xs-12">
                    <div class="clients-logo">
                        <img loading="lazy" src="{{ asset('public/assets/img/logo-8.png') }}" alt="client-6"
                            class="img-fluid">
                    </div>
                </div>

            </div>

            <div class="row collaborations-row portfolio-block">
                <div class="col-md-2 col-sm-6 col-xs-12">
                    <div class="clients-logo">
                        <img loading="lazy" src="{{ asset('public/assets/img/logo-8.png') }}" alt="client-4"
                            class="img-fluid">
                    </div>
                </div>

                <div class="col-md-2 col-sm-6 col-xs-12">
                    <div class="clients-logo">
                        <img loading="lazy" src="{{ asset('public/assets/img/logo-2.png') }}" alt="client-5"
                            class="img-fluid">
                    </div>
                </div>

                <div class="col-md-2 col-sm-6 col-xs-12">
                    <div class="clients-logo">
                        <img loading="lazy" src="{{ asset('public/assets/img/logo-8.png') }}" alt="client-6"
                            class="img-fluid">
                    </div>
                </div>

                <div class="col-md-2 col-sm-6 col-xs-12">
                    <div class="clients-logo">
                        <img loading="lazy" src="{{ asset('public/assets/img/logo-1.png') }}" alt="client-4"
                            class="img-fluid">
                    </div>
                </div>

                <div class="col-md-2 col-sm-6 col-xs-12">
                    <div class="clients-logo">
                        <img loading="lazy" src="{{ asset('public/assets/img/logo-2.png') }}" alt="client-5"
                            class="img-fluid">
                    </div>
                </div>

                <div class="col-md-2 col-sm-6 col-xs-12">
                    <div class="clients-logo">
                        <img loading="lazy" src="{{ asset('public/assets/img/logo-8.png') }}" alt="client-6"
                            class="img-fluid">
                    </div>
                </div>

            </div>

            <div class="row collaborations-row portfolio-block">
                <div class="col-md-2 col-sm-6 col-xs-12">
                    <div class="clients-logo">
                        <img loading="lazy" src="{{ asset('public/assets/img/logo-2.png') }}" alt="client-4"
                            class="img-fluid">
                    </div>
                </div>

                <div class="col-md-2 col-sm-6 col-xs-12">
                    <div class="clients-logo">
                        <img loading="lazy" src="{{ asset('public/assets/img/logo-2.png') }}" alt="client-5"
                            class="img-fluid">
                    </div>
                </div>

                <div class="col-md-2 col-sm-6 col-xs-12">
                    <div class="clients-logo">
                        <img loading="lazy" src="{{ asset('public/assets/img/logo-8.png') }}" alt="client-6"
                            class="img-fluid">
                    </div>
                </div>

                <div class="col-md-2 col-sm-6 col-xs-12">
                    <div class="clients-logo">
                        <img loading="lazy" src="{{ asset('public/assets/img/logo-2.png') }}" alt="client-4"
                            class="img-fluid">
                    </div>
                </div>

                <div class="col-md-2 col-sm-6 col-xs-12">
                    <div class="clients-logo">
                        <img loading="lazy" src="{{ asset('public/assets/img/logo-2.png') }}" alt="client-5"
                            class="img-fluid">
                    </div>
                </div>

                <div class="col-md-2 col-sm-6 col-xs-12">
                    <div class="clients-logo">
                        <img loading="lazy" src="{{ asset('public/assets/img/logo-8.png') }}" alt="client-6"
                            class="img-fluid">
                    </div>
                </div>

            </div>

            <div class="row collaborations-row portfolio-block">
                <div class="col-md-2 col-sm-6 col-xs-12">
                    <div class="clients-logo">
                        <img loading="lazy" src="{{ asset('public/assets/img/logo-8.png') }}" alt="client-6"
                            class="img-fluid">
                    </div>
                </div>

                <div class="col-md-2 col-sm-6 col-xs-12">
                    <div class="clients-logo">
                        <img loading="lazy" src="{{ asset('public/assets/img/logo-1.png') }}" alt="client-5"
                            class="img-fluid">
                    </div>
                </div>

                <div class="col-md-2 col-sm-6 col-xs-12">
                    <div class="clients-logo">
                        <img loading="lazy" src="{{ asset('public/assets/img/logo-2.png') }}" alt="client-6"
                            class="img-fluid">
                    </div>
                </div>

                <div class="col-md-2 col-sm-6 col-xs-12">
                    <div class="clients-logo">
                        <img loading="lazy" src="{{ asset('public/assets/img/logo-1.png') }}" alt="client-4"
                            class="img-fluid">
                    </div>
                </div>

                <div class="col-md-2 col-sm-6 col-xs-12">
                    <div class="clients-logo">
                        <img loading="lazy" src="{{ asset('public/assets/img/logo-2.png') }}" alt="client-5"
                            class="img-fluid">
                    </div>
                </div>

                <div class="col-md-2 col-sm-6 col-xs-12">
                    <div class="clients-logo">
                        <img loading="lazy" src="{{ asset('public/assets/img/logo-8.png') }}" alt="client-6"
                            class="img-fluid">
                    </div>
                </div>

            </div>

        </div>
    </section>

    <!-- fifth section -->
    <section class="meet-team-section" id="labs-team-section">
        <div class="container">
            <div class="row">
                <div class="sec-title text-left mb-5">
                    <span class="title">Know About</span>
                    <h2 class="heading-h2">Our Team</h2>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="card">
                        <img loading="lazy" src="{{ asset('public/assets/img/team-1.jpg') }}" alt="Labs Image"
                            class="img-fluid">
                        <div class="card-body">
                            <h5 class="card-title">Alex O. | Investment</h5>
                            <p class="card-text">Tyler is an Investment Manager at Wealth Mark Labs, with a focus on
                                equity
                                & token investments and strategic M&A. Prior to Wealth Mark.</p>
                            <a href="#" class="btn btn-yellow shadow"> Read More</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="card">
                        <img loading="lazy" src="{{ asset('public/assets/img/team-2.jpg') }}" alt="Labs Image"
                            class="img-fluid">
                        <div class="card-body">
                            <h5 class="card-title">Latest Insights & Analysis</h5>
                            <p class="card-text">Tyler is an Investment Manager at Wealth Mark Labs, with a focus on
                                equity
                                & token investments and strategic M&A. Prior to Wealth Mark.</p>
                            <a href="#" class="btn btn-yellow shadow"> Read More</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="card">
                        <img loading="lazy" src="{{ asset('public/assets/img/team-3.jpg') }}" alt="Labs Image"
                            class="img-fluid">
                        <div class="card-body">
                            <h5 class="card-title">Latest Insights & Analysis</h5>
                            <p class="card-text">Tyler is an Investment Manager at Wealth Mark Labs, with a focus on
                                equity
                                & token investments and strategic M&A. Prior to Wealth Mark.</p>
                            <a href="#" class="btn btn-yellow shadow"> Read More</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="card">
                        <img loading="lazy" src="{{ asset('public/assets/img/team-4.jpg') }}" alt="Labs Image"
                            class="img-fluid">
                        <div class="card-body">
                            <h5 class="card-title">Latest Insights & Analysis</h5>
                            <p class="card-text">Tyler is an Investment Manager at Wealth Mark Labs, with a focus on
                                equity
                                & token investments and strategic M&A. Prior to Wealth Mark.</p>
                            <a href="#" class="btn btn-yellow shadow"> Read More</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="card">
                        <img loading="lazy" src="{{ asset('public/assets/img/team-1.jpg') }}" alt="Labs Image"
                            class="img-fluid">
                        <div class="card-body">
                            <h5 class="card-title">Alex O. | Investment</h5>
                            <p class="card-text">Tyler is an Investment Manager at Wealth Mark Labs, with a focus on
                                equity
                                & token investments and strategic M&A. Prior to Wealth Mark.</p>
                            <a href="#" class="btn btn-yellow shadow"> Read More</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="card">
                        <img loading="lazy" src="{{ asset('public/assets/img/team-2.jpg') }}" alt="Labs Image"
                            class="img-fluid">
                        <div class="card-body">
                            <h5 class="card-title">Latest Insights & Analysis</h5>
                            <p class="card-text">Tyler is an Investment Manager at Wealth Mark Labs, with a focus on
                                equity
                                & token investments and strategic M&A. Prior to Wealth Mark.</p>
                            <a href="#" class="btn btn-yellow shadow"> Read More</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="card">
                        <img loading="lazy" src="{{ asset('public/assets/img/team-3.jpg') }}" alt="Labs Image"
                            class="img-fluid">
                        <div class="card-body">
                            <h5 class="card-title">Latest Insights & Analysis</h5>
                            <p class="card-text">Tyler is an Investment Manager at Wealth Mark Labs, with a focus on
                                equity
                                & token investments and strategic M&A. Prior to Wealth Mark.</p>
                            <a href="#" class="btn btn-yellow shadow"> Read More</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="card">
                        <img loading="lazy" src="{{ asset('public/assets/img/team-4.jpg') }}" alt="Labs Image"
                            class="img-fluid">
                        <div class="card-body">
                            <h5 class="card-title">Latest Insights & Analysis</h5>
                            <p class="card-text">Tyler is an Investment Manager at Wealth Mark Labs, with a focus on
                                equity
                                & token investments and strategic M&A. Prior to Wealth Mark.</p>
                            <a href="#" class="btn btn-yellow shadow"> Read More</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="card">
                        <img loading="lazy" src="{{ asset('public/assets/img/team-1.jpg') }}" alt="Labs Image"
                            class="img-fluid">
                        <div class="card-body">
                            <h5 class="card-title">Alex O. | Investment</h5>
                            <p class="card-text">Tyler is an Investment Manager at Wealth Mark Labs, with a focus on
                                equity
                                & token investments and strategic M&A. Prior to Wealth Mark.</p>
                            <a href="#" class="btn btn-yellow shadow"> Read More</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="card">
                        <img loading="lazy" src="{{ asset('public/assets/img/team-2.jpg') }}" alt="Labs Image"
                            class="img-fluid">
                        <div class="card-body">
                            <h5 class="card-title">Latest Insights & Analysis</h5>
                            <p class="card-text">Tyler is an Investment Manager at Wealth Mark Labs, with a focus on
                                equity
                                & token investments and strategic M&A. Prior to Wealth Mark.</p>
                            <a href="#" class="btn btn-yellow shadow"> Read More</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="card">
                        <img loading="lazy" src="{{ asset('public/assets/img/team-3.jpg') }}" alt="Labs Image"
                            class="img-fluid">
                        <div class="card-body">
                            <h5 class="card-title">Latest Insights & Analysis</h5>
                            <p class="card-text">Tyler is an Investment Manager at Wealth Mark Labs, with a focus on
                                equity
                                & token investments and strategic M&A. Prior to Wealth Mark.</p>
                            <a href="#" class="btn btn-yellow shadow"> Read More</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="card">
                        <img loading="lazy" src="{{ asset('public/assets/img/team-4.jpg') }}" alt="Labs Image"
                            class="img-fluid">
                        <div class="card-body">
                            <h5 class="card-title">Latest Insights & Analysis</h5>
                            <p class="card-text">Tyler is an Investment Manager at Wealth Mark Labs, with a focus on
                                equity
                                & token investments and strategic M&A. Prior to Wealth Mark.</p>
                            <a href="#" class="btn btn-yellow shadow"> Read More</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="card">
                        <img loading="lazy" src="{{ asset('public/assets/img/team-1.jpg') }}" alt="Labs Image"
                            class="img-fluid">
                        <div class="card-body">
                            <h5 class="card-title">Alex O. | Investment</h5>
                            <p class="card-text">Tyler is an Investment Manager at Wealth Mark Labs, with a focus on
                                equity
                                & token investments and strategic M&A. Prior to Wealth Mark.</p>
                            <a href="#" class="btn btn-yellow shadow"> Read More</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="card">
                        <img loading="lazy" src="{{ asset('public/assets/img/team-2.jpg') }}" alt="Labs Image"
                            class="img-fluid">
                        <div class="card-body">
                            <h5 class="card-title">Latest Insights & Analysis</h5>
                            <p class="card-text">Tyler is an Investment Manager at Wealth Mark Labs, with a focus on
                                equity
                                & token investments and strategic M&A. Prior to Wealth Mark.</p>
                            <a href="#" class="btn btn-yellow shadow"> Read More</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="card">
                        <img loading="lazy" src="{{ asset('public/assets/img/team-3.jpg') }}" alt="Labs Image"
                            class="img-fluid">
                        <div class="card-body">
                            <h5 class="card-title">Latest Insights & Analysis</h5>
                            <p class="card-text">Tyler is an Investment Manager at Wealth Mark Labs, with a focus on
                                equity
                                & token investments and strategic M&A. Prior to Wealth Mark.</p>
                            <a href="#" class="btn btn-yellow shadow"> Read More</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="card">
                        <img loading="lazy" src="{{ asset('public/assets/img/team-4.jpg') }}" alt="Labs Image"
                            class="img-fluid">
                        <div class="card-body">
                            <h5 class="card-title">Latest Insights & Analysis</h5>
                            <p class="card-text">Tyler is an Investment Manager at Wealth Mark Labs, with a focus on
                                equity
                                & token investments and strategic M&A. Prior to Wealth Mark.</p>
                            <a href="#" class="btn btn-yellow shadow"> Read More</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="card">
                        <img loading="lazy" src="{{ asset('public/assets/img/team-1.jpg') }}" alt="Labs Image"
                            class="img-fluid">
                        <div class="card-body">
                            <h5 class="card-title">Alex O. | Investment</h5>
                            <p class="card-text">Tyler is an Investment Manager at Wealth Mark Labs, with a focus on
                                equity
                                & token investments and strategic M&A. Prior to Wealth Mark.</p>
                            <a href="#" class="btn btn-yellow shadow"> Read More</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="card">
                        <img loading="lazy" src="{{ asset('public/assets/img/team-2.jpg') }}" alt="Labs Image"
                            class="img-fluid">
                        <div class="card-body">
                            <h5 class="card-title">Latest Insights & Analysis</h5>
                            <p class="card-text">Tyler is an Investment Manager at Wealth Mark Labs, with a focus on
                                equity
                                & token investments and strategic M&A. Prior to Wealth Mark.</p>
                            <a href="#" class="btn btn-yellow shadow"> Read More</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="card">
                        <img loading="lazy" src="{{ asset('public/assets/img/team-3.jpg') }}" alt="Labs Image"
                            class="img-fluid">
                        <div class="card-body">
                            <h5 class="card-title">Latest Insights & Analysis</h5>
                            <p class="card-text">Tyler is an Investment Manager at Wealth Mark Labs, with a focus on
                                equity
                                & token investments and strategic M&A. Prior to Wealth Mark.</p>
                            <a href="#" class="btn btn-yellow shadow"> Read More</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="card justify-content-center">
                        <img loading="lazy" src="{{ asset('public/assets/img/team-4.jpg') }}" alt="Labs Image"
                            class="img-fluid">
                        <div class="card-body">
                            <h5 class="card-title">Latest Insights & Analysis</h5>
                            <p class="card-text">Tyler is an Investment Manager at Wealth Mark Labs, with a focus on
                                equity
                                & token investments and strategic M&A. Prior to Wealth Mark.</p>
                            <a href="#" class="btn btn-yellow shadow"> Read More</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section id="apply-now-section" class="apply-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12 d-block justify-content-center align-item-center">
                    <h3>Apply for Wealth Mark Labs</h3>
                    <span class="apply-txt">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod
                        tempor incididunt ut
                        labore et dolore magna aliqua,for inquiries and supplementary materials contact us.</span>
                    <p class="text-center fw-bold">Email us at: wealthmark@gmail.com</p>
                    <a href="#" class="btn btn-yellow shadow mt-3"> Apply Now</a>
                </div>
            </div>
        </div>
    </section>
    @include('template.country_language')
    @include('template.web_footer')
</body>

</html>