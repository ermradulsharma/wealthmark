<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <title>Wealth Mark | {{ Request::segment(2) }}</title>
    @include('template.web_css')
    <link rel='stylesheet' href="{{('../public/assets/css/deepak_custom.css') }}">
    <style>
    :root {
        /* --blue: #6495ed; */
    }

    /* body { background-color: var(--blue); }
h2 { border-bottom: 2px solid var(--blue); } */
    </style>
    
</head>

<body>
    @include('template.mobile_menu')
    @include('template.web_menu')

    <section class="block-chain-crypto" id="academy-block-chain-crypto-section">
        <div class="container">
            <div class="row crypto-block-row">
                <div class="col-md-6 col-lg-6 col-sm-12 col-xs-12 order-2 order-lg-1">
                    <div class="sec-title">
                        <span class="title">Know About</span>
                        <h2 class="heading-h2">Blockchain & Crypto</h2>
                    </div>
                    <div class="crypto-inner-box">
                        <p>We're Wealth Mark Charity, the first-ever blockchain-enabled transparent donation platform.
                        </p>

                        <p>As a 501(c)(3) non-profit, we unlock the power of blockchain and make technology work for
                            people. With our network of trusted partners and the crypto community, we're using
                            blockchain to support the UN's Sustainable Development Goals by working to eradicate
                            poverty, fight inequality and ensure the health of people and our planet.</p>
                    </div>
                    <div class="btn-group">
                        <a href="#" class="btn btn-yellow shadow mt-3">Start here</a>
                    </div>
                </div>
                <div class="col-md-6 col-sm-12 col-xs-12 order-1 order-lg-2">
                    <div class="right-side-feature-box">
                        <div class="crypto-inner-box academy-top-right-box">
                            <!-- <h4 class="crypto-title">FEATURED</h4> -->
                            <img loading="lazy" class="img-fluid mb-3"
                                src="{{ asset('public/assets/img/wm-home.png') }}" alt="Academy image"><br />
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="Latest-Releases" id="academy-Latest-Releases-section">
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-xs-6 col-sm-6 sec-title text-left">
                    <div class="sec-title">
                        <span class="title">Know About</span>
                        <h2 class="heading-h2">Latest Releases</h2>
                    </div>


                </div>
                <div class="col-md-4 col-xs-6 col-sm-6 sec-title text-right view-all-block">
                    <h2 class="float-right view-all-btn text-right">See All Latest Releases →</h2>
                </div>
            </div>

            <div class="row mt-3">
                <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                    <div class="card">
                        <img loading="lazy" src="{{ asset('public/assets/img/latest-release-1.png') }}"
                            class="img-fluid">
                        <h5 class="heading-latest-release">What is Wealth Mark BENQI (QI)?</h5>
                        <div class="featured-detaild-block mt-1">
                            <span class="badge bg-warning text-darkg">Beginner </span>
                            <span class="cryto-date-block">Nov 16, 2020</span>
                            <span class="cryto-distance-block"> 6m</span>

                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                    <div class="card">
                        <img loading="lazy" src="{{ asset('public/assets/img/latest-release-2.png') }}"
                            class="img-fluid">
                        <h5 class="heading-latest-release">What is Wealth Mark BENQI (QI)?</h5>
                        <div class="featured-detaild-block mt-1">
                            <span class="badge bg-warning text-darkg">Beginner </span>
                            <span class="cryto-date-block">Nov 16, 2020</span>
                            <span class="cryto-distance-block"> 6m</span>

                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                    <div class="card">
                        <img loading="lazy" src="{{ asset('public/assets/img/latest-release-3.png') }}"
                            class="img-fluid">
                        <h5 class="heading-latest-release">What is Wealth Mark BENQI (QI)?</h5>
                        <div class="featured-detaild-block mt-1">
                            <span class="badge bg-warning text-darkg">Beginner </span>
                            <span class="cryto-date-block">Nov 16, 2020</span>
                            <span class="cryto-distance-block"> 6m</span>

                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                    <div class="card">
                        <img loading="lazy" src="{{ asset('public/assets/img/latest-release-4.png') }}"
                            class="img-fluid">
                        <h5 class="heading-latest-release">What is Wealth Mark BENQI (QI)?</h5>
                        <div class="featured-detaild-block mt-1">
                            <span class="badge bg-warning text-darkg">Beginner </span>
                            <span class="cryto-date-block">Nov 16, 2020</span>
                            <span class="cryto-distance-block"> 6m</span>

                        </div>
                    </div>
                </div>
            </div>
            <div class="row mt-3">
                <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                    <div class="card">
                        <img loading="lazy" src="{{ asset('public/assets/img/latest-release-3.png') }}"
                            class="img-fluid">
                        <h5 class="heading-latest-release">What is Wealth Mark BENQI (QI)?</h5>
                        <div class="featured-detaild-block mt-1">
                            <span class="badge bg-warning text-darkg">Beginner </span>
                            <span class="cryto-date-block">Nov 16, 2020</span>
                            <span class="cryto-distance-block"> 6m</span>

                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                    <div class="card">
                        <img loading="lazy" src="{{ asset('public/assets/img/latest-release-4.png') }}"
                            class="img-fluid">
                        <h5 class="heading-latest-release">What is Wealth Mark BENQI (QI)?</h5>
                        <div class="featured-detaild-block mt-1">
                            <span class="badge bg-warning text-darkg">Beginner </span>
                            <span class="cryto-date-block">Nov 16, 2020</span>
                            <span class="cryto-distance-block"> 6m</span>

                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                    <div class="card">
                        <img loading="lazy" src="{{ asset('public/assets/img/latest-release-1.png') }}"
                            class="img-fluid">
                        <h5 class="heading-latest-release">What is Wealth Mark BENQI (QI)?</h5>
                        <div class="featured-detaild-block mt-1">
                            <span class="badge bg-warning text-darkg">Beginner </span>
                            <span class="cryto-date-block">Nov 16, 2020</span>
                            <span class="cryto-distance-block"> 6m</span>

                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                    <div class="card release-content-block release-content-block-last">
                        <div class="sharing-block">
                            <h2 class="heading-h2">Sharding</h2>
                            <p>Sharding is a method of splitting blockchains into
                                smaller, partitioned bloc... </p>
                            <a class="sharding-btn">Full Defination 
                                &#10141; </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="learn-blockchain" id="academy-learn-blockchain-section">
        <div class="container">
            <div class="row mvb-program-inner-block">
                <div class="col-12 col-md-6 col-lg-5 col-sm-12 col-xs-12 order-2 order-lg-1">
                    <div class="sec-title text-left">
                        <span class="title">Know About</span>
                        <h2 class="heading-h2">Earn Crypto by learning</h2>
                    </div>
                    <p>Build your blockchain knowledge, complete quizzes, and earn free crypto, Complete quiz now and
                        get lots of things, Hurry Up!!.</p>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
                        labore et dolore magna aliqua.Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                        eiusmod tempor incididunt ut labore et dolore magna aliqua.Lorem ipsum dolor sit amet,
                        consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                    </p>
                    <div class="read-more-block mt-4">
                        <a href="#" class="btn btn-yellow shadow mt-3">Get Started</a>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-7 col-sm-12 col-xs-12 order-1 order-lg-2 img-hover3">
                    <figure> <svg viewBox="0 0 548 308" fill="none" 
                            class="css-122y91a e3ftz9k0">
                            <g clip-path="url(#clip0_5080_132575)">
                                <path opacity="0.2" d="M190.187 208.965H337.89V281.79H190.187V208.965Z"
                                    fill="url(#paint0_linear_5080_132575)"></path>
                                <path opacity="0.2" d="M171 93.4902H373.508V148.609H171V93.4902Z"
                                    fill="url(#paint1_linear_5080_132575)"></path>
                                <path opacity="0.2" d="M176.197 48.7578H390.335V82.0091H176.197V48.7578Z"
                                    fill="url(#paint2_linear_5080_132575)"></path>
                                <path
                                    d="M354.145 165.019L349.314 169.846L344.484 165.019L349.314 160.193L354.145 165.019Z"
                                    fill="#328DFD"></path>
                                <path
                                    d="M248.948 208.798L252.022 205.727L255.095 208.798L252.022 211.869L248.948 208.798Z"
                                    fill="white"></path>
                                <path d="M484.042 188.083L489.97 182.16L495.898 188.083L489.97 194.007L484.042 188.083Z"
                                    fill="#F0B90B"></path>
                                <path
                                    d="M307.18 126.974L313.108 121.051L319.036 126.974L313.108 132.897L307.18 126.974Z"
                                    fill="white"></path>
                                <path d="M341.687 28.7751L350.469 20L359.251 28.7751L350.469 37.5502L341.687 28.7751Z"
                                    fill="#F0B90B"></path>
                                <path
                                    d="M465.603 199.712L468.677 196.641L471.751 199.712L468.677 202.783L465.603 199.712Z"
                                    fill="#FF7E0D"></path>
                                <path
                                    d="M210.574 148.253L213.648 145.182L216.722 148.253L213.648 151.324L210.574 148.253Z"
                                    fill="#FF7E0D"></path>
                                <path
                                    d="M440.82 69.0836L444.772 65.1348L448.724 69.0836L444.772 73.0323L440.82 69.0836Z"
                                    fill="#FF7E0D"></path>
                                <path fill-rule="evenodd" clip-rule="evenodd"
                                    d="M354.384 93.2808L341.598 93.283C341.447 93.283 341.301 93.2228 341.194 93.1155L319.723 71.6622L306.951 84.4233L328.422 105.877C331.917 109.369 336.658 111.331 341.602 111.33L354.387 111.328L354.384 93.2808Z"
                                    fill="#FFBEA6"></path>
                                <g style="mix-blend-mode:soft-light" opacity="0.6">
                                    <path fill-rule="evenodd" clip-rule="evenodd"
                                        d="M354.384 93.2808L341.361 93.2831L319.723 71.6622L306.951 84.4233L328.59 106.044C331.978 109.429 336.573 111.331 341.364 111.33L354.387 111.328L354.384 93.2808Z"
                                        fill="url(#paint3_linear_5080_132575)"></path>
                                </g>
                                <path
                                    d="M296.915 60.7188L309.687 73.4799L322.458 60.7187L309.687 47.9576L296.915 60.7188Z"
                                    fill="#FFBEA6"></path>
                                <path d="M384.079 228.695L383.125 182.882" stroke="#FFBEA6" stroke-width="16.8091">
                                </path>
                                <path d="M383.99 143.018L383.99 162.209L383.988 193.286" stroke="#328DFD"
                                    stroke-width="24.1987"></path>
                                <path d="M418.751 155.427L400.882 155.366L371.946 155.266" stroke="#328DFD"
                                    stroke-width="24.1987"></path>
                                <path
                                    d="M434.99 223.604L434.683 186.817C434.676 185.981 434.341 185.182 433.75 184.591L412.702 163.561"
                                    stroke="#FFBEA6" stroke-width="16.8091"></path>
                                <path
                                    d="M408.091 143.019L408.091 158.329C408.091 160.819 409.059 163.211 410.789 165.001L429.159 184.003"
                                    stroke="#328DFD" stroke-width="24.1987"></path>
                                <g style="mix-blend-mode:soft-light">
                                    <path fill-rule="evenodd" clip-rule="evenodd"
                                        d="M420.048 143.027V157.333L437.719 175.612L420.314 192.411L401.943 173.408C400.24 171.646 398.865 169.627 397.854 167.445L371.904 167.356L371.988 143.177L395.849 143.259V143.027H420.048Z"
                                        fill="#14151A"></path>
                                </g>
                                <path fill-rule="evenodd" clip-rule="evenodd"
                                    d="M437.044 110.833L484.965 110.833L484.965 92.786L437.044 92.786L437.044 110.833Z"
                                    fill="#FFBEA6"></path>
                                <g style="mix-blend-mode:soft-light" opacity="0.6">
                                    <path fill-rule="evenodd" clip-rule="evenodd"
                                        d="M437.044 110.833L484.965 110.833L484.965 92.786L437.044 92.786L437.044 110.833Z"
                                        fill="url(#paint4_linear_5080_132575)"></path>
                                </g>
                                <path
                                    d="M503.456 115.484L516.228 102.723L503.456 89.962L490.685 102.723L503.456 115.484Z"
                                    fill="#FFBEA6"></path>
                                <path fill-rule="evenodd" clip-rule="evenodd"
                                    d="M369.779 92.3291L342.411 92.3291L342.411 112.954H369.779L369.779 92.3291Z"
                                    fill="#02C076"></path>
                                <g style="mix-blend-mode:soft-light" opacity="0.6">
                                    <path fill-rule="evenodd" clip-rule="evenodd"
                                        d="M369.779 92.3291L342.411 92.3291L342.411 112.954H369.779L369.779 92.3291Z"
                                        fill="url(#paint5_linear_5080_132575)"></path>
                                </g>
                                <path fill-rule="evenodd" clip-rule="evenodd"
                                    d="M420.975 112.847L444.931 112.847L444.931 92.222L420.975 92.2219L420.975 112.847Z"
                                    fill="#02C076"></path>
                                <g style="mix-blend-mode:soft-light" opacity="0.6">
                                    <path fill-rule="evenodd" clip-rule="evenodd"
                                        d="M420.975 112.847L444.931 112.847L444.931 92.222L420.975 92.2219L420.975 112.847Z"
                                        fill="url(#paint6_linear_5080_132575)"></path>
                                </g>
                                <path fill-rule="evenodd" clip-rule="evenodd"
                                    d="M403.169 92.2637L393.145 102.259L383.121 92.2637L368.309 92.2637L368.309 150.6L425.074 150.809L425.074 92.2637L403.169 92.2637Z"
                                    fill="#02C076"></path>
                                <path
                                    d="M402.982 79.7675C411.003 75.1404 413.751 64.8925 409.12 56.8781C404.49 48.8638 394.233 46.1179 386.213 50.745C378.192 55.372 375.443 65.62 380.074 73.6343C384.705 81.6487 394.961 84.3946 402.982 79.7675Z"
                                    fill="#FFBEA6"></path>
                                <path
                                    d="M380.074 73.6343C375.443 65.62 378.195 55.3702 386.213 50.745C394.23 46.1197 404.49 48.8638 409.12 56.8781L380.074 73.6343Z"
                                    fill="#935A30"></path>
                                <path d="M276.696 256.615H383.06L358.5 232.123H252.136L281.783 244.369L276.696 256.615Z"
                                    fill="#328DFD"></path>
                                <path
                                    d="M288.237 208.92H449.502L499.171 258.549V262.416L449.502 212.787H288.237V208.92Z"
                                    fill="#FF7E0D"></path>
                                <path d="M288.237 232.123H449.502L499.171 281.752H337.906L288.237 232.123Z"
                                    fill="#FF7E0D"></path>
                                <path
                                    d="M499.171 281.753L449.502 232.123H299.203H288.882C294.226 232.123 298.558 227.795 298.558 222.455C298.558 217.116 294.226 212.787 288.882 212.787H299.203H449.502L499.171 262.416V281.753Z"
                                    fill="white"></path>
                                <path d="M449.5 232.123L499.17 281.753V262.416L449.5 212.787V232.123Z" fill="#E6E8EA">
                                </path>
                                <g style="mix-blend-mode:soft-light" opacity="0.6">
                                    <path d="M288.237 232.123H449.502L499.171 281.752H337.906L288.237 232.123Z"
                                        fill="url(#paint7_linear_5080_132575)"></path>
                                </g>
                                <path d="M495.298 258.551H499.168V281.754L495.298 277.887V258.551Z" fill="#FF7E0D">
                                </path>
                                <g opacity="0.6">
                                    <path
                                        d="M67.8001 193.033C67.8001 193.033 74.7149 194.189 77.136 201.106C79.5571 208.023 71.9821 223.944 52.8505 229.456C42.4649 232.449 36.9075 228.895 33.7732 223.987L67.8001 193.033Z"
                                        fill="#D0980B"></path>
                                    <path
                                        d="M70.6409 193.97C77.5494 197.88 75.5972 208.448 66.2805 217.576C56.9638 226.704 43.8107 230.934 36.9021 227.025C29.9935 223.115 31.9458 212.547 41.2624 203.42C50.5789 194.292 63.7324 190.061 70.6409 193.97Z"
                                        fill="url(#paint8_linear_5080_132575)"></path>
                                    <path
                                        d="M65.9756 196.653C60.7462 193.682 50.9427 197.221 44.0787 204.559C37.2147 211.897 35.8902 220.255 41.1196 223.227C46.349 226.198 56.1525 222.658 63.0162 215.32C69.8799 207.982 71.2047 199.625 65.9756 196.653ZM62.7006 215.048C55.9561 222.257 46.3524 225.752 41.2503 222.855C36.1482 219.957 37.4793 211.764 44.2237 204.555C50.9682 197.346 60.5719 193.851 65.674 196.749C70.7761 199.646 69.445 207.839 62.7006 215.048Z"
                                        fill="#D0980B"></path>
                                    <g style="mix-blend-mode:overlay" opacity="0.3">
                                        <path
                                            d="M60.3202 197.014L34.3451 223.779C34.9095 225.187 35.9104 226.353 37.3661 227.176C37.6578 227.341 37.9625 227.489 38.279 227.621L63.6248 197.13C62.5919 196.969 61.4829 196.932 60.3202 197.014Z"
                                            fill="url(#paint9_linear_5080_132575)"></path>
                                    </g>
                                    <g style="mix-blend-mode:overlay" opacity="0.4">
                                        <path
                                            d="M63.1693 220.239L73.6102 206.796C74.1804 205.113 74.4414 203.503 74.3809 202.033L55.712 224.764C58.2459 223.61 60.7839 222.085 63.1693 220.239Z"
                                            fill="url(#paint10_linear_5080_132575)"></path>
                                    </g>
                                </g>
                                <path
                                    d="M206.98 73.5696C206.98 73.5696 208.556 82.3479 218.663 87.6711C228.77 92.9943 252.265 89.3155 260.686 68.0371C265.257 56.4861 260.139 48.5242 252.993 43.0309L206.98 73.5696Z"
                                    fill="#D0980B"></path>
                                <path
                                    d="M208.301 77.3344C213.917 87.0562 229.459 88.3416 243.015 80.2053C256.571 72.0691 263.007 57.5923 257.391 47.8703C251.775 38.1483 236.234 36.8631 222.678 44.9993C209.123 53.1354 202.686 67.6126 208.301 77.3344Z"
                                    fill="url(#paint11_linear_5080_132575)"></path>
                                <path
                                    d="M212.319 72.608C208.05 65.2447 213.415 54.588 224.302 48.8056C235.189 43.0231 247.476 44.3054 251.745 51.6686C256.014 59.0319 250.65 69.6886 239.762 75.4708C228.875 81.2529 216.589 79.9711 212.319 72.608ZM239.368 74.9941C250.064 69.3118 255.36 58.882 251.197 51.6985C247.034 44.515 234.989 43.2977 224.293 48.9799C213.598 54.6622 208.302 65.0921 212.464 72.2755C216.627 79.459 228.672 80.6764 239.368 74.9941Z"
                                    fill="#D0980B"></path>
                                <g style="mix-blend-mode:overlay" opacity="0.3">
                                    <path
                                        d="M212.948 65.8813L252.674 43.6525C254.73 44.8228 256.423 46.4383 257.605 48.4867C257.842 48.897 258.054 49.3174 258.242 49.7464L213.061 69.9256C212.842 68.6184 212.808 67.262 212.948 65.8813Z"
                                        fill="url(#paint12_linear_5080_132575)"></path>
                                </g>
                                <g style="mix-blend-mode:overlay" opacity="0.4">
                                    <path
                                        d="M246.981 77.3563L227.075 85.3642C224.594 85.4734 222.229 85.2339 220.073 84.6527L253.751 69.8833C252.014 72.5551 249.732 75.1035 246.981 77.3563Z"
                                        fill="url(#paint13_linear_5080_132575)"></path>
                                </g>
                                <g filter="url(#filter0_d_5080_132575)">
                                    <path
                                        d="M132.005 185.169C102.035 185.169 77.7392 160.893 77.7392 130.947C77.7392 101.002 102.035 76.7259 132.005 76.7259C161.975 76.7259 186.27 101.002 186.27 130.947L186.27 185.169L132.005 185.169Z"
                                        fill="url(#paint14_linear_5080_132575)"></path>
                                </g>
                                <path
                                    d="M117.812 152.994C114.474 149.659 114.474 144.251 117.812 140.916V140.916C121.15 137.581 126.562 137.581 129.9 140.916L135.944 146.955L129.9 152.994C126.562 156.329 121.15 156.329 117.812 152.994V152.994Z"
                                    stroke="white" stroke-width="2.80335"></path>
                                <path
                                    d="M154.075 116.762C150.737 113.426 145.325 113.426 141.987 116.762V116.762C138.649 120.097 138.649 125.504 141.987 128.84L148.031 134.878L154.075 128.84C157.413 125.504 157.413 120.097 154.075 116.762V116.762Z"
                                    stroke="white" stroke-width="2.80335"></path>
                                <path
                                    d="M135.946 146.959L148.034 134.881L178.394 165.216L166.306 177.294L135.946 146.959Z"
                                    stroke="white" stroke-width="2.80335"></path>
                                <rect width="46.4943" height="30.2015"
                                    transform="matrix(0.707393 -0.70682 0.707393 0.70682 153.37 185.154)"
                                    fill="url(#paint15_linear_5080_132575)"></rect>
                                <path d="M179.233 202.01L203.127 178.135L210.998 186L187.104 209.874L179.233 202.01Z"
                                    fill="#474D57"></path>
                                <path d="M186.824 161.844L162.93 185.719" stroke="#474D57" stroke-width="2.80335">
                                </path>
                                <path d="M192.444 167.461L168.55 191.336" stroke="#474D57" stroke-width="2.80335">
                                </path>
                                <path d="M198.068 173.078L174.174 196.953" stroke="#474D57" stroke-width="2.80335">
                                </path>
                                <path
                                    d="M164.529 248.159L159.189 235.951L178.102 254.807L204.801 253.778L192.602 259.12L189.394 267.313L169.863 275.864L161.326 256.342L164.529 248.159Z"
                                    fill="#76808F"></path>
                                <path
                                    d="M180.893 249.711L172.354 230.189L159.195 235.951L173.071 267.675L204.806 253.777L190.931 222.054L176.957 228.173L185.496 247.695L180.893 249.711Z"
                                    fill="url(#paint16_linear_5080_132575)"></path>
                                <path
                                    d="M154.591 244.268L147.267 247.475L150.469 254.796L157.793 251.589L154.591 244.268Z"
                                    fill="#76808F"></path>
                            </g>
                            <defs>
                                <filter id="filter0_d_5080_132575" x="-6.25465" y="-7.26735" width="276.519"
                                    height="276.429" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                                    <feFlood flood-opacity="0" result="BackgroundImageFix"></feFlood>
                                    <feColorMatrix in="SourceAlpha" type="matrix"
                                        values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha">
                                    </feColorMatrix>
                                    <feOffset></feOffset>
                                    <feGaussianBlur stdDeviation="41.997"></feGaussianBlur>
                                    <feComposite in2="hardAlpha" operator="out"></feComposite>
                                    <feColorMatrix type="matrix" values="0 0 0 0 1 0 0 0 0 1 0 0 0 0 1 0 0 0 0.7 0">
                                    </feColorMatrix>
                                    <feBlend mode="normal" in2="BackgroundImageFix"
                                        result="effect1_dropShadow_5080_132575"></feBlend>
                                    <feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow_5080_132575"
                                        result="shape"></feBlend>
                                </filter>
                                <linearGradient id="paint0_linear_5080_132575" x1="190.187" y1="281.79" x2="337.89"
                                    y2="281.79" gradientUnits="userSpaceOnUse">
                                    <stop stop-color="#F8D33A" stop-opacity="0"></stop>
                                    <stop offset="1" stop-color="#F8D33A"></stop>
                                </linearGradient>
                                <linearGradient id="paint1_linear_5080_132575" x1="171" y1="148.609" x2="421.233"
                                    y2="148.609" gradientUnits="userSpaceOnUse">
                                    <stop stop-color="#F8D33A" stop-opacity="0"></stop>
                                    <stop offset="1" stop-color="#F8D33A"></stop>
                                </linearGradient>
                                <linearGradient id="paint2_linear_5080_132575" x1="176.197" y1="82.0091" x2="390.335"
                                    y2="82.0091" gradientUnits="userSpaceOnUse">
                                    <stop stop-color="#F8D33A" stop-opacity="0"></stop>
                                    <stop offset="1" stop-color="#935A30"></stop>
                                </linearGradient>
                                <linearGradient id="paint3_linear_5080_132575" x1="366.164" y1="96.3081" x2="323.796"
                                    y2="96.3081" gradientUnits="userSpaceOnUse">
                                    <stop></stop>
                                    <stop offset="1" stop-opacity="0"></stop>
                                </linearGradient>
                                <linearGradient id="paint4_linear_5080_132575" x1="416.984" y1="108.646" x2="484.821"
                                    y2="108.646" gradientUnits="userSpaceOnUse">
                                    <stop></stop>
                                    <stop offset="1" stop-opacity="0"></stop>
                                </linearGradient>
                                <linearGradient id="paint5_linear_5080_132575" x1="372.662" y1="95.8053" x2="342.536"
                                    y2="95.8053" gradientUnits="userSpaceOnUse">
                                    <stop></stop>
                                    <stop offset="1" stop-opacity="0"></stop>
                                </linearGradient>
                                <linearGradient id="paint6_linear_5080_132575" x1="436.428" y1="99.0625" x2="421.994"
                                    y2="113.508" gradientUnits="userSpaceOnUse">
                                    <stop stop-opacity="0"></stop>
                                    <stop offset="1"></stop>
                                </linearGradient>
                                <linearGradient id="paint7_linear_5080_132575" x1="380.803" y1="232.123" x2="380.803"
                                    y2="281.752" gradientUnits="userSpaceOnUse">
                                    <stop stop-opacity="0"></stop>
                                    <stop offset="1"></stop>
                                </linearGradient>
                                <linearGradient id="paint8_linear_5080_132575" x1="42.78" y1="226.913" x2="54.0373"
                                    y2="188.81" gradientUnits="userSpaceOnUse">
                                    <stop stop-color="#F0B90B"></stop>
                                    <stop offset="1" stop-color="#F7DB83"></stop>
                                </linearGradient>
                                <linearGradient id="paint9_linear_5080_132575" x1="32.4681" y1="219.255" x2="66.8816"
                                    y2="204.982" gradientUnits="userSpaceOnUse">
                                    <stop offset="0.0195" stop-color="white"></stop>
                                    <stop offset="1" stop-color="white" stop-opacity="0"></stop>
                                </linearGradient>
                                <linearGradient id="paint10_linear_5080_132575" x1="72.2338" y1="201.625" x2="67.4054"
                                    y2="226.99" gradientUnits="userSpaceOnUse">
                                    <stop stop-color="white" stop-opacity="0.8"></stop>
                                    <stop offset="1" stop-color="white" stop-opacity="0"></stop>
                                </linearGradient>
                                <linearGradient id="paint11_linear_5080_132575" x1="257.125" y1="54.9541" x2="205.996"
                                    y2="71.1474" gradientUnits="userSpaceOnUse">
                                    <stop stop-color="#F0B90B"></stop>
                                    <stop offset="1" stop-color="#F7DB83"></stop>
                                </linearGradient>
                                <linearGradient id="paint12_linear_5080_132575" x1="246.067" y1="39.8151" x2="224.665"
                                    y2="76.6656" gradientUnits="userSpaceOnUse">
                                    <stop offset="0.0195" stop-color="white"></stop>
                                    <stop offset="1" stop-color="white" stop-opacity="0"></stop>
                                </linearGradient>
                                <linearGradient id="paint13_linear_5080_132575" x1="219.51" y1="81.9098" x2="254.736"
                                    y2="74.6884" gradientUnits="userSpaceOnUse">
                                    <stop stop-color="white" stop-opacity="0.8"></stop>
                                    <stop offset="1" stop-color="white" stop-opacity="0"></stop>
                                </linearGradient>
                                <linearGradient id="paint14_linear_5080_132575" x1="101.58" y1="177.228" x2="178.261"
                                    y2="100.485" gradientUnits="userSpaceOnUse">
                                    <stop stop-color="#F0B90B"></stop>
                                    <stop offset="1" stop-color="#F8D33A"></stop>
                                </linearGradient>
                                <linearGradient id="paint15_linear_5080_132575" x1="46.4943" y1="30.2015" x2="0"
                                    y2="30.2015" gradientUnits="userSpaceOnUse">
                                    <stop stop-color="#1E2026"></stop>
                                    <stop offset="1"></stop>
                                </linearGradient>
                                <linearGradient id="paint16_linear_5080_132575" x1="173.071" y1="267.675" x2="190.905"
                                    y2="222.044" gradientUnits="userSpaceOnUse">
                                    <stop stop-color="#F0B90B"></stop>
                                    <stop offset="1" stop-color="#F8D33A"></stop>
                                </linearGradient>
                                <clipPath id="clip0_5080_132575">
                                    <rect width="548" height="308" fill="white"></rect>
                                </clipPath>
                            </defs>
                        </svg>
                    </figure>

                </div>
            </div>

        </div>
    </section>


    <section class="eye-on-bitcoin" id="academy-eye-on-bitcoin-section">
        <div class="container">
            <div class="row bitcoin-inner">
                <div class="col-md-6 col-xs-6 col-sm-6">
                    <img loading="lazy" class="hero-image  img-fluid"
                        src="{{ asset('public/assets/img/eye-on-bitcoin.png') }}" alt="Trust Wallet app">
                </div>
                <div class="col-md-6 col-xs-6 col-sm-6">
                    <h2>Keep an eye on Bitcoin </h2>
                    <p>Every four years, the Bitcoin rewards are slashed in half. Find
                        out why on the Halving page.Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                        eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                    <a href="#" class="btn btn-yellow shadow mt-3">Bitcoin halving page</a>
                </div>

            </div>
        </div>
    </section>

    <section class="trading-block" id="academy-trading-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-xs-6 col-sm-6 sec-title text-left width-50">
                    <div class="sec-title text-left">
                        <span class="title">Know About</span>
                        <h2 class="heading-h2">Trading</h2>
                    </div>


                </div>
                <div class="col-lg-6 col-md-6 col-xs-6 col-sm-6 sec-title text-right view-all-block width-50">
                    <h2 class="float-right view-all-btn text-right">See All Trading Content →</h2>
                </div>
            </div>

            <div class="row mt-3">
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <div class="card">
                        <img loading="lazy" src="{{ asset('public/assets/img/trading-img-1.png') }}" class="img-fluid">
                        <h5 class="heading-latest-release">Crypto Fear & Index Green</h5>
                        <div class="featured-detaild-block mt-1">
                            <span class="badge bg-warning text-darkg">Beginner </span>
                            <span class="cryto-date-block">Nov 16, 2020</span>
                            <span class="cryto-distance-block"> 6m</span>

                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <div class="card">
                        <img loading="lazy" src="{{ asset('public/assets/img/trading-img-2.png') }}" class="img-fluid">
                        <h5 class="heading-latest-release">Now, Keep an eye on Bitcoin</h5>
                        <div class="featured-detaild-block mt-1">
                            <span class="badge bg-warning text-darkg">Beginner </span>
                            <span class="cryto-date-block">Nov 16, 2020</span>
                            <span class="cryto-distance-block"> 6m</span>

                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <div class="card">
                        <img loading="lazy" src="{{ asset('public/assets/img/latest-release-1.png') }}"
                            class="img-fluid">
                        <h5 class="heading-latest-release">Calculate Investment for Future</h5>
                        <div class="featured-detaild-block mt-1">
                            <span class="badge bg-warning text-darkg">Beginner </span>
                            <span class="cryto-date-block">Nov 16, 2020</span>
                            <span class="cryto-distance-block"> 6m</span>

                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <div class="card">
                        <img loading="lazy" src="{{ asset('public/assets/img/latest-release-2.png') }}"
                            class="img-fluid">
                        <h5 class="heading-latest-release">Limit Orders, Calculate Investment </h5>
                        <div class="featured-detaild-block mt-1">
                            <span class="badge bg-warning text-darkg">Beginner </span>
                            <span class="cryto-date-block">Nov 16, 2020</span>
                            <span class="cryto-distance-block"> 6m</span>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="academuy-multi-tabs" id="academuy-multi-tabs-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <h4>Topics </h4>
                    <div class="academy-multiselect-tabs">
                        <ul class="ks-cboxtags">
                            <li class="academy-first-tab"><input type="checkbox" id="checkboxOne" value="Rainbow Dash"
                                    checked><label for="checkboxOne">Wealth Mark Coin</label></li>
                            <li class="academy-second-tab"><input type="checkbox" id="checkboxTwo"
                                    value="Cotton Candy"><label for="checkboxTwo">Bitcoin</label></li>
                            <li class="academy-third-tab"><input type="checkbox" id="checkboxThree"
                                    value="Rarity"><label for="checkboxThree">Blockchain</label></li>
                            <li class="academy-fourth-tab"><input type="checkbox" id="checkboxFour"
                                    value="Moondancer"><label for="checkboxFour">Economics</label></li>
                            <li class="academy-fifth-tab"><input type="checkbox" id="checkboxFive"
                                    value="Surprise"><label for="checkboxFive">Essentials</label></li>
                            <li class="academy-sixth-tab"><input type="checkbox" id="checkboxSix"
                                    value="Twilight Sparkle"><label for="checkboxSix">NFT</label></li>
                            <li class="academy-seventh-tab"><input type="checkbox" id="checkboxSeven"
                                    value="Fluttershy"><label for="checkboxSeven">Security</label></li>
                            <li class="academy-eighth-tab"><input type="checkbox" id="checkboxEight"
                                    value="Derpy Hooves"><label for="checkboxEight">Tech</label></li>
                            <li class="academy-ninth-tab"><input type="checkbox" id="checkboxNine"
                                    value="Princess Celestia"><label for="checkboxNine">Technical Analysis</label></li>
                            <li class="academy-tenth-tab"><input type="checkbox" id="checkboxTen" value="Gusty"><label
                                    for="checkboxTen">Gusty</label></li>
                            <li class="ks-selected"><input type="checkbox" id="checkboxEleven" value="Discord"><label
                                    for="checkboxEleven">Trading</label></li>
                            <li><input type="checkbox" id="checkboxTwelve" value="Clover"><label
                                    for="checkboxTwelve">Tutorials</label></li>
                            <li><input type="checkbox" id="checkboxThirteen" value="Baby Moondancer"><label
                                    for="checkboxThirteen">Minning</label></li>
                            <li><input type="checkbox" id="checkboxFourteen" value="Medley"><label
                                    for="checkboxFourteen">DeFi</label></li>
                            <li><input type="checkbox" id="checkboxFifteen" value="Firefly"><label
                                    for="checkboxFifteen">History</label></li>
                        </ul>

                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <h4>Difficulty </h4>
                    <div class="academy-multiselect-tabs">
                        <ul class="ks-cboxtags">
                            <li><input type="checkbox" id="checkboxSixteen" value="Baby Moondancer"><label
                                    for="checkboxSixteen">Wealth Mark</label></li>
                            <li><input type="checkbox" id="checkboxSeventeen" value="Medley"><label
                                    for="checkboxSeventeen">Crypto Coin</label></li>
                            <li><input type="checkbox" id="checkboxEighteen" value="Firefly"><label
                                    for="checkboxEighteen">Bitcoin</label></li>
                        </ul>

                    </div>
                </div>
            </div>


            <div class="row" id="wealthmark-coin-tab-content">
                <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                    <div class="row tab-first-content-box">
                        <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                            <div class="academy-inner-box">
                                <div class="card">
                                    <img loading="lazy" src="{{ asset('public/assets/img/latest-release-2.png') }}"
                                        class="img-fluid">
                                    <div class="card-content-block">
                                        <h5 class="heading-latest-release">What is Wealth Mark BENQI (QI)?</h5>
                                        <div class="featured-detaild-block mt-1">
                                            <span class="badge bg-warning text-darkg">Beginner </span>
                                            <span class="cryto-date-block">Nov 16, 2020</span>
                                            <span class="cryto-distance-block"> 6m</span>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-8 col-md-8 col-sm-6 col-xs-12">
                            <div class="academy-inner-box">
                                <div class="row academy-subscribe-inner-block subscribe-first-block">
                                    <div class="col-md-6"><img <img="" loading="lazy"
                                            src="{{ asset('public/assets/img/crypto-slang.png') }}"
                                            class="img-fluid float-end">
                                    </div>
                                    <div class="col-md-6">
                                        <div class="css-19af35r e122kejs0">
                                            <h2 class="heading">Lost in all the crypto slang?</h2>
                                            <p class="para">Take a closer look at our blockchain &amp; crypto
                                                glossary.</p>
                                            <a href="#" class="btn btn-yellow shadow mt-3">Get Started</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-8 col-md-8 col-sm-6 col-xs-12">
                            <div class="academy-inner-box">
                                <div class="row academy-subscribe-inner-block subscribe-first-block">
                                    <div class="col-md-6"><img <img="" loading="lazy"
                                            src="{{ asset('public/assets/img/academy-tab-img-1.png') }}"
                                            class="img-fluid float-end">
                                    </div>
                                    <div class="col-md-6">
                                        <div class="css-19af35r e122kejs0">
                                            <h2 class="heading">Lost in all the crypto slang?</h2>
                                            <p class="para">Take a closer look at our blockchain &amp; crypto
                                                glossary.</p>
                                            <a href="#" class="btn btn-yellow shadow mt-3">Get Started</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                            <div class="academy-inner-box">
                                <div class="card">
                                    <img loading="lazy" src="{{ asset('public/assets/img/latest-release-1.png') }}"
                                        class="img-fluid">
                                    <div class="card-content-block">
                                        <h5 class="heading-latest-release">What is Wealth Mark BENQI (QI)?</h5>
                                        <div class="featured-detaild-block mt-1">
                                            <span class="badge bg-warning text-darkg">Beginner </span>
                                            <span class="cryto-date-block">Nov 16, 2020</span>
                                            <span class="cryto-distance-block"> 6m</span>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                            <div class="academy-inner-box">
                                <div class="row academy-subscribe-inner-block subscribe-first-block subscribe-last-row">
                                    <div class="col-md-3"><img loading="lazy"
                                            src="{{ asset('public/assets/img/crypto-slang.png') }}"
                                            class="img-fluid float-end">
                                    </div>
                                    <div class="col-md-9">
                                        <div class="css-19af35r e122kejs0">
                                            <h2 class="heading">Lost in all the crypto slang?</h2>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                            <div class="academy-inner-box">
                                <div class="row academy-subscribe-inner-block subscribe-first-block subscribe-last-row">
                                    <div class="col-md-3"><img <img="" loading="lazy"
                                            src="{{ asset('public/assets/img/banner-img-1.png') }}"
                                            class="img-fluid float-end">
                                    </div>
                                    <div class="col-md-9">
                                        <div class="css-19af35r e122kejs0">
                                            <h2 class="heading">Lost in all the crypto slang?</h2>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12 col-md-12 col-sm-6 col-xs-12">
                            <div class="academy-tab-more-btn d-flex mt-4 justify-content-center align-content-center">
                                <a href="#" class="btn btn-yellow shadow"> See more content about this topic</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row" id="bitcoin-tab-content">
                <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                    <div class="row tab-first-content-box">
                        <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                            <div class="academy-inner-box">
                                <div class="card">
                                    <img loading="lazy" src="{{ asset('public/assets/img/latest-release-4.png') }}"
                                        class="img-fluid">
                                    <div class="card-content-block">
                                        <h5 class="heading-latest-release">What is Wealth Mark BENQI (QI)?</h5>
                                        <div class="featured-detaild-block mt-1">
                                            <span class="badge bg-warning text-darkg">Beginner </span>
                                            <span class="cryto-date-block">Nov 16, 2020</span>
                                            <span class="cryto-distance-block"> 6m</span>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-8 col-md-8 col-sm-6 col-xs-12">
                            <div class="academy-inner-box">
                                <div class="row academy-subscribe-inner-block subscribe-first-block">
                                    <div class="col-md-6"><img <img="" loading="lazy"
                                            src="{{ asset('public/assets/img/crypto-slang.png') }}"
                                            class="img-fluid float-end">
                                    </div>
                                    <div class="col-md-6">
                                        <div class="css-19af35r e122kejs0">
                                            <h2 class="heading">Lost in all the crypto slang?</h2>
                                            <p class="para">Take a closer look at our blockchain &amp; crypto
                                                glossary.</p>
                                            <a href="#" class="btn btn-yellow shadow mt-3">Get Started</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-8 col-md-8 col-sm-6 col-xs-12">
                            <div class="academy-inner-box">
                                <div class="row academy-subscribe-inner-block subscribe-first-block">
                                    <div class="col-md-6"><img <img="" loading="lazy"
                                            src="{{ asset('public/assets/img/academy-tab-img-1.png') }}"
                                            class="img-fluid float-end">
                                    </div>
                                    <div class="col-md-6">
                                        <div class="css-19af35r e122kejs0">
                                            <h2 class="heading">Lost in all the crypto slang?</h2>
                                            <p class="para">Take a closer look at our blockchain &amp; crypto
                                                glossary.</p>
                                            <a href="#" class="btn btn-yellow shadow mt-3">Get Started</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                            <div class="academy-inner-box">
                                <div class="card">
                                    <img loading="lazy" src="{{ asset('public/assets/img/latest-release-5.png') }}"
                                        class="img-fluid">
                                    <div class="card-content-block">
                                        <h5 class="heading-latest-release">What is Wealth Mark BENQI (QI)?</h5>
                                        <div class="featured-detaild-block mt-1">
                                            <span class="badge bg-warning text-darkg">Beginner </span>
                                            <span class="cryto-date-block">Nov 16, 2020</span>
                                            <span class="cryto-distance-block"> 6m</span>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                            <div class="academy-inner-box">
                                <div class="row academy-subscribe-inner-block subscribe-first-block subscribe-last-row">
                                    <div class="col-md-3"><img loading="lazy"
                                            src="{{ asset('public/assets/img/crypto-slang.png') }}"
                                            class="img-fluid float-end">
                                    </div>
                                    <div class="col-md-9">
                                        <div class="css-19af35r e122kejs0">
                                            <h2 class="heading">Lost in all the crypto slang?</h2>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                            <div class="academy-inner-box">
                                <div class="row academy-subscribe-inner-block subscribe-first-block subscribe-last-row">
                                    <div class="col-md-3"><img <img="" loading="lazy"
                                            src="{{ asset('public/assets/img/banner-img-1.png') }}"
                                            class="img-fluid float-end">
                                    </div>
                                    <div class="col-md-9">
                                        <div class="css-19af35r e122kejs0">
                                            <h2 class="heading">Lost in all the crypto slang?</h2>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12 col-md-12 col-sm-6 col-xs-12">
                            <div class="academy-tab-more-btn d-flex mt-4 justify-content-center align-content-center">
                                <a href="#" class="btn btn-yellow shadow"> See more content about this topic</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </section>
    <section class="academy-no-idea" id="academy-no-idea-section">
        <div class="container">
            <div class="row bitcoin-inner">
                <div class="col-md-2 d-sm-none d-xs-none"></div>
                <div class="col-md-4">
                    <img loading="lazy" class="hero-image  img-fluid"
                        src="{{ asset('public/assets/img/no-idea-illustration.svg') }}" alt="Trust Wallet app">
                </div>
                <div class="col-md-4">
                    <h2>No idea what you just scrolled through?</h2>
                    <p>Not to worry. Our no-nonsense beginner's guide will get you up to speed..Lorem ipsum dolor sit
                        amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna
                        aliqua.</p>
                    <a href="#" class="btn btn-yellow shadow mt-3">Get Started Here</a>
                </div>
                <div class="col-md-2 d-sm-none d-xs-none"></div>

            </div>
        </div>
    </section>

    <section class="essential-block" id="academy-essential-section">
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-xs-6 col-sm-6 sec-title text-left">
                    <div class="sec-title">
                        <span class="title">Know About</span>
                        <h2 class="heading-h2">Essential</h2>
                    </div>
                </div>
                <div class="col-md-4 col-xs-6 col-sm-6 sec-title text-right view-all-block">
                    <h2 class="float-right view-all-btn text-right">See All Essential Content →</h2>
                </div>
            </div>

            <div class="row mt-3">
                <div class="col-lg-3 col-md-3 col-xs-12 col-sm-12">
                    <div class="card">
                        <img loading="lazy" src="{{ asset('public/assets/img/essential-2.png') }}" class="img-fluid">
                        <h5 class="heading-latest-release">Crypto Fear & Index Green</h5>
                        <div class="featured-detaild-block mt-1">
                            <span class="badge bg-warning text-darkg">Beginner </span>
                            <span class="cryto-date-block">Nov 16, 2020</span>
                            <span class="cryto-distance-block"> 6m</span>

                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-3 col-xs-12 col-sm-12">
                    <div class="card">
                        <img loading="lazy" src="{{ asset('public/assets/img/trading-img-2.png') }}" class="img-fluid">
                        <h5 class="heading-latest-release">What Is Staking In Crypto?</h5>
                        <div class="featured-detaild-block mt-1">
                            <span class="badge bg-warning text-darkg">Beginner </span>
                            <span class="cryto-date-block">Nov 16, 2020</span>
                            <span class="cryto-distance-block"> 6m</span>

                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-xs-12 col-sm-12">
                    <div class="card">
                        <img loading="lazy" src="{{ asset('public/assets/img/essential-1.png') }}" class="img-fluid">
                        <h5 class="heading-latest-release">Calculate Investment.</h5>
                        <div class="featured-detaild-block mt-1">
                            <span class="badge bg-warning text-darkg">Beginner </span>
                            <span class="cryto-date-block">Nov 16, 2020</span>
                            <span class="cryto-distance-block"> 6m</span>

                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-xs-12 col-sm-12">
                    <div class="card">
                        <img loading="lazy" src="{{ asset('public/assets/img/latest-release-4.png') }}"
                            class="img-fluid">
                        <h5 class="heading-latest-release">Moving Averages Explained</h5>
                        <div class="featured-detaild-block mt-1">
                            <span class="badge bg-warning text-darkg">Beginner </span>
                            <span class="cryto-date-block">Nov 16, 2020</span>
                            <span class="cryto-distance-block"> 6m</span>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <section class="blockchain-block" id="academy-blockchain-section">
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-xs-6 col-sm-6 sec-title text-left">
                    <div class="sec-title">
                        <span class="title">Know About</span>
                        <h2 class="heading-h2">Blockchain</h2>
                    </div>
                </div>
                <div class="col-md-4 col-xs-6 col-sm-6 sec-title text-right view-all-block">
                    <h2 class="float-right view-all-btn text-right">See All BlockChain Content →</h2>
                </div>
            </div>

            <div class="row mt-3">

                <div class="col-lg-3 col-md-3 col-xs-12 col-sm-12">
                    <div class="card">
                        <img loading="lazy" src="{{ asset('public/assets/img/blockchain-img-1.png') }}"
                            class="img-fluid">
                        <h5 class="heading-latest-release">Crypto Fear & Index Green</h5>
                        <div class="featured-detaild-block mt-1">
                            <span class="badge bg-warning text-darkg">Beginner </span>
                            <span class="cryto-date-block">Nov 16, 2020</span>
                            <span class="cryto-distance-block"> 6m</span>

                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-3 col-xs-12 col-sm-12">
                    <div class="card">
                        <img loading="lazy" src="{{ asset('public/assets/img/latest-release-4.png') }}"
                            class="img-fluid">
                        <h5 class="heading-latest-release">Keep an eye on Bitcoin</h5>
                        <div class="featured-detaild-block mt-1">
                            <span class="badge bg-warning text-darkg">Beginner </span>
                            <span class="cryto-date-block">Nov 16, 2020</span>
                            <span class="cryto-distance-block"> 6m</span>

                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-3 col-xs-12 col-sm-12">
                    <div class="card">
                        <img loading="lazy" src="{{ asset('public/assets/img/blockchain-img-2.png') }}"
                            class="img-fluid">
                        <h5 class="heading-latest-release">Calculate Investment</h5>
                        <div class="featured-detaild-block mt-1">
                            <span class="badge bg-warning text-darkg">Beginner </span>
                            <span class="cryto-date-block">Nov 16, 2020</span>
                            <span class="cryto-distance-block"> 6m</span>

                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-3 col-xs-12 col-sm-12">
                    <div class="card">
                        <img loading="lazy" src="{{ asset('public/assets/img/latest-release-2.png') }}"
                            class="img-fluid">
                        <h5 class="heading-latest-release">Limit Order</h5>
                        <div class="featured-detaild-block mt-1">
                            <span class="badge bg-warning text-darkg">Beginner </span>
                            <span class="cryto-date-block">Nov 16, 2020</span>
                            <span class="cryto-distance-block"> 6m</span>

                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>

    <section class="academy-featured-block" id="academy-featured-section">
        <div class="container">
            <div class="row bitcoin-inner">
                <div class="col-md-6 col-xs-6 col-sm-6">
                    <div class="row academy-subscribe-inner-block subscribe-first-block">
                        <div class="col-md-6"><img <img loading="lazy"
                                src="{{ asset('public/assets/img/crypto-slang.png') }}" class="img-fluid float-end">
                        </div>
                        <div class="col-md-6">
                            <div class="css-19af35r e122kejs0">
                                <h2 class="heading">Lost in all the crypto slang?</h2>
                                <p class="para">Take a closer look at our blockchain &amp; crypto
                                    glossary.</p>
                                <a href="#" class="btn btn-yellow shadow mt-3">Get Started</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-xs-6 col-sm-6">
                    <div class="row academy-subscribe-inner-block subscribe-second-block">
                        <div class="col-md-6"><img <img loading="lazy"
                                src="{{ asset('public/assets/img/academy-learning-material.jpg') }}" class="img-fluid">
                        </div>
                        <div class="col-md-6">
                            <div class="css-19af35r e122kejs0 float-start">
                                <h2 class="heading text-white">Lost in all the crypto slang?</h2>
                                <p class="para text-white">Take a closer look at our blockchain &amp; crypto
                                    glossary.</p>
                                <a href="#" class="btn bg-light shadow mt-3">Get Started</a>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>


    <section class="academy-card-with-info" id="academy-card-with-info">
        <div class="container">
            <div class="row mt-3">
                <div class="col-lg-3 col-md-3 col-xs-6 col-sm-6">
                    <div class="card release-content-block">
                        <div class="sec-title academy-search-icon-block">
                            <h2 class="heading-h2 text-warning">278</h2>
                            <p>What's the number of terms in our glossary. How many do you know?</p>
                            <div class="input-group mb-3 mt-3">
                                        <input type="text" class="form-control"  placeholder="Search glossary"  aria-label="Recipient's username" aria-describedby="basic-addon2">
                                        <a href="#" class="input-group-text" id="basic-addon2">Search</a>
                                    </div>

                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-xs-6 col-sm-6">
                    <div class="card release-content-block">
                        <div class="sec-title">
                            <h2 class="heading-h2">Ask Price</h2>
                            <p>An allotment of tokens or equity, that may be earned, purchased, or set aside for a
                                certain investor, team,...</p>
                            <span class="badge bg-warning text-dark full-defination-btn ">Full Defination
                                &#10141;</span>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-xs-6 col-sm-6">
                    <div class="card release-content-block">
                        <div class="sec-title">
                            <h2 class="heading-h2">Allocation</h2>
                            <p>An allotment of tokens or equity, that may be earned, purchased, or set aside for a
                                certain investor, team,...</p>
                            <span class="badge bg-warning text-dark full-defination-btn ">Full Defination
                                &#10141;</span>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-xs-6 col-sm-6">
                    <div class="card release-content-block">
                        <div class="sec-title">
                            <h2 class="heading-h2">Ponzi Scheme</h2>
                            <p>An allotment of tokens or equity, that may be earned, purchased, or set aside for a
                                certain investor, team,...</p>
                            <span class="badge bg-warning text-dark full-defination-btn ">Full Defination
                                &#10141;</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="academy-subscribe-block" id="academy-subscribe-section">
        <div class="container">
            <div class="row bitcoin-inner">
                <div class="col-md-6 col-xs-6 col-sm-6">
                    <img loading="lazy" class="img-fluid  d-flex mx-auto"
                        src="{{ asset('public/assets/img/academy-subscribe-img.png') }}" alt="Trust Wallet app">
                </div>
                <div class="col-md-6 col-xs-6 col-sm-6">
                    <h2 class="subscribe-heading"><strong>No noise. Just signal.</strong></h2>
                    <p class="pb-3">Get the latest in crypto dropped to your email, every week.</p>
                    <div class="input-group mb-3">
                        <input type="text" class="form-control" placeholder="Enter Your Email Address"
                            aria-label="Recipient's username" aria-describedby="basic-addon2">
                        <a href="#" class="input-group-text academy-suscribe-btn" id="basic-addon2">Subscribe</a>
                    </div>
                    <input type="checkbox" /> I have read and agree to Wealth Mark's <a href="#" class="terms-txt">
                        &nbsp;Terms of
                        Service</a>
                </div>

            </div>
        </div>
    </section>
    <script src="https://kit.fontawesome.com/96b7211fcc.js" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script>
    $(document).ready(function() {
        $(".academy-first-tab").click(function() {
            $("#wealthmark-coin-tab-content").show();
            $("#bitcoin-tab-content").hide();
        });
        $(".academy-second-tab").click(function() {
            $("#wealthmark-coin-tab-content").hide();
            $("#bitcoin-tab-content").show();
        });
        $(".academy-third-tab").click(function() {
            $("#wealthmark-coin-tab-content").show();
            $("#bitcoin-tab-content").hide();
        });
        $(".academy-fourth-tab").click(function() {
            $("#wealthmark-coin-tab-content").hide();
            $("#bitcoin-tab-content").show();
        });
        $(".academy-fifth-tab").click(function() {
            $("#wealthmark-coin-tab-content").show();
            $("#bitcoin-tab-content").hide();
        });
        $(".academy-sixth-tab").click(function() {
            $("#wealthmark-coin-tab-content").hide();
            $("#bitcoin-tab-content").show();
        });
        $(".academy-seventh-tab").click(function() {
            $("#wealthmark-coin-tab-content").show();
            $("#bitcoin-tab-content").hide();
        });
        $(".academy-eighth-tab").click(function() {
            $("#wealthmark-coin-tab-content").hide();
            $("#bitcoin-tab-content").show();
        });
        $(".academy-ninth-tab").click(function() {
            $("#wealthmark-coin-tab-content").show();
            $("#bitcoin-tab-content").hide();
        });
        $(".academy-tenth-tab").click(function() {
            $("#wealthmark-coin-tab-content").hide();
            $("#bitcoin-tab-content").show();
        });
    });
    </script>

    @include('template.country_language')
    @include('template.web_footer')
</body>

</html>