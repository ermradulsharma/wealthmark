  <!DOCTYPE html>
  <html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

  <head>
      <meta charset="utf-8">
      <meta content="width=device-width, initial-scale=1.0" name="viewport">
      <title>Wealth Mark | Create Entity Account</title>
      @include('template.web_css')
      <link rel='stylesheet' href="{{('../public/assets/css/deepak_custom.css') }}">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

      <style>
      #header {
          background: white;

      }

      @media screen and (min-width: 768px) {
          .under-maintance {
              max-width: 50%;

          }

          .under-maintance-div {
              padding: 50px 0px;
              text-align: center;
          }
      }
      </style>


  </head>

  <body class="bg-white">

      @include('template.mobile_menu')
      @include('template.web_menu')


      

      <section class="card-deposit-first-section">
          <div class="container">
              <div class="row">
                  <div class="sec-title text-left">
                      <span class="title">Know About</span>
                      <h2 class="heading-h2">Deposit <span class="yellow-text">Fiat(Order History)</span></h2>
                  </div>
              </div>
              <div class="row deposit-card-first-row">
                  <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                      <div class="card-deposit-top-block">
                          <h4>1. Select currency </h4><br />
                          <label>₹ Currency </label>
                          <div class="input-group mb-3">
                              <div class="input-group-prepend">
                                  <label class="input-group-text" for="inputGroupSelect01">EUR(EURO)</label>
                              </div>
                              <select class="custom-select" id="inputGroupSelect01" data-bs-toggle="modal"
                                  data-bs-target="#card-deposit-select-currency" disabled>
                              </select>
                          </div>
                          <br />
                          <label>Deposit With</label>
                          <ul class="nav nav-tabs" id="myTab" role="tablist">
                              <li class="nav-item" role="presentation">
                                  <button class="nav-link active" id="home-tab" data-bs-toggle="tab"
                                      data-bs-target="#home" type="button" role="tab" aria-controls="home"
                                      aria-selected="true">Recommended</button>
                              </li>
                              <li class="nav-item" role="presentation">
                                  <button class="nav-link" id="profile-tab" data-bs-toggle="tab"
                                      data-bs-target="#profile" type="button" role="tab" aria-controls="profile"
                                      aria-selected="false">Other Methods</button>
                              </li>
                          </ul>
                          <div class="tab-content" id="myTabContent">
                              <div class="tab-pane fade show active" id="home" role="tabpanel"
                                  aria-labelledby="home-tab">
                                  <div class="row">
                                      <div class="col-md-6">
                                          <label class="InputWrapper__Wrapper-sc-122d5e8-0 eBhcfm CustomCheckbox__StyledInputWrapper-sc-1nxek7f-0 hgBdZ"
                                              for="input-115">
                                              <div display="flex" width="100%"
                                                  data-ui-test="morning-time-icon-button-container"
                                                  class="Box-sc-32o1rb-0 CustomCheckbox__CheckboxContainer-sc-1nxek7f-1 dZqsNY cLcaMH">
                                                  <div class="CustomCheckbox__IconWrapper-sc-1nxek7f-2 cuHnVb">
                                                      <div data-ui-test="morning-time-icon-button-off-icon"><svg
                                                              width="24" height="24" viewBox="0 0 24 24">
                                                              <path
                                                                  d="m4.54286 5.82857c0-.71008.57563-1.28571 1.28571-1.28571h12.34283c.7101 0 1.2857.57563 1.2857 1.28571v12.34283c0 .7101-.5756 1.2857-1.2857 1.2857h-12.34283c-.71008 0-1.28571-.5756-1.28571-1.2857zm13.62854-2.82857h-12.34283c-1.56218 0-2.82857 1.26639-2.82857 2.82857v12.34283c0 1.5622 1.26639 2.8286 2.82857 2.8286h12.34283c1.5622 0 2.8286-1.2664 2.8286-2.8286v-12.34283c0-1.56218-1.2664-2.82857-2.8286-2.82857z">
                                                              </path>
                                                          </svg></div>
                                                  </div>
                                                  <label for="input-115" data-ui-test="morning-time-icon-button-content"
                                                      class="CustomCheckbox__CheckboxLabel-sc-1nxek7f-3 bbYFTT"><svg
                                                           width="16" height="16"
                                                          fill="currentColor" class="bi bi-bank" viewBox="0 0 16 16">
                                                          <path
                                                              d="m8 0 6.61 3h.89a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-.5.5H15v7a.5.5 0 0 1 .485.38l.5 2a.498.498 0 0 1-.485.62H.5a.498.498 0 0 1-.485-.62l.5-2A.501.501 0 0 1 1 13V6H.5a.5.5 0 0 1-.5-.5v-2A.5.5 0 0 1 .5 3h.89L8 0ZM3.777 3h8.447L8 1 3.777 3ZM2 6v7h1V6H2Zm2 0v7h2.5V6H4Zm3.5 0v7h1V6h-1Zm2 0v7H12V6H9.5ZM13 6v7h1V6h-1Zm2-1V4H1v1h14Zm-.39 9H1.39l-.25 1h13.72l-.25-1Z" />
                                                      </svg><br />
                                                      <h4>Bank Transfer (SEPA)
                                                  </label></h4><br />
                                                  <label data-ui-test="morning-time-icon-button-subcontent"
                                                      class="CustomCheckbox__CheckboxSubLabel-sc-1nxek7f-4 dCHhCE">1EUR
                                                      Discounted Transaction Fee, 1-3 business days</label>
                                              </div>
                                              <input name="specifiedTimes" width="120px" type="checkbox" data-ui-test="morning-time-icon-button" id="input-115" 
                                              class="InputWrapper__WrappedInput-sc-122d5e8-1 ivRDKP check" value="morning">
                                          </label>
                                      </div>
                                      <div class="col-md-6">
                                          <label class="InputWrapper__Wrapper-sc-122d5e8-0 eBhcfm CustomCheckbox__StyledInputWrapper-sc-1nxek7f-0 hgBdZ2"
                                              for="input-115">
                                              <div display="flex" width="100%"
                                                  data-ui-test="morning-time-icon-button-container"
                                                  class="Box-sc-32o1rb-0 CustomCheckbox__CheckboxContainer-sc-1nxek7f-1 dZqsNY cLcaMH">
                                                  <div class="CustomCheckbox__IconWrapper-sc-1nxek7f-2 cuHnVb">
                                                      <div data-ui-test="morning-time-icon-button-off-icon"><svg
                                                              width="24" height="24" viewBox="0 0 24 24">
                                                              <path
                                                                  d="m4.54286 5.82857c0-.71008.57563-1.28571 1.28571-1.28571h12.34283c.7101 0 1.2857.57563 1.2857 1.28571v12.34283c0 .7101-.5756 1.2857-1.2857 1.2857h-12.34283c-.71008 0-1.28571-.5756-1.28571-1.2857zm13.62854-2.82857h-12.34283c-1.56218 0-2.82857 1.26639-2.82857 2.82857v12.34283c0 1.5622 1.26639 2.8286 2.82857 2.8286h12.34283c1.5622 0 2.8286-1.2664 2.8286-2.8286v-12.34283c0-1.56218-1.2664-2.82857-2.8286-2.82857z">
                                                              </path>
                                                          </svg></div>
                                                  </div>
                                                  <label for="input-115" data-ui-test="morning-time-icon-button-content"
                                                      class="CustomCheckbox__CheckboxLabel-sc-1nxek7f-3 bbYFTT"><svg
                                                           width="16" height="16"
                                                          fill="currentColor" class="bi bi-bank" viewBox="0 0 16 16">
                                                          <path
                                                              d="m8 0 6.61 3h.89a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-.5.5H15v7a.5.5 0 0 1 .485.38l.5 2a.498.498 0 0 1-.485.62H.5a.498.498 0 0 1-.485-.62l.5-2A.501.501 0 0 1 1 13V6H.5a.5.5 0 0 1-.5-.5v-2A.5.5 0 0 1 .5 3h.89L8 0ZM3.777 3h8.447L8 1 3.777 3ZM2 6v7h1V6H2Zm2 0v7h2.5V6H4Zm3.5 0v7h1V6h-1Zm2 0v7H12V6H9.5ZM13 6v7h1V6h-1Zm2-1V4H1v1h14Zm-.39 9H1.39l-.25 1h13.72l-.25-1Z" />
                                                      </svg><br />
                                                      <h4>Bank Card (VISA/MC)
                                                  </label></h4><br />
                                                  <label data-ui-test="morning-time-icon-button-subcontent"
                                                      class="CustomCheckbox__CheckboxSubLabel-sc-1nxek7f-4 dCHhCE">1EUR
                                                      Discounted Transaction Fee, 1-3 business days</label>
                                              </div>
                                              <input name="specifiedTimes" width="120px" type="checkbox"
                                                  data-ui-test="morning-time-icon-button" id="input-115" class="InputWrapper__WrappedInput-sc-122d5e8-1 ivRDKP check2"
                                                  value="morning">
                                          </label>
                                      </div>
                                  </div>
                              </div>
                              <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                                  <div class="row">
                                      <div class="col-md-6 col-lg-6 col-xs-12 col-sm-6">
                                          <label class="InputWrapper__Wrapper-sc-122d5e8-0 eBhcfm CustomCheckbox__StyledInputWrapper-sc-1nxek7f-0 hgBdZ3" for="input-115">
                                              <div display="flex" width="100%"
                                                  data-ui-test="morning-time-icon-button-container"
                                                  class="Box-sc-32o1rb-0 CustomCheckbox__CheckboxContainer-sc-1nxek7f-1 dZqsNY cLcaMH">
                                                  <div class="CustomCheckbox__IconWrapper-sc-1nxek7f-2 cuHnVb">
                                                      <div data-ui-test="morning-time-icon-button-off-icon"><svg
                                                               width="16" height="16"
                                                              fill="currentColor" class="bi bi-credit-card-2-back"
                                                              viewBox="0 0 16 16">
                                                              <path
                                                                  d="M11 5.5a.5.5 0 0 1 .5-.5h2a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1-.5-.5v-1z" />
                                                              <path
                                                                  d="M2 2a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2H2zm13 2v5H1V4a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1zm-1 9H2a1 1 0 0 1-1-1v-1h14v1a1 1 0 0 1-1 1z" />
                                                          </svg></div>
                                                  </div>
                                                  <label for="input-115" data-ui-test="morning-time-icon-button-content"
                                                      class="CustomCheckbox__CheckboxLabel-sc-1nxek7f-3 bbYFTT"><svg
                                                           width="16" height="16"
                                                          fill="currentColor" class="bi bi-credit-card-2-front"
                                                          viewBox="0 0 16 16">
                                                          <path
                                                              d="M14 3a1 1 0 0 1 1 1v8a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h12zM2 2a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2H2z" />
                                                          <path
                                                              d="M2 5.5a.5.5 0 0 1 .5-.5h2a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1-.5-.5v-1zm0 3a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1-.5-.5zm0 2a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 0 1h-1a.5.5 0 0 1-.5-.5zm3 0a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 0 1h-1a.5.5 0 0 1-.5-.5zm3 0a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 0 1h-1a.5.5 0 0 1-.5-.5zm3 0a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 0 1h-1a.5.5 0 0 1-.5-.5z" />
                                                      </svg><br />
                                                      <h4>P2P Express
                                                  </label></h4><br />
                                                  <label data-ui-test="morning-time-icon-button-subcontent"
                                                      class="CustomCheckbox__CheckboxSubLabel-sc-1nxek7f-4 dCHhCE">1EUR
                                                      0</label>
                                              </div>
                                              <input name="specifiedTimes" width="120px" type="checkbox" data-ui-test="morning-time-icon-button" id="input-115" 
                                              class="InputWrapper__WrappedInput-sc-122d5e8-1 ivRDKP check3" value="morning">
                                          </label>
                                      </div>
                                      <div class="col-md-6 col-lg-6 col-xs-12 col-sm-6">
                                          <label class="InputWrapper__Wrapper-sc-122d5e8-0 eBhcfm CustomCheckbox__StyledInputWrapper-sc-1nxek7f-0 hgBdZ4" for="input-115">
                                              <div display="flex" width="100%"
                                                  data-ui-test="morning-time-icon-button-container"
                                                  class="Box-sc-32o1rb-0 CustomCheckbox__CheckboxContainer-sc-1nxek7f-1 dZqsNY cLcaMH">
                                                  <div class="CustomCheckbox__IconWrapper-sc-1nxek7f-2 cuHnVb">
                                                      <div data-ui-test="morning-time-icon-button-off-icon"><svg
                                                               width="16" height="16"
                                                              fill="currentColor" class="bi bi-credit-card-2-back"
                                                              viewBox="0 0 16 16">
                                                              <path
                                                                  d="M11 5.5a.5.5 0 0 1 .5-.5h2a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1-.5-.5v-1z" />
                                                              <path
                                                                  d="M2 2a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2H2zm13 2v5H1V4a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1zm-1 9H2a1 1 0 0 1-1-1v-1h14v1a1 1 0 0 1-1 1z" />
                                                          </svg></div>
                                                  </div>
                                                  <label for="input-115" data-ui-test="morning-time-icon-button-content"
                                                      class="CustomCheckbox__CheckboxLabel-sc-1nxek7f-3 bbYFTT"><svg
                                                           width="16" height="16"
                                                          fill="currentColor" class="bi bi-credit-card-2-front"
                                                          viewBox="0 0 16 16">
                                                          <path
                                                              d="M14 3a1 1 0 0 1 1 1v8a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h12zM2 2a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2H2z" />
                                                          <path
                                                              d="M2 5.5a.5.5 0 0 1 .5-.5h2a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1-.5-.5v-1zm0 3a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1-.5-.5zm0 2a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 0 1h-1a.5.5 0 0 1-.5-.5zm3 0a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 0 1h-1a.5.5 0 0 1-.5-.5zm3 0a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 0 1h-1a.5.5 0 0 1-.5-.5zm3 0a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 0 1h-1a.5.5 0 0 1-.5-.5z" />
                                                      </svg><br />
                                                      <h4>Cash Account Balance
                                                  </label></h4><br />
                                                  <label data-ui-test="morning-time-icon-button-subcontent"
                                                      class="CustomCheckbox__CheckboxSubLabel-sc-1nxek7f-4 dCHhCE">0 Fee
                                                      <span class="text-warning">Supports SEPA transfer</span></label>
                                              </div>
                                              <input name="specifiedTimes" width="120px" type="checkbox"
                                                  data-ui-test="morning-time-icon-button" id="input-115"
                                                  class="InputWrapper__WrappedInput-sc-122d5e8-1 ivRDKP check4"
                                                  value="morning">
                                          </label>
                                      </div>
                                  </div>
                              </div>
                              <a class="btn btn-warning d-block mt-3">Continue </a>
                              <span class="card-deporsit-terms-text">This service is powered by Bifinity UAB. Your
                                  information is used for identity verification only, and will be kept secure by
                                  Bifinity UAB. </span>
                          </div>

                      </div>
                  </div>

                  <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                      <div class="row">
                          <div class="col-lg-12 col-md-12 col-xs-6 col-sm-6 sec-title text-left popular-head-block">
                              <span class="title">Know About</span>
                              <h2 class="heading-h2">Deposit <span class="yellow-text">FAQ</span></h2>
                          </div>
                      </div>

                      <div class="row">
                          <div class="faq-inner-block" id="faq-inner-section">
                              <div class="col-md-12">
                              <div class="accordion" id="accordian-api">
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingOne">
                                    <button class="accordion-button" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                        1. What is Wealthmark Pay?
                                    </button>
                                </h2>
                                <div id="collapseOne" class="accordion-collapse collapse show"
                                    aria-labelledby="headingOne" data-bs-parent="#accordian-api">
                                    <div class="accordion-body">
                                        <strong>This is the first item's accordion body.</strong> It is shown by
                                        default, until the collapse plugin adds the appropriate classes that we use to
                                        style each element. These classes control the overall appearance, as well as the
                                        showing and hiding via CSS transitions. You can modify any of this with custom
                                        CSS or overriding our default variables. It's also worth noting that just about
                                        any HTML can go within the <code>.accordion-body</code>, though the transition
                                        does limit overflow.
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingTwo">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                        2. Can I pay with Bitcoin, Wealthmark and other cryptocurrencies supported by
                                        Wealthmark?
                                    </button>
                                </h2>
                                <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo"
                                    data-bs-parent="#accordian-api">
                                    <div class="accordion-body">
                                        <strong>You can access your Wealthmark Pay Wallet by clicking [Wallets] -
                                            [Funding] - [Pay] on your Wealthmark App.
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingThree">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapseThree" aria-expanded="false"
                                        aria-controls="collapseThree">
                                        3. How long does it take for a Wealthmark Pay transaction to be completed?
                                    </button>
                                </h2>
                                <div id="collapseThree" class="accordion-collapse collapse"
                                    aria-labelledby="headingThree" data-bs-parent="#accordian-api">
                                    <div class="accordion-body">
                                        <strong>Wealthmark Pay transactions are usually confirmed instantly.
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingfour">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapsefour" aria-expanded="false"
                                        aria-controls="collapsefour">
                                        4. Can I pay with Bitcoin, Wealthmark and other cryptocurrencies supported by
                                        Wealthmark?
                                    </button>
                                </h2>
                                <div id="collapsefour" class="accordion-collapse collapse" aria-labelledby="headingfour"
                                    data-bs-parent="#accordian-api">
                                    <div class="accordion-body">
                                        <strong>You can access your Wealthmark Pay Wallet by clicking [Wallets] -
                                            [Funding] - [Pay] on your Wealthmark App.
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      </section>

      <section class="deposit-fun-account-block" id="deposit-fun-account-section">
          <div class="container">
              <div class="row">
                  <div class="sec-title text-left">
                      <span class="title">Know About</span>
                      <h2 class="heading-h2">Fund Your Account with <span class="yellow-text">Fiat Currencies</span>
                      </h2>
                  </div>
              </div>
              <div class="row mt-5">
                  <div class="col-lg-4 col-md-4 col-sm-6 col-xs-6 cash-deposit-inner">
                      <div class="card">
                          <img src="{{ asset('public/assets/img/depsit-fund-icon-1.svg') }}" class="img-fluid"
                              alt="cash-balance-img" />
                          <div class="card-body">
                              <h5 class="card-title">Easy for both new & experienced trader</h5>
                              <p class="card-text mb-3">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                                  eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                              <div class="read-more-block">
                                  <a href="#" class="btn btn-yellow shadow"> Read More</a>
                              </div>
                          </div>
                      </div>
                  </div>
                  <div class="col-lg-4 col-md-4 col-sm-6 col-xs-6 cash-deposit-inner">
                      <div class="card second-fund-card">
                          <img src="{{ asset('public/assets/img/depsit-fund-icon-2.svg') }}" class="img-fluid"
                              alt="cash-balance-img" />
                          <div class="card-body">
                              <h5 class="card-title">WealthMark offers deposit with fiat currency</h5>
                              <p class="card-text mb-3">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                                  eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                              <div class="read-more-block">
                                  <a href="#" class="btn btn-yellow shadow"> Read More</a>
                              </div>
                          </div>
                      </div>
                  </div>
                  <div class="col-lg-4 col-md-4 col-sm-6 col-xs-6 cash-deposit-inner">
                      <div class="card fund-last-card">
                          <img src="{{ asset('public/assets/img/depsit-fund-icon-3.svg') }}" class="img-fluid"
                              alt="cash-balance-img" />
                          <div class="card-body">
                              <h5 class="card-title">WealthMark supports the following currencies</h5>
                              <p class="card-text mb-3">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                                  eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                              <div class="read-more-block">
                                  <a href="#" class="btn btn-yellow shadow"> Read More</a>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      </section>



      <section class="why-deposit-EUR" id=deposti-eur">
          <div class="container">
              <div class="row align-items-center justify-content-center justify-content-md-between">

                  <div class="col-12 col-lg-5 text-md-left mb-4 order-2 order-lg-1">
                      <div class="sec-title text-left">
                          <span class="title">Know About</span>
                          <h2 class="heading-h2">Why Deposit <span class="yellow-text">EUR with SEPA</span>Transfer ?
                          </h2>
                      </div>
                      <p class="lead">Customers in Europe can deposit and withdraw EUR using SEPA bank transfer and
                          enjoy high spending limits and zero processing fees. Unlike credit card orders, SEPA transfers
                          carry no additional processing fee.</p>
                  </div>
                  <div class="col-12 col-lg-7 img-hover3 order-1 order-lg-2">
                      <figure>
                          <img src="{{ asset('public/assets/img/eur_why_deposit.png') }}"
                              class="img-fluid d-block mx-auto" alt="cash-balance-img" />
                      </figure>
                  </div>
              </div>
          </div>
      </section>


      <section class="why-deposit-EUR-block" id="deposti-eur-table">
          <div class="container">
              <div class="row align-items-center justify-content-center justify-content-md-between">
                  <div class="sec-title text-left">
                      <span class="title">Know About</span>
                      <h2 class="heading-h2">€ EUR <span class="yellow-text">Deposit</span> Options</h2>
                  </div>
                  <div class="col-12 col-md-12 col-lg-12 img-hover3 order-1 order-lg-2">
                      <div class="table-responsive">
                          <table class="table table-hover table-bordered">
                              <thead>
                                  <tr>
                                      <th scope="col">Recommended</th>
                                      <th scope="col">Deposit Fees</th>
                                      <th scope="col">Processing Time</th>
                                  </tr>
                              </thead>
                              <tbody>
                                  <tr>
                                      <td>Bank Transfer (SEPA)</td>
                                      <td>Zero</td>
                                      <td>0-3 business days* (Weekdays only)</td>
                                  </tr>
                                  <tr>
                                      <td>Bank Transfer (SEPA Instant)</td>
                                      <td>Zero</td>
                                      <td>Half an hour (24x7x365)</td>
                                  </tr>
                                  <tr>
                                      <td>Bank Transfer (SEPA)</td>
                                      <td>Zero</td>
                                      <td>0-3 business days* (Weekdays only)</td>
                                  </tr>
                              </tbody>
                          </table>
                      </div>
                  </div>
              </div>
          </div>
      </section>
      <!-- popup modal card deposit -->
      <!-- Modal -->
      <div class="modal fade" id="card-deposit-select-currency" tabindex="-1"
          aria-labelledby="card-deposit-select-currencyLabel" aria-hidden="true">
          <div class="modal-dialog">
              <div class="modal-content">
                  <div class="modal-header">
                      <h5 class="modal-title" id="card-deposit-select-currencyLabel">Select Currency</h5>
                      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                  </div>
                  <div class="modal-body">
                      <div class="row">
                          <div class="col-md-12 col-lg-12 col-xs-12 col-sm-12">
                              <input type="text" class="form-control" placeholder="Search" />
                          </div>
                          <div class="col-md-12 col-lg-12 col-xs-12 col-sm-12">
                              <div class="select-country-group">
                                  <div class="select-currency-tab">
                                      <img src="{{ asset('public/assets/img/currency-1.png') }}" class="img-fluid"
                                          alt="cash-balance-img" />
                                      <div class="currency-detail">
                                          <h5>AED </h5>
                                          <span>United Arab Emirates dirham </span>
                                      </div>
                                  </div>
                                  <div class="select-currency-tab">
                                      <img src="{{ asset('public/assets/img/currency-2.png') }}" class="img-fluid"
                                          alt="cash-balance-img" />
                                      <div class="currency-detail">
                                          <h5>AED </h5>
                                          <span>United Arab Emirates dirham </span>
                                      </div>
                                  </div>
                                  <div class="select-currency-tab">
                                      <img src="{{ asset('public/assets/img/currency-3.png') }}" class="img-fluid"
                                          alt="cash-balance-img" />
                                      <div class="currency-detail">
                                          <h5>AED </h5>
                                          <span>United Arab Emirates dirham </span>
                                      </div>
                                  </div>
                                  <div class="select-currency-tab">
                                      <img src="{{ asset('public/assets/img/currency-4.png') }}" class="img-fluid"
                                          alt="cash-balance-img" />
                                      <div class="currency-detail">
                                          <h5>AED </h5>
                                          <span>United Arab Emirates dirham </span>
                                      </div>
                                  </div>
                                  <div class="select-currency-tab">
                                      <img src="{{ asset('public/assets/img/currency-5.png') }}" class="img-fluid"
                                          alt="cash-balance-img" />
                                      <div class="currency-detail">
                                          <h5>AED </h5>
                                          <span>United Arab Emirates dirham </span>
                                      </div>
                                  </div>
                              </div>
                          </div>
                      </div>
                  </div>
                  <div class="modal-footer">
                      <button type="button" class="btn btn-yellow shadow" data-bs-dismiss="modal">Close</button>
                      <button type="button" class="btn btn-primary">Save changes</button>
                  </div>
              </div>
          </div>
      </div>
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
      <script>
      $(document).ready(function() {
          $(".check").click(function() {
              $(".hgBdZ").toggleClass("checked-box");
          });
      });
      </script>
      <script>
      $(document).ready(function() {
          $(".check2").click(function() {
              $(".hgBdZ2").toggleClass("checked-box2");
          });
      });
      </script>
      <script>
      $(document).ready(function() {
          $(".check3").click(function() {
              $(".hgBdZ3").toggleClass("checked-box3");
          });
      });
      </script>
      <script>
      $(document).ready(function() {
          $(".check4").click(function() {
              $(".hgBdZ4").toggleClass("checked-box4");
          });
      });
      </script>

      @include('template.country_language')
      @include('template.web_footer')



  </body>

  </html>