<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <title>Wealth Mark | {{ Request::segment(2) }}</title>
    @include('template.web_css')
    <link rel='stylesheet' href="{{('../public/assets/css/deepak_custom.css') }}">
    <link rel="stylesheet" href="https:cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>
    @include('template.mobile_menu')
    @include('template.web_menu')
    <!-- first section -->
    <section class="dex-banner-section" id="dex-banner-section">
        <div class="container ">
            <div class="row" id="banner-dex">
                <div class="col-md-6 col-sm-6 col-xs-12 order-2 order-lg-1 mt-3">
                    <div class="left-content-block">
                        <h1>Explore the <span class="highlighted-txt">BNB <br />Chain</span> Ecosystem</h1>
                        <span class="sub-content">The best-performing decentralized economy. Ready for massive user
                            access.</span><br>
                        <div class="dex-banner-btn-group mt-4">
                            <a href="#" class="btn btn-warning">Develop with BNB Chain</a>
                            <a href="#" class="btn btn-warning">Explore Ecosystem </a>
                        </div>
                    </div>

                </div>
                <div class="col-md-6 col-sm-6 col-xs-12 order-1 order-lg-">
                    <div class="right-content-block">
                        <img loading="lazy" src="{{ asset('public/assets/img/dex-banner-img.png') }}" class="img-fluid">
                    </div>
                </div>

            </div>
        </div>
    </section>
<!-- 
    <section>
    <div class=" row seperator-img">
                <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                    <img loading="lazy" src="{{ asset('public/assets/img/banner-bottom-bg.png') }}"
                        class="img-fluid dex-seperator-img">
                </div>
            </div>
    </section> -->

    <!-- second section -->

    <section class="new-in-wealthmark" id="new-chain">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-xs-6 col-sm-6 sec-title text-left chain-heading-row">
                    <span class="title">Know About</span>
                    <h2 class="heading-h2">New in Chain</h2>
                </div>
                <div class="col-md-6 col-xs-6 col-sm-6 sec-title text-right view-all-block chain-heading-row">
                    <h2 class="float-right view-all-btn text-right">Load More →</h2>
                </div>
            </div>

            <div class="row mt-3">
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <img loading="lazy" src="{{ asset('public/assets/img/chain-img1.png') }}" class="img-fluid">
                    <h5 class="heading-dex-what-new">Wealth Mark Chain Builder Grant Opens Door to Innovators </h5>
                    <div class="date-time">
                        <span class="date">Oct 03 </span>
                        <span class="time"> 3 min read </span>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <img loading="lazy" src="{{ asset('public/assets/img/chain-img2.png') }}" class="img-fluid">
                    <h5 class="heading-dex-what-new">Wealth Mark Chain Accelerator Announces Startups as Winners</h5>
                    <div class="date-time">
                        <span class="date">Oct 03 </span>
                        <span class="time"> 3 min read </span>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <img loading="lazy" src="{{ asset('public/assets/img/chain-img3.png') }}" class="img-fluid">
                    <h5 class="heading-dex-what-new">Wealth Mark Chain Mothly Ecosystem Report </h5>
                    <div class="date-time">
                        <span class="date">Oct 03 </span>
                        <span class="time"> 3 min read </span>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <img loading="lazy" src="{{ asset('public/assets/img/chain-img4.png') }}" class="img-fluid">
                    <h5 class="heading-dex-what-new">Wealth Mark Weekly Ecosystem (Sep. 23rd to Sep. 29th)</h5>
                    <div class="date-time">
                        <span class="date">Oct 03 </span>
                        <span class="time"> 3 min read </span>
                    </div>
                </div>
            </div>

            <div class="row mt-5">
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <img loading="lazy" src="{{ asset('public/assets/img/chain-img3.png') }}" class="img-fluid">
                    <h5 class="heading-dex-what-new">Wealth Mark Chain Builder Grant Opens Door to Innovators </h5>
                    <div class="date-time">
                        <span class="date">Oct 03 </span>
                        <span class="time"> 3 min read </span>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <img loading="lazy" src="{{ asset('public/assets/img/chain-img4.png') }}" class="img-fluid">
                    <h5 class="heading-dex-what-new">Wealth Mark Chain Accelerator Announces Startups as Winners</h5>
                    <div class="date-time">
                        <span class="date">Oct 03 </span>
                        <span class="time"> 3 min read </span>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <img loading="lazy" src="{{ asset('public/assets/img/chain-img2.png') }}" class="img-fluid">
                    <h5 class="heading-dex-what-new">Wealth Mark Chain Mothly Ecosystem Report </h5>
                    <div class="date-time">
                        <span class="date">Oct 03 </span>
                        <span class="time"> 3 min read </span>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <img loading="lazy" src="{{ asset('public/assets/img/chain-img1.png') }}" class="img-fluid">
                    <h5 class="heading-dex-what-new">Wealth Mark Weekly Ecosystem (Sep. 23rd to Sep. 29th)</h5>
                    <div class="date-time">
                        <span class="date">Oct 03 </span>
                        <span class="time"> 3 min read </span>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- third section -->

    <section class="new-in-wealthmark" id="what-new-wealthmark">
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-xs-6 col-sm-6 sec-title text-left">
                    <span class="title">Know About</span>
                    <h2 class="heading-h2">Chain Ecosystem</h2>
                </div>
            </div>

            <div class="row align-items-center justify-content-center justify-content-md-between">
                <div class="col-12 col-md-6 col-lg-7 img-hover3">
                    <figure><img loading="lazy" class="hero-image  img-fluid"
                            src="{{ asset('public/assets/img/dowload-wallet.jpg') }}" alt="Trust Wallet app"></figure>
                </div>
                <div class="col-12 col-md-6 col-lg-5 text-md-left mb-4">
                    <h2 class="display-4 font-weight-bold mt-8">Download a wallet</h2>
                    <p class="lead text-gray-700">A wallet helps you connect to Wealth Mark Chain and manage your funds.
                    </p>
                    <a href="#" class="btn btn-yellow shadow mt-3">Download Wallet</a>
                </div>
            </div>

            <div class="row align-items-center justify-content-center justify-content-md-between">
                <div class="col-12 col-md-6 col-lg-5 text-md-left mb-4 order-2 order-lg-1">
                    <h2 class="display-4 font-weight-bold mt-8">Get BNB</h2>
                    <p class="lead text-gray-700">Wealth mark is the currency of WM Chain - you can use it in WM-Apps.
                    </p>
                    <a href="#" class="btn btn-yellow shadow mt-3">Get Wealth Mark</a>
                </div>
                <div class="col-12 col-md-6 col-lg-7 img-hover3 order-1 order-lg-2">
                    <figure><img loading="lazy" class="hero-image mx-auto float-end  d-flex mx-auto img-fluid"
                            src="{{ asset('public/assets/img/get-bnb.png') }}" alt="Trust Wallet app">
                    </figure>
                </div>
            </div>

            <div class="row align-items-center">
                <div class="col-12 col-md-6 col-lg-7 img-hover3">
                    <figure>
                        <img loading="lazy" src="{{ asset('public/assets/img/dex-download-app.png') }}"
                            class="hero-image mx-auto float-start  d-flex mx-auto img-fluid">
                    </figure>
                </div>
                <div class="col-12 col-md-6 col-lg-5 text-md-left mb-4">
                    <h2 class="display-4 font-weight-bold mt-8">Use a WM-App</h2>
                    <p class="lead text-gray-700">Discover the hottest projects on BNB Chain.</p>
                    <a href="#" class="btn btn-yellow shadow mt-3">Find Your First WM-App</a>
                </div>

            </div>
        </div>
    </section>


    <section class="build-chain" id="build-chain-section">
        <div class="container">
            <div class="row build-chain-row-main">
                <div class="col-md-6 col-md-6 col-sm-6 col-xs-12">
                <div class="sec-title">
                    <span class="title">Know About</span>
                    <h2 class="heading-h2">Build on Wealth Mark Chain</h2>
                </div>
                    <div class="build-chain-inner-box">
                        <p>Wealth Mark Smart Chain (BSC) supports the most popular programming languages, flexible
                            tools, and
                            comes with clear and canonical documentation. You can quickly start and deploy your
                            application on a blockchain designed with real use in mind.</p>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
                            labore et dolore magna aliqua.</p>
                    </div>
                    <div class="btn-group">
                        <a href="#" class="btn btn-yellow shadow mt-3">Start Building</a>
                        <a href="#" class="btn btn-yellow shadow mt-3">Read the Docs</a>
                    </div>
                </div>
                <div class="col-md-6 col-md-6 col-sm-6 col-xs-12">
                    <div class="build-chain-inner-box">
                        <img loading="lazy" class="chain-img img-fluid d-block mx-auto" src="{{ asset('public/assets/img/build-code-1.png') }}"
                            alt="Trust Wallet app">
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="chain-four-blocks" id="chain-four-blocks-section">
        <div class="container">
            <div class="row mt-4">
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                    <div class="second-chain-inner-box">
                        <h4><span class="sidechain-slash">// </span> Best EVM Compatible</h4>
                        <p>The best-performing EVM compatible layer 1. Fully compatible tooling for EVM with up to 35
                            times of capacity.</p>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                    <div class="second-chain-inner-box">
                        <h4><span class="sidechain-slash">// </span> Massive User Base</h4>
                        <p>The best-performing EVM compatible layer 1. Fully compatible tooling for EVM with up to 35
                            times of capacity.</p>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                    <div class="second-chain-inner-box">
                        <h4><span class="sidechain-slash">// </span> Most Diversified Assets</h4>
                        <p>The best-performing EVM compatible layer 1. Fully compatible tooling for EVM with up to 35
                            times of capacity.</p>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                    <div class="second-chain-inner-box">
                        <h4><span class="sidechain-slash">// </span> Strongest Ecosystem</h4>
                        <p>The best-performing EVM compatible layer 1. Fully compatible tooling for EVM with up to 35
                            times of capacity.</p>
                    </div>
                </div>

            </div>
        </div>
    </section>



    <section class="discover-apps-now" id="wealthmark-program">
        <div class="container">
            <div class="row mvb-program-inner-block">
                <div class="col-12 col-md-6 col-lg-5 col-sm-12 col-xs-12">
                <div class="sec-title text-left mb-5">
                    <span class="title">Know About</span>
                    <h2 class="heading-h2">MVB Program</h2>
                </div>
                    <p>The MVB V Accelerator Program is a BNB-focused accelerator program between BNB Chain and Wealth Mark
                        Labs to help projects develop and grow more organically through coaching, investment, and
                        network support.</p>
                    <div class="read-more-block mt-4">
                        <a href="#" class="btn btn-yellow shadow mt-3">Read More</a>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-7 col-sm-12 col-xs-12 img-hover3">
                    <figure> <img loading="lazy" class="chain-img img-fluid d-block mx-auto"
                            src="{{ asset('public/assets/img/mv-program.jpg') }}" alt="chain img">
                    </figure>

                </div>
            </div>

        </div>
    </section>

    <section class="scale-sidechain" id="sidechain-section">
        <div class="container">
            <div class="row">
                <div class="sec-title">
                    <span class="title">Know About</span>
                    <h2 class="heading-h2">Scale with BNB Sidechain</h2>
                </div>
            </div>

            <div class="row build-chain-row-main">
                <div class="col-md-6 col-lg-6 col-sm-12 col-xs-12 order-2 order-lg-1">
                    <div class="build-sidechain-inner-box">
                        <p>BNB Sidechain is an infrastructure introduced to help developers and the application
                            community to build and run their dedicated blockchain as a focused value system for a
                            massive number of users while still maintaining a close connection with BNB Chain.</p>
                    </div>
                </div>
                <div class="col-md-6 col-lg-6 col-sm-12 col-xs-12 order-1 order-lg-2">
                    <img loading="lazy" class="chain-img img-fluid d-block mx-auto"
                        src="{{ asset('public/assets/img/scale-side-chain.webp') }}" alt="chain img">
                </div>
            </div>
        </div>
    </section>

    <section class="sidechain-blocks" id="sidechain-blocks-section">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="sidechain-inner-box">
                        <h4><span class="sidechain-slash">// </span> Integration</h4>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
                            labore et dolore magna aliqua. </p>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="sidechain-inner-box">
                        <h4><span class="sidechain-slash">// </span> Support</h4>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
                            labore et dolore magna aliqua. </p>
                    </div>
                </div>

            </div>
        </div>
    </section>
    <section class="sidechain-blocks" id="sidechain-blocks-section">
        <div class="container">
            <div class="row mt-5">
                <div class="col-md-6">
                    <div class="sidechain-inner-box">
                        <h4><span class="sidechain-slash">// </span> Dedication</h4>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
                            incididunt ut labore et dolore magna aliqua. </p>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="sidechain-inner-box">
                        <h4><span class="sidechain-slash">// </span> Sustainability</h4>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
                            incididunt ut labore et dolore magna aliqua. </p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- fouth section -->
    <section class="discover-apps-now" id="discover-apps-now">
        <div class="container">
            <div class="row">
         
                <div class="col-12 col-md-6 col-lg-5 col-sm-12 col-xs-12">
                <div class="sec-title">
                    <span class="title">Know About</span>
                    <h2 class="heading-h2">WM-Apps on Playstore</h2>
                </div>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
                        labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco
                        laboris nisi ut aliquip ex ea commodo consequat.</p>
                    <div class="read-more-block mt-4">
                        <a href="#" class="btn btn-yellow shadow mt-3">Read More</a>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-7 col-sm-12 col-xs-12 img-hover3">
                    <figure><img loading="lazy" class="hero-image mx-auto  d-flex float-end mx-auto img-fluid"
                            src="{{ asset('public/assets/img/many-app-store.svg') }}" alt="launch-rpoject">
                    </figure>

                </div>
            </div>

        </div>
    </section>

    <!-- fifth section -->
    <section class="community-part-section" id="dex-collaborations">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-xs-12 col-sm-12 sec-title text-left">
                    <span class="title">Know About</span>
                    <h2 class="heading-h2">Be Part of the Community</h2>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-2 col-md-2 col-xs-6 col-sm-6 col-sm-12">
                    <div class="clients-logo">
                        <svg viewBox="0 0 24 24" focusable="false" class="chakra-icon css-1kfbigr">
                            <path
                                d="M18.2379 6.26906C17.0906 5.73109 15.8603 5.33473 14.574 5.10772C14.5506 5.10334 14.5272 5.11429 14.5151 5.13618C14.3569 5.42378 14.1817 5.79897 14.0589 6.09386C12.6754 5.88219 11.299 5.88219 9.94385 6.09386C9.82109 5.79241 9.63947 5.42378 9.48054 5.13618C9.46847 5.11502 9.44507 5.10407 9.42164 5.10772C8.13604 5.334 6.90578 5.73036 5.75781 6.26906C5.74787 6.27344 5.73935 6.28075 5.7337 6.29023C3.40015 9.85309 2.76089 13.3284 3.07449 16.7606C3.07591 16.7774 3.08513 16.7934 3.09791 16.8036C4.63751 17.9591 6.12889 18.6606 7.59256 19.1256C7.61599 19.1329 7.64081 19.1241 7.65572 19.1044C8.00195 18.6212 8.31059 18.1117 8.57521 17.5759C8.59083 17.5445 8.57592 17.5073 8.544 17.4949C8.05445 17.3051 7.58831 17.0737 7.1399 16.811C7.10444 16.7898 7.1016 16.7379 7.13422 16.7131C7.22858 16.6409 7.32297 16.5657 7.41307 16.4898C7.42937 16.4759 7.45209 16.473 7.47125 16.4817C10.4171 17.8562 13.6063 17.8562 16.5173 16.4817C16.5365 16.4722 16.5592 16.4752 16.5762 16.489C16.6663 16.5649 16.7607 16.6409 16.8558 16.7131C16.8884 16.7379 16.8863 16.7898 16.8508 16.811C16.4024 17.0788 15.9362 17.3051 15.446 17.4942C15.4141 17.5066 15.3999 17.5445 15.4155 17.5759C15.6858 18.111 15.9944 18.6205 16.3343 19.1037C16.3485 19.1241 16.374 19.1329 16.3974 19.1256C17.8682 18.6606 19.3596 17.9591 20.8992 16.8036C20.9127 16.7934 20.9212 16.7781 20.9226 16.7613C21.2979 12.7933 20.294 9.34652 18.2613 6.29095C18.2563 6.28075 18.2478 6.27344 18.2379 6.26906ZM9.01512 14.6707C8.12823 14.6707 7.39745 13.8386 7.39745 12.8167C7.39745 11.7947 8.11406 10.9626 9.01512 10.9626C9.92326 10.9626 10.647 11.8021 10.6328 12.8167C10.6328 13.8386 9.91616 14.6707 9.01512 14.6707ZM14.9962 14.6707C14.1093 14.6707 13.3785 13.8386 13.3785 12.8167C13.3785 11.7947 14.0951 10.9626 14.9962 10.9626C15.9043 10.9626 16.628 11.8021 16.6138 12.8167C16.6138 13.8386 15.9043 14.6707 14.9962 14.6707Z"
                                fill="currentColor"></path>
                        </svg>
                        <h4 class="text-center">Discord </4>
                    </div>
                </div>
                <div class="col-lg-2 col-md-2 col-xs-6 col-sm-6 col-sm-12">
                    <div class="clients-logo">
                        <svg viewBox="0 0 24 24" focusable="false" class="chakra-icon css-1kfbigr">
                            <path
                                d="M20 6.65724C19.3746 6.93839 18.7023 7.12832 17.9969 7.21376C18.7169 6.77637 19.27 6.08376 19.5304 5.25841C18.8564 5.6635 18.11 5.95756 17.3155 6.11605C16.6794 5.42913 15.7729 5 14.7698 5C12.8437 5 11.282 6.58239 11.282 8.53422C11.282 8.81123 11.3128 9.08101 11.3723 9.33967C8.47364 9.19229 5.90375 7.78518 4.18351 5.64688C3.88329 6.16886 3.71125 6.77594 3.71125 7.42368C3.71125 8.6499 4.32699 9.73167 5.26284 10.3655C4.69113 10.3471 4.15334 10.1881 3.68312 9.92341C3.68272 9.93814 3.68272 9.95295 3.68272 9.96785C3.68272 11.6802 4.88496 13.1086 6.4805 13.4335C6.18785 13.5143 5.87972 13.5575 5.56165 13.5575C5.33691 13.5575 5.11846 13.5352 4.90545 13.4941C5.34932 14.8981 6.63733 15.92 8.16359 15.9484C6.96993 16.8964 5.46611 17.4614 3.83198 17.4614C3.55046 17.4614 3.27285 17.4447 3 17.412C4.54352 18.4149 6.3768 19 8.34642 19C14.7616 19 18.2698 13.6146 18.2698 8.94396C18.2698 8.79073 18.2664 8.63835 18.2597 8.48667C18.9411 7.98846 19.5324 7.36605 19.9999 6.65724H20Z"
                                fill="currentColor"></path>
                        </svg>
                        <h4 class="text-center">Twitter </4>
                    </div>
                </div>
                <div class="col-lg-2 col-md-2 col-xs-6 col-sm-6 col-sm-12">
                    <div class="clients-logo">
                        <svg viewBox="0 0 24 24" focusable="false" class="chakra-icon css-1kfbigr">
                            <path fill-rule="evenodd" clip-rule="evenodd"
                                d="M19.4931 5.4082C20.3403 5.63266 21.0012 6.28983 21.2303 7.12907C21.8295 9.52332 21.7905 14.05 21.2429 16.4816C21.0163 17.3209 20.3529 17.9755 19.5057 18.2025C17.1139 18.7886 6.40137 18.7163 4.14808 18.2025C3.30089 17.978 2.64001 17.3209 2.41091 16.4816C1.8457 14.1996 1.88472 9.37368 2.39832 7.14154C2.62491 6.3023 3.28831 5.64762 4.13549 5.42067C7.3329 4.75975 18.3551 4.97299 19.4931 5.4082ZM10.3205 8.78201L14.859 11.8077L10.3205 14.8333V8.78201Z"
                                fill="currentColor"></path>
                        </svg>
                        <h4 class="text-center">YouTube </4>
                    </div>
                </div>
                <div class="col-lg-2 col-md-2 col-xs-6 col-sm-6 col-sm-12">
                    <div class="clients-logo">
                        <svg viewBox="0 0 24 24" focusable="false" class="chakra-icon css-1kfbigr">
                            <path fill-rule="evenodd" clip-rule="evenodd"
                                d="M19.4931 5.4082C20.3403 5.63266 21.0012 6.28983 21.2303 7.12907C21.8295 9.52332 21.7905 14.05 21.2429 16.4816C21.0163 17.3209 20.3529 17.9755 19.5057 18.2025C17.1139 18.7886 6.40137 18.7163 4.14808 18.2025C3.30089 17.978 2.64001 17.3209 2.41091 16.4816C1.8457 14.1996 1.88472 9.37368 2.39832 7.14154C2.62491 6.3023 3.28831 5.64762 4.13549 5.42067C7.3329 4.75975 18.3551 4.97299 19.4931 5.4082ZM10.3205 8.78201L14.859 11.8077L10.3205 14.8333V8.78201Z"
                                fill="currentColor"></path>
                        </svg>
                        <h4 class="text-center">Telegram </4>
                    </div>
                </div>
                <div class="col-lg-2 col-md-2 col-xs-6 col-sm-6 col-sm-12">
                    <div class="clients-logo">
                        <svg viewBox="0 0 24 24" focusable="false" class="chakra-icon css-1kfbigr">
                            <path opacity="0.9" fill-rule="evenodd" clip-rule="evenodd"
                                d="M4.38474 11.4694C9.12086 9.35919 12.2738 7.95703 13.857 7.27678C18.3631 5.34707 19.3103 5.01388 19.9192 5C20.0545 5 20.3522 5.02777 20.5552 5.19436C20.7176 5.33319 20.7582 5.51366 20.7853 5.65249C20.8123 5.79132 20.8394 6.08286 20.8123 6.30498C20.5687 8.94271 19.5133 15.3427 18.972 18.2858C18.742 19.5353 18.2954 19.9518 17.8624 19.9934C16.9152 20.0767 16.198 19.3548 15.2914 18.744C13.857 17.786 13.0586 17.1891 11.6648 16.2451C10.0546 15.1622 11.0965 14.5652 12.0167 13.5934C12.2602 13.3436 16.4145 9.45637 16.4957 9.1093C16.5092 9.06766 16.5092 8.90106 16.4145 8.81776C16.3198 8.73447 16.1844 8.76223 16.0762 8.79C15.9273 8.81777 13.654 10.3726 9.22912 13.4407C8.57959 13.8989 7.99772 14.121 7.46998 14.1071C6.88812 14.0932 5.77851 13.7739 4.93954 13.4963C3.92466 13.1631 3.11275 12.9826 3.18041 12.3995C3.22101 12.0941 3.62696 11.7887 4.38474 11.4694Z"
                                fill="currentColor"></path>
                        </svg>
                        <h4 class="text-center">Github </4>
                    </div>
                </div>
                <div class="col-lg-2 col-md-2 col-xs-6 col-sm-6 col-sm-12">
                    <div class="clients-logo">
                        <img loading="lazy" class="chain-img img-fluid d-block mx-auto coming-soon-img"
                            src="{{ asset('public/assets/img/coming-soon.png') }}" alt="chain img">
                        <h4 class="text-center">Coming Soon </4>
                    </div>
                </div>
            </div>

        </div>
    </section>

    @include('template.country_language')
    @include('template.web_footer')
</body>

</html>