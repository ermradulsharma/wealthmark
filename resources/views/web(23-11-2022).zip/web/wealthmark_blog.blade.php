<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <title>Wealth Mark | {{ Request::segment(2) }}</title>
    @include('template.web_css')
    <link rel='stylesheet' href="{{('../public/assets/css/deepak_custom.css') }}">
</head>

<body onload="typeWriter()">
    @include('template.mobile_menu')
    @include('template.web_menu')

    <section class="wealthmark-blogs" id="wealth-mark-blogs-slider-section">
        <div class="container">
            <div class="row">
                <div class="sec-title text-left mb-3">
                    <span class="title">Know About</span>
                    <h2 class="heading-h2">Wealth Mark Blog</h2>
                    <p>Wealthmark pay is available to all eligible users on Wealthmark.com. To start using Wealthmark
                        Pay, please register on Wealthmark.com and complete your Identity Verification.</p>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">

                    <!-- Carousel -->
                    <div id="demo" class="carousel slide" data-bs-ride="carousel">

                        <!-- Indicators/dots -->
                        <div class="carousel-indicators">
                            <button type="button" data-bs-target="#demo" data-bs-slide-to="0" class="active"></button>
                            <button type="button" data-bs-target="#demo" data-bs-slide-to="1"></button>
                            <button type="button" data-bs-target="#demo" data-bs-slide-to="2"></button>
                        </div>

                        <!-- The slideshow/carousel -->
                        <div class="carousel-inner">
                            <div class="carousel-item active">
                                <div class="row mt-5">
                                    <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12">
                                        <div class="blogs-inner-box-slider">
                                            <img src="{{ asset('public/assets/img/blogs-img-4.png') }}"
                                                class="img-fluid" alt="walth mark blog">
                                        </div>
                                    </div>

                                    <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12">
                                        <div class="blogs-inner-box-slider">
                                            <h1 id="demo_sldier_1"></h1>
                                            <a class="text-warning">2022-10-17 </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <div class="row mt-5">
                                    <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12">
                                        <div class="blogs-inner-box-slider">
                                            <img src="{{ asset('public/assets/img/blogs-img-4.png') }}"
                                                class="img-fluid" alt="walth mark blog">
                                        </div>
                                    </div>

                                    <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12">
                                        <div class="blogs-inner-box-slider">
                                            <h1>Wealthmark crypto to friends and family
                                                worldwide.</h1>
                                            <a class="text-warning">2022-10-17 </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <div class="row mt-5">
                                    <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12">
                                        <div class="blogs-inner-box-slider">
                                            <img src="{{ asset('public/assets/img/blogs-img-4.png') }}"
                                                class="img-fluid" alt="walth mark blog">
                                        </div>
                                    </div>

                                    <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12">
                                        <div class="blogs-inner-box-slider">
                                            <h1>Stay up to date with the latest stories and commentary brought.</h1>
                                            <a class="text-warning">2022-10-17 </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Left and right controls/icons -->
                        <button class="carousel-control-prev" type="button" data-bs-target="#demo" data-bs-slide="prev">
                            <span class="carousel-control-prev-icon"></span>
                        </button>
                        <button class="carousel-control-next" type="button" data-bs-target="#demo" data-bs-slide="next">
                            <span class="carousel-control-next-icon"></span>
                        </button>
                    </div>

                </div>
            </div>
        </div>
    </section>

    <section class="wealthmark-blogs-pills-listing" id="blogs-listing-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12" id="blogs-listing-inner-tabs">
                    <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active" id="pills-from-cz-tab" data-bs-toggle="pill"
                                data-bs-target="#pills-from-cz" type="button" role="tab" aria-controls="pills-from-cz"
                                aria-selected="true">From-CZ</button>
                        </li>

                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="pills-leadership-tab" data-bs-toggle="pill"
                                data-bs-target="#pills-leadership" type="button" role="tab"
                                aria-controls="pills-leadership" aria-selected="false">Leadership</button>
                        </li>

                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="pills-ecosystem-tab" data-bs-toggle="pill"
                                data-bs-target="#pills-ecosystem" type="button" role="tab"
                                aria-controls="pills-ecosystem" aria-selected="false">Ecosystem</button>
                        </li>

                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="pills-Community-tab" data-bs-toggle="pill"
                                data-bs-target="#pills-Community" type="button" role="tab"
                                aria-controls="pills-Community" aria-selected="true">Community</button>
                        </li>

                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="pills-P2P-tab" data-bs-toggle="pill"
                                data-bs-target="#pills-P2P" type="button" role="tab" aria-controls="pills-P2P"
                                aria-selected="false">P2P</button>
                        </li>

                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="pills-Markets-tab" data-bs-toggle="pill"
                                data-bs-target="#pills-Markets" type="button" role="tab" aria-controls="pills-Markets"
                                aria-selected="false">Markets</button>
                        </li>

                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="pills-Payment-tab" data-bs-toggle="pill"
                                data-bs-target="#pills-Payment" type="button" role="tab" aria-controls="pills-Payment"
                                aria-selected="true">Payment</button>
                        </li>

                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="pills-Fiat-tab" data-bs-toggle="pill"
                                data-bs-target="#pills-Fiat" type="button" role="tab" aria-controls="pills-Fiat"
                                aria-selected="false">Fiat</button>
                        </li>

                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="pills-Earn-tab" data-bs-toggle="pill"
                                data-bs-target="#pills-Earn" type="button" role="tab" aria-controls="pills-Earn"
                                aria-selected="false">Earn</button>
                        </li>

                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="pills-Charity-tab" data-bs-toggle="pill"
                                data-bs-target="#pills-Charity" type="button" role="tab" aria-controls="pills-Charity"
                                aria-selected="true">Charity</button>
                        </li>

                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="pills-OTC-tab" data-bs-toggle="pill"
                                data-bs-target="#pills-OTC" type="button" role="tab" aria-controls="pills-OTC"
                                aria-selected="false">OTC</button>
                        </li>

                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="pills-Search-tab" data-bs-toggle="pill"
                                data-bs-target="#pills-Search" type="button" role="tab" aria-controls="pills-Search"
                                aria-selected="false"> <svg width="16" height="16" fill="currentColor"
                                    class="bi bi-search" viewBox="0 0 16 16">
                                    <path
                                        d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z" />
                                </svg></button>
                        </li>
                    </ul>
                    <div class="tab-content" id="pills-tabContent">


                        <div class="tab-pane fade show active" id="pills-from-cz" role="tabpanel"
                            aria-labelledby="pills-from-cz-tab">

                            <div class="row mt-4 mb-4" id="blogs-list-tabs">
                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-1.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-2.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-3.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-4.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>3 Reasons Why Traders Use Wealth Mark Convert</h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-5.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-6.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Convert Cash to BUSD to Earn up to 8% Interest</h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-1.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-2.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-3.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-4.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-5.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-6.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                            </div>

                        </div>

                        <div class="tab-pane fade" id="pills-leadership" role="tabpanel"
                            aria-labelledby="pills-leadership-tab">
                            <div class="row mt-4 mb-4">
                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-1.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-2.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-3.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-4.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>3 Reasons Why Traders Use Wealth Mark Convert</h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-5.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-6.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Convert Cash to BUSD to Earn up to 8% Interest</h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-1.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-2.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-3.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-4.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-5.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-6.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                            </div>
                        </div>

                        <div class="tab-pane fade" id="pills-ecosystem" role="tabpanel"
                            aria-labelledby="pills-ecosystem-tab">
                            <div class="row mt-4 mb-4">
                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-1.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-2.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-3.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-4.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>3 Reasons Why Traders Use Wealth Mark Convert</h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-5.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-6.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Convert Cash to BUSD to Earn up to 8% Interest</h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-1.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-2.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-3.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-4.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-5.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-6.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                            </div>
                        </div>

                        <div class="tab-pane fade" id="pills-Community" role="tabpanel"
                            aria-labelledby="pills-Community-tab">
                            <div class="row mt-4 mb-4">
                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-1.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-2.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-3.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-4.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>3 Reasons Why Traders Use Wealth Mark Convert</h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-5.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-6.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Convert Cash to BUSD to Earn up to 8% Interest</h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-1.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-2.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-3.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-4.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-5.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-6.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                            </div>
                        </div>

                        <div class="tab-pane fade" id="pills-P2P" role="tabpanel" aria-labelledby="pills-P2P-tab">
                            <div class="row mt-4 mb-4">
                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-1.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-2.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-3.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-4.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>3 Reasons Why Traders Use Wealth Mark Convert</h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-5.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-6.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Convert Cash to BUSD to Earn up to 8% Interest</h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-1.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-2.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-3.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-4.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-5.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-6.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                            </div>
                        </div>

                        <div class="tab-pane fade" id="pills-Markets" role="tabpanel"
                            aria-labelledby="pills-Markets-tab">
                            <div class="row mt-4 mb-4">
                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-1.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-2.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-3.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-4.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>3 Reasons Why Traders Use Wealth Mark Convert</h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-5.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-6.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Convert Cash to BUSD to Earn up to 8% Interest</h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-1.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-2.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-3.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-4.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-5.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-6.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                            </div>
                        </div>

                        <div class="tab-pane fade" id="pills-Payment" role="tabpanel"
                            aria-labelledby="pills-Payment-tab">
                            <div class="row mt-4 mb-4">
                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-1.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-2.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-3.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-4.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>3 Reasons Why Traders Use Wealth Mark Convert</h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-5.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-6.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Convert Cash to BUSD to Earn up to 8% Interest</h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-1.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-2.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-3.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-4.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-5.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-6.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                            </div>
                        </div>

                        <div class="tab-pane fade" id="pills-Fiat" role="tabpanel" aria-labelledby="pills-Fiat-tab">

                            <div class="row mt-4 mb-4">
                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-1.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-2.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-3.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-4.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>3 Reasons Why Traders Use Wealth Mark Convert</h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-5.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-6.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Convert Cash to BUSD to Earn up to 8% Interest</h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-1.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-2.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-3.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-4.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-5.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-6.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                            </div>

                        </div>

                        <div class="tab-pane fade" id="pills-Earn" role="tabpanel" aria-labelledby="pills-Earn-tab">
                            <div class="row mt-4 mb-4">
                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-1.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-2.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-3.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-4.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>3 Reasons Why Traders Use Wealth Mark Convert</h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-5.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-6.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Convert Cash to BUSD to Earn up to 8% Interest</h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-1.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-2.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-3.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-4.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-5.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-6.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                            </div>

                        </div>

                        <div class="tab-pane fade" id="pills-Charity" role="tabpanel"
                            aria-labelledby="pills-Charity-tab">
                            <div class="row mt-4 mb-4">
                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-1.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-2.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-3.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-4.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>3 Reasons Why Traders Use Wealth Mark Convert</h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-5.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-6.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Convert Cash to BUSD to Earn up to 8% Interest</h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-1.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-2.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-3.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-4.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-5.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-6.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                            </div>
                        </div>

                        <div class="tab-pane fade" id="pills-OTC" role="tabpanel" aria-labelledby="pills-OTC-tab">

                            <div class="row mt-4 mb-4">
                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-1.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-2.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-3.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-4.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>3 Reasons Why Traders Use Wealth Mark Convert</h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-5.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-6.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Convert Cash to BUSD to Earn up to 8% Interest</h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-1.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-2.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-3.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-4.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-5.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                                <div class="col-md-4 col-lg-4 col-sm-6">
                                    <div class="blogs-inner-box">
                                        <img src="{{ asset('public/assets/img/blogs-img-6.png') }}" class="img-fluid"
                                            alt="walth mark blog">
                                        <h4>Our Response to the Latest Reuters Story </h4>
                                        <p>CZ replies to the latest Reuters piece with his insights, thoughts, and
                                            feelings on the
                                            topics raised. </p>
                                        <a class="text-warning">2022-10-17 </a>
                                    </div>
                                </div>

                            </div>
                        </div>

                        <div class="tab-pane fade" id="pills-Search" role="tabpanel" aria-labelledby="pills-Search-tab">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="blogs-search-post">
                                        <div class="input-group mb-3">
                                            <input type="text" class="form-control" placeholder="Search Post"
                                                aria-label="Search Post" aria-describedby="basic-addon2">
                                            <span class="input-group-text" id="basic-addon2">Search</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>

    <script>
    var i = 0;
    var txt = 'A Letter from Our CEO: 5 Years of Protecting Users and Supporting';
    var speed = 50;

    function typeWriter() {
        if (i < txt.length) {
            document.getElementById("demo_sldier_1").innerHTML += txt.charAt(i);
            i++;
            setTimeout(typeWriter, speed);
        }
    }
    </script>
    @include('template.country_language')
    @include('template.web_footer')
</body>

</html>