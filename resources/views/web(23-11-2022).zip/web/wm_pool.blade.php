  <!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
   <head>
      <meta charset="utf-8">
      <meta content="width=device-width, initial-scale=1.0" name="viewport">
      <title>Wealth Mark | Create Entity Account</title>
  @include('template.web_css')
       <!--<link rel="stylesheet" href="https://www.wealthmark.io/public/assets/css/dashboard.css">-->
  
 <style>
     #header{
         background:white;
         
     }


 </style>
  
  
   </head>
   
 <body class="bg-white">
     
     @include('template.mobile_menu')
        @include('template.web_menu')
    
   


   <div class="Liquid_Swap_top pt-5 mb-0 pb-0">
     <div class="container">
         <div class="row align-items-center justify-content-center" >
             <div class="col-md-8 col-sm-10 col-xs-12">
                <div class="sec-title text-center">
                            <span class="title">Welcome to Wealthmark</span>
                            <h2 class="heading-h2 text-white">Wealthmark Liquid Swap </h2>
                            <div class="text text-center text-white">Trade Instantly & Pool Tokens to Earn Rewards</div>
                        </div>
                 
             </div>
             
         </div>
         
         </div>
     
 </div>




 <div class="Liquid_Swap_bg-overlay">
   <div class="container">
     <div class="tab-pills-div-top">
       <div class="tab-pills-div-top-left scrollbar-style">
         <a href="{{ url( app()->getLocale(), 'wm-pool') }}" class="lp-link-top">
           <div class="active-tab lp-link-top-active">
             <div class="lp-link-top-block-inner">
               <div class="lp-link-top-txt">Overview</div>
               </div>
              </div>
         </a>
         <a href="{{ url( app()->getLocale(), 'liquidity-farming') }}" class="lp-link-top">
           <div class=" lp-link-top-block">
             <div class="lp-link-top-block-inner">
               <div class="lp-link-top-txt">Liquidity</div>
                </div>
            </div>
         </a>
         <a href="{{ url( app()->getLocale(), 'swap-farming') }}" class="lp-link-top">
           <div class=" lp-link-top-block">
             <div class="lp-link-top-block-inner">
                <div class="lp-link-top-txt">Swap</div>
                 <div class="lp-reward">
                   <div class="lp-reward-txt">Rewards</div>
                 </div>
               </div>
            </div>
         </a>
         <div class="lp-link-top-block">
           <div class="lp-link-top-block-inner">
             <div class="lp-link-top-txt">History</div>
           </div>
          </div>
       </div>
       <div class="tab-pills-div-top-right">
         <button type="button" class=" tutorial-btn">
           <svg viewBox="0 0 24 24" fill="none" class="tutorial-btn-video">
             <path d="M12 3.35c-4.8 0-8.8 3.9-8.8 8.8 0 4.8 3.9 8.8 8.8 8.8s8.8-3.9 8.8-8.8c0-4.8-4-8.8-8.8-8.8zm0 15.6c-3.7 0-6.8-3-6.8-6.8 0-3.7 3-6.8 6.8-6.8s6.8 3 6.8 6.8c0 3.7-3.1 6.8-6.8 6.8z" fill="currentColor"></path>
             <path d="M16.5 12.15l-6.8-3.9v7.8l6.8-3.9z" fill="currentColor"></path>
           </svg>
           <div class="tutorial-btn-txt">Tutorial</div>
         </button>
         <a href="#" class="tab-pills-div-top-right-txt">FAQ</a>
       </div>
     </div>
   </div>
 </div>
   
 

  
   <section id="wm-pool-tbl-record">
       
       <div class="container">
           <div class="dashboard-tabpills">
            <div class="dashboard-card-body">
                        <ul class="nav nav-pills my-1 border-bottom" id="pills-tab" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active" id="pills-spot-tab" data-bs-toggle="pill" data-bs-target="#pills-spot" type="button" role="tab" aria-controls="pills-spot" aria-selected="false">Stable</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="pills-p2p-tab" data-bs-toggle="pill" data-bs-target="#pills-p2p" type="button" role="tab" aria-controls="pills-p2p" aria-selected="false">Innovative</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link " id="pills-margin-tab" data-bs-toggle="pill" data-bs-target="#pills-margin" type="button" role="tab" aria-controls="pills-margin" aria-selected="true">Watchlist</button>
                        </li>
                        
                     
                        </ul>
                    <div class="tab-content mt-5" id="pills-tabContent">
                        <div class="tab-pane fade active show" id="pills-spot" role="tabpanel" aria-labelledby="pills-spot-tab">
                            <div class="table-responsive">
            <table class="table  table-borderless ">
                <thead class="thead-dark">
                    <tr>
                        <th scope="col">Pool</th>
                        <th scope="col">Total Yield</th>
                        <th scope="col">Total Yield. </th>
                        <th scope="col">Reward Coins</th>
                        <th scope="col">Volume (24hr)</th>
                         <th scope="col">Operation</th>
                    </tr>
                </thead>
                <tbody>
                    <tr class="trpool">
                        <td data-label="Pool">
                            <div class="">
                     
                      <div class="wp-pool-tbl-div1">
                        <div class="pool-wm-coin-div">
                          <div class="pool-wm-coin-div-inner">
                            <img class="pool-wm-coin-div-inner-img-1" src="https://www.wealthmark.io/public/assets/img/86c97fe9-1b7d-41ca-b5d4-a646baa22f47.png">
                            <img class="pool-wm-coin-div-inner-img-2" src="https://www.wealthmark.io/public/assets/img/2b5c7d80-7bcd-4cfb-8bd9-d1760a752afc.png">
                          </div>
                        </div>
                        <div class="pool-wm-coin-title-main">IOTX/USDT</div>
                      </div>
                    </div>
                  </td>
                        <td data-label="Total Yield">
                            <div class="Yield_div">
                      <div class="Yield_title">795,926 USD</div>
                      <div class="Yield_subtitle">15,333,972 IOTX + 398,010 USDT</div>
                    </div>
                        </td>
                        <td data-label="Total Yield">
                            <div class="d-flex">
                      <div class="Yield_precentage">2.65%</div>
                      <div class="Yield_precentage-icn-div">
                        <svg viewBox="0 0 48 48" fill="none" cursor="pointer" class="Yield_precentage-icn-div-info">
                          <path d="M25 16.67h-2v2h2v-2zM25 20.67h-2v10.68h2V20.67z" fill="currentColor"></path>
                          <path d="M24 12c6.62 0 12 5.38 12 12s-5.38 12-12 12-12-5.38-12-12 5.38-12 12-12zm0-2c-7.73 0-14 6.27-14 14s6.27 14 14 14 14-6.27 14-14-6.27-14-14-14z" fill="currentColor"></path>
                        </svg>
                      </div>
                    </div>
                        </td>
                        <td data-label="Reward Coins">
                            <div class="">
                      <div class="wp-pool-tbl-div1">
                        <div class="wp-pool-tbl-div-img">
                          <img class="wp-pool-tbl-div-img--" src="https://www.wealthmark.io/public/assets/img/2b5c7d80-7bcd-4cfb-8bd9-d1760a752afc.png">
                          
                        </div>
                        <div class="wp-pool-tbl-reward-txt">IOTX</div>
                      </div>
                    </div>
                        </td>
                        <td data-label="Reward Coins">
                            <div class="wp-pool-valume">115,914 USD</div>
                        </td>
                        <td data-label="Reward Coins">
                    <div class="pool-operation">
                      <div class="btn-yellow active">Add</div>
                      <div class="btn-yellow inactive">Remove</div>
                      <div class="btn-yellow inactive">Swap</div>
                      <div class="btn-yellow inactive">My Portion</div>
                    </div>
                        </td>
                    </tr>
                     <tr class="trpool">
                        <td data-label="Pool">
                            <div class="">
                     
                      <div class="wp-pool-tbl-div1">
                        <div class="pool-wm-coin-div">
                          <div class="pool-wm-coin-div-inner">
                            <img class="pool-wm-coin-div-inner-img-1" src="https://www.wealthmark.io/public/assets/img/86c97fe9-1b7d-41ca-b5d4-a646baa22f47.png">
                            <img class="pool-wm-coin-div-inner-img-2" src="https://www.wealthmark.io/public/assets/img/2b5c7d80-7bcd-4cfb-8bd9-d1760a752afc.png">
                          </div>
                        </div>
                        <div class="pool-wm-coin-title-main">IOTX/USDT</div>
                      </div>
                    </div>
                  </td>
                        <td data-label="Total Yield">
                            <div class="Yield_div">
                      <div class="Yield_title">795,926 USD</div>
                      <div class="Yield_subtitle">15,333,972 IOTX + 398,010 USDT</div>
                    </div>
                        </td>
                        <td data-label="Total Yield">
                            <div class="d-flex">
                      <div class="Yield_precentage">2.65%</div>
                      <div class="Yield_precentage-icn-div">
                        <svg viewBox="0 0 48 48" fill="none" cursor="pointer" class="Yield_precentage-icn-div-info">
                          <path d="M25 16.67h-2v2h2v-2zM25 20.67h-2v10.68h2V20.67z" fill="currentColor"></path>
                          <path d="M24 12c6.62 0 12 5.38 12 12s-5.38 12-12 12-12-5.38-12-12 5.38-12 12-12zm0-2c-7.73 0-14 6.27-14 14s6.27 14 14 14 14-6.27 14-14-6.27-14-14-14z" fill="currentColor"></path>
                        </svg>
                      </div>
                    </div>
                        </td>
                        <td data-label="Reward Coins">
                            <div class="">
                      <div class="wp-pool-tbl-div1">
                        <div class="wp-pool-tbl-div-img">
                          <img class="wp-pool-tbl-div-img--" src="https://www.wealthmark.io/public/assets/img/2b5c7d80-7bcd-4cfb-8bd9-d1760a752afc.png">
                          
                        </div>
                        <div class="wp-pool-tbl-reward-txt">IOTX</div>
                      </div>
                    </div>
                        </td>
                        <td data-label="Reward Coins">
                            <div class="wp-pool-valume">115,914 USD</div>
                        </td>
                        <td data-label="Reward Coins">
                    <div class="pool-operation">
                      <div class="btn-yellow active">Add</div>
                      <div class="btn-yellow inactive">Remove</div>
                      <div class="btn-yellow inactive">Swap</div>
                      <div class="btn-yellow inactive">My Portion</div>
                    </div>
                        </td>
                    </tr>
                     <tr class="trpool">
                        <td data-label="Pool">
                            <div class="">
                     
                      <div class="wp-pool-tbl-div1">
                        <div class="pool-wm-coin-div">
                          <div class="pool-wm-coin-div-inner">
                            <img class="pool-wm-coin-div-inner-img-1" src="https://www.wealthmark.io/public/assets/img/86c97fe9-1b7d-41ca-b5d4-a646baa22f47.png">
                            <img class="pool-wm-coin-div-inner-img-2" src="https://www.wealthmark.io/public/assets/img/2b5c7d80-7bcd-4cfb-8bd9-d1760a752afc.png">
                          </div>
                        </div>
                        <div class="pool-wm-coin-title-main">IOTX/USDT</div>
                      </div>
                    </div>
                  </td>
                        <td data-label="Total Yield">
                            <div class="Yield_div">
                      <div class="Yield_title">795,926 USD</div>
                      <div class="Yield_subtitle">15,333,972 IOTX + 398,010 USDT</div>
                    </div>
                        </td>
                        <td data-label="Total Yield">
                            <div class="d-flex">
                      <div class="Yield_precentage">2.65%</div>
                      <div class="Yield_precentage-icn-div">
                        <svg viewBox="0 0 48 48" fill="none" cursor="pointer" class="Yield_precentage-icn-div-info">
                          <path d="M25 16.67h-2v2h2v-2zM25 20.67h-2v10.68h2V20.67z" fill="currentColor"></path>
                          <path d="M24 12c6.62 0 12 5.38 12 12s-5.38 12-12 12-12-5.38-12-12 5.38-12 12-12zm0-2c-7.73 0-14 6.27-14 14s6.27 14 14 14 14-6.27 14-14-6.27-14-14-14z" fill="currentColor"></path>
                        </svg>
                      </div>
                    </div>
                        </td>
                        <td data-label="Reward Coins">
                            <div class="">
                      <div class="wp-pool-tbl-div1">
                        <div class="wp-pool-tbl-div-img">
                          <img class="wp-pool-tbl-div-img--" src="https://www.wealthmark.io/public/assets/img/2b5c7d80-7bcd-4cfb-8bd9-d1760a752afc.png">
                          
                        </div>
                        <div class="wp-pool-tbl-reward-txt">IOTX</div>
                      </div>
                    </div>
                        </td>
                        <td data-label="Reward Coins">
                            <div class="wp-pool-valume">115,914 USD</div>
                        </td>
                        <td data-label="Reward Coins">
                    <div class="pool-operation">
                      <div class="btn-yellow active">Add</div>
                      <div class="btn-yellow inactive">Remove</div>
                      <div class="btn-yellow inactive">Swap</div>
                      <div class="btn-yellow inactive">My Portion</div>
                    </div>
                        </td>
                    </tr>
                     <tr class="trpool">
                        <td data-label="Pool">
                            <div class="">
                     
                      <div class="wp-pool-tbl-div1">
                        <div class="pool-wm-coin-div">
                          <div class="pool-wm-coin-div-inner">
                            <img class="pool-wm-coin-div-inner-img-1" src="https://www.wealthmark.io/public/assets/img/86c97fe9-1b7d-41ca-b5d4-a646baa22f47.png">
                            <img class="pool-wm-coin-div-inner-img-2" src="https://www.wealthmark.io/public/assets/img/2b5c7d80-7bcd-4cfb-8bd9-d1760a752afc.png">
                          </div>
                        </div>
                        <div class="pool-wm-coin-title-main">IOTX/USDT</div>
                      </div>
                    </div>
                  </td>
                        <td data-label="Total Yield">
                            <div class="Yield_div">
                      <div class="Yield_title">795,926 USD</div>
                      <div class="Yield_subtitle">15,333,972 IOTX + 398,010 USDT</div>
                    </div>
                        </td>
                        <td data-label="Total Yield">
                            <div class="d-flex">
                      <div class="Yield_precentage">2.65%</div>
                      <div class="Yield_precentage-icn-div">
                        <svg viewBox="0 0 48 48" fill="none" cursor="pointer" class="Yield_precentage-icn-div-info">
                          <path d="M25 16.67h-2v2h2v-2zM25 20.67h-2v10.68h2V20.67z" fill="currentColor"></path>
                          <path d="M24 12c6.62 0 12 5.38 12 12s-5.38 12-12 12-12-5.38-12-12 5.38-12 12-12zm0-2c-7.73 0-14 6.27-14 14s6.27 14 14 14 14-6.27 14-14-6.27-14-14-14z" fill="currentColor"></path>
                        </svg>
                      </div>
                    </div>
                        </td>
                        <td data-label="Reward Coins">
                            <div class="">
                      <div class="wp-pool-tbl-div1">
                        <div class="wp-pool-tbl-div-img">
                          <img class="wp-pool-tbl-div-img--" src="https://www.wealthmark.io/public/assets/img/2b5c7d80-7bcd-4cfb-8bd9-d1760a752afc.png">
                          
                        </div>
                        <div class="wp-pool-tbl-reward-txt">IOTX</div>
                      </div>
                    </div>
                        </td>
                        <td data-label="Reward Coins">
                            <div class="wp-pool-valume">115,914 USD</div>
                        </td>
                        <td data-label="Reward Coins">
                    <div class="pool-operation">
                      <div class="btn-yellow active">Add</div>
                      <div class="btn-yellow inactive">Remove</div>
                      <div class="btn-yellow inactive">Swap</div>
                      <div class="btn-yellow inactive">My Portion</div>
                    </div>
                        </td>
                    </tr>
                     <tr class="trpool">
                        <td data-label="Pool">
                            <div class="">
                     
                      <div class="wp-pool-tbl-div1">
                        <div class="pool-wm-coin-div">
                          <div class="pool-wm-coin-div-inner">
                            <img class="pool-wm-coin-div-inner-img-1" src="https://www.wealthmark.io/public/assets/img/86c97fe9-1b7d-41ca-b5d4-a646baa22f47.png">
                            <img class="pool-wm-coin-div-inner-img-2" src="https://www.wealthmark.io/public/assets/img/2b5c7d80-7bcd-4cfb-8bd9-d1760a752afc.png">
                          </div>
                        </div>
                        <div class="pool-wm-coin-title-main">IOTX/USDT</div>
                      </div>
                    </div>
                  </td>
                        <td data-label="Total Yield">
                            <div class="Yield_div">
                      <div class="Yield_title">795,926 USD</div>
                      <div class="Yield_subtitle">15,333,972 IOTX + 398,010 USDT</div>
                    </div>
                        </td>
                        <td data-label="Total Yield">
                            <div class="d-flex">
                      <div class="Yield_precentage">2.65%</div>
                      <div class="Yield_precentage-icn-div">
                        <svg viewBox="0 0 48 48" fill="none" cursor="pointer" class="Yield_precentage-icn-div-info">
                          <path d="M25 16.67h-2v2h2v-2zM25 20.67h-2v10.68h2V20.67z" fill="currentColor"></path>
                          <path d="M24 12c6.62 0 12 5.38 12 12s-5.38 12-12 12-12-5.38-12-12 5.38-12 12-12zm0-2c-7.73 0-14 6.27-14 14s6.27 14 14 14 14-6.27 14-14-6.27-14-14-14z" fill="currentColor"></path>
                        </svg>
                      </div>
                    </div>
                        </td>
                        <td data-label="Reward Coins">
                            <div class="">
                      <div class="wp-pool-tbl-div1">
                        <div class="wp-pool-tbl-div-img">
                          <img class="wp-pool-tbl-div-img--" src="https://www.wealthmark.io/public/assets/img/2b5c7d80-7bcd-4cfb-8bd9-d1760a752afc.png">
                          
                        </div>
                        <div class="wp-pool-tbl-reward-txt">IOTX</div>
                      </div>
                    </div>
                        </td>
                        <td data-label="Reward Coins">
                            <div class="wp-pool-valume">115,914 USD</div>
                        </td>
                        <td data-label="Reward Coins">
                    <div class="pool-operation">
                      <div class="btn-yellow active">Add</div>
                      <div class="btn-yellow inactive">Remove</div>
                      <div class="btn-yellow inactive">Swap</div>
                      <div class="btn-yellow inactive">My Portion</div>
                    </div>
                        </td>
                    </tr>
                   
                </tbody>
            </table>
        </div>
                            <div class="pagination-div mt-3">
                   <button type="button" class="mirror pagination-back" aria-label="Previous page" disabled="">
                     <svg viewBox="0 0 24 24" fill="none" class="custom-modal-close-icon">
                       <path fill-rule="evenodd" clip-rule="evenodd" d="M11.934 12l3.89 3.89-1.769 1.767L8.398 12l1.768-1.768 3.89-3.889 1.767 1.768-3.889 3.89z" fill="currentColor"></path>
                     </svg>
                   </button>
                   <button type="button" aria-label="Page number 1" class="pagination-active" disabled="">1</button>
                   <button type="button" aria-label="Page number 2" class="pagination-all">2</button>
                   <button type="button" aria-label="Page number 3" class="pagination-all">3</button>
                   <button type="button" aria-label="Page number 4" class="pagination-all">4</button>
                   <button type="button" aria-label="Page number 5" class="pagination-all">5</button>
                   <button type="button" class="mirror pagination-next" aria-label="Next page">
                     <svg viewBox="0 0 24 24" fill="none" class="custom-modal-close-icon">
                       <path fill-rule="evenodd" clip-rule="evenodd" d="M12.288 12l-3.89 3.89 1.768 1.767L15.823 12l-1.768-1.768-3.889-3.889-1.768 1.768 3.89 3.89z" fill="currentColor"></path>
                     </svg>
                   </button>
                 </div>
                        </div>
                        
                        <div class="tab-pane fade" id="pills-p2p" role="tabpanel" aria-labelledby="pills-p2p-tab">
                            <div class="table-responsive">
            <table class="table  table-borderless ">
                <thead class="thead-dark">
                    <tr>
                        <th scope="col">Pool</th>
                        <th scope="col">Total Yield</th>
                        <th scope="col">Total Yield. </th>
                        <th scope="col">Reward Coins</th>
                        <th scope="col">Volume (24hr)</th>
                         <th scope="col">Operation</th>
                    </tr>
                </thead>
                <tbody>
                    <tr class="trpool">
                        <td data-label="Pool">
                            <div class="">
                     
                      <div class="wp-pool-tbl-div1">
                        <div class="pool-wm-coin-div">
                          <div class="pool-wm-coin-div-inner">
                            <img class="pool-wm-coin-div-inner-img-1" src="https://www.wealthmark.io/public/assets/img/86c97fe9-1b7d-41ca-b5d4-a646baa22f47.png">
                            <img class="pool-wm-coin-div-inner-img-2" src="https://www.wealthmark.io/public/assets/img/2b5c7d80-7bcd-4cfb-8bd9-d1760a752afc.png">
                          </div>
                        </div>
                        <div class="pool-wm-coin-title-main">IOTX/USDT</div>
                      </div>
                    </div>
                  </td>
                        <td data-label="Total Yield">
                            <div class="Yield_div">
                      <div class="Yield_title">795,926 USD</div>
                      <div class="Yield_subtitle">15,333,972 IOTX + 398,010 USDT</div>
                    </div>
                        </td>
                        <td data-label="Total Yield">
                            <div class="d-flex">
                      <div class="Yield_precentage">2.65%</div>
                      <div class="Yield_precentage-icn-div">
                        <svg viewBox="0 0 48 48" fill="none" cursor="pointer" class="Yield_precentage-icn-div-info">
                          <path d="M25 16.67h-2v2h2v-2zM25 20.67h-2v10.68h2V20.67z" fill="currentColor"></path>
                          <path d="M24 12c6.62 0 12 5.38 12 12s-5.38 12-12 12-12-5.38-12-12 5.38-12 12-12zm0-2c-7.73 0-14 6.27-14 14s6.27 14 14 14 14-6.27 14-14-6.27-14-14-14z" fill="currentColor"></path>
                        </svg>
                      </div>
                    </div>
                        </td>
                        <td data-label="Reward Coins">
                            <div class="">
                      <div class="wp-pool-tbl-div1">
                        <div class="wp-pool-tbl-div-img">
                          <img class="wp-pool-tbl-div-img--" src="https://www.wealthmark.io/public/assets/img/2b5c7d80-7bcd-4cfb-8bd9-d1760a752afc.png">
                          
                        </div>
                        <div class="wp-pool-tbl-reward-txt">IOTX</div>
                      </div>
                    </div>
                        </td>
                        <td data-label="Reward Coins">
                            <div class="wp-pool-valume">115,914 USD</div>
                        </td>
                        <td data-label="Reward Coins">
                    <div class="pool-operation">
                      <div class="btn-yellow active">Add</div>
                      <div class="btn-yellow inactive">Remove</div>
                      <div class="btn-yellow inactive">Swap</div>
                      <div class="btn-yellow inactive">My Portion</div>
                    </div>
                        </td>
                    </tr>
                     <tr class="trpool">
                        <td data-label="Pool">
                            <div class="">
                     
                      <div class="wp-pool-tbl-div1">
                        <div class="pool-wm-coin-div">
                          <div class="pool-wm-coin-div-inner">
                            <img class="pool-wm-coin-div-inner-img-1" src="https://www.wealthmark.io/public/assets/img/86c97fe9-1b7d-41ca-b5d4-a646baa22f47.png">
                            <img class="pool-wm-coin-div-inner-img-2" src="https://www.wealthmark.io/public/assets/img/2b5c7d80-7bcd-4cfb-8bd9-d1760a752afc.png">
                          </div>
                        </div>
                        <div class="pool-wm-coin-title-main">IOTX/USDT</div>
                      </div>
                    </div>
                  </td>
                        <td data-label="Total Yield">
                            <div class="Yield_div">
                      <div class="Yield_title">795,926 USD</div>
                      <div class="Yield_subtitle">15,333,972 IOTX + 398,010 USDT</div>
                    </div>
                        </td>
                        <td data-label="Total Yield">
                            <div class="d-flex">
                      <div class="Yield_precentage">2.65%</div>
                      <div class="Yield_precentage-icn-div">
                        <svg viewBox="0 0 48 48" fill="none" cursor="pointer" class="Yield_precentage-icn-div-info">
                          <path d="M25 16.67h-2v2h2v-2zM25 20.67h-2v10.68h2V20.67z" fill="currentColor"></path>
                          <path d="M24 12c6.62 0 12 5.38 12 12s-5.38 12-12 12-12-5.38-12-12 5.38-12 12-12zm0-2c-7.73 0-14 6.27-14 14s6.27 14 14 14 14-6.27 14-14-6.27-14-14-14z" fill="currentColor"></path>
                        </svg>
                      </div>
                    </div>
                        </td>
                        <td data-label="Reward Coins">
                            <div class="">
                      <div class="wp-pool-tbl-div1">
                        <div class="wp-pool-tbl-div-img">
                          <img class="wp-pool-tbl-div-img--" src="https://www.wealthmark.io/public/assets/img/2b5c7d80-7bcd-4cfb-8bd9-d1760a752afc.png">
                          
                        </div>
                        <div class="wp-pool-tbl-reward-txt">IOTX</div>
                      </div>
                    </div>
                        </td>
                        <td data-label="Reward Coins">
                            <div class="wp-pool-valume">115,914 USD</div>
                        </td>
                        <td data-label="Reward Coins">
                    <div class="pool-operation">
                      <div class="btn-yellow active">Add</div>
                      <div class="btn-yellow inactive">Remove</div>
                      <div class="btn-yellow inactive">Swap</div>
                      <div class="btn-yellow inactive">My Portion</div>
                    </div>
                        </td>
                    </tr>
                     <tr class="trpool">
                        <td data-label="Pool">
                            <div class="">
                     
                      <div class="wp-pool-tbl-div1">
                        <div class="pool-wm-coin-div">
                          <div class="pool-wm-coin-div-inner">
                            <img class="pool-wm-coin-div-inner-img-1" src="https://www.wealthmark.io/public/assets/img/86c97fe9-1b7d-41ca-b5d4-a646baa22f47.png">
                            <img class="pool-wm-coin-div-inner-img-2" src="https://www.wealthmark.io/public/assets/img/2b5c7d80-7bcd-4cfb-8bd9-d1760a752afc.png">
                          </div>
                        </div>
                        <div class="pool-wm-coin-title-main">IOTX/USDT</div>
                      </div>
                    </div>
                  </td>
                        <td data-label="Total Yield">
                            <div class="Yield_div">
                      <div class="Yield_title">795,926 USD</div>
                      <div class="Yield_subtitle">15,333,972 IOTX + 398,010 USDT</div>
                    </div>
                        </td>
                        <td data-label="Total Yield">
                            <div class="d-flex">
                      <div class="Yield_precentage">2.65%</div>
                      <div class="Yield_precentage-icn-div">
                        <svg viewBox="0 0 48 48" fill="none" cursor="pointer" class="Yield_precentage-icn-div-info">
                          <path d="M25 16.67h-2v2h2v-2zM25 20.67h-2v10.68h2V20.67z" fill="currentColor"></path>
                          <path d="M24 12c6.62 0 12 5.38 12 12s-5.38 12-12 12-12-5.38-12-12 5.38-12 12-12zm0-2c-7.73 0-14 6.27-14 14s6.27 14 14 14 14-6.27 14-14-6.27-14-14-14z" fill="currentColor"></path>
                        </svg>
                      </div>
                    </div>
                        </td>
                        <td data-label="Reward Coins">
                            <div class="">
                      <div class="wp-pool-tbl-div1">
                        <div class="wp-pool-tbl-div-img">
                          <img class="wp-pool-tbl-div-img--" src="https://www.wealthmark.io/public/assets/img/2b5c7d80-7bcd-4cfb-8bd9-d1760a752afc.png">
                          
                        </div>
                        <div class="wp-pool-tbl-reward-txt">IOTX</div>
                      </div>
                    </div>
                        </td>
                        <td data-label="Reward Coins">
                            <div class="wp-pool-valume">115,914 USD</div>
                        </td>
                        <td data-label="Reward Coins">
                    <div class="pool-operation">
                      <div class="btn-yellow active">Add</div>
                      <div class="btn-yellow inactive">Remove</div>
                      <div class="btn-yellow inactive">Swap</div>
                      <div class="btn-yellow inactive">My Portion</div>
                    </div>
                        </td>
                    </tr>
                     <tr class="trpool">
                        <td data-label="Pool">
                            <div class="">
                     
                      <div class="wp-pool-tbl-div1">
                        <div class="pool-wm-coin-div">
                          <div class="pool-wm-coin-div-inner">
                            <img class="pool-wm-coin-div-inner-img-1" src="https://www.wealthmark.io/public/assets/img/86c97fe9-1b7d-41ca-b5d4-a646baa22f47.png">
                            <img class="pool-wm-coin-div-inner-img-2" src="https://www.wealthmark.io/public/assets/img/2b5c7d80-7bcd-4cfb-8bd9-d1760a752afc.png">
                          </div>
                        </div>
                        <div class="pool-wm-coin-title-main">IOTX/USDT</div>
                      </div>
                    </div>
                  </td>
                        <td data-label="Total Yield">
                            <div class="Yield_div">
                      <div class="Yield_title">795,926 USD</div>
                      <div class="Yield_subtitle">15,333,972 IOTX + 398,010 USDT</div>
                    </div>
                        </td>
                        <td data-label="Total Yield">
                            <div class="d-flex">
                      <div class="Yield_precentage">2.65%</div>
                      <div class="Yield_precentage-icn-div">
                        <svg viewBox="0 0 48 48" fill="none" cursor="pointer" class="Yield_precentage-icn-div-info">
                          <path d="M25 16.67h-2v2h2v-2zM25 20.67h-2v10.68h2V20.67z" fill="currentColor"></path>
                          <path d="M24 12c6.62 0 12 5.38 12 12s-5.38 12-12 12-12-5.38-12-12 5.38-12 12-12zm0-2c-7.73 0-14 6.27-14 14s6.27 14 14 14 14-6.27 14-14-6.27-14-14-14z" fill="currentColor"></path>
                        </svg>
                      </div>
                    </div>
                        </td>
                        <td data-label="Reward Coins">
                            <div class="">
                      <div class="wp-pool-tbl-div1">
                        <div class="wp-pool-tbl-div-img">
                          <img class="wp-pool-tbl-div-img--" src="https://www.wealthmark.io/public/assets/img/2b5c7d80-7bcd-4cfb-8bd9-d1760a752afc.png">
                          
                        </div>
                        <div class="wp-pool-tbl-reward-txt">IOTX</div>
                      </div>
                    </div>
                        </td>
                        <td data-label="Reward Coins">
                            <div class="wp-pool-valume">115,914 USD</div>
                        </td>
                        <td data-label="Reward Coins">
                    <div class="pool-operation">
                      <div class="btn-yellow active">Add</div>
                      <div class="btn-yellow inactive">Remove</div>
                      <div class="btn-yellow inactive">Swap</div>
                      <div class="btn-yellow inactive">My Portion</div>
                    </div>
                        </td>
                    </tr>
                     <tr class="trpool">
                        <td data-label="Pool">
                            <div class="">
                     
                      <div class="wp-pool-tbl-div1">
                        <div class="pool-wm-coin-div">
                          <div class="pool-wm-coin-div-inner">
                            <img class="pool-wm-coin-div-inner-img-1" src="https://www.wealthmark.io/public/assets/img/86c97fe9-1b7d-41ca-b5d4-a646baa22f47.png">
                            <img class="pool-wm-coin-div-inner-img-2" src="https://www.wealthmark.io/public/assets/img/2b5c7d80-7bcd-4cfb-8bd9-d1760a752afc.png">
                          </div>
                        </div>
                        <div class="pool-wm-coin-title-main">IOTX/USDT</div>
                      </div>
                    </div>
                  </td>
                        <td data-label="Total Yield">
                            <div class="Yield_div">
                      <div class="Yield_title">795,926 USD</div>
                      <div class="Yield_subtitle">15,333,972 IOTX + 398,010 USDT</div>
                    </div>
                        </td>
                        <td data-label="Total Yield">
                            <div class="d-flex">
                      <div class="Yield_precentage">2.65%</div>
                      <div class="Yield_precentage-icn-div">
                        <svg viewBox="0 0 48 48" fill="none" cursor="pointer" class="Yield_precentage-icn-div-info">
                          <path d="M25 16.67h-2v2h2v-2zM25 20.67h-2v10.68h2V20.67z" fill="currentColor"></path>
                          <path d="M24 12c6.62 0 12 5.38 12 12s-5.38 12-12 12-12-5.38-12-12 5.38-12 12-12zm0-2c-7.73 0-14 6.27-14 14s6.27 14 14 14 14-6.27 14-14-6.27-14-14-14z" fill="currentColor"></path>
                        </svg>
                      </div>
                    </div>
                        </td>
                        <td data-label="Reward Coins">
                            <div class="">
                      <div class="wp-pool-tbl-div1">
                        <div class="wp-pool-tbl-div-img">
                          <img class="wp-pool-tbl-div-img--" src="https://www.wealthmark.io/public/assets/img/2b5c7d80-7bcd-4cfb-8bd9-d1760a752afc.png">
                          
                        </div>
                        <div class="wp-pool-tbl-reward-txt">IOTX</div>
                      </div>
                    </div>
                        </td>
                        <td data-label="Reward Coins">
                            <div class="wp-pool-valume">115,914 USD</div>
                        </td>
                        <td data-label="Reward Coins">
                    <div class="pool-operation">
                      <div class="btn-yellow active">Add</div>
                      <div class="btn-yellow inactive">Remove</div>
                      <div class="btn-yellow inactive">Swap</div>
                      <div class="btn-yellow inactive">My Portion</div>
                    </div>
                        </td>
                    </tr>
                   
                </tbody>
            </table>
        </div>
                            <div class="pagination-div mt-3">
                   <button type="button" class="mirror pagination-back" aria-label="Previous page" disabled="">
                     <svg viewBox="0 0 24 24" fill="none" class="custom-modal-close-icon">
                       <path fill-rule="evenodd" clip-rule="evenodd" d="M11.934 12l3.89 3.89-1.769 1.767L8.398 12l1.768-1.768 3.89-3.889 1.767 1.768-3.889 3.89z" fill="currentColor"></path>
                     </svg>
                   </button>
                   <button type="button" aria-label="Page number 1" class="pagination-active" disabled="">1</button>
                   <button type="button" aria-label="Page number 2" class="pagination-all">2</button>
                   <button type="button" aria-label="Page number 3" class="pagination-all">3</button>
                   <button type="button" aria-label="Page number 4" class="pagination-all">4</button>
                   <button type="button" aria-label="Page number 5" class="pagination-all">5</button>
                   <button type="button" class="mirror pagination-next" aria-label="Next page">
                     <svg viewBox="0 0 24 24" fill="none" class="custom-modal-close-icon">
                       <path fill-rule="evenodd" clip-rule="evenodd" d="M12.288 12l-3.89 3.89 1.768 1.767L15.823 12l-1.768-1.768-3.889-3.889-1.768 1.768 3.89 3.89z" fill="currentColor"></path>
                     </svg>
                   </button>
                 </div>
                        </div>
                        
                        <div class="tab-pane fade" id="pills-margin" role="tabpanel" aria-labelledby="pills-margin-tab">
                            
                        </div>
                    </div>
            </div>
        </div>
    </div>

   </section>
   
 
  @include('template.country_language')
    @include('template.web_footer') 
    
   
  
    </body>
</html>