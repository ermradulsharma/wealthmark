<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <title>Wealth Mark | {{ Request::segment(2) }}</title>
    @include('template.web_css')
    <link rel='stylesheet' href="{{('../public/assets/css/deepak_custom.css') }}">
</head>

<body>
    @include('template.mobile_menu')
    @include('template.web_menu')


    <section class="affiliate-section-block shadow-sm wm-pay-top" id="affiliate-section">
        <div class="container mt-3">
            <div class="row">
                <div class="col-md-6 col-lg-6 col-xs-12 col-sm-12 order-2 order-lg-1" data-aos="fade-up"
                    data-aos-delay="200">
                    <h5><span class="yellow-text">Know About</span></h5>
                    <h3 class="top-heading"><strong>Join the Wealth Mark Affiliate Program </strong></h3>
                    <p class="top-p">Monetize your traffic and earn crypto commissions when you share Wealth Mark with
                        your
                        audiences. Content creators, influencers and platforms can earn commissions and special rewards
                        on every trade, across Wealth Mark Spot, Futures, Margin trading or even Wealth Mark Pool.</p>
                    <a class="btn btn-yellow shadow become-affiliate-btn">Become an Affiliate </a>
                </div>
                <div class="col-md-6 col-lg-6 col-xs-12 col-sm-12 order-1 order-lg-2" data-aos="zoom-in"
                    data-aos-delay="200">
                    <img src="{{ asset('public/assets/img/join-wealthmark.png') }}" class="img-fluid"
                        alt="Affiliate img">
                </div>
            </div>
        </div>
    </section>

    <section class="affiliated-program-works-block" id="affiliated-program-works-section">
        <div class="container">
            <div class="row">
                <div class="sec-title text-left mb-5">
                    <span class="title">Know About</span>
                    <h2 class="heading-h2">Wealth Mark <span class="yellow-text">Affiliate Program Work?</span></h2>
                </div>
            </div>
            <div class="row affiliate-step-row">
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="steps-inner-box">
                        <div class="show-number">
                            1
                        </div>
                        <h4>Sign up to become an affiliate</h4>
                        <p>Submit your application by filling the form below. Our team will evaluate your application
                            and ensure you meet our affiliate criteria.</p>
                    </div>
                </div>
                <div class="col-md-1 col-lg-1 col-xs-1 col-xs-1 affiliate-right-arrow-box">
                    <svg width="16" height="16" fill="currentColor" class="bi bi-arrow-right" viewBox="0 0 16 16">
                        <path fill-rule="evenodd"
                            d="M1 8a.5.5 0 0 1 .5-.5h11.793l-3.147-3.146a.5.5 0 0 1 .708-.708l4 4a.5.5 0 0 1 0 .708l-4 4a.5.5 0 0 1-.708-.708L13.293 8.5H1.5A.5.5 0 0 1 1 8z" />
                    </svg>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="steps-inner-box">
                        <div class="show-number">
                            2
                        </div>
                        <h4>Create and share your affiliate link </h4>
                        <p>Create, manage and track the performance of your affiliate links right from your Wealth Mark
                            account.</p>
                    </div>
                </div>
                <div class="col-md-1 col-lg-1 col-xs-1 col-xs-1 affiliate-right-arrow-box">
                    <svg width="16" height="16" fill="currentColor" class="bi bi-arrow-right" viewBox="0 0 16 16">
                        <path fill-rule="evenodd"
                            d="M1 8a.5.5 0 0 1 .5-.5h11.793l-3.147-3.146a.5.5 0 0 1 .708-.708l4 4a.5.5 0 0 1 0 .708l-4 4a.5.5 0 0 1-.708-.708L13.293 8.5H1.5A.5.5 0 0 1 1 8z" />
                    </svg>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="steps-inner-box">
                        <div class="show-number">
                            3
                        </div>
                        <h4>Earn up to 50% commissions </h4>
                        <p>When users create an account with your affiliate link, you’ll receive commission on every
                            trade they make.</p>
                    </div>
                </div>

            </div>

        </div>
    </section>

    <section class="affiliate-commission-benefits" id="affiliate-commission-section">
        <div class="container">
            <div class="row">

                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="sec-title text-left mb-5">
                        <span class="title">Know About</span>
                        <h2 class="heading-h2">Wealth Mark <span class="yellow-text">Affiliate Program</span> Commission
                            Benefits</h2>
                    </div>
                    <p>Check more detailed rules of the affiliate program <a class="yellow-text">Detailed Rules</a></p>
                </div>
            </div>
        </div>
    </section>

    <section class="affiliate-incentives-block" id="affiliate-incentives-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="sec-title text-left mb-5">
                        <span class="title">Know About</span>
                        <h2 class="heading-h2">Earn more <span class="yellow-text">affiliate incentives</span></h2>
                    </div>
                </div>
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="table-responsive table-incentives">
                        <table class="table table-striped">
                            <tbody>
                                <tr>
                                    <th>Spot commission</th>
                                    <td>Up to 50%</td>
                                </tr>
                                <tr>
                                    <th>Futures commission</th>
                                    <td>30%</td>
                                </tr>
                                <tr>
                                    <th>Wealth Mark pool commission</th>
                                    <td>30%</td>
                                </tr>
                                <tr>
                                    <th>NFT commission</th>
                                    <td>20%</td>
                                </tr>
                                <tr>
                                    <th>Liquid swap commission</th>
                                    <td>15%</td>
                                </tr>
                                <tr>
                                    <th>Dual investment commission</th>
                                    <td>3%</td>
                                </tr>
                                <tr>
                                    <th>Sign-up bonus package</th>
                                    <td>Share a $50 new user sign-up bonus package with your community.</td>
                                </tr>
                                <tr>
                                    <th>Minimum requirements</th>
                                    <td>Must have more than 5000 followers on social media,more than 500 members in
                                        community</td>
                                </tr>
                                <tr>
                                    <th>Eligibility</th>
                                    <td>Only eligible users can participate after submitting an application</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="additional-affiliate-benefits" id="additional-affiliate-benefits-section">
        <div class="container">
            <div class="row">
                <div class="sec-title text-left mb-5">
                    <span class="title">Know About</span>
                    <h2 class="heading-h2">Additional<span class="yellow-text"> Affiliate Program</span> Benefits</h2>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="affiliate-build-inner-block">
                        <img src="{{ asset('public/assets/img/affiliate-program-1.png') }}" class="img-fluid"
                            alt="Affiliate img">
                        <h5>More rewards </h5>
                        <p>Earn a bonus reward of up to $72,000 every month based on the total fees paid by Futures
                            referrals.</p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="affiliate-build-inner-block">
                        <img src="{{ asset('public/assets/img/affiliate-program-2.png') }}" class="img-fluid"
                            alt="Affiliate img">
                        <h5>Convenient payments </h5>
                        <p>Get paid for every first-time buyer, with no referral limit and a lifetime attribution for
                            spot referrals.</p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="affiliate-build-inner-block">
                        <img src="{{ asset('public/assets/img/affiliate-program-3.png') }}" class="img-fluid"
                            alt="Affiliate img">
                        <h5>Dedicated account manager </h5>
                        <p>Gain access to professional support, tutorials, marketing material, and a dedicated Wealth
                            Mark
                            Affiliate manager.</p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="affiliate-build-inner-block">
                        <img src="{{ asset('public/assets/img/affiliate-program-4.png') }}" class="img-fluid"
                            alt="Affiliate img">
                        <h5>Exclusive content program </h5>
                        <p>Earn up to 3,000 BUSD per month and a special sign-up bonus for your audience when you create
                            quality</p>
                    </div>
                </div>
            </div>

        </div>
    </section>

    <section class="affiliate-faq-block" id="affiliate-faq-section">
        <div class="container">
            <div class="row">
                <div class="sec-title text-left">
                    <span class="title">Know About</span>
                    <h2 class="heading-h2">FAQ</h2>
                </div>
            </div>
            <div class="row">
                <div class="faq-inner-block" id="faq-inner-section">
                    <div class="col-md-12 col-lg-12 col-xs-12 col-sm-12">
                    <div class="accordion" id="accordian-api">
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingOne">
                                    <button class="accordion-button" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                        1. What is Wealthmark Pay?
                                    </button>
                                </h2>
                                <div id="collapseOne" class="accordion-collapse collapse show"
                                    aria-labelledby="headingOne" data-bs-parent="#accordian-api">
                                    <div class="accordion-body">
                                        <strong>This is the first item's accordion body.</strong> It is shown by
                                        default, until the collapse plugin adds the appropriate classes that we use to
                                        style each element. These classes control the overall appearance, as well as the
                                        showing and hiding via CSS transitions. You can modify any of this with custom
                                        CSS or overriding our default variables. It's also worth noting that just about
                                        any HTML can go within the <code>.accordion-body</code>, though the transition
                                        does limit overflow.
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingTwo">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                        2. Can I pay with Bitcoin, Wealthmark and other cryptocurrencies supported by
                                        Wealthmark?
                                    </button>
                                </h2>
                                <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo"
                                    data-bs-parent="#accordian-api">
                                    <div class="accordion-body">
                                        <strong>You can access your Wealthmark Pay Wallet by clicking [Wallets] -
                                            [Funding] - [Pay] on your Wealthmark App.
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingThree">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapseThree" aria-expanded="false"
                                        aria-controls="collapseThree">
                                        3. How long does it take for a Wealthmark Pay transaction to be completed?
                                    </button>
                                </h2>
                                <div id="collapseThree" class="accordion-collapse collapse"
                                    aria-labelledby="headingThree" data-bs-parent="#accordian-api">
                                    <div class="accordion-body">
                                        <strong>Wealthmark Pay transactions are usually confirmed instantly.
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingfour">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapsefour" aria-expanded="false"
                                        aria-controls="collapsefour">
                                        4. Can I pay with Bitcoin, Wealthmark and other cryptocurrencies supported by
                                        Wealthmark?
                                    </button>
                                </h2>
                                <div id="collapsefour" class="accordion-collapse collapse" aria-labelledby="headingfour"
                                    data-bs-parent="#accordian-api">
                                    <div class="accordion-body">
                                        <strong>You can access your Wealthmark Pay Wallet by clicking [Wallets] -
                                            [Funding] - [Pay] on your Wealthmark App.
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingfive">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapsefive" aria-expanded="false"
                                        aria-controls="collapsefive">
                                        5. How long does it take for a Wealthmark Pay transaction to be completed?
                                    </button>
                                </h2>
                                <div id="collapsefive" class="accordion-collapse collapse" aria-labelledby="headingfive"
                                    data-bs-parent="#accordian-api">
                                    <div class="accordion-body">
                                        <strong>Wealthmark Pay transactions are usually confirmed instantly.
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="become-walthmark-affiliate" id="become-walthmark-affiliate-section">
        <div class="container">
            <div class="row">

                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="sec-title text-left mb-5">
                        <span class="title">Know About</span>
                        <h2 class="heading-h2">Promote Wealth Mark.<span class="yellow-text"> Get paid.</span> Simple
                            right?</h2>
                    </div>
                    <a class=" btn btn-yellow shadow">Become a Wealth Mark Affiliate</a>
                </div>
            </div>
        </div>
    </section>

    @include('template.country_language')
    @include('template.web_footer')
</body>

</html>