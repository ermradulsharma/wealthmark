  <!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
   <head>
      <meta charset="utf-8">
      <meta content="width=device-width, initial-scale=1.0" name="viewport">
      <title>Wealth Mark | Create Entity Account</title>
  @include('template.web_css')
    
 <style>
     #header{
         background:white;
         
     }




 </style>
  
  
   </head>
   
 <body class="bg-white">
     
     @include('template.mobile_menu')
        @include('template.web_menu')
    
   <section class="bg-light-blue">
<div class="container">
    <div class="row align-items-center justify-content-center">
       
       <div class="w-auto me-5">
           <div class="sec-title">
                            <span class="title">Welcome to Wealthmark</span>
                            <h2 class="heading-h2">Buy crypto in 3 steps</h2>
                            <div class="text">
                                Buy Bitcoin and 99+ cryptocurrency with 50+ fiat currencies
                            </div>
          </div>
       </div>
         <div class="Crypto-loans-right">
      <div class="crypto-right-inner-main mt-0">
          <div class="dashboard-tabpills">
         <div class="dashboard-card-body">
                        <ul class="nav nav-pills my-1 border-bottom" id="pills-tab" role="tablist">
                        <li class="nav-item w-50" role="presentation">
                            <button class="nav-link active w-100" id="pills-spot-tab" data-bs-toggle="pill" data-bs-target="#pills-spot" type="button" role="tab" aria-controls="pills-spot" aria-selected="true">Credit Card and Debit Card</button>
                        </li>
                        <li class="nav-item w-50" role="presentation">
                            <button class="nav-link w-100" id="pills-p2p-tab" data-bs-toggle="pill" data-bs-target="#pills-p2p" type="button" role="tab" aria-controls="pills-p2p" aria-selected="false">Bank Deposit</button>
                        </li>
                        </ul>
                    <div class="tab-content" id="pills-tabContent">
                        <div class="tab-pane fade active show" id="pills-spot" role="tabpanel" aria-labelledby="pills-spot-tab">
                            <div class="crypto-right-inner flex-column">
          <div class="flex-1">
            <div class="field crypto-rght-first-box">
             
             <div id="ocbs-guide-step1" class="bS-crypto-div">
                  <div class="bS-crypto-div-inner">
                    <div class="bS-crypto-div-title">Spend</div>
                    <div class="bS-crypto-div-inp-div">
                      <div class="bS-crypto-div-inp-div-1">
                        <input type="text" placeholder="70.00 - 55000.00" class="bS-crypto-div-input" value="">
                      </div>
                      <div class="bS-crypto-div-open-list"  id="select_crrency">
                        <img src="{{ asset('public/assets/img/inr-img.png') }}" class="bS-crypto-select-coin">
                        <div  class="bS-crypto-select-coin-title">INR</div>
                        <svg viewBox="0 0 24 24" fill="none" class="bS-crypto-div-open-list-svg">
                          <path fill-rule="evenodd" clip-rule="evenodd" d="M12.11 12.178L16 8.287l1.768 1.768-5.657 5.657-1.768-1.768-3.889-3.889 1.768-1.768 3.889 3.89z" fill="currentColor"></path>
                        </svg>
                      </div>
                    </div>
                  </div>
                </div>
            
            <div id="ocbs-guide-step1" class="bS-crypto-div">
              <div class="bS-crypto-div-inner">
                <div class="bS-crypto-div-title">Spend</div>
                <div class="bS-crypto-div-inp-div">
                  <div class="bS-crypto-div-inp-div-1">
                    <input type="text" placeholder="70.00 - 55000.00" class="bS-crypto-div-input" value="">
                  </div>
                  <div class="bS-crypto-div-open-list" id="select_crypto">
                    <img src="{{ asset('public/assets/img/3a8c9fe6-2a76-4ace-aa07-415d994de6f0.png') }}" class="bS-crypto-select-coin">
                    <div  class="bS-crypto-select-coin-title">ETH</div>
                    <svg viewBox="0 0 24 24" fill="none" class="bS-crypto-div-open-list-svg">
                      <path fill-rule="evenodd" clip-rule="evenodd" d="M12.11 12.178L16 8.287l1.768 1.768-5.657 5.657-1.768-1.768-3.889-3.889 1.768-1.768 3.889 3.89z" fill="currentColor"></path>
                    </svg>
                  </div>
                </div>
              </div>
            </div>
          </div>
 </div> 
 <div class="mt-5">
    
     <div class="bS-est-div">
   <div class="bS-est-div-inner" data-bs-toggle="tooltip" data-bs-placement="top" title="" data-bs-original-title="The price of crypto changes frequently based on market conditions. Please refer to the price on the confirm order page as your final quotation.">
    
     <div class="bS-est-div-inner-title">Estimate price:</div>
     <div class="bS-est-div-inner-price-div">
       <div class="bS-est-div-inner-price-div-title">1 BTC ≈ 62,042.92 AED</div>
     </div>
   </div>
   <div class="switch-div">
     <svg viewBox="0 0 24 24" fill="none" class="switch-div-icon">
       <path d="M21 7.5v3H2.5l7-7v4H21zM3 16.5v-3h18.5l-7 7v-4H3z" fill="currentColor"></path>
     </svg>
   </div>
 </div>
 
 <button class="btn btn-yellow w-100 mt-4">Log In</button>
 <div class="Recurring_Buy-div">
  <div class="Recurring_Buy">
    <svg viewBox="0 0 24 24" fill="none" class="titmer-svg">
      <path fill-rule="evenodd" clip-rule="evenodd" d="M16.597 16.594A6.48 6.48 0 0112 18.498h-1.25v2.5H12a9 9 0 006.364-15.364 9 9 0 00-12.728 0l1.767 1.768a6.5 6.5 0 019.193 9.192zM13.25 8h-2.5v4.518l3.185 3.185 1.768-1.768-2.453-2.453V8zM5.627 9.568v1.2l-.092.006c-.767.062-1.371.29-1.783.662-.41.37-.639.891-.639 1.564 0 .684.24 1.223.676 1.642.438.421 1.08.726 1.889.925l.076.019v1.901l-.123-.029a3.94 3.94 0 01-.838-.305 2.512 2.512 0 01-.596-.4L3.14 17.935c.446.416 1.309.784 2.268.974l.08.016v1.277h1.578v-1.207l.086-.011c.796-.11 1.357-.448 1.718-.891a2.457 2.457 0 00.532-1.562c0-.669-.246-1.177-.668-1.568-.426-.394-1.037-.675-1.772-.874l-.074-.02v-1.802l.125.033c.406.106.816.31 1.099.558l1.035-1.136c-.43-.4-1.102-.697-1.875-.861l-.08-.017V9.568H5.628zm.19 4.272l-.137-.056c-.221-.09-.381-.185-.485-.303a.599.599 0 01-.149-.418c0-.133.028-.298.126-.448.1-.152.265-.279.522-.34l.123-.03v1.595zm1.057 3.678v-1.732l.147.08a.934.934 0 01.376.346.936.936 0 01.122.483.9.9 0 01-.096.429.744.744 0 01-.414.343l-.135.05z" fill="currentColor"></path>
    </svg>
    <span class="text">Recurring Buy</span>
  </div>
</div>
</div>
 </div>
                        </div>
                        <div class="tab-pane fade" id="pills-p2p" role="tabpanel" aria-labelledby="pills-p2p-tab">
    <div class="d-flex flex-column align-items-center">
  <img src="{{ asset('public/assets/img/empty-wallet.svg') }}" class="empty-wallet">
  <h4 class="title text-center">You have insufficient assets to sell</h4>
  <div class="text text-center">Here are the hot cryptos</div>
  <div class="max-height-300px">
    <div class="custom-modal-drpdn-outer">
      <div id="choose-coin-BNB" class="custom-modal-drpdn">
        <div class="custom-modal-drpdn-inner">
          <div class="d-flex">
            <img src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}" class="custom-modal-drpdn-img-1">
            <div class="custom-modal-drpdn-img">
              <div class="custom-modal-drpdn-title">BNB</div>
              <div class="custom-modal-drpdn-subtitle">BNB</div>
            </div>
          </div>
        </div>
        <div class="">
          <div class="custom-modal-drpdn-price">274.03350853 </div>
          <div class="custom-modal-drpdn-status">-3.64 %</div>
        </div>
      </div>
      <div id="choose-coin-BNB" class="custom-modal-drpdn">
        <div class="custom-modal-drpdn-inner">
          <div class="d-flex">
            <img src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}" class="custom-modal-drpdn-img-1">
            <div class="custom-modal-drpdn-img">
              <div class="custom-modal-drpdn-title">BNB</div>
              <div class="custom-modal-drpdn-subtitle">BNB</div>
            </div>
          </div>
        </div>
        <div class="">
          <div class="custom-modal-drpdn-price">274.03350853 </div>
          <div class="custom-modal-drpdn-status">-3.64 %</div>
        </div>
      </div>
      <div id="choose-coin-BNB" class="custom-modal-drpdn">
        <div class="custom-modal-drpdn-inner">
          <div class="d-flex">
            <img src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}" class="custom-modal-drpdn-img-1">
            <div class="custom-modal-drpdn-img">
              <div class="custom-modal-drpdn-title">BNB</div>
              <div class="custom-modal-drpdn-subtitle">BNB</div>
            </div>
          </div>
        </div>
        <div class="">
        <div class="custom-modal-drpdn-price">274.03350853 </div>
          <div class="custom-modal-drpdn-status">-3.64 %</div>
        </div>
      </div>
      <div id="choose-coin-BNB" class="custom-modal-drpdn">
        <div class="custom-modal-drpdn-inner">
          <div class="d-flex">
            <img src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}" class="custom-modal-drpdn-img-1">
            <div class="custom-modal-drpdn-img">
              <div class="custom-modal-drpdn-title">BNB</div>
              <div class="custom-modal-drpdn-subtitle">BNB</div>
            </div>
          </div>
        </div>
        <div class="">
         <div class="custom-modal-drpdn-price">274.03350853 </div>
          <div class="custom-modal-drpdn-status">-3.64 %</div>
        </div>
      </div>
      <div id="choose-coin-BNB" class="custom-modal-drpdn">
        <div class="custom-modal-drpdn-inner">
          <div class="d-flex">
            <img src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}" class="custom-modal-drpdn-img-1">
            <div class="custom-modal-drpdn-img">
              <div class="custom-modal-drpdn-title">BNB</div>
              <div class="custom-modal-drpdn-subtitle">BNB</div>
            </div>
          </div>
        </div>
        <div class="">
         <div class="custom-modal-drpdn-price">274.03350853 </div>
          <div class="custom-modal-drpdn-status">-3.64 %</div>
        </div>
      </div>
      <div id="choose-coin-BNB" class="custom-modal-drpdn">
        <div class="custom-modal-drpdn-inner">
          <div class="d-flex">
            <img src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}" class="custom-modal-drpdn-img-1">
            <div class="custom-modal-drpdn-img">
              <div class="custom-modal-drpdn-title">BNB</div>
              <div class="custom-modal-drpdn-subtitle">BNB</div>
            </div>
          </div>
        </div>
        <div class="">
        <div class="custom-modal-drpdn-price">274.03350853 </div>
          <div class="custom-modal-drpdn-status">-3.64 %</div>
        </div>
      </div>
      <div id="choose-coin-BNB" class="custom-modal-drpdn">
        <div class="custom-modal-drpdn-inner">
          <div class="d-flex">
            <img src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}" class="custom-modal-drpdn-img-1">
            <div class="custom-modal-drpdn-img">
              <div class="custom-modal-drpdn-title">BNB</div>
              <div class="custom-modal-drpdn-subtitle">BNB</div>
            </div>
          </div>
        </div>
        <div class="">
         <div class="custom-modal-drpdn-price">274.03350853 </div>
          <div class="custom-modal-drpdn-status">-3.64 %</div>
        </div>
      </div>
      <div id="choose-coin-BNB" class="custom-modal-drpdn">
        <div class="custom-modal-drpdn-inner">
          <div class="d-flex">
            <img src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}" class="custom-modal-drpdn-img-1">
            <div class="custom-modal-drpdn-img">
              <div class="custom-modal-drpdn-title">BNB</div>
              <div class="custom-modal-drpdn-subtitle">BNB</div>
            </div>
          </div>
        </div>
        <div class="">
       <div class="custom-modal-drpdn-price">274.03350853 </div>
          <div class="custom-modal-drpdn-status">-3.64 %</div>
        </div>
      </div>
      <div id="choose-coin-BNB" class="custom-modal-drpdn">
        <div class="custom-modal-drpdn-inner">
          <div class="d-flex">
            <img src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}" class="custom-modal-drpdn-img-1">
            <div class="custom-modal-drpdn-img">
              <div class="custom-modal-drpdn-title">BNB</div>
              <div class="custom-modal-drpdn-subtitle">BNB</div>
            </div>
          </div>
        </div>
        <div class="">
          <div class="custom-modal-drpdn-price">274.03350853 </div>
          <div class="custom-modal-drpdn-status">-3.64 %</div>
        </div>
      </div>

     
</div>
</div>
<div class="w-100">
  <button type="button" type="primary" class="btn btn-yellow w-100 mt-5">Buy Crypto</button>
</div>
</div>
</div>
    
                    </div>
   </div>
    </div>
   </div>
   </div>
    </div>
</div>


</section>





<section class="crypto-three-steps bg-white">
  
              <div class="container">
                  <div class="row">
                      <div class="sec-title">
                            <span class="title">Welcome to Wealthmark</span>
                            <h2 class="heading-h2">Buy & Sell Crypto on wealthmark: Where You Trade Crypto in 3 Steps</h2>
                            <div class="text">
                               wealthmark is a safe and secure platform to buy and sell cryptocurrencies quickly using our streamlined buy/sell process. You're just three steps away from your first Bitcoin, Ethereum, and other cryptocurrencies.
                            </div>
          </div>
                  </div>
    <div class="row">
        <div class="col-md-4 col-sm-4">
            <div class="serviceBox">
                <div class="service-icon">
                    <span>
                        <i class="bi bi-person-bounding-box"></i>
                    </span>
                </div>
                <h3 class="title">Register for an account</h3>
                <div class="text p-4">Lorem ipsum dolor sit amet conse ctetur adipisicing elit. Qui quaerat fugit quas veniam perferendis repudiandae sequi, dolore quisquam illum.</div>
            </div>
        </div>
        <div class="col-md-4 col-sm-4">
            <div class="serviceBox">
                <div class="service-icon">
                    <span>
                      <i class="bi bi-person-check"></i>
                    </span>
                </div>
                <h3 class="title">Verify your identity</h3>
                <div class="text p-4">Lorem ipsum dolor sit amet conse ctetur adipisicing elit. Qui quaerat fugit quas veniam perferendis repudiandae sequi, dolore quisquam illum.</div>
            </div>
        </div>
         <div class="col-md-4 col-sm-4">
            <div class="serviceBox">
                <div class="service-icon">
                    <span>
                       <i class="bi bi-currency-bitcoin"></i>
                    </span>
                </div>
                <h3 class="title">Buy Crypto!</h3>
                <div class="text p-4">Lorem ipsum dolor sit amet conse ctetur adipisicing elit. Qui quaerat fugit quas veniam perferendis repudiandae sequi, dolore quisquam illum.</div>
            </div>
        </div>
    </div>
</div>
       
</section>












  @include('template.country_language')
    @include('template.web_footer') 
    
   
    
    
    
    
    
    
    
    
   <!----------------------------modal---------------------------------->
  <div class="hide">
  <div class="wm-custom-modal-diolog">
  
    <div class="wm-custom-modal-body">
        <div id="select_currency_list" style="display:block">
            
              
    <div class="wm-custom-modal-header">
    <span>
        Select Currency 
    </span>
    <svg viewBox="0 0 24 24" fill="none" class="wm-custom-modal-close" id="wm-custom-modal-close">
      <path d="M6.697 4.575L4.575 6.697 9.88 12l-5.304 5.303 2.122 2.122L12 14.12l5.303 5.304 2.122-2.122L14.12 12l5.304-5.303-2.122-2.122L12 9.88 6.697 4.575z" fill="currentColor"></path>
    </svg>
    </div>
     <div class="pb-3" >
      <div class="custom-modal-search-div">
        <svg viewBox="0 0 24 24" fill="none" class="custom-modal-search-icn">
          <path fill-rule="evenodd" clip-rule="evenodd" d="M11 6a5 5 0 110 10 5 5 0 010-10zm0-3a8 8 0 017.021 11.838l3.07 3.07-1.59 1.591-1.591 1.591-3.07-3.07A8 8 0 1111 3z" fill="currentColor"></path>
        </svg>
        <input type="text" id="coinModalInput" placeholder="Search" class="custom-modal-search-input" value="">
      </div>
      <div class="wm-custom-modal-max-height">
        <div class="">
          <div id="choose-coin-INR" class="custom-modal-drpdn">
            <div class="custom-modal-drpdn-inner">
              <div class="d-flex">
                <img src="{{ asset('public/assets/img/87496d50-2408-43e1-ad4c-78b47b448a6a.png') }}" class="custom-modal-drpdn-img-1">
                <div class="custom-modal-drpdn-img">
                  <div class="custom-modal-drpdn-title">AED</div>
                  <div class="custom-modal-drpdn-subtitle">United Arab Emirates dirham</div>
                </div>
              </div>
              
            </div>
          </div>
          <div id="choose-coin-INR" class="custom-modal-drpdn">
            <div class="custom-modal-drpdn-inner">
              <div class="d-flex">
                <img src="{{ asset('public/assets/img/inr-img.png') }}" class="custom-modal-drpdn-img-1">
                <div class="custom-modal-drpdn-img">
                  <div class="custom-modal-drpdn-title">INR</div>
                  <div class="custom-modal-drpdn-subtitle">India</div>
                </div>
              </div>
              
            </div>
          </div>
           <div id="choose-coin-Demo" class="custom-modal-drpdn">
            <div class="custom-modal-drpdn-inner">
              <div class="d-flex">
                <img src="{{ asset('public/assets/img/inr-img.png') }}" class="custom-modal-drpdn-img-1">
                <div class="custom-modal-drpdn-img">
                  <div class="custom-modal-drpdn-title">INR</div>
                  <div class="custom-modal-drpdn-subtitle">India</div>
                </div>
              </div>
              
            </div>
          </div>
           <div id="choose-coin-Demo" class="custom-modal-drpdn">
            <div class="custom-modal-drpdn-inner">
              <div class="d-flex">
                <img src="{{ asset('public/assets/img/inr-img.png') }}" class="custom-modal-drpdn-img-1">
                <div class="custom-modal-drpdn-img">
                  <div class="custom-modal-drpdn-title">INR</div>
                  <div class="custom-modal-drpdn-subtitle">India</div>
                </div>
              </div>
              
            </div>
          </div>
           <div id="choose-coin-Demo" class="custom-modal-drpdn">
            <div class="custom-modal-drpdn-inner">
              <div class="d-flex">
                <img src="{{ asset('public/assets/img/inr-img.png') }}" class="custom-modal-drpdn-img-1">
                <div class="custom-modal-drpdn-img">
                  <div class="custom-modal-drpdn-title">INR</div>
                  <div class="custom-modal-drpdn-subtitle">India</div>
                </div>
              </div>
              
            </div>
          </div>
           <div id="choose-coin-Demo" class="custom-modal-drpdn">
            <div class="custom-modal-drpdn-inner">
              <div class="d-flex">
                <img src="{{ asset('public/assets/img/inr-img.png') }}" class="custom-modal-drpdn-img-1">
                <div class="custom-modal-drpdn-img">
                  <div class="custom-modal-drpdn-title">INR</div>
                  <div class="custom-modal-drpdn-subtitle">India</div>
                </div>
              </div>
              
            </div>
          </div>
           <div id="choose-coin-Demo" class="custom-modal-drpdn">
            <div class="custom-modal-drpdn-inner">
              <div class="d-flex">
                <img src="{{ asset('public/assets/img/inr-img.png') }}" class="custom-modal-drpdn-img-1">
                <div class="custom-modal-drpdn-img">
                  <div class="custom-modal-drpdn-title">INR</div>
                  <div class="custom-modal-drpdn-subtitle">India</div>
                </div>
              </div>
              
            </div>
          </div>
           <div id="choose-coin-Demo" class="custom-modal-drpdn">
            <div class="custom-modal-drpdn-inner">
              <div class="d-flex">
                <img src="{{ asset('public/assets/img/inr-img.png') }}" class="custom-modal-drpdn-img-1">
                <div class="custom-modal-drpdn-img">
                  <div class="custom-modal-drpdn-title">INR</div>
                  <div class="custom-modal-drpdn-subtitle">India</div>
                </div>
              </div>
              
            </div>
          </div>
           <div id="choose-coin-Demo" class="custom-modal-drpdn">
            <div class="custom-modal-drpdn-inner">
              <div class="d-flex">
                <img src="{{ asset('public/assets/img/inr-img.png') }}" class="custom-modal-drpdn-img-1">
                <div class="custom-modal-drpdn-img">
                  <div class="custom-modal-drpdn-title">INR</div>
                  <div class="custom-modal-drpdn-subtitle">India</div>
                </div>
              </div>
              
            </div>
          </div>
           <div id="choose-coin-Demo" class="custom-modal-drpdn">
            <div class="custom-modal-drpdn-inner">
              <div class="d-flex">
                <img src="{{ asset('public/assets/img/inr-img.png') }}" class="custom-modal-drpdn-img-1">
                <div class="custom-modal-drpdn-img">
                  <div class="custom-modal-drpdn-title">INR</div>
                  <div class="custom-modal-drpdn-subtitle">India</div>
                </div>
              </div>
              
            </div>
          </div>
           <div id="choose-coin-Demo" class="custom-modal-drpdn">
            <div class="custom-modal-drpdn-inner">
              <div class="d-flex">
                <img src="{{ asset('public/assets/img/inr-img.png') }}" class="custom-modal-drpdn-img-1">
                <div class="custom-modal-drpdn-img">
                  <div class="custom-modal-drpdn-title">INR</div>
                  <div class="custom-modal-drpdn-subtitle">India</div>
                </div>
              </div>
              
            </div>
          </div>
           <div id="choose-coin-Demo" class="custom-modal-drpdn">
            <div class="custom-modal-drpdn-inner">
              <div class="d-flex">
                <img src="{{ asset('public/assets/img/inr-img.png') }}" class="custom-modal-drpdn-img-1">
                <div class="custom-modal-drpdn-img">
                  <div class="custom-modal-drpdn-title">INR</div>
                  <div class="custom-modal-drpdn-subtitle">India</div>
                </div>
              </div>
              
            </div>
          </div>
           <div id="choose-coin-Demo" class="custom-modal-drpdn">
            <div class="custom-modal-drpdn-inner">
              <div class="d-flex">
                <img src="{{ asset('public/assets/img/inr-img.png') }}" class="custom-modal-drpdn-img-1">
                <div class="custom-modal-drpdn-img">
                  <div class="custom-modal-drpdn-title">INR</div>
                  <div class="custom-modal-drpdn-subtitle">India</div>
                </div>
              </div>
              
            </div>
          </div>
           <div id="choose-coin-Demo" class="custom-modal-drpdn">
            <div class="custom-modal-drpdn-inner">
              <div class="d-flex">
                <img src="{{ asset('public/assets/img/inr-img.png') }}" class="custom-modal-drpdn-img-1">
                <div class="custom-modal-drpdn-img">
                  <div class="custom-modal-drpdn-title">INR</div>
                  <div class="custom-modal-drpdn-subtitle">India</div>
                </div>
              </div>
              
            </div>
          </div>
          
         
        </div>
      </div>
    </div>
        </div>
   
        <div id="select_crypto_list" style="display:block">
               <svg viewBox="0 0 24 24" fill="none" class="wm-custom-modal-close">
      <path d="M6.697 4.575L4.575 6.697 9.88 12l-5.304 5.303 2.122 2.122L12 14.12l5.303 5.304 2.122-2.122L14.12 12l5.304-5.303-2.122-2.122L12 9.88 6.697 4.575z" fill="currentColor"></path>
    </svg>
    <div class="wm-custom-modal-header">Select Currency</div>
             <div class="pb-3">
     <div class="custom-modal-search-div">
    <svg viewBox="0 0 24 24" fill="none" class="custom-modal-search-icn">
      <path fill-rule="evenodd" clip-rule="evenodd" d="M11 6a5 5 0 110 10 5 5 0 010-10zm0-3a8 8 0 017.021 11.838l3.07 3.07-1.59 1.591-1.591 1.591-3.07-3.07A8 8 0 1111 3z" fill="currentColor"></path>
    </svg>
    <input type="text" id="coinModalInput" placeholder="Search" class="custom-modal-search-input" value="">
  </div>
  <div class="custom-modal-drpdn-filter">
    <div class="custom-modal-drpdn-filter-text">Sort by</div>
    <div class="d-flex">
      <div class="custom-modal-drpdn-filter-active">24h Vol</div>
      <div class="custom-modal-drpdn-filter-text">24h Change <svg viewBox="0 0 24 24" fill="none" class="custom-modal-drpdn-filter-svg">
          <path d="M5 13.47l1.41-1.41 5.1 5.1V3h1.99v14.15l5.09-5.09L20 13.47l-7.5 7.5-7.5-7.5z" fill="currentColor"></path>
        </svg>
      </div>
      <div class="custom-modal-drpdn-filter-text">24h Change <svg viewBox="0 0 24 24" fill="none" class="custom-modal-drpdn-filter-svg">
          <path d="M19 10.5l-1.41 1.41-5.1-5.1v14.16H10.5V6.82l-5.09 5.09L4 10.5 11.5 3l7.5 7.5z" fill="currentColor"></path>
        </svg>
      </div>
    </div>
  </div>
  <div class="wm-custom-modal-max-height">
    <div class="">
      <div id="choose-coin-BTC" class="custom-modal-drpdn">
        <div class="custom-modal-drpdn-inner">
          <div class="d-flex">
            <img src="{{ asset('public/assets/img/87496d50-2408-43e1-ad4c-78b47b448a6a.png') }}" class="custom-modal-drpdn-img-1">
            <div class="custom-modal-drpdn-img">
              <div class="custom-modal-drpdn-title">BTC</div>
              <div class="custom-modal-drpdn-subtitle">Bitcoin</div>
            </div>
          </div>
          
        </div>
        <div class="">
           <div class="custom-modal-drpdn-price">251.256254</div>
          <div class="custom-modal-drpdn-status">-2.21 %</div>
        </div>
      </div>
      <div id="choose-coin-ETH" class="custom-modal-drpdn">
        <div class="custom-modal-drpdn-inner">
          <div class="d-flex">
            <img src="{{ asset('public/assets/img/3a8c9fe6-2a76-4ace-aa07-415d994de6f0.png') }}" class="custom-modal-drpdn-img-1">
            <div class="custom-modal-drpdn-img">
              <div class="custom-modal-drpdn-title">ETH</div>
              <div class="custom-modal-drpdn-subtitle">Ethereum</div>
            </div>
          </div>
          
        </div>
        <div class="">
           <div class="custom-modal-drpdn-price">251.256254</div>
          <div class="custom-modal-drpdn-status">-0.05 %</div>
        </div>
      </div>
      <div id="choose-coin-BNB" class="custom-modal-drpdn">
        <div class="custom-modal-drpdn-inner">
          <div class="d-flex">
            <img src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}" class="custom-modal-drpdn-img-1">
            <div class="custom-modal-drpdn-img">
              <div class="custom-modal-drpdn-title">BNB</div>
              <div class="custom-modal-drpdn-subtitle">BNB</div>
            </div>
          </div>
          
        </div>
        <div class="">
          <div class="custom-modal-drpdn-price">251.256254</div>
          <div class="custom-modal-drpdn-status">-3.02 %</div>
        </div>
      </div>
     
      <div id="choose-coin-XRP" class="custom-modal-drpdn">
        <div class="custom-modal-drpdn-inner">
          <div class="d-flex">
            <img src="{{ asset('public/assets/img/4766a9cc-8545-4c2b-bfa4-cad2be91c135.png') }}" class="custom-modal-drpdn-img-1">
            <div class="custom-modal-drpdn-img">
              <div class="custom-modal-drpdn-title">XRP</div>
              <div class="custom-modal-drpdn-subtitle">Ripple</div>
            </div>
          </div>
          
        </div>
        <div class="">
          <div class="custom-modal-drpdn-price">251.256254</div>
          <div class="custom-modal-drpdn-status">-4.31 %</div>
        </div>
      </div>
    
      <div id="choose-coin-LTC" class="custom-modal-drpdn">
        <div class="custom-modal-drpdn-inner">
          <div class="d-flex">
            <img src="{{ asset('public/assets/img/359ca651-a084-4010-92d8-4eaff96e6384.png') }}" class="custom-modal-drpdn-img-1">
            <div class="custom-modal-drpdn-img">
              <div class="custom-modal-drpdn-title">LTC</div>
              <div class="custom-modal-drpdn-subtitle">Litecoin</div>
            </div>
          </div>
          
        </div>
        <div class="">
          <div class="custom-modal-drpdn-price">251.256254</div>
          <div class="custom-modal-drpdn-status">-3.83 %</div>
        </div>
      </div>
    
      
      <div id="choose-coin-BUSD" class="custom-modal-drpdn">
        <div class="custom-modal-drpdn-inner">
          <div class="d-flex">
            <img src="{{ asset('public/assets/img/3222a10d-5618-4100-8476-ee7fe0a6fb12.png') }}" class="custom-modal-drpdn-img-1">
            <div class="custom-modal-drpdn-img">
              <div class="custom-modal-drpdn-title">BUSD</div>
              <div class="custom-modal-drpdn-subtitle">BUSD</div>
            </div>
          </div>
          
        </div>
        <div class="">
            <div class="custom-modal-drpdn-price">251.256254</div>
        </div>
      </div>
      <div id="choose-coin-USDT" class="custom-modal-drpdn">
        <div class="custom-modal-drpdn-inner">
          <div class="d-flex">
            <img src="{{ asset('public/assets/img/2b5c7d80-7bcd-4cfb-8bd9-d1760a752afc.png') }}" class="custom-modal-drpdn-img-1">
            <div class="custom-modal-drpdn-img">
              <div class="custom-modal-drpdn-title">USDT</div>
              <div class="custom-modal-drpdn-subtitle">TetherUS</div>
            </div>
          </div>
          
        </div>
        <div class="">
          <div class="custom-modal-drpdn-price">251.256254</div>
        </div>
      </div>
    </div>
  </div>
</div>
        </div>
   
  </div>
  </div>
 
</div>










 <script>
        
        
        $("#select_crrency").click(function() {
            $(".hide").addClass("custom-modal-bck-bg").removeClass("hide");
      $("#select_currency_list").css("display" , "block");
       $("#select_crypto_list").css("display" , "none");
      
     
    });
       
        $("#select_crypto").click(function() {
         $(".hide").addClass("custom-modal-bck-bg").removeClass("hide");
      $("#select_crypto_list").css("display" , "block");
      $("#select_currency_list").css("display" , "none");
     
    });
    
       $(".wm-custom-modal-close").click(function() {
          $(".custom-modal-bck-bg").addClass("hide").removeClass("custom-modal-bck-bg");
      
     
    });
    
    
    </script>
    






    </body>
</html>