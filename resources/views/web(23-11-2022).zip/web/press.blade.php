  <!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
   <head>
      <meta charset="utf-8">
      <meta content="width=device-width, initial-scale=1.0" name="viewport">
      <title>Wealth Mark | Create Entity Account</title>
  @include('template.web_css')
      
 
 <style>
     #header{
         background:white;
         
     }
    
 </style>
  
  
   </head>
   
 <body class="bg-white">
     
     @include('template.mobile_menu')
        @include('template.web_menu')
    
    
  
    
<div class="bg-light-blue">
    
        <div class="container">
                <div class="row">
                    <div class="col-md-4 col-sm-6 col-xs-12">
                        <div class="nav-tabs-list d-flex justify-content-between">
                            <a  href="{{ url( app()->getLocale(), 'about-us') }}" class="nav-tabs-a">About</a>
                            <a  href="{{ url( app()->getLocale(), 'careers') }}" class="nav-tabs-a">Careers</a>
                            <a  href="{{ url( app()->getLocale(), 'press') }}" class="nav-tabs-a active">Press</a>
                            <a  href="{{ url( app()->getLocale(), 'community') }}" class="nav-tabs-a">Community</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    
    
   <section id="press"  class="breadcrumbs shadow-sm bg-dark-blue p-5">
          <div class="container-fluid">
              <div class="row justify-content-center">
                   
                 <div class="col-lg-4  d-flex flex-column justify-content-center pt-lg-0 order-2 order-lg-1" data-aos="fade-up" data-aos-delay="200">
                 <h3 class="top-heading yellow-text">Wealthmark Newsroom</h3>
                 <p class="top-p text-white">Your source for the latest news from Wealthmark. Get access to our official announcements, blog posts, news updates, media assets and more. When it comes to blockchain and crypto, Wealthmark is always at the heart of the story.</p>
               
                 </div>
                
                <div class="col-lg-5 offset-lg-1 hero-img">
                    <img src="{{ asset('public/assets/img/press-cover-graphic.png') }}" class="img-fluid w-75" alt="" >
                 </div>
              </div>
            </div>
      </section>
      
 
    <div class="support-sec press bg-light-blue p-3">
         <div class="container">
                  <div class="threediv">
  <div class="threediv-block">
   <a href="#">
    <div class="threediv-block-inner">
      <!--<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="support-sec-svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M22 6H2v14h20V6zM4 10h16V8H4v2zm8 2h8v2h-8v-2zm0 4h4v2h-4v-2zm-8-4h6v6H4v-6z" fill="url(#blog-g_svg__paint0_linear)"></path><path d="M2 3.998h20v2H2v-2z" fill="#76808F"></path><defs><linearGradient id="blog-g_svg__paint0_linear" x1="2" y1="13" x2="22" y2="13" gradientUnits="userSpaceOnUse"><stop stop-color="#F0B90B"></stop><stop offset="1" stop-color="#F8D33A"></stop></linearGradient></defs></svg>-->
     <img src="{{ asset('public/assets/img/blog.svg') }}" class="support-sec-svg" alt="" >
      <div class="threediv-block-txt-div">
        <div class="threediv-block-txt-top">Wealthmark Blog</div>
        <!--<div class="css-1s4zn8r">Average daily volume</div>-->
      </div>
    </div>
    </a>
  </div>
  <div class="threediv-block">
       <a href="#">
    <div class="threediv-block-inner">
     <!--<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="support-sec-svg"><path d="M3 13h2V8H3v5z" fill="#76808F"></path><path d="M17 6H5v9H17l4 4V2l-4 4z" fill="url(#announcement-g_svg__paint0_linear)"></path><path d="M14 15H7v7h4v-5h3v-2z" fill="#76808F"></path><defs><linearGradient id="announcement-g_svg__paint0_linear" x1="13.001" y1="19" x2="13.001" y2="2" gradientUnits="userSpaceOnUse"><stop stop-color="#F0B90B"></stop><stop offset="1" stop-color="#F8D33A"></stop></linearGradient></defs></svg>-->
      <img src="{{ asset('public/assets/img/announcements.svg') }}" class="support-sec-svg" alt="" >
      <div class="threediv-block-txt-div">
        <div class="threediv-block-txt-top">Announcements</div>
        <!--<div class="css-1s4zn8r">Transactions per second</div>-->
      </div>
    </div></a>
  </div>
  <div class="threediv-block">
       <a href="#">
    <div class="threediv-block-inner">
    <!--<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="support-sec-svg"><path d="M11.5 17a4.5 4.5 0 10-9 0 4.5 4.5 0 009 0z" fill="url(#all-g_svg__paint0_linear_1341_1)"></path><path d="M17 12l-5-5 5-5 5 5-5 5z" fill="url(#all-g_svg__paint1_linear_1341_1)"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M21 21v-8h-8v8h8z" fill="#76808F"></path><path fill="#76808F" d="M11 11H3V3h8z"></path><defs><linearGradient id="all-g_svg__paint0_linear_1341_1" x1="7" y1="21.5" x2="7" y2="12.5" gradientUnits="userSpaceOnUse"><stop stop-color="#F0B90B"></stop><stop offset="1" stop-color="#F8D33A"></stop></linearGradient><linearGradient id="all-g_svg__paint1_linear_1341_1" x1="17" y1="12" x2="17" y2="2" gradientUnits="userSpaceOnUse"><stop stop-color="#F0B90B"></stop><stop offset="1" stop-color="#F8D33A"></stop></linearGradient></defs></svg>-->
      <img src="{{ asset('public/assets/img/media-assets.svg') }}" class="support-sec-svg" alt="" >
      <div class="threediv-block-txt-div">
        <div class="threediv-block-txt-top">Media Assets</div>
        <!--<div class="css-1s4zn8r">Customer Support in 40 languages</div>-->
      </div>
    </div></a>
  </div>
</div>
              </div>
      
     </div> 
     

   <section>
       <div class="container">
             <div class="row">
           <div class="col-md-12">
                <div class="sec-title">
                            <span class="title">Welcome to Wealthmark</span>
                            <h2 class="heading-h2">About Wealthmark</h2>
                </div>
                <div class="text">
                    Wealthmark is the world’s leading blockchain ecosystem and cryptocurrency infrastructure provider with a financial product suite that includes the largest digital asset exchange.
                </div>
                  <div class="mt-3">
                     <a href="#" class="btn btn-blue shadow"> View Openings</a>
                 </div>
           </div>
            </div>
        </div>
   </section>
   
   <section class="remove-- bg-light-blue">
  <div class="container">

    
       <div class="col-md-12">
                   <div class="sec-title text-left mb-3">
                        <h2 class="heading-h2">Official Announcements</h2>
                        <div class="text mt-0"><b> Stay up to date on Wealthmark product updates, new listings, trading competitions and other important announcements... </b></div>
                        <a href="#" class="news-link-btn">View More &gt;&gt;</a>
                    </div>
            </div>
            
  
      <h2>
      Latest announcement
      </h2>
      <div class="news-container">
        <div class="news-sidebar-left">
          <a  href="#"  class="news-title-link">
            <h5>
              <div class="overflow-ellipsis-div">Wealthmark P2P Turns 3! Stand a Chance to Share 33,000 BUSD in Rewards, Receive Exclusive Wealthmark <wbr>
                <span class="overflow-ellipsis">…</span>
              </div>
            </h5>
          </a>
          <div  class="news-text">
            <div class="overflow-ellipsis-div">This is a general announcement. Products and services referred to here may not be available in your region.Reminder: Click the [Join now] button on the main activity page to be eligible for the rewards.To celebrate Wealthmark P2P’s third anniversary, we are launching a series of promotions for all P2P users! A total rewards pool of 33,000 BUSD is up for grabs, and eligible users will <wbr>
              <span class="overflow-ellipsis">…</span>
            </div>
          </div>
          <div  class="news-hosted-by">By Wealthmark Team, 11:40</div>
        </div>
        <div class="news-sidebar">
          <a  href="#" class="news-list-right">
            <div class="news-list-flex-div">
              <div  class="news-list-flex-div-inner">
                <div class="overflow-ellipsis-div">Subscribe to ALPINE Locked Products &amp; Stand a Chance to Enjoy <wbr>
                  <span class="overflow-ellipsis">…</span>
                </div>
              </div>
              <div  class="news-time">09:35</div>
            </div>
          </a>
          <a  href="#"  class="news-list-right">
            <div class="news-list-flex-div">
              <div  class="news-list-flex-div-inner">
                <div class="LinesEllipsis  ">Wealthmark Convert Adds PROS <wbr>
                </div>
              </div>
              <div  class="news-time">08:30</div>
            </div>
          </a>
          <a  href="#" class="news-list-right">
            <div class="news-list-flex-div">
              <div  class="news-list-flex-div-inner">
                <div class="overflow-ellipsis-div">Read Wealthmark News and Play WODL to Share $25,000 in SKL Token <wbr>
                  <span class="overflow-ellipsis">…</span>
                </div>
              </div>
              <div  class="news-time">07:30</div>
            </div>
          </a>
          <a  href="#" class="news-list-right">
            <div class="news-list-flex-div">
              <div  class="news-list-flex-div-inner">
                <div class="overflow-ellipsis-div">Join the Wealthmark Academy NFT Study Week and Share Up to 50,000 <wbr>
                  <span class="overflow-ellipsis">…</span>
                </div>
              </div>
              <div  class="news-time">05:30</div>
            </div>
          </a>
        </div>
      </div>
   
  </div>
</section>
   
   <section class="latest_news">
       <div class="container">
      <div class="row">
          <div class="col-md-12">
                   <div class="sec-title text-left mb-3">
                        <h2 class="heading-h2">Latest News</h2>
                        <div class="text mt-0"><b> Keep up to date with the latest crypto news and updates.. </b></div>
                        <a href="#" class="news-link-btn">View More &gt;&gt;</a>
                    </div>
            </div>
          <div class="col-md-4 col-sm-6">
               <div class="card">
            <div class="card-left">
                <div class="card-img"></div>
            </div>
            <div class="card-right">
                <h5 class="">New 1-Second Interval Feature Now Available on Spot and Margin Charts</h5>
                <div class="text">Wealthmark has just launched our latest feature for traders who want to monitor price changes by the second....</div>
                <div class="card-right-body">
                    <div class="card-rb-1">
                        <img src="https://rvs-article-preview-component.netlify.app/images/avatar-michelle.jpg" alt="">
                    </div>
                    <div class="card-rb-2">
                        <div class="card-rb-2-title fw-7">Michelle Appleton</div>
                        <div class="card-rb-2-text fw-5">28 Jun 2020</div>
                    </div>
                    <div class="card-rb-3">
                        <div class="card-rb-3-inner"></div>
                        <div class="card-rb-3-inner-before">
                            <div class="before-1">SHARE</div>
                            <div class="before-2"><img src="https://rvs-article-preview-component.netlify.app/images/icon-facebook.svg" alt=""></div>
                            <div class="before-3"><img src="https://rvs-article-preview-component.netlify.app/images/icon-twitter.svg" alt=""></div>
                            <div class="before-4"><img src="https://rvs-article-preview-component.netlify.app/images/icon-pinterest.svg" alt=""></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
          </div>
          <div class="col-md-4 col-sm-6">
               <div class="card">
            <div class="card-left">
                <div class="card-img"></div>
            </div>
            <div class="card-right"> 
                <h5 class="">New 1-Second Interval Feature Now Available on Spot and Margin Charts</h5>
                <div class="text">Wealthmark has just launched our latest feature for traders who want to monitor price changes by the second....</div>
                <div class="card-right-body">
                    <div class="card-rb-1">
                        <img src="https://rvs-article-preview-component.netlify.app/images/avatar-michelle.jpg" alt="">
                    </div>
                    <div class="card-rb-2">
                        <div class="card-rb-2-title fw-7">Michelle Appleton</div>
                        <div class="card-rb-2-text fw-5">28 Jun 2020</div>
                    </div>
                    <div class="card-rb-3">
                        <div class="card-rb-3-inner"></div>
                        <div class="card-rb-3-inner-before">
                            <div class="before-1">SHARE</div>
                            <div class="before-2"><img src="https://rvs-article-preview-component.netlify.app/images/icon-facebook.svg" alt=""></div>
                            <div class="before-3"><img src="https://rvs-article-preview-component.netlify.app/images/icon-twitter.svg" alt=""></div>
                            <div class="before-4"><img src="https://rvs-article-preview-component.netlify.app/images/icon-pinterest.svg" alt=""></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
          </div>
          <div class="col-md-4 col-sm-6">
               <div class="card">
            <div class="card-left">
                <div class="card-img"></div>
            </div>
            <div class="card-right">
               <h5 class="">New 1-Second Interval Feature Now Available on Spot and Margin Charts</h5>
                <div class="text">Wealthmark has just launched our latest feature for traders who want to monitor price changes by the second....</div>
                <div class="card-right-body">
                    <div class="card-rb-1">
                        <img src="https://rvs-article-preview-component.netlify.app/images/avatar-michelle.jpg" alt="">
                    </div>
                    <div class="card-rb-2">
                        <div class="card-rb-2-title fw-7">Michelle Appleton</div>
                        <div class="card-rb-2-text fw-5">28 Jun 2020</div>
                    </div>
                    <div class="card-rb-3">
                        <div class="card-rb-3-inner"></div>
                        <div class="card-rb-3-inner-before">
                            <div class="before-1">SHARE</div>
                            <div class="before-2"><img src="https://rvs-article-preview-component.netlify.app/images/icon-facebook.svg" alt=""></div>
                            <div class="before-3"><img src="https://rvs-article-preview-component.netlify.app/images/icon-twitter.svg" alt=""></div>
                            <div class="before-4"><img src="https://rvs-article-preview-component.netlify.app/images/icon-pinterest.svg" alt=""></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
          </div>
         
          <div class="col-md-4 col-sm-6">
               <div class="card">
            <div class="card-left">
                <div class="card-img"></div>
            </div>
            <div class="card-right">
              <h5 class="">New 1-Second Interval Feature Now Available on Spot and Margin Charts</h5>
                <div class="text">Wealthmark has just launched our latest feature for traders who want to monitor price changes by the second....</div>
                <div class="card-right-body">
                    <div class="card-rb-1">
                        <img src="https://rvs-article-preview-component.netlify.app/images/avatar-michelle.jpg" alt="">
                    </div>
                    <div class="card-rb-2">
                        <div class="card-rb-2-title fw-7">Michelle Appleton</div>
                        <div class="card-rb-2-text fw-5">28 Jun 2020</div>
                    </div>
                    <div class="card-rb-3">
                        <div class="card-rb-3-inner"></div>
                        <div class="card-rb-3-inner-before">
                            <div class="before-1">SHARE</div>
                            <div class="before-2"><img src="https://rvs-article-preview-component.netlify.app/images/icon-facebook.svg" alt=""></div>
                            <div class="before-3"><img src="https://rvs-article-preview-component.netlify.app/images/icon-twitter.svg" alt=""></div>
                            <div class="before-4"><img src="https://rvs-article-preview-component.netlify.app/images/icon-pinterest.svg" alt=""></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
          </div>
          <div class="col-md-4 col-sm-6">
               <div class="card">
            <div class="card-left">
                <div class="card-img"></div>
            </div>
            <div class="card-right">
               <h5 class="">New 1-Second Interval Feature Now Available on Spot and Margin Charts</h5>
                <div class="text">Wealthmark has just launched our latest feature for traders who want to monitor price changes by the second....</div>
                <div class="card-right-body">
                    <div class="card-rb-1">
                        <img src="https://rvs-article-preview-component.netlify.app/images/avatar-michelle.jpg" alt="">
                    </div>
                    <div class="card-rb-2">
                        <div class="card-rb-2-title fw-7">Michelle Appleton</div>
                        <div class="card-rb-2-text fw-5">28 Jun 2020</div>
                    </div>
                    <div class="card-rb-3">
                        <div class="card-rb-3-inner"></div>
                        <div class="card-rb-3-inner-before">
                            <div class="before-1">SHARE</div>
                            <div class="before-2"><img src="https://rvs-article-preview-component.netlify.app/images/icon-facebook.svg" alt=""></div>
                            <div class="before-3"><img src="https://rvs-article-preview-component.netlify.app/images/icon-twitter.svg" alt=""></div>
                            <div class="before-4"><img src="https://rvs-article-preview-component.netlify.app/images/icon-pinterest.svg" alt=""></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
          </div>
          <div class="col-md-4 col-sm-6">
               <div class="card">
            <div class="card-left">
                <div class="card-img"></div>
            </div>
            <div class="card-right">
               <h5 class="">New 1-Second Interval Feature Now Available on Spot and Margin Charts</h5>
                <div class="text">Wealthmark has just launched our latest feature for traders who want to monitor price changes by the second....</div>
                <div class="card-right-body">
                    <div class="card-rb-1">
                        <img src="https://rvs-article-preview-component.netlify.app/images/avatar-michelle.jpg" alt="">
                    </div>
                    <div class="card-rb-2">
                        <div class="card-rb-2-title fw-7">Michelle Appleton</div>
                        <div class="card-rb-2-text fw-5">28 Jun 2020</div>
                    </div>
                    <div class="card-rb-3">
                        <div class="card-rb-3-inner"></div>
                        <div class="card-rb-3-inner-before">
                            <div class="before-1">SHARE</div>
                            <div class="before-2"><img src="https://rvs-article-preview-component.netlify.app/images/icon-facebook.svg" alt=""></div>
                            <div class="before-3"><img src="https://rvs-article-preview-component.netlify.app/images/icon-twitter.svg" alt=""></div>
                            <div class="before-4"><img src="https://rvs-article-preview-component.netlify.app/images/icon-pinterest.svg" alt=""></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
          </div>
         
      </div>
       </div>
    
   </section>
   
    <section>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                   <div class="sec-title text-left mb-3">
                        <span class="title">Welcome to Wealthmark</span>
                        <h2 class="heading-h2">Latest News</h2>
                        <div class="text mt-0"><b> Keep up to date with the latest crypto news and updates.. </b></div>
                        <a   href="#" class="news-link-btn">View More &gt;&gt;</a>
                    </div>
                </div>
          
                <div class="col-md-12">
                 <a href="#">
                    <div class="news_container">
                      <div class="news_main_div">
                        <img src="https://rvs-article-preview-component.netlify.app/images/drawers.jpg" class="news_img">
                        <div class="news_inner-right">
                         
                            <h4 class="">Read Wealthmark News and Play WODL to Share $25,000 in SKL Token Vouchers, With Additional $5,00 <wbr>
                              <span class="overflow-ellipsis">...</span>
                            </h4>
                         
                        
                            <div class="text">Activity Period: 2022-10-10 00:00 (UTC) to 2022-10-16 23:59 (UTC)Crypto WODL is a mini-game that allows users to guess mystery words to understand the latest market developments while earning crypto rewards.&nbsp;The theme of this week is ETH Merge. Read Wealthmark News to learn more about this topic and participate in this week’s WODL. Users who get at least five corre <wbr>
                              <span class="overflow-ellipsis">...</span>
                            </div>
                          
                          <div class="news_bottom">
                            
                              <div class="latest-news-text">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="latest-news-svg">
                                  <path fill-rule="evenodd" clip-rule="evenodd" d="M15 3.5a5.502 5.502 0 00-5.302 4.032 7.502 7.502 0 016.77 6.77A5.502 5.502 0 0015 3.5zM14.5 15a5.5 5.5 0 10-11 0 5.5 5.5 0 0011 0zm-8 0L9 17.5l2.5-2.5L9 12.5 6.5 15zM9 4H4v5l5-5zm11 16h-5l5-5v5z" fill="currentColor"></path>
                                </svg>
                                <div class="news-brand">BTC</div>
                                <div class="news-status">-0.97%</div>
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="latest-news-svg">
                                  <path fill-rule="evenodd" clip-rule="evenodd" d="M12.288 12l-3.89 3.89 1.768 1.767L15.823 12l-1.768-1.768-3.889-3.889-1.768 1.768 3.89 3.89z" fill="currentColor"></path>
                                </svg>
                              </div>
                            
                            
                              <div class="latest-news-text">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="latest-news-svg">
                                  <path fill-rule="evenodd" clip-rule="evenodd" d="M15 3.5a5.502 5.502 0 00-5.302 4.032 7.502 7.502 0 016.77 6.77A5.502 5.502 0 0015 3.5zM14.5 15a5.5 5.5 0 10-11 0 5.5 5.5 0 0011 0zm-8 0L9 17.5l2.5-2.5L9 12.5 6.5 15zM9 4H4v5l5-5zm11 16h-5l5-5v5z" fill="currentColor"></path>
                                </svg>
                                <div class="news-brand">ETH</div>
                                <div class="news-status">-0.84%</div>
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="latest-news-svg">
                                  <path fill-rule="evenodd" clip-rule="evenodd" d="M12.288 12l-3.89 3.89 1.768 1.767L15.823 12l-1.768-1.768-3.889-3.889-1.768 1.768 3.89 3.89z" fill="currentColor"></path>
                                </svg>
                              </div>
                          
                              <div class="latest-news-text">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="latest-news-svg">
                                  <path fill-rule="evenodd" clip-rule="evenodd" d="M15 3.5a5.502 5.502 0 00-5.302 4.032 7.502 7.502 0 016.77 6.77A5.502 5.502 0 0015 3.5zM14.5 15a5.5 5.5 0 10-11 0 5.5 5.5 0 0011 0zm-8 0L9 17.5l2.5-2.5L9 12.5 6.5 15zM9 4H4v5l5-5zm11 16h-5l5-5v5z" fill="currentColor"></path>
                                </svg>
                                <div class="news-brand">BNB</div>
                                <div class="news-status">-1.15%</div>
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="latest-news-svg">
                                  <path fill-rule="evenodd" clip-rule="evenodd" d="M12.288 12l-3.89 3.89 1.768 1.767L15.823 12l-1.768-1.768-3.889-3.889-1.768 1.768 3.89 3.89z" fill="currentColor"></path>
                                </svg>
                              </div>
                           
                          </div>
                        
                        </div>
                      </div>
                    </div>
                    </a>
                </div>
            </div> 
         </section>
    
    @include('template.country_language')
    @include('template.web_footer') 
    
   
  
    </body>
</html>