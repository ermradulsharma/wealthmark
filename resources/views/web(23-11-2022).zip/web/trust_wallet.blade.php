<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <title>Wealth Mark | {{ Request::segment(2) }}</title>
    <link rel='stylesheet' href="{{('../public/assets/css/deepak_custom.css') }}">
    @include('template.web_css')
</head>
<body>
    @include('template.mobile_menu')
    @include('template.web_menu')
    <!-- <div class="text-center bg-light-yellow" id="register-row">
        <a href="{{ url( app()->getLocale(), 'register') }}"> <span class="offer-text-head">
                Register now - Enjoy Welcome Rewards up to 1 BMK! ( for verified user)
            </span>
        </a>
    </div> -->

    <!-- banner section started -->

    <section class="pt-8 pb-8 bg-gradient-primary trust-banner-section" id="trust-wallet-banner-section">
        <div class="container">
            <div class="row align-items-center justify-content-center justify-content-md-between">
                <div class="col-12 col-lg-6 mb-8 text-md-left text-white order-2 order-lg-1">
                    <h1 class="display-3 font-weight-bold trust-wallet-heading">The most trusted &amp; secure crypto wallet</h1>
                    <p class="text-white-90 lead mb-4 banner-para">Buy, store, collect NFTs, exchange &amp; earn
                        crypto.<br />
                        Join 25 million+ people using Trust Wallet.</p>
                    <div class="download-button">
                        <div class="row download-button-group">
                            <div class="col-12 col-lg-4 col-sm-4 apple-button">
                                <a href="#"><img loading="lazy" class="mx-auto d-block img-fluid"
                                        src="{{ asset('public/assets/img/app-store.svg') }}" alt="Trust Wallet Image">
                                </a>
                            </div>
                            <div class="col-12 col-lg-4 col-sm-4 googleplay-button">
                                <a href="#"><img loading="lazy" class="mx-auto d-block img-fluid"
                                        src="{{ asset('public/assets/img/google_play.svg') }}" alt="Trust Wallet Image">
                                </a>
                            </div>
                            <div class="col-12 col-lg-4 col-sm-4 androidapk-button">
                                <a href="#"><img loading="lazy" class="mx-auto d-block img-fluid"
                                        src="{{ asset('public/assets/img/window-10.svg') }}" alt="Trust Wallet Image">
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-lg-6 text-center order-1 order-lg-2">
                    <img loading="lazy" class="mx-auto d-block img-fluid banner-main-img"
                        src="{{ asset('public/assets/img/home_hero.png') }}" alt="Trust Wallet Image">
                </div>
            </div>
        </div>
    </section>
    <!-- banner section End -->

    <!-- three offers block start -->

    <section class="three-offers-block" id="three-offers-section">
        <div class="container">
            <div class="row border-bottom justify-content-center pt-4 pb-4">
                <div class="col-12 col-md-auto mr-auto d-flex d-flex-1">
                    <div class="icon icon-xs">
                        <img loading="lazy" class="mx-auto d-block img-fluid"
                            src="{{ asset('public/assets/img/buy-card.png') }}" alt="Trust Wallet Image">
                    </div>
                    <div class="ml-4">
                        <span class="font-weight-bold lead">
                            Buy Crypto With a Card
                        </span>
                    </div>
                </div>
                <div class="col-12 col-md-auto d-flex d-flex-2">
                    <div class="icon icon-xs">
                        <img loading="lazy" class="mx-auto d-block  img-fluid"
                            src="{{ asset('public/assets/img/exchange-icon.png') }}" alt="Trust Wallet Image">
                    </div>
                    <div class="ml-4">
                        <span class="font-weight-bold lead">
                            Exchange Instantly
                        </span>
                    </div>
                </div>
                <div class="col-12 col-md-auto ml-auto d-flex d-flex-3">
                    <div class="icon icon-xs">
                        <img loading="lazy" class="mx-auto d-block img-fluid"
                            src="{{ asset('public/assets/img/secure-icon.png') }}" alt="Trust Wallet Image">
                    </div>
                    <div class="ml-4">
                        <span class="font-weight-bold lead">
                            Private &amp; Secure
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- three offers block end -->


    <!-- basic crypto info block start -->
    <section class="pt-8" id="crypto-info-section">
        <div class="container">
            <div class="row">
                <div class="sec-title text-left">
                    <span class="title">Know About</span>
                    <h2 class="heading-h2">Cryptocurrencies & Trust Wallet</h2>
                </div>
            </div>
            <div class="row align-items-center justify-content-center justify-content-md-between pb-4 text-center">
                <div class="col-12 col-lg-6">
                    <div class="list-group-item d-flex"><span class="check-icon"> </span>Buy Bitcoin in
                        under five minutes</div>
                    <div class="list-group-item d-flex"><span class="check-icon"></span>Easily earn
                        interest on the crypto in your wallet</div>
                    <div class="list-group-item d-flex"><span class="check-icon"></span>See your
                        collectibles. Art &amp; NFTs in one place</div>
                </div>
                <div class="col-12 col-lg-6">
                    <div class="list-group-item d-flex"><span class="check-icon"></span>Exchange your
                        crypto without leaving the app</div>
                    <div class="list-group-item d-flex"><span class="check-icon"></span>Track charts
                        and prices within the app</div>
                    <div class="list-group-item d-flex"><span class="check-icon"></span>Keep your
                        crypto safe from hackers &amp; scammers</div>
                </div>
                <a href="#" class="btn btn-yellow shadow crypto-download-btn info-button btn btn-primary mt-6 mx-auto ">
                    Download Now</a>
            </div>
        </div>
    </section>
    <!-- basic crypto info block end -->

    <!-- About us  block start -->
    <section class="pt-8" id="about-us-section">
        <div class="container">

            <div class="row align-items-center justify-content-center justify-content-md-between">
                <div class="col-12 col-md-6 col-lg-5 text-md-left mb-4 order-2 order-lg-2">
                    <h2 class="display-4 font-weight-bold mt-4">Buy Crypto With a Card</h2>
                    <p class="lead text-gray-7">Get your first $50 of Bitcoin, Ethereum, Wealth Mark Coin and many
                        other
                        cryptocurrencies.</p>
                </div>
                <div class="col-12 col-md-6 col-lg-7 img-hover2 order-1 order-lg-1">
                    <figure><img loading="lazy" class="mx-auto d-block img-fluid float-start"
                            src="{{ asset('public/assets/img/home_cards.png') }}" alt="Trust Wallet Image">
                        <figure>
                </div>
            </div>

            <div class="row align-items-center justify-content-center justify-content-md-between">
                <div class="col-12 col-md-6 col-lg-5 text-md-left mb-4 order-2 order-lg-1">
                    <h2 class="display-4 font-weight-bold mt-8">Exchange Instantly</h2>
                    <p class="lead text-gray-700">No forms, no selfies. Trade crypto anytime with ease.</p>
                </div>
                <div class="col-12 col-md-6 col-lg-7 img-hover3 order-1 order-lg-2">
                    <figure><img loading="lazy" class="mx-auto d-block img-fluid float-end"
                            src="{{ asset('public/assets/img/home_dex.png') }}" alt="Trust Wallet Image"></figure>
                </div>
            </div>

            <div class="row align-items-center justify-content-center justify-content-md-between">
                <div class="col-12 col-md-6 col-lg-5 order-sm-2 text-md-left mb-4  order-2 order-lg-2">
                    <h2 class="display-4 font-weight-bold mt-8">Private &amp; Secure</h2>
                    <p class="lead text-gray-700">Only you can access your wallet. We don’t collect any personal data.
                    </p>
                </div>
                <div class="col-12 col-md-6 col-lg-7 img-hover4 order-1 order-lg-1">
                    <figure> <img loading="lazy" class="mx-auto d-block img-fluid float-start"
                            src="{{ asset('public/assets/img/home_security.png') }}" alt="Trust Wallet Image">
                        <figure>
                </div>
            </div>

            <div class="row align-items-center justify-content-center justify-content-md-between">
                <div class="col-12 col-md-6 col-lg-5 text-md-left order-2 order-lg-1">
                    <h2 class="display-4 font-weight-bold mt-8">Browser for Apps</h2>
                    <p class="lead text-gray-700">Use your favourite decentralized apps &amp; find new ones, without
                        leaving your wallet.</p>
                </div>
                <div class="col-12 col-md-6 col-lg-7 img-hover5 order-1 order-lg-2">
                    <figure><img loading="lazy" class="mx-auto d-block float-end img-fluid"
                            src="{{ asset('public/assets/img/home_dapps.png') }}" alt="Trust Wallet Image">
                        <figure>
                </div>
            </div>

        </div>
    </section>
    <!-- About us  block end -->


    <!-- Get Started in three steps start -->

    <section class="pt-8 pb-8 pt-sm-10 pb-sm-10" id="steps-section">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center mb-2">
                    <h3 class="display-4 font-weight-bold">
                        Get started in 3 simple steps
                    </h3>
                    <p class="lead text-gray-700">It only takes a few minutes</p>
                </div>
            </div>
            <div class="row no-gutters mt-8 mb-6 mb-md-7" id="character-group">
                <div class="col-12 col-md-4 text-center">
                    <div class="row step-row">
                        <a href="#"><img loading="lazy" class="hero-image mx-auto d-block img-fluid"
                                src="{{ asset('public/assets/img/get-started-icon-1.png') }}" alt="Trust Wallet Image">
                        </a>
                        <h3 class="font-weight-bold">
                            Download Trust Wallet
                        </h3>
                    </div>

                </div>
                <div class="col-12 col-md-4 text-center">
                    <div class="row step-row">
                        <a href="#"><img loading="lazy" class="hero-image mx-auto d-block img-fluid"
                                src="{{ asset('public/assets/img/get-started-icon-2.png') }}" alt="Trust Wallet Image">
                        </a>
                        <h3 class="font-weight-bold">
                            Create a new wallet
                        </h3>
                    </div>

                </div>
                <div class="col-12 col-md-4 text-center">
                    <div class="row step-row">
                        <a href="#"><img loading="lazy" class="hero-image mx-auto d-block img-fluid"
                                src="{{ asset('public/assets/img/get-started-icon-3.png') }}" alt="Trust Wallet Image">
                        </a>
                        <h3 class="font-weight-bold">
                            Get some crypto
                        </h3>
                    </div>

                </div>
            </div>
            <div class="row">
                <div class="col-12 text-center">
                    <a href="#" class="btn btn-yellow shadow mt-6 mx-auto info-button crypto-download-btn"> Download
                        Now</a>
                </div>
            </div>
        </div>
    </section>
    <!-- Get Started in three steps end -->

    <!-- Get the Trust Wallet Image now section start -->
    <!-- <section class="bg-light" id="get-trust-app-section">
        <div class="container pt-8 pb-8">
            <div class="row align-items-center">
                <div class="col-12 col-md text-lg-left mt-2">
                    <h3 class="font-weight-bold mb-1">
                        Get the Trust Wallet Image now!
                    </h3>
                    <p class="text-gray-700 mb-6 mb-md-0 no-whitespace">
                        The most trusted &amp; secure crypto wallet
                    </p>
                </div>
                <div class="col-12 col-lg-7">
                    <div class="download-button">
                        <div class="row download">
                        <div class="col-12 col-lg-4 appleapp">
                            <a href="#"><img loading="lazy" class="hero-image mx-auto d-block img-fluid" src="{{ asset('public/assets/img/app-store.svg') }}"
                        alt="Trust Wallet Image">
                                </a>
                            </div>
                            <div class="col-12 col-lg-4 googleplay">
                            <a href="#"><img loading="lazy" class="hero-image mx-auto d-block img-fluid" src="{{ asset('public/assets/img/google_play.svg') }}"
                        alt="Trust Wallet Image">
                                </a>
                            </div>
                            <div class="col-12 col-lg-4 androidapk">
                            <a href="#"><img loading="lazy" class="hero-image mx-auto d-block img-fluid" src="{{ asset('public/assets/img/window-10.svg') }}"
                        alt="Trust Wallet Image">
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section> -->
    <!-- Get the Trust Wallet Image now section end -->

    @include('template.country_language')
    @include('template.web_footer')
</body>

</html>