<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <title>Wealth Mark | {{ Request::segment(2) }}</title>
    @include('template.web_css')
    <link rel='stylesheet' href="{{('../public/assets/css/deepak_custom.css') }}">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script>
    $(document).ready(function() {
        $("#project-1").click(function() {
            $("#project-1").addClass("active-project-tab");
            $("#project-2").removeClass("active-project-tab");
            $("#project-report-tab").show();
            $("#project-analysis-tab").hide();
        });
        $("#project-2").click(function() {
            $("#project-2").addClass("active-project-tab");
            $("#project-1").removeClass("active-project-tab");
            $("#project-report-tab").hide();
            $("#project-analysis-tab").show();
        });
    });
    </script>

</head>

<body>
    @include('template.mobile_menu')
    @include('template.web_menu')

    <!-- banner section started -->
    <section class="pt-8 pb-8 bg-gradient-primary" id="research-banner-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-xs-12 col-sm-12 text-center text-md-left text-white">
                    <h1 class="display-3 font-weight-bold text-left">Wealth Mark</h1>
                    <p class="text-white-90 lead mb-4 banner-para">Wealth Mark Research provides institutional-grade
                        analysis, in-depth insights, and unbiased information to all participants in the digital asset
                        industry.</p>
                </div>
                <div class="col-lg-6 col-xs-12 col-sm-12 text-center">
                    <img loading="lazy" class="d-block img-fluid banner-main-img"
                        src="{{ asset('public/assets/img/research-banner.png') }}" alt="Research Image">
                </div>
            </div>
        </div>
    </section>
    <!-- banner section End -->

    <!-- project tabs -->
    <section class="pt-8 pb-8" id="project-tabs-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-xs-12 col-sm-12 text-center">
                    <ul class="row nav nav-tabs" id="myTab" role="tablist">
                        <li class="col-md-6 nav-item" role="presentation">
                            <button class="nav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#home"
                                type="button" role="tab" aria-controls="home" aria-selected="true">
                                <img loading="lazy" class="mx-auto d-block project-icon img-fluid"
                                    src="{{ asset('public/assets/img/project-report-icon.png') }}"
                                    alt="Research Image">
                                Project Reports
                            </button>
                        </li>
                        <li class="col-md-6 nav-item" role="presentation">
                            <button class="nav-link" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile"
                                type="button" role="tab" aria-controls="profile" aria-selected="false">
                                <img loading="lazy" class="mx-auto d-block project-icon img-fluid"
                                    src="{{ asset('public/assets/img/analysis-report.png') }}" alt="Research Image">
                                Analysis Report
                            </button>
                        </li>
                    </ul>
                    <div class="tab-content" id="myTabContent">
                        <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                            <div class="row">
                                <div class="col-md-4">
                                    <img loading="lazy" src="{{ asset('public/assets/img/latest-project.png') }}"
                                        alt="Research Image" class="img-fluid">
                                </div>
                                <div class="col-md-8">
                                    <h3 class="">Project Reports</h3>
                                    <p class="mb-3">"Lorem Ipsum is simply dummy text of the printing and typesetting
                                        industry". </p>
                                    <a class="text-warning">Read More </a>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">

                            <div class="row">
                                <div class="col-md-4">
                                    <img loading="lazy" src="{{ asset('public/assets/img/latest-insight-img.png') }}"
                                        alt="Research Image" class="img-fluid">
                                </div>
                                <div class="col-md-8">
                                    <h3 class="">Analysis Reports</h3>
                                    <p class="mb-3">"Lorem Ipsum is simply dummy text of the printing and typesetting
                                        industry". </p>
                                    <span class="text-warning">Read our latest report </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- project tabs -->


    <section class="insight-section" id="insight">
        <div class="container">
            <div class="row heading-row-insight">
                <div class="col-md-8 col-xs-6 col-sm-6 sec-title text-left insight-heading-block">
                    <span class="title">Know About</span>
                    <h2 class="heading-h2">Insights & Analysis</h2>
                </div>
                <div class="col-md-4 col-xs-6 col-sm-6 sec-title text-right view-all-block insight-heading-block ">
                    <h2 class="float-right view-all-btn  research-view-all">View all cards →</h2>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="card">
                        <img loading="lazy" src="{{ asset('public/assets/img/latest-insight-img.png') }}"
                            alt="Research Image" class="img-fluid">
                        <div class="card-body">
                            <h5 class="card-title">Latest Insights & Analysis</h5>
                            <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
                            <a href="" class="text-warning">View More</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="card">
                        <img loading="lazy" src="{{ asset('public/assets/img/latest-insight-img.png') }}"
                            alt="Research Image" class="img-fluid">
                        <div class="card-body">
                            <h5 class="card-title">Latest Insights & Analysis</h5>
                            <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
                            <a href="" class="text-warning">View More</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="card">
                        <img loading="lazy" src="{{ asset('public/assets/img/latest-insight-img.png') }}"
                            alt="Research Image" class="img-fluid">
                        <div class="card-body">
                            <h5 class="card-title">Latest Insights & Analysis</h5>
                            <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
                            <a href="" class="text-warning">View More</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="card">
                        <img loading="lazy" src="{{ asset('public/assets/img/latest-insight-img.png') }}"
                            alt="Research Image" class="img-fluid">
                        <div class="card-body">
                            <h5 class="card-title">Latest Insights & Analysis</h5>
                            <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
                            <a href="" class="text-warning">View More</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>



    <!-- latest project report -->

    <section class="project-section" id="project-report-new">
        <div class="container">
            <div class="row project-report-new_heading-row">
                <div class="col-md-8 col-xs-6 col-sm-6 sec-title text-left new-project-heading-block">
                    <span class="title">Know About</span>
                    <h2 class="heading-h2">Latest Project Report</h2>
                </div>
                <div class="col-md-4 col-xs-6 col-sm-6 sec-title text-right view-all-block  new-project-heading-block">
                    <h2 class="float-right view-all-btn text-right">View all cards →</h2>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="card">
                        <img loading="lazy" src="{{ asset('public/assets/img/latest-project.png') }}"
                            alt="Research Image" class="img-fluid">
                        <div class="card-body">
                            <h5 class="card-title">Latest Project Reports-1</h5>
                            <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
                            <a href="" class="text-warning">View More</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="card">
                        <img loading="lazy" src="{{ asset('public/assets/img/latest-project.png') }}"
                            alt="Research Image" class="img-fluid">
                        <div class="card-body">
                            <h5 class="card-title">Latest Project Reports-1</h5>
                            <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
                            <a href="" class="text-warning">View More</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="card">
                        <img loading="lazy" src="{{ asset('public/assets/img/latest-project.png') }}"
                            alt="Research Image" class="img-fluid">
                        <div class="card-body">
                            <h5 class="card-title">Latest Project Reports-1</h5>
                            <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
                            <a href="" class="text-warning">View More</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="card">
                        <img loading="lazy" src="{{ asset('public/assets/img/latest-project.png') }}"
                            alt="Research Image" class="img-fluid">
                        <div class="card-body">
                            <h5 class="card-title">Latest Project Reports-1</h5>
                            <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
                            <a href="" class="text-warning">View More</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- our collaboration with clients -->

    <section class="research-clients-section" id="our-collaborations">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-xs-12 col-sm-12 sec-title text-left">
                    <span class="title">Know About</span>
                    <h2 class="heading-h2">Wealth Mark Research & collaborations</h2>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
                    <div class="clients-logo">
                        <img loading="lazy" src="{{ asset('public/assets/img/logo-1.png') }}" alt="Research Image"
                            class="img-fluid">
                    </div>
                </div>
                <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
                    <div class="clients-logo">
                        <img loading="lazy" src="{{ asset('public/assets/img/logo-2.png') }}" alt="Research Image"
                            class="img-fluid">
                    </div>
                </div>
                <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
                    <div class="clients-logo">
                        <img loading="lazy" src="{{ asset('public/assets/img/logo-3.png') }}" alt="Research Image"
                            class="img-fluid">
                    </div>
                </div>
                <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
                    <div class="clients-logo">
                        <img loading="lazy" src="{{ asset('public/assets/img/logo-4.png') }}" alt="Research Image"
                            class="img-fluid">
                    </div>
                </div>
                <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
                    <div class="clients-logo">
                        <img loading="lazy" src="{{ asset('public/assets/img/logo-5.png') }}" alt="Research Image"
                            class="img-fluid">
                    </div>
                </div>
               
                <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
                    <div class="clients-logo">
                        <img loading="lazy" src="{{ asset('public/assets/img/logo-8.png') }}" alt="Research Image"
                            class="img-fluid">
                    </div>
                </div>

            </div>

        </div>
    </section>
    @include('template.country_language')
    @include('template.web_footer')
</body>

</html>