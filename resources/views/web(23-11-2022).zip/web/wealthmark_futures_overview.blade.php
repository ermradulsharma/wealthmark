<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <title>Wealth Mark | Create Entity Account</title>
    @include('template.web_css')
    <link rel='stylesheet' href="{{('../public/assets/css/deepak_custom.css') }}">
</head>

<body class="bg-white">

    @include('template.mobile_menu')
    @include('template.web_menu')

    <section class="future-overview" id="future-overview-section">
        <div class="container">
            <div class="row">
                <div class="overview-inner-box">
                    <h3 class="digital-asset-heading">Trade Crypto Futures</h3>
                </div>
            </div>
            <div class="row overview-assets-row">
                <div class="col-md-12 d-flex">
                    <a class="btn btn-warning ">Register Now </a>
                    <a class="btn btn-primary">Login</a>
                </div>
            </div>

            <div class="row mt-5">
                <div class="col-md-2 col-lg-lg-2 col-sm-6 col-xs-6">
                    <div class="future-overview-detial-block">
                        <p>BTCBUSD <span>+4.05+ </span> </p>
                        <span class="text-warning">Perpetual </span>
                        <h4>1325.04 </h4>
                    </div>
                </div>
                <div class="col-md-2 col-lg-lg-2 col-sm-6 col-xs-6">
                    <div class="future-overview-detial-block">
                        <p>BTCBUSD <span>+4.05+ </span> </p>
                        <span class="text-warning">Perpetual </span>
                        <h4>1325.04 </h4>
                    </div>
                </div>
                <div class="col-md-2 col-lg-lg-2 col-sm-6 col-xs-6">
                    <div class="future-overview-detial-block">
                        <p>BTCBUSD <span>+4.05+ </span> </p>
                        <span class="text-warning">Perpetual </span>
                        <h4>1325.04 </h4>
                    </div>
                </div>
                <div class="col-md-2 col-lg-lg-2 col-sm-6 col-xs-6">
                    <div class="future-overview-detial-block">
                        <p>BTCBUSD <span>+4.05+ </span> </p>
                        <span class="text-warning">Perpetual </span>
                        <h4>1325.04 </h4>
                    </div>
                </div>
                <div class="col-md-2 col-lg-lg-2 col-sm-6 col-xs-6">
                    <div class="future-overview-detial-block">
                        <p>BTCBUSD <span>+4.05+ </span> </p>
                        <span class="text-warning">Perpetual </span>
                        <h4>1325.04 </h4>
                    </div>
                </div>
                <div class="col-md-2 col-lg-lg-2 col-sm-6 col-xs-6">
                    <div class="future-overview-detial-block">
                        <p>BTCBUSD <span>+4.05+ </span> </p>
                        <span class="text-warning">Perpetual </span>
                        <h4>1325.04 </h4>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <section class="future-overview-second" id="future-overview-second">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-lg-3 col-sm-6 col-xs-6">
                    <div class="future-overview-detial-block text-center">
                        <img loading="lazy" class="mx-auto d-block img-fluid"
                            src="{{ asset('public/assets/img/product-usdt-margin.svg') }}" alt="Wallet futures Overview Image">
                        <h4>Wealth Mark Options</h4>
                        <p class="text-center">Perpetual or Quarterly Contracts settled in USDT or BUSD.</p>
                        <a href="#" class="btn btn-yellow shadow mt-3">Trade Now</a>
                    </div>
                </div>
                <div class="col-md-3 col-lg-3 col-sm-6 col-xs-6">
                    <div class="future-overview-detial-block text-center">
                        <img loading="lazy" class="mx-auto d-block img-fluid"
                            src="{{ asset('public/assets/img/product-coin-margin.svg') }}" alt="Wallet futures Overview Image">
                        <h4>Strategy Trading</h4>
                        <p class="text-center">Perpetual or Quarterly Contracts settled in USDT or BUSD.</p>
                        <a href="#" class="btn btn-yellow shadow mt-3">Trade Now</a>
                    </div>
                </div>
                <div class="col-md-3 col-lg-3 col-sm-6 col-xs-6">
                    <div class="future-overview-detial-block text-center">
                        <img loading="lazy" class="mx-auto d-block img-fluid"
                            src="{{ asset('public/assets/img/product-social-trading.svg') }}" alt="Wallet futures Overview Image">
                        <h4>USDⓈ-M Futures</h4>
                        <p class="text-center">Perpetual or Quarterly Contracts settled in USDT or BUSD.</p>
                        <a href="#" class="btn btn-yellow shadow mt-3">Trade Now</a>
                    </div>
                </div>
                <div class="col-md-3 col-lg-3 col-sm-6 col-xs-6">
                    <div class="future-overview-detial-block text-center">
                        <img loading="lazy" class="mx-auto d-block img-fluid"
                            src="{{ asset('public/assets/img/product-eoptions.svg') }}" alt="Wallet futures Overview Image">
                        <h4>COIN-M Futures</h4>
                        <p class="text-center">Perpetual or Quarterly Contracts settled in USDT or BUSD.</p>
                        <a href="#" class="btn btn-yellow shadow mt-3">Trade Now</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="future-third-box" id="future-third-section">
        <div class="container">
            <div class="row mb-3">
                <div class="content-column col-lg-6 col-md-6 col-sm-12">
                    <div class="inner-column">
                        <div class="sec-title">
                            <span class="title">Know About</span>
                            <h2 class="heading-h2">Responsible Trading with Wealth Mark</h2>
                        </div>
                        <p>2021-06-29 18:01 | <span class="text-warning"> <a href="#" class="text-warning">Share to Friends &#8594;</a></span></p>
                        <div class="text">Trading should be well-planned and deliberate. To be a successful trader, you
                            must trade responsibly. Find out why responsible trading is crucial to any trader’s success
                            and learn some tips to get started.</div>
                        <div class="trading-avalibility">
                            <p>Available in: &nbsp;</p>
                            <a href="#" class="btn btn-blue shadow mt-2"> Learn More</a>
                        </div>
                    </div>

                </div>

                <!-- Image Column -->
                <div class="image-column col-lg-6 col-md-6 col-sm-12">
                    <img loading="lazy" class="mx-auto d-block img-fluid"
                        src="{{ asset('public/assets/img/future-trading-img.png') }}" alt="Wallet futures Overview Image">
                </div>

            </div>
        </div>
    </section>

    <section class="future-overview-second" id="future-overview-second">
        <div class="container" id="featureContainer">
            <div class="row">
            <div class="sec-title">
                    <span class="title">Know About</span>
                    <h2 class="heading-h2">Broker Partners</h2>
                </div>
            </div>

            <div class="row mx-auto my-auto justify-content-center">
                <div id="featureCarousel" class="carousel slide" data-bs-ride="carousel">
                    <div class="float-end pe-md-4 mb-4">
                        <a class="indicator" href="#featureCarousel" role="button" data-bs-slide="prev">
                            <span> &#8249;</span>
                        </a> &nbsp;&nbsp;
                        <a class="w-aut indicator" href="#featureCarousel" role="button" data-bs-slide="next">
                            <span> &#8250;</span>
                        </a>
                    </div>
                    <div class="carousel-inner" role="listbox">
                        <div class="carousel-item active">
                        <div class="col-md-3 col-lg-3 col-sm-6 col-xs-12">
                    <div class="overview-partiner-inner text-center">
                        <img loading="lazy" class="mx-auto d-block img-fluid"
                            src="{{ asset('public/assets/img/moonbot.svg') }}" alt="Wallet futures Overview Image">
                        <a href="#" class="btn btn-yellow shadow mt-3">View More</a>
                    </div>

                </div>
                        </div>
                        <div class="carousel-item">
                        <div class="col-md-3 col-lg-3 col-sm-6 col-xs-12">
                    <div class="overview-partiner-inner text-center">
                        <img loading="lazy" class="mx-auto d-block img-fluid"
                            src="{{ asset('public/assets/img/gunthy.svg') }}" alt="Wallet futures Overview Image">
                            <a href="#" class="btn btn-yellow shadow mt-3">View More</a>
                    </div>

                </div>
                        </div>
                        <div class="carousel-item">
                        <div class="col-md-3 col-lg-3 col-sm-6 col-xs-12">
                    <div class="overview-partiner-inner text-center">
                        <img loading="lazy" class="mx-auto d-block img-fluid"
                            src="{{ asset('public/assets/img/moonbot.svg') }}" alt="Wallet futures Overview Image">
                            <a href="#" class="btn btn-yellow shadow mt-3">View More</a>
                    </div>

                </div>
                        </div>
                        <div class="carousel-item">
                        <div class="col-md-3 col-lg-3 col-sm-6 col-xs-12">
                    <div class="overview-partiner-inner text-center">
                        <img loading="lazy" class="mx-auto d-block img-fluid"
                            src="{{ asset('public/assets/img/moonbot.svg') }}" alt="Wallet futures Overview Image">
                            <a href="#" class="btn btn-yellow shadow mt-3">View More</a>
                    </div>

                </div>
                        </div>
                        <div class="carousel-item">
                        <div class="col-md-3 col-lg-3 col-sm-6 col-xs-12">
                    <div class="overview-partiner-inner text-center">
                        <img loading="lazy" class="mx-auto d-block img-fluid"
                            src="{{ asset('public/assets/img/moonbot.svg') }}" alt="Wallet futures Overview Image">
                        <a href="#" class="btn btn-yellow shadow mt-3">Trade Now</a>
                    </div>

                </div>
                        </div>
                        <div class="carousel-item">
                        <div class="col-md-3 col-lg-3 col-sm-6 col-xs-12">
                    <div class="overview-partiner-inner text-center">
                        <img loading="lazy" class="mx-auto d-block img-fluid"
                            src="{{ asset('public/assets/img/gunthy.svg') }}" alt="Wallet futures Overview Image">
                        <a href="#" class="btn btn-yellow shadow mt-3">Trade Now</a>
                    </div>

                </div>
                        </div>
                        <div class="carousel-item">
                        <div class="col-md-3 col-lg-3 col-sm-6 col-xs-12">
                    <div class="overview-partiner-inner text-center">
                        <img loading="lazy" class="mx-auto d-block img-fluid"
                            src="{{ asset('public/assets/img/moonbot.svg') }}" alt="Wallet futures Overview Image">
                        <a href="#" class="btn btn-yellow shadow mt-3">Trade Now</a>
                    </div>

                </div>
                        </div>
                        <div class="carousel-item">
                        <div class="col-md-3 col-lg-3 col-sm-6 col-xs-12">
                    <div class="overview-partiner-inner text-center">
                        <img loading="lazy" class="mx-auto d-block img-fluid"
                            src="{{ asset('public/assets/img/moonbot.svg') }}" alt="Wallet futures Overview Image">
                        <a href="#" class="btn btn-yellow shadow mt-3">Trade Now</a>
                    </div>

                </div>
                        </div>
                        <div class="carousel-item">
                        <div class="col-md-3 col-lg-3 col-sm-6 col-xs-12">
                    <div class="overview-partiner-inner text-center">
                        <img loading="lazy" class="mx-auto d-block img-fluid"
                            src="{{ asset('public/assets/img/gunthy.svg') }}" alt="Wallet futures Overview Image">
                        <a href="#" class="btn btn-yellow shadow mt-3">Trade Now</a>
                    </div>

                </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>
 

    <section class="insight-section" id="insight">
        <div class="container">
            <div class="row heading-row-insight">
                <div class="col-md-8 col-xs-6 col-sm-6 sec-title text-left insight-heading-block">
                    <span class="title">Know About</span>
                    <h2 class="heading-h2">Wealth Mark Futures Highlights</h2>
                </div>
                <div class="col-md-4 col-xs-6 col-sm-6 sec-title text-right view-all-block insight-heading-block ">
                    <h2 class="float-right view-all-btn  research-view-all">Join Us</h2>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="card">
                        <img loading="lazy" class="mx-auto d-block img-fluid"
                            src="{{ asset('public/assets/img/act-grid.svg') }}" alt="Wallet futures Overview Image">
                        <div class="card-body">
                            <h5 class="card-title">Latest Insights &amp; Analysis</h5>
                            <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
                            <a href="#">Learn More &rarr;</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="card">
                        <img loading="lazy" class="mx-auto d-block img-fluid"
                            src="{{ asset('public/assets/img/act-affliate.svg') }}" alt="Wallet futures Overview Image">
                        <div class="card-body">
                            <h5 class="card-title">Latest Insights &amp; Analysis</h5>
                            <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
                            <a href="#">Learn More &rarr;</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="card">
                        <img loading="lazy" class="mx-auto d-block img-fluid"
                            src="{{ asset('public/assets/img/act-leaderboard.svg') }}" alt="Wallet futures Overview Image">
                        <div class="card-body">
                            <h5 class="card-title">Latest Insights &amp; Analysis</h5>
                            <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
                            <a href="#">Learn More &rarr;</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="card">
                        <img loading="lazy" class="mx-auto d-block img-fluid"
                            src="{{ asset('public/assets/img/act-battle.svg') }}" alt="Wallet futures Overview Image">
                        <div class="card-body">
                            <h5 class="card-title">Latest Insights &amp; Analysis</h5>
                            <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
                            <a href="#">Learn More &rarr;</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="future-blogs-box" id="proprietary">
        <div class="container">
            <div class="row">
                <div class="sec-title text-left mb-5">
                    <span class="title">Know About</span>
                    <h2 class="heading-h2">Blog</h2>
                </div>
            </div>
            <div class="row">
                <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="pills-contact2-tab" data-bs-toggle="pill"
                            data-bs-target="#pills-contact2" type="button" role="tab" aria-controls="pills-contact2"
                            aria-selected="true">Latest Articles</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="pills-home-tab" data-bs-toggle="pill" data-bs-target="#pills-home"
                            type="button" role="tab" aria-controls="pills-home" aria-selected="false">Futures 101
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="pills-profile-tab" data-bs-toggle="pill"
                            data-bs-target="#pills-profile" type="button" role="tab" aria-controls="pills-profile"
                            aria-selected="false">Futures Decrypted
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="pills-contact-tab" data-bs-toggle="pill"
                            data-bs-target="#pills-contact" type="button" role="tab" aria-controls="pills-contact"
                            aria-selected="false">Futures Analysis</button>
                    </li>

                </ul>
                <div class="tab-content" id="pills-tabContent">
                    <div class="tab-pane fade" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">
                        <div class="row">
                            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                                <div class="card">
                                    <img loading="lazy" class="mx-auto d-block img-fluid"
                                        src="{{ asset('public/assets/img/future-blog-1.png') }}"
                                        alt="Wallet futures Overview Image">
                                    <div class="card-body">
                                        <h5 class="card-title">Latest Insights &amp; Analysis</h5>
                                        <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
                                        <a href="#" class="btn btn-yellow shadow mt-3">Learn More</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                                <div class="card">
                                    <img loading="lazy" class="mx-auto d-block img-fluid"
                                        src="{{ asset('public/assets/img/future-blog-2.png') }}"
                                        alt="Wallet futures Overview Image">
                                    <div class="card-body">
                                        <h5 class="card-title">Latest Insights &amp; Analysis</h5>
                                        <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
                                        <a href="#" class="btn btn-yellow shadow mt-3">View More</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                                <div class="card">
                                    <img loading="lazy" class="mx-auto d-block img-fluid"
                                        src="{{ asset('public/assets/img/future-blog-3.png') }}"
                                        alt="Wallet futures Overview Image">
                                    <div class="card-body">
                                        <h5 class="card-title">Latest Insights &amp; Analysis</h5>
                                        <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
                                        <a href="#" class="btn btn-yellow shadow mt-3">Trade Now</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                                <div class="card">
                                    <img loading="lazy" class="mx-auto d-block img-fluid"
                                        src="{{ asset('public/assets/img/future-blog-5.png') }}"
                                        alt="Wallet futures Overview Image">
                                    <div class="card-body">
                                        <h5 class="card-title">Latest Insights &amp; Analysis</h5>
                                        <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
                                        <a href="#" class="btn btn-yellow shadow mt-3">View More</a>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div class="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab">
                        <div class="row">
                            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                                <div class="card">
                                    <img loading="lazy" class="mx-auto d-block img-fluid"
                                        src="{{ asset('public/assets/img/future-blog-3.png') }}"
                                        alt="Wallet futures Overview Image">
                                    <div class="card-body">
                                        <h5 class="card-title">Latest Insights &amp; Analysis</h5>
                                        <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
                                        <a href="#" class="btn btn-yellow shadow mt-3">Learn More</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                                <div class="card">
                                    <img loading="lazy" class="mx-auto d-block img-fluid"
                                        src="{{ asset('public/assets/img/future-blog-1.png') }}"
                                        alt="Wallet futures Overview Image">
                                    <div class="card-body">
                                        <h5 class="card-title">Latest Insights &amp; Analysis</h5>
                                        <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
                                        <a href="#" class="btn btn-yellow shadow mt-3">View More</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                                <div class="card">
                                    <img loading="lazy" class="mx-auto d-block img-fluid"
                                        src="{{ asset('public/assets/img/future-blog-3.png') }}"
                                        alt="Wallet futures Overview Image">
                                    <div class="card-body">
                                        <h5 class="card-title">Latest Insights &amp; Analysis</h5>
                                        <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
                                        <a href="#" class="btn btn-yellow shadow mt-3">Trade Now</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                                <div class="card">
                                    <img loading="lazy" class="mx-auto d-block img-fluid"
                                        src="{{ asset('public/assets/img/future-blog-5.png') }}"
                                        alt="Wallet futures Overview Image">
                                    <div class="card-body">
                                        <h5 class="card-title">Latest Insights &amp; Analysis</h5>
                                        <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
                                        <a href="#" class="btn btn-yellow shadow mt-3">View More</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="pills-contact" role="tabpanel" aria-labelledby="pills-contact-tab">
                        <div class="row">
                            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                                <div class="card">
                                    <img loading="lazy" class="mx-auto d-block img-fluid"
                                        src="{{ asset('public/assets/img/future-blog-4.jpg') }}"
                                        alt="Wallet futures Overview Image">
                                    <div class="card-body">
                                        <h5 class="card-title">Latest Insights &amp; Analysis</h5>
                                        <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
                                        <a href="#" class="btn btn-yellow shadow mt-3">Learn More</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                                <div class="card">
                                    <img loading="lazy" class="mx-auto d-block img-fluid"
                                        src="{{ asset('public/assets/img/future-blog-1.png') }}"
                                        alt="Wallet futures Overview Image">
                                    <div class="card-body">
                                        <h5 class="card-title">Latest Insights &amp; Analysis</h5>
                                        <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
                                        <a href="#" class="btn btn-yellow shadow mt-3">View More</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                                <div class="card">
                                    <img loading="lazy" class="mx-auto d-block img-fluid"
                                        src="{{ asset('public/assets/img/future-blog-4.jpg') }}"
                                        alt="Wallet futures Overview Image">
                                    <div class="card-body">
                                        <h5 class="card-title">Latest Insights &amp; Analysis</h5>
                                        <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
                                        <a href="#" class="btn btn-yellow shadow mt-3">Trade Now</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                                <div class="card">
                                    <img loading="lazy" class="mx-auto d-block img-fluid"
                                        src="{{ asset('public/assets/img/future-blog-5.png') }}"
                                        alt="Wallet futures Overview Image">
                                    <div class="card-body">
                                        <h5 class="card-title">Latest Insights &amp; Analysis</h5>
                                        <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
                                        <a href="#" class="btn btn-yellow shadow mt-3">View More</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade active show" id="pills-contact2" role="tabpanel"
                        aria-labelledby="pills-contact-tab">
                        <div class="row">
                            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                                <div class="card">
                                    <img loading="lazy" class="mx-auto d-block img-fluid"
                                        src="{{ asset('public/assets/img/future-blog-4.jpg') }}"
                                        alt="Wallet futures Overview Image">
                                    <div class="card-body">
                                        <h5 class="card-title">Latest Insights &amp; Analysis</h5>
                                        <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
                                        <a href="#" class="btn btn-yellow shadow mt-3">Learn More</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                                <div class="card">
                                    <img loading="lazy" class="mx-auto d-block img-fluid"
                                        src="{{ asset('public/assets/img/future-blog-1.png') }}"
                                        alt="Wallet futures Overview Image">
                                    <div class="card-body">
                                        <h5 class="card-title">Latest Insights &amp; Analysis</h5>
                                        <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
                                        <a href="#" class="btn btn-yellow shadow mt-3">View More</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                                <div class="card">
                                    <img loading="lazy" class="mx-auto d-block img-fluid"
                                        src="{{ asset('public/assets/img/future-blog-3.png') }}"
                                        alt="Wallet futures Overview Image">
                                    <div class="card-body">
                                        <h5 class="card-title">Latest Insights &amp; Analysis</h5>
                                        <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
                                        <a href="#" class="btn btn-yellow shadow mt-3">Trade Now</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                                <div class="card">
                                    <img loading="lazy" class="mx-auto d-block img-fluid"
                                        src="{{ asset('public/assets/img/future-blog-4.jpg') }}"
                                        alt="Wallet futures Overview Image">
                                    <div class="card-body">
                                        <h5 class="card-title">Latest Insights &amp; Analysis</h5>
                                        <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
                                        <a href="#" class="btn btn-yellow shadow mt-3">View More</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="future-last-price" id="future-last-price-section">
        <div class="container">
            <div class="row heading-row-insight">
                <div class="col-md-12 col-lg-12  col-xs-12 col-sm-12 sec-title text-left insight-heading-block">
                    <span class="title">Know About</span>
                    <h2 class="heading-h2">Crypto Futures Last Prices (24h Volume)</h2>
                </div>
            </div>

            <div class="row mb-3">
                <div class="col-lg-3  col-md-3 col-sm-6 col-xs-6 coin-m-heading">
                    <div class="future-last-inner-box">
                        <img loading="lazy" class="mx-auto d-block img-fluid"
                            src="{{ asset('public/assets/img/product-usdt-margin.svg') }}" alt="Wallet futures Overview Image">
                        &nbsp;
                        <div class="last-price-inner-box">
                            <span>COIN-M Futures</span>
                            <h3>441,918.23BTC</h3>
                        </div>
                    </div>
                </div>

                <div class="col-lg-6  col-md-6 hidden-xs">
                    &nbsp;
                </div>

                <div class="col-lg-3  col-md-3 col-sm-6 col-xs-6 coin-m-heading">
                    <div class="future-last-inner-box">
                        <img loading="lazy" class="mx-auto d-block img-fluid"
                            src="{{ asset('public/assets/img/product-usdt-margin.svg') }}" alt="Wallet futures Overview Image">
                        &nbsp;
                        <div class="last-price-inner-box">
                            <span>COIN-M Futures</span>
                            <h3>441,918.23BTC</h3>
                        </div>
                    </div>
                </div>


            </div>

            <div class="row mb-3">
                <div class="col-lg-6  col-md-6 col-sm-6 col-xs-6">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th class="fw-bold" scope="col">Symbols</th>
                                <th class="fw-bold" scope="col">Last Price</th>
                                <th class="fw-bold" scope="col">24h Change</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>UNIUSD Perpetual</td>
                                <td>19.715000</td>
                                <td><span class="text-success">+21.04</span></td>
                            </tr>

                            <tr>
                                <td>ETCUSD Perpetual</td>
                                <td>19.715000</td>
                                <td><span class="text-success">+21.04</span></td>
                            </tr>
                            <tr>
                                <td>ENSUSD Perpetual</td>
                                <td>19.715000</td>
                                <td><span class="text-success">+21.04</span></td>
                            </tr>
                            <tr>
                                <td>XRPUSD Perpetual</td>
                                <td>19.715000</td>
                                <td><span class="text-success">+21.04</span></td>
                            </tr>
                            <tr>
                                <td>ALGOUSD Perpetual</td>
                                <td>19.715000</td>
                                <td><span class="text-success">+21.04</span></td>
                            </tr>
                            <tr>
                                <td>ENUUSD Perpetual</td>
                                <td>19.715000</td>
                                <td><span class="text-success">+21.04</span></td>
                            </tr>
                        </tbody>
                    </table>
                </div>

                <div class="col-lg-6  col-md-6 col-sm-6 col-xs-6">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th class="fw-bold" scope="col">Symbols</th>
                                <th class="fw-bold" scope="col">Last Price</th>
                                <th class="fw-bold" scope="col">24h Change</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>UNIUSD Perpetual</td>
                                <td>19.715000</td>
                                <td><span class="text-success">+21.04</span></td>
                            </tr>

                            <tr>
                                <td>ETCUSD Perpetual</td>
                                <td>19.715000</td>
                                <td><span class="text-success">+21.04</span></td>
                            </tr>
                            <tr>
                                <td>ENSUSD Perpetual</td>
                                <td>19.715000</td>
                                <td><span class="text-success">+21.04</span></td>
                            </tr>
                            <tr>
                                <td>XRPUSD Perpetual</td>
                                <td>19.715000</td>
                                <td><span class="text-success">+21.04</span></td>
                            </tr>
                            <tr>
                                <td>ALGOUSD Perpetual</td>
                                <td>19.715000</td>
                                <td><span class="text-success">+21.04</span></td>
                            </tr>
                            <tr>
                                <td>ENUUSD Perpetual</td>
                                <td>19.715000</td>
                                <td><span class="text-success">+21.04</span></td>
                            </tr>
                        </tbody>
                    </table>
                </div>


            </div>

            <div class="row mb-3">
                <div class="col-lg-3  col-md-3 col-sm-6 col-xs-6 coin-m-heading">
                    <div class="future-last-inner-box">
                        <img loading="lazy" class="mx-auto d-block img-fluid"
                            src="{{ asset('public/assets/img/product-usdt-margin.svg') }}" alt="Wallet futures Overview Image">
                        &nbsp;
                        <div class="last-price-inner-box">
                            <span>WM Leveraged Tokens</span>
                            <h3>441,918.23BTC</h3>
                        </div>
                    </div>
                </div>

                <div class="col-lg-6  col-md-6 hidden-xs">
                    &nbsp;
                </div>

                <div class="col-lg-3  col-md-3 col-sm-6 col-xs-6 coin-m-heading">
                    <div class="future-last-inner-box">
                        <img loading="lazy" class="mx-auto d-block img-fluid"
                            src="{{ asset('public/assets/img/product-usdt-margin.svg') }}" alt="Wallet futures Overview Image">
                        &nbsp;
                        <div class="last-price-inner-box">
                            <span>COIN-M Futures</span>
                            <h3>441,918.23BTC</h3>
                        </div>
                    </div>
                </div>


            </div>
            <div class="row">
                <div class="col-lg-6  col-md-6 col-sm-6 col-xs-6">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th class="fw-bold" scope="col">Symbols</th>
                                <th class="fw-bold" scope="col">Last Price</th>
                                <th class="fw-bold" scope="col">24h Change</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>UNIUSD Perpetual</td>
                                <td>19.715000</td>
                                <td><span class="text-success">+21.04</span></td>
                            </tr>

                            <tr>
                                <td>ETCUSD Perpetual</td>
                                <td>19.715000</td>
                                <td><span class="text-success">+21.04</span></td>
                            </tr>
                            <tr>
                                <td>ENSUSD Perpetual</td>
                                <td>19.715000</td>
                                <td><span class="text-success">+21.04</span></td>
                            </tr>
                            <tr>
                                <td>XRPUSD Perpetual</td>
                                <td>19.715000</td>
                                <td><span class="text-success">+21.04</span></td>
                            </tr>
                            <tr>
                                <td>ALGOUSD Perpetual</td>
                                <td>19.715000</td>
                                <td><span class="text-success">+21.04</span></td>
                            </tr>
                            <tr>
                                <td>ENUUSD Perpetual</td>
                                <td>19.715000</td>
                                <td><span class="text-success">+21.04</span></td>
                            </tr>
                        </tbody>
                    </table>
                </div>

                <div class="col-lg-6  col-md-6 col-sm-6 col-xs-6">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th class="fw-bold" scope="col">Symbols</th>
                                <th class="fw-bold" scope="col">Last Price</th>
                                <th class="fw-bold" scope="col">24h Change</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>UNIUSD Perpetual</td>
                                <td>19.715000</td>
                                <td><span class="text-success">+21.04</span></td>
                            </tr>

                            <tr>
                                <td>ETCUSD Perpetual</td>
                                <td>19.715000</td>
                                <td><span class="text-success">+21.04</span></td>
                            </tr>
                            <tr>
                                <td>ENSUSD Perpetual</td>
                                <td>19.715000</td>
                                <td><span class="text-success">+21.04</span></td>
                            </tr>
                            <tr>
                                <td>XRPUSD Perpetual</td>
                                <td>19.715000</td>
                                <td><span class="text-success">+21.04</span></td>
                            </tr>
                            <tr>
                                <td>ALGOUSD Perpetual</td>
                                <td>19.715000</td>
                                <td><span class="text-success">+21.04</span></td>
                            </tr>
                            <tr>
                                <td>ENUUSD Perpetual</td>
                                <td>19.715000</td>
                                <td><span class="text-success">+21.04</span></td>
                            </tr>
                        </tbody>
                    </table>
                </div>


            </div>

        </div>
    </section>

    <section class="trade-anywher-box" id="trade-anywher-section">
        <div class="container">
            <div class="row mb-3">
                <div class="content-column col-lg-6 col-md-6 col-sm-12">
                    <div class="inner-column">
                        <div class="sec-title">
                            <span class="title">Know About</span>
                            <h2 class="heading-h2">Trade Anywhere.</h2>
                        </div>
                        <div class="text">Connecting you to crypto - Anytime, anywhere and on any device!</div>
                    </div>
                    <div class="download-apps mt-3 mb-3">
                        <div class="set d-flex apps-row">
                            <a href="" target="_blank" rel="noopener noreferrer">
                                <img loading="lazy" class="img-fluid"
                                    src="{{ asset('public/assets/img/window-10.svg') }}" alt="Wallet futures Overview Image">
                            </a>

                            <a href="" target="_blank" rel="noopener noreferrer">
                                <img loading="lazy" class="img-fluid"
                                    src="{{ asset('public/assets/img/macos.svg') }}" alt="Wallet futures Overview Image">
                            </a>
                        </div>
                    </div>


                    <div class="download-apps ">
                        <div class="set d-flex">
                            <a href="" target="_blank" rel="noopener noreferrer">
                                <img loading="lazy" class="mx-auto d-block img-fluid"
                                    src="{{ asset('public/assets/img/mac-dark.svg') }}" alt="Wallet futures Overview Image">
                            </a>

                            <a href="" target="_blank" rel="noopener noreferrer">
                                <img loading="lazy" class="mx-auto d-block img-fluid"
                                    src="{{ asset('public/assets/img/windows-dark.svg') }}" alt="Wallet futures Overview Image">
                            </a>

                            <a href="" target="_blank" rel="noopener noreferrer">
                                <img loading="lazy" class="mx-auto d-block img-fluid"
                                    src="{{ asset('public/assets/img/deb-dark.svg') }}" alt="Wallet futures Overview Image">
                            </a>

                            <a href="" target="_blank" rel="noopener noreferrer">
                                <img loading="lazy" class="mx-auto d-block img-fluid"
                                    src="{{ asset('public/assets/img/rpm-dark.svg') }}" alt="Wallet futures Overview Image">
                            </a>
                        </div>
                    </div>

                </div>

                <!-- Image Column -->
                <div class="image-column col-lg-6 col-md-6 col-sm-12">
                    <img loading="lazy" class="mx-auto d-block img-fluid"
                        src="{{ asset('public/assets/img/banner-devices-big-fresh.png') }}" alt="Wallet futures Overview Image">
                </div>

            </div>
        </div>
    </section>


    <section class="trade-with-us" id="trade-with-us-section">
        <div class="container">
            <div class="row mb-3">
                <div class="content-column col-lg-6 col-md-6 col-sm-12">
                    <div class="inner-column">
                        <div class="sec-title">
                            <span class="title">Know About</span>
                            <h2 class="heading-h2">Trade Anywhere.</h2>
                        </div>
                        
                    </div>
                  
                </div>

                <!-- Image Column -->
           

            </div>
            <div class="row mt-4">
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                    <div class="second-chain-inner-box">
                        
                        <img loading="lazy" class="mx-auto d-block img-fluid"
                                    src="{{ asset('public/assets/img/icon-user.svg') }}" alt="Wallet futures Overview Image">
                                   <div class="trade-us-inner-box"> 
                                   <h4>  User-centricity</h4>
                        <p>The best-performing EVM compatible layer 1. Fully compatible tooling for EVM with up to 35
                            times of capacity.</p>
                                   </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                    <div class="second-chain-inner-box">
                        
                        <img loading="lazy" class="mx-auto d-block img-fluid"
                                    src="{{ asset('public/assets/img/icon-engine.svg') }}" alt="Wallet futures Overview Image">
                                   <div class="trade-us-inner-box"> 
                                   <h4>  User-centricity</h4>
                        <p>The best-performing EVM compatible layer 1. Fully compatible tooling for EVM with up to 35
                            times of capacity.</p>
                                   </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                    <div class="second-chain-inner-box">
                        
                        <img loading="lazy" class="mx-auto d-block img-fluid"
                                    src="{{ asset('public/assets/img/icon-extensive.svg') }}" alt="Wallet futures Overview Image">
                                   <div class="trade-us-inner-box"> 
                                   <h4>  User-centricity</h4>
                        <p>The best-performing EVM compatible layer 1. Fully compatible tooling for EVM with up to 35
                            times of capacity.</p>
                                   </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                    <div class="second-chain-inner-box">
                        
                        <img loading="lazy" class="mx-auto d-block img-fluid"
                                    src="{{ asset('public/assets/img/icon-trade.svg') }}" alt="Wallet futures Overview Image">
                                   <div class="trade-us-inner-box"> 
                                   <h4>  User-centricity</h4>
                        <p>The best-performing EVM compatible layer 1. Fully compatible tooling for EVM with up to 35
                            times of capacity.</p>
                                   </div>
                    </div>
                </div>

            </div>
        </div>
    </section>

    <section class="our-clients-word-block" id="our-clients-word">
        <div class="container">
            <div class="row mt-4">
                <div class="sec-title">
                    <span class="title">Know About</span>
                    <h2 class="heading-h2">What Our Clients Say</h2>
                </div>
                <div class="col-md-4 col-lg-4 col-sm-6 col-xs-12 ">
                    <div class="overview-partiner-inner">
                        <img loading="lazy" class="img-fluid mt-2 mb-2"
                            src="{{ asset('public/assets/img/ourclient-says-1.svg') }}" alt="Wallet futures Overview Image">
                            <p>Nice range of coins. Plus Wealth Mark has not let me down in 4 years of crypto trading so far. </p>
                        <p class="mt-2"><span class="text-primary">#Twitter | </span> by The Crypto Collective <p>
                    </div>

                </div>
                <div class="col-md-4 col-lg-4 col-sm-6 col-xs-12">
                    <div class="overview-partiner-inner">
                        <img loading="lazy" class="img-fluid mt-2 mb-2"
                            src="{{ asset('public/assets/img/ourclient-says-2.svg') }}" alt="Wallet futures Overview Image">
                            <p>Nice range of coins. Plus Wealth Mark has not let me down in 4 years of crypto trading so far. </p>
                        <p class="mt-2"><span class="text-primary">#Twitter | </span> by The Crypto Collective <p>
                    </div>

                </div>
                <div class="col-md-4 col-lg-4 col-sm-6 col-xs-12">
                    <div class="overview-partiner-inner">
                        <img loading="lazy" class="img-fluid mt-2 mb-2"
                            src="{{ asset('public/assets/img/ourclient-says-3.svg') }}" alt="Wallet futures Overview Image">
                            <p>Nice range of coins. Plus Wealth Mark has not let me down in 4 years of crypto trading so far. </p>
                        <p class="mt-2"><span class="text-primary">#Twitter | </span> by The Crypto Collective <p>
                    </div>

                </div>
            </div>
        </div>
    </section>

    <section class="future-overview" id="future-overview-section">
        <div class="container">
            <div class="row">
                <div class="overview-inner-box">
                    <h3 class="digital-asset-heading text-center">Trade Crypto Futures</h3>
                </div>
            </div>
            <div class="row overview-assets-row">
                <div class="col-md-12 d-flex justify-content-center">
                    <a class="btn btn-warning ">Register Now </a>
                    <a class="btn btn-primary">Trade Now</a>
                </div>
            </div>
        </div>
    </section>
    <script src="https://code.jquery.com/jquery-3.6.0.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous">
    </script>
    <script>
    let items = document.querySelectorAll('#featureContainer .carousel .carousel-item');
    items.forEach((el) => {
        const minPerSlide = 4
        let next = el.nextElementSibling
        for (var i = 1; i < minPerSlide; i++) {
            if (!next) {
                // wrap carousel by using first child
                next = items[0]
            }
            let cloneChild = next.cloneNode(true)
            el.appendChild(cloneChild.children[0])
            next = next.nextElementSibling
        }
    })
    $(document).ready(function() {
        $('#featureCarousel').carousel({
            interval: false
        });
        $('#featureCarousel').carousel('pause');
    });
    </script>
    <script type="text/javascript">
    var _gaq = _gaq || [];
    _gaq.push(['_setAccount', 'UA-36251023-1']);
    _gaq.push(['_setDomainName', 'jqueryscript.net']);
    _gaq.push(['_trackPageview']);

    (function() {
        var ga = document.createElement('script');
        ga.type = 'text/javascript';
        ga.async = true;
        ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') +
            '.google-analytics.com/ga.js';
        var s = document.getElementsByTagName('script')[0];
        s.parentNode.insertBefore(ga, s);
    })();
    </script>
    <script>
    try {
        fetch(new Request("https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js", {
            method: 'HEAD',
            mode: 'no-cors'
        })).then(function(response) {
            return true;
        }).catch(function(e) {
            var carbonScript = document.createElement("script");
            carbonScript.src =
                "//cdn.carbonads.com/carbon.js?serve=CK7DKKQU&placement=wwwjqueryscriptnet";
            carbonScript.id = "_carbonads_js";
            document.getElementById("carbon-block").appendChild(carbonScript);
        });
    } catch (error) {
        console.log(error);
    }
    </script>


    @include('template.country_language')
    @include('template.web_footer')



</body>

</html>