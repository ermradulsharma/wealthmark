  <!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
   <head>
      <meta charset="utf-8">
      <meta content="width=device-width, initial-scale=1.0" name="viewport">
      <title>Wealth Mark | Create Entity Account</title>
  @include('template.web_css')
      
  
 <style>
     #header{
         background:white;
         
     }







 </style>
  
  
   </head>
   
 <body class="bg-white">
     
     @include('template.mobile_menu')
        @include('template.web_menu')
    
    
  
    
    
        
   <section  class="breadcrumbs shadow-sm auto-invesment p-5">
          <div class="container-fluid">
              <div class="row justify-content-center">
                 <div class="col-lg-4  d-flex flex-column justify-content-center pt-lg-0 order-2 order-lg-1 align-items-center" data-aos="fade-up" data-aos-delay="200">
                 <h3 class="top-heading">Binance Earn</h3>
                 <p class="top-p">Simple & Secure. Search popular coins and start earning.</p>
               
                 </div>
                 <div class="col-lg-5 offset-lg-1 order-1 order-lg-2 hero-img mt-3 mb-5" data-aos="zoom-in" data-aos-delay="200">
                   
                   <div class="asset-overview login-box-main">
                          <div class="login-box-bg">
                            <div class="login-box">
                              <img src="{{ asset('public/assets/img/account.png') }}" class="login-box-img">
                              <div class="login-box-txt">Log in to view holding details</div>
                              <button type="button" class="btn btn-yellow">Log In</button>
                            </div>
                          </div>
                        </div>
                 </div>
              </div>
            </div>
      </section>
      
    <section class="earn-content pt-0">
        <div class="bg-light-blue pt-2 pb-2">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-sm-6 col-xs-12">
                        <div class="nav-tabs-list d-flex justify-content-between">
                          <a  href="#" class="nav-tabs-a active">Simple Earn</a>
                          <a  href="#" class="nav-tabs-a">Staking</a>
                          <a  href="#" class="nav-tabs-a">Faming</a>
                          <a  href="#" class="nav-tabs-a">Dual Investment</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
       
       
       
       
       
       
       
       
        <div class="container">
            
          <div class="row align-items-center content-justify pt-4 pb-4">
              <div class="col-md-8 col-sm-7 col-xs-12 ">	
              <nav>
    			<div class="nav nav-tabs border-0" id="nav-tab" role="tablist">
    				<button class="nav-link active" id="nav-home-tab" data-bs-toggle="tab" data-bs-target="#nav-home" type="button" role="tab" aria-controls="nav-home" aria-selected="true">Protected</button>
    				<button class="nav-link" id="nav-profile-tab" data-bs-toggle="tab" data-bs-target="#nav-profile" type="button" role="tab" aria-controls="nav-profile" aria-selected="false">High Yield</button>
    				<button class="nav-link" id="nav-contact-tab" data-bs-toggle="tab" data-bs-target="#nav-contact" type="button" role="tab" aria-controls="nav-contact" aria-selected="false">Auto-Invest</button>
    			</div>
		        </nav>
		  </div>
		  <div class="col-md-4 col-sm-5 col-xs-12">
		 
			<select id="country" placeholder="Search Coin" style="max-width:100%">
			<!-- Dropdown List Option -->
			</select>
	
		      </div>
		      </div> 
		  <div class="row  align-items-center content-justify">
                <div class="col-md-12">
                    <div class="coins-filter">
                      <div class="coins-filter-mid">
                        <div class="coins-filter-inner">
                          <div class="coins-filter-inner-block">
                              <a href="javascript:void(0)" onclick="toggleVisibility('Popular_Coins');">
                            <div class="coins-filter-type-div">
                              <span class="coins-filter-type-span">
                                <img src="{{ asset('public/assets/img/hot-g.png') }}" class="coins-filter-type-span-icn">
                              </span>Popular Coins
                            </div>
                            </a>
                          </div>
                          <div class="coins-filter-inner-block">
                              <a href="javascript:void(0)" onclick="toggleVisibility('BfB');">
                            <div class="coins-filter-inner-block-div">
                              <span class="coins-filter-type-span">
                                <img src="{{ asset('public/assets/img/thumb-up-g.png') }}" class="coins-filter-type-span-icn">
                              </span>Best for Beginners
                            </div>
                            </a>
                          </div>
                          <div class="coins-filter-inner-block">
                              <a href="javascript:void(0)" onclick="toggleVisibility('BNB_Chain_Zone');">
                            <div class="coins-filter-inner-block-div">
                              <span class="coins-filter-type-span">
                                <img src="{{ asset('public/assets/img/bc_zone.svg') }}" class="coins-filter-type-span-icn">
                              </span>BNB Chain Zone
                            </div>
                            </a>
                          </div>
                          <div  class="coins-filter-inner-block">
                              <a href="javascript:void(0)" onclick="toggleVisibility('Polka_Zone');">
                            <div class="coins-filter-inner-block-div">
                              <span class="coins-filter-type-span">
                                <img src="{{ asset('public/assets/img/polka_zone.svg') }}" class="coins-filter-type-span-icn">
                              </span>Polka Zone
                            </div>
                            </a>
                          </div>
                          <div class="coins-filter-inner-block">
                              <a href="javascript:void(0)" onclick="toggleVisibility('Solana_Zone');">
                            <div class="coins-filter-inner-block-div">
                                
                              <span class="coins-filter-type-span">
                                <img src="{{ asset('public/assets/img/sol_zone.svg') }}" class="coins-filter-type-span-icn">
                              </span>Solana Zone
                            </div>
                            </a>
                          </div>
                        </div>
                       
                      </div>
                    </div>
                </div>
            </div>
		  <div class="row align-items-center content-justify">
		      <div class="col-md-12 pt-5">
		           	<div class="tab-content">
			            <div class="tab-pane fade active show" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
			              
			              
			            <div id="Popular_Coins" class="earn-record-sec">
  <div class="earn-tbl" style="width: 100%;">
   
      <div class="table-responsive">
        <table style="table-layout: auto;">
          <colgroup>
            <col style="width: 17%;">
            <col style="width: 28%;">
            <col style="width: 18%;">
            <col style="width: 15%;">
            <col style="width: 22%;">
          </colgroup>
          <thead class="earn-tbl-thead">
            <tr>
              <th class="earn-td-block">
                <div class="earn-product-text">Coin</div>
              </th>
              <th class="earn-td-block">Product</th>
              <th class="earn-td-block">
                <div class="earn-amt-div">Est. APR <div class="svg-fillter-div">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="svg-fillter">
                      <path opacity="0.5" d="M9 10.153V8.5L12.25 5l3.25 3.501v1.652H9z" fill="#848E9C"></path>
                      <path d="M15.5 13.257v1.652l-3.25 3.5L9 14.91v-1.652h6.5z" fill="url(#sorting-down-color-s24_svg__paint0_linear)"></path>
                      <defs>
                        <linearGradient id="sorting-down-color-s24_svg__paint0_linear" x1="9" y1="18.41" x2="15.5" y2="18.41" gradientUnits="userSpaceOnUse">
                          <stop stop-color="#EFB80B"></stop>
                          <stop offset="1" stop-color="#FBDA3C"></stop>
                        </linearGradient>
                      </defs>
                    </svg>
                  </div>
                </div>
              </th>
              <th class="earn-td-block">
                <div class="earn-amt-div">Duration <div class="svg-fillter-div">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="svg-fillter">
                      <path d="M9 10.368v-1.4L11.968 6l2.968 2.968v1.4H9zM14.936 13v1.4l-2.968 2.968L9 14.4V13h5.936z" fill="#C1C6CD"></path>
                    </svg>
                  </div>
                </div>
              </th>
              <th class="earn-td-block" style="text-align: right;"></th>
            </tr>
          </thead>
          <tbody class="earn-tbl-tbody">
            <tr class="earn-tbl-row earn-tbl-row-level-0">
              <td class="earn-td-block">
                <a  target="_blank" href="#" class="earn-td-block-link">
                  <div class="earn-td-block-link-img">
                    <img class="earn-coin-img" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}">
                      
                    <div  class="earn-coin-text">AXS</div>
                  </div>
                </a>
              </td>
              <td class="earn-td-block">
                <div class="earn-product-text">Simple Earn</div>
              </td>
              <td class="earn-td-block">
                <div class="earn-amt-div">
                  <div class="earn-amt-text">59.00%</div>
                </div>
              </td>
              <td class="earn-td-block">
                <div class="earn-duration-text">90 Days</div>
              </td>
              <td class="earn-td-block" style="text-align: right;">
                <div class="">
                  <a  href="#" target="_blank" class="">
                    <button type="button" class="btn-yellow border-0 shadow-none">Subscribe</button>
                  </a>
                </div>
              </td>
            </tr>
            <tr class="earn-tbl-row earn-tbl-row-level-0">
              <td class="earn-td-block">
                <a  target="_blank" href="#" class="earn-td-block-link">
                  <div class="earn-td-block-link-img">
                   <img class="earn-coin-img" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}">
                    <div  class="earn-coin-text">NEAR</div>
                  </div>
                </a>
              </td>
              <td class="earn-td-block">
                <div class="earn-product-text">Simple Earn</div>
              </td>
              <td class="earn-td-block">
                <div class="earn-amt-div">
                  <div class="earn-amt-text">30.49%</div>
                </div>
              </td>
              <td class="earn-td-block">
                <div class="earn-duration-text">120 Days</div>
              </td>
              <td class="earn-td-block" style="text-align: right;">
                <div class="">
                  <a  href="#" target="_blank" class="">
                    <button type="button" class="btn-yellow border-0 shadow-none">Subscribe</button>
                  </a>
                </div>
              </td>
            </tr>
            <tr class="earn-tbl-row earn-tbl-row-level-0">
              <td class="earn-td-block">
                <a  target="_blank" href="#" class="earn-td-block-link">
                  <div class="earn-td-block-link-img">
                    <img class="earn-coin-img" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}">
                    <div  class="earn-coin-text">AXS</div>
                  </div>
                </a>
              </td>
              <td class="earn-td-block">
                <div class="earn-product-text">Simple Earn</div>
              </td>
              <td class="earn-td-block">
                <div class="earn-amt-div">
                  <div class="earn-amt-text">
                    <div class="">24.00%</div>
                  </div>
                </div>
              </td>
              <td class="earn-td-block">
                <div class="earn-duration-text">Flexible</div>
              </td>
              <td class="earn-td-block" style="text-align: right;">
                <div class="">
                  <a  href="#" target="_blank" class="">
                    <button type="button" class="btn-yellow border-0 shadow-none">Subscribe</button>
                  </a>
                </div>
              </td>
            </tr>
            <tr class="earn-tbl-row earn-tbl-row-level-0">
              <td class="earn-td-block">
                <a  target="_blank" href="#" class="earn-td-block-link">
                  <div class="earn-td-block-link-img">
                    <img class="earn-coin-img" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}">
                    <div  class="earn-coin-text">DOT</div>
                  </div>
                </a>
              </td>
              <td class="earn-td-block">
                <div class="earn-product-text">Simple Earn</div>
              </td>
              <td class="earn-td-block">
                <div class="earn-amt-div">
                  <div class="earn-amt-text">20.98%</div>
                </div>
              </td>
              <td class="earn-td-block">
                <div class="earn-duration-text">120 Days</div>
              </td>
              <td class="earn-td-block" style="text-align: right;">
                <div class="">
                  <a  href="#" target="_blank" class="">
                    <button type="button" class="btn-yellow border-0 shadow-none">Subscribe</button>
                  </a>
                </div>
              </td>
            </tr>
            <tr class="earn-tbl-row earn-tbl-row-level-0">
              <td class="earn-td-block">
                <a  target="_blank" href="#" class="earn-td-block-link">
                  <div class="earn-td-block-link-img">
                   <img class="earn-coin-img" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}">
                    <div  class="earn-coin-text">AVAX</div>
                  </div>
                </a>
              </td>
              <td class="earn-td-block">
                <div class="earn-product-text">Simple Earn</div>
              </td>
              <td class="earn-td-block">
                <div class="earn-amt-div">
                  <div class="earn-amt-text">18.90%</div>
                </div>
              </td>
              <td class="earn-td-block">
                <div class="earn-duration-text">120 Days</div>
              </td>
              <td class="earn-td-block" style="text-align: right;">
                <div class="">
                  <a  href="#" target="_blank" class="">
                    <button type="button" class="btn-yellow border-0 shadow-none">Subscribe</button>
                  </a>
                </div>
              </td>
            </tr>
            <tr class="earn-tbl-row earn-tbl-row-level-0">
              <td class="earn-td-block">
                <a  target="_blank" href="#" class="earn-td-block-link">
                  <div class="earn-td-block-link-img">
                    <img class="earn-coin-img" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}">
                    <div  class="earn-coin-text">ADA</div>
                  </div>
                </a>
              </td>
              <td class="earn-td-block">
                <div class="earn-product-text">Simple Earn</div>
              </td>
              <td class="earn-td-block">
                <div class="earn-amt-div">
                  <div class="earn-amt-text">9.85%</div>
                </div>
              </td>
              <td class="earn-td-block">
                <div class="earn-duration-text">90 Days</div>
              </td>
              <td class="earn-td-block" style="text-align: right;">
                <div class="">
                  <a  href="#" target="_blank" class="">
                    <button type="button" class="btn-yellow border-0 shadow-none">Subscribe</button>
                  </a>
                </div>
              </td>
            </tr>
            <tr  class="earn-tbl-row earn-tbl-row-level-0">
              <td class="earn-td-block">
                <a  target="_blank" href="#" class="earn-td-block-link">
                  <div class="earn-td-block-link-img">
                    <img class="earn-coin-img" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}">
                    <div  class="earn-coin-text">USDT</div>
                  </div>
                </a>
              </td>
              <td class="earn-td-block">
                <div class="earn-product-text">Simple Earn</div>
              </td>
              <td class="earn-td-block">
                <div class="earn-amt-div">
                  <div class="earn-amt-text">
                    <div class="">
                      <div class="earn-product-text">8.00%</div>
                    </div>
                  </div>
                 
                </div>
              </td>
              <td class="earn-td-block">
                <div class="earn-duration-text">Flexible</div>
              </td>
              <td class="earn-td-block" style="text-align: right;">
                <div class="">
                  <a  href="#" target="_blank" class="">
                    <button type="button" class="btn-yellow border-0 shadow-none">Subscribe</button>
                  </a>
                </div>
              </td>
            </tr>
            <tr class="earn-tbl-row earn-tbl-row-level-0">
              <td class="earn-td-block">
                <a  target="_blank" href="#" class="earn-td-block-link">
                  <div class="earn-td-block-link-img">
                    <img class="earn-coin-img" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}">
                    <div  class="earn-coin-text">BUSD</div>
                  </div>
                </a>
              </td>
              <td class="earn-td-block">
                <div class="earn-product-text">Simple Earn</div>
              </td>
              <td class="earn-td-block">
                <div class="earn-amt-div">
                  <div class="earn-amt-text">
                    <div class="">
                      <div class="earn-product-text">8.00%</div>
                    </div>
                  </div>
                 
                </div>
              </td>
              <td class="earn-td-block">
                <div class="earn-duration-text">Flexible</div>
              </td>
              <td class="earn-td-block" style="text-align: right;">
                <div class="">
                  <a  href="#" target="_blank" class="">
                    <button type="button" class="btn-yellow border-0 shadow-none">Subscribe</button>
                  </a>
                </div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
   
  </div>
</div>
			            <div id="BfB" class="earn-record-sec" style="display: none;background:red;">
  <div class="earn-tbl" style="width: 100%;">
   
      <div class="table-responsive">
        <table style="table-layout: auto;">
          <colgroup>
            <col style="width: 17%;">
            <col style="width: 28%;">
            <col style="width: 18%;">
            <col style="width: 15%;">
            <col style="width: 22%;">
          </colgroup>
          <thead class="earn-tbl-thead">
            <tr>
              <th class="earn-td-block">
                <div class="earn-product-text">Coin</div>
              </th>
              <th class="earn-td-block">Product</th>
              <th class="earn-td-block">
                <div class="earn-amt-div">Est. APR <div class="svg-fillter-div">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="svg-fillter">
                      <path opacity="0.5" d="M9 10.153V8.5L12.25 5l3.25 3.501v1.652H9z" fill="#848E9C"></path>
                      <path d="M15.5 13.257v1.652l-3.25 3.5L9 14.91v-1.652h6.5z" fill="url(#sorting-down-color-s24_svg__paint0_linear)"></path>
                      <defs>
                        <linearGradient id="sorting-down-color-s24_svg__paint0_linear" x1="9" y1="18.41" x2="15.5" y2="18.41" gradientUnits="userSpaceOnUse">
                          <stop stop-color="#EFB80B"></stop>
                          <stop offset="1" stop-color="#FBDA3C"></stop>
                        </linearGradient>
                      </defs>
                    </svg>
                  </div>
                </div>
              </th>
              <th class="earn-td-block">
                <div class="earn-amt-div">Duration <div class="svg-fillter-div">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="svg-fillter">
                      <path d="M9 10.368v-1.4L11.968 6l2.968 2.968v1.4H9zM14.936 13v1.4l-2.968 2.968L9 14.4V13h5.936z" fill="#C1C6CD"></path>
                    </svg>
                  </div>
                </div>
              </th>
              <th class="earn-td-block" style="text-align: right;"></th>
            </tr>
          </thead>
          <tbody class="earn-tbl-tbody">
            <tr class="earn-tbl-row earn-tbl-row-level-0">
              <td class="earn-td-block">
                <a  target="_blank" href="#" class="earn-td-block-link">
                  <div class="earn-td-block-link-img">
                    <img class="earn-coin-img" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}">
                      
                    <div  class="earn-coin-text">AXS</div>
                  </div>
                </a>
              </td>
              <td class="earn-td-block">
                <div class="earn-product-text">Simple Earn</div>
              </td>
              <td class="earn-td-block">
                <div class="earn-amt-div">
                  <div class="earn-amt-text">59.00%</div>
                </div>
              </td>
              <td class="earn-td-block">
                <div class="earn-duration-text">90 Days</div>
              </td>
              <td class="earn-td-block" style="text-align: right;">
                <div class="">
                  <a  href="#" target="_blank" class="">
                    <button type="button" class="btn-yellow border-0 shadow-none">Subscribe</button>
                  </a>
                </div>
              </td>
            </tr>
            <tr class="earn-tbl-row earn-tbl-row-level-0">
              <td class="earn-td-block">
                <a  target="_blank" href="#" class="earn-td-block-link">
                  <div class="earn-td-block-link-img">
                   <img class="earn-coin-img" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}">
                    <div  class="earn-coin-text">NEAR</div>
                  </div>
                </a>
              </td>
              <td class="earn-td-block">
                <div class="earn-product-text">Simple Earn</div>
              </td>
              <td class="earn-td-block">
                <div class="earn-amt-div">
                  <div class="earn-amt-text">30.49%</div>
                </div>
              </td>
              <td class="earn-td-block">
                <div class="earn-duration-text">120 Days</div>
              </td>
              <td class="earn-td-block" style="text-align: right;">
                <div class="">
                  <a  href="#" target="_blank" class="">
                    <button type="button" class="btn-yellow border-0 shadow-none">Subscribe</button>
                  </a>
                </div>
              </td>
            </tr>
            <tr class="earn-tbl-row earn-tbl-row-level-0">
              <td class="earn-td-block">
                <a  target="_blank" href="#" class="earn-td-block-link">
                  <div class="earn-td-block-link-img">
                    <img class="earn-coin-img" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}">
                    <div  class="earn-coin-text">AXS</div>
                  </div>
                </a>
              </td>
              <td class="earn-td-block">
                <div class="earn-product-text">Simple Earn</div>
              </td>
              <td class="earn-td-block">
                <div class="earn-amt-div">
                  <div class="earn-amt-text">
                    <div class="">24.00%</div>
                  </div>
                </div>
              </td>
              <td class="earn-td-block">
                <div class="earn-duration-text">Flexible</div>
              </td>
              <td class="earn-td-block" style="text-align: right;">
                <div class="">
                  <a  href="#" target="_blank" class="">
                    <button type="button" class="btn-yellow border-0 shadow-none">Subscribe</button>
                  </a>
                </div>
              </td>
            </tr>
            <tr class="earn-tbl-row earn-tbl-row-level-0">
              <td class="earn-td-block">
                <a  target="_blank" href="#" class="earn-td-block-link">
                  <div class="earn-td-block-link-img">
                    <img class="earn-coin-img" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}">
                    <div  class="earn-coin-text">DOT</div>
                  </div>
                </a>
              </td>
              <td class="earn-td-block">
                <div class="earn-product-text">Simple Earn</div>
              </td>
              <td class="earn-td-block">
                <div class="earn-amt-div">
                  <div class="earn-amt-text">20.98%</div>
                </div>
              </td>
              <td class="earn-td-block">
                <div class="earn-duration-text">120 Days</div>
              </td>
              <td class="earn-td-block" style="text-align: right;">
                <div class="">
                  <a  href="#" target="_blank" class="">
                    <button type="button" class="btn-yellow border-0 shadow-none">Subscribe</button>
                  </a>
                </div>
              </td>
            </tr>
            <tr class="earn-tbl-row earn-tbl-row-level-0">
              <td class="earn-td-block">
                <a  target="_blank" href="#" class="earn-td-block-link">
                  <div class="earn-td-block-link-img">
                   <img class="earn-coin-img" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}">
                    <div  class="earn-coin-text">AVAX</div>
                  </div>
                </a>
              </td>
              <td class="earn-td-block">
                <div class="earn-product-text">Simple Earn</div>
              </td>
              <td class="earn-td-block">
                <div class="earn-amt-div">
                  <div class="earn-amt-text">18.90%</div>
                </div>
              </td>
              <td class="earn-td-block">
                <div class="earn-duration-text">120 Days</div>
              </td>
              <td class="earn-td-block" style="text-align: right;">
                <div class="">
                  <a  href="#" target="_blank" class="">
                    <button type="button" class="btn-yellow border-0 shadow-none">Subscribe</button>
                  </a>
                </div>
              </td>
            </tr>
            <tr class="earn-tbl-row earn-tbl-row-level-0">
              <td class="earn-td-block">
                <a  target="_blank" href="#" class="earn-td-block-link">
                  <div class="earn-td-block-link-img">
                    <img class="earn-coin-img" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}">
                    <div  class="earn-coin-text">ADA</div>
                  </div>
                </a>
              </td>
              <td class="earn-td-block">
                <div class="earn-product-text">Simple Earn</div>
              </td>
              <td class="earn-td-block">
                <div class="earn-amt-div">
                  <div class="earn-amt-text">9.85%</div>
                </div>
              </td>
              <td class="earn-td-block">
                <div class="earn-duration-text">90 Days</div>
              </td>
              <td class="earn-td-block" style="text-align: right;">
                <div class="">
                  <a  href="#" target="_blank" class="">
                    <button type="button" class="btn-yellow border-0 shadow-none">Subscribe</button>
                  </a>
                </div>
              </td>
            </tr>
            <tr  class="earn-tbl-row earn-tbl-row-level-0">
              <td class="earn-td-block">
                <a  target="_blank" href="#" class="earn-td-block-link">
                  <div class="earn-td-block-link-img">
                    <img class="earn-coin-img" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}">
                    <div  class="earn-coin-text">USDT</div>
                  </div>
                </a>
              </td>
              <td class="earn-td-block">
                <div class="earn-product-text">Simple Earn</div>
              </td>
              <td class="earn-td-block">
                <div class="earn-amt-div">
                  <div class="earn-amt-text">
                    <div class="">
                      <div class="earn-product-text">8.00%</div>
                    </div>
                  </div>
                 
                </div>
              </td>
              <td class="earn-td-block">
                <div class="earn-duration-text">Flexible</div>
              </td>
              <td class="earn-td-block" style="text-align: right;">
                <div class="">
                  <a  href="#" target="_blank" class="">
                    <button type="button" class="btn-yellow border-0 shadow-none">Subscribe</button>
                  </a>
                </div>
              </td>
            </tr>
            <tr class="earn-tbl-row earn-tbl-row-level-0">
              <td class="earn-td-block">
                <a  target="_blank" href="#" class="earn-td-block-link">
                  <div class="earn-td-block-link-img">
                    <img class="earn-coin-img" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}">
                    <div  class="earn-coin-text">BUSD</div>
                  </div>
                </a>
              </td>
              <td class="earn-td-block">
                <div class="earn-product-text">Simple Earn</div>
              </td>
              <td class="earn-td-block">
                <div class="earn-amt-div">
                  <div class="earn-amt-text">
                    <div class="">
                      <div class="earn-product-text">8.00%</div>
                    </div>
                  </div>
                 
                </div>
              </td>
              <td class="earn-td-block">
                <div class="earn-duration-text">Flexible</div>
              </td>
              <td class="earn-td-block" style="text-align: right;">
                <div class="">
                  <a  href="#" target="_blank" class="">
                    <button type="button" class="btn-yellow border-0 shadow-none">Subscribe</button>
                  </a>
                </div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
   
  </div>
</div>
			            <div id="BNB_Chain_Zone" class="earn-record-sec" style="display: none;background:blue;">
                              <div class="earn-tbl" style="width: 100%;">
                               
                                  <div class="table-responsive">
                                    <table style="table-layout: auto;">
                                      <colgroup>
                                        <col style="width: 17%;">
                                        <col style="width: 28%;">
                                        <col style="width: 18%;">
                                        <col style="width: 15%;">
                                        <col style="width: 22%;">
                                      </colgroup>
                                      <thead class="earn-tbl-thead">
                                        <tr>
                                          <th class="earn-td-block">
                                            <div class="earn-product-text">Coin</div>
                                          </th>
                                          <th class="earn-td-block">Product</th>
                                          <th class="earn-td-block">
                                            <div class="earn-amt-div">Est. APR <div class="svg-fillter-div">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="svg-fillter">
                                                  <path opacity="0.5" d="M9 10.153V8.5L12.25 5l3.25 3.501v1.652H9z" fill="#848E9C"></path>
                                                  <path d="M15.5 13.257v1.652l-3.25 3.5L9 14.91v-1.652h6.5z" fill="url(#sorting-down-color-s24_svg__paint0_linear)"></path>
                                                  <defs>
                                                    <linearGradient id="sorting-down-color-s24_svg__paint0_linear" x1="9" y1="18.41" x2="15.5" y2="18.41" gradientUnits="userSpaceOnUse">
                                                      <stop stop-color="#EFB80B"></stop>
                                                      <stop offset="1" stop-color="#FBDA3C"></stop>
                                                    </linearGradient>
                                                  </defs>
                                                </svg>
                                              </div>
                                            </div>
                                          </th>
                                          <th class="earn-td-block">
                                            <div class="earn-amt-div">Duration <div class="svg-fillter-div">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="svg-fillter">
                                                  <path d="M9 10.368v-1.4L11.968 6l2.968 2.968v1.4H9zM14.936 13v1.4l-2.968 2.968L9 14.4V13h5.936z" fill="#C1C6CD"></path>
                                                </svg>
                                              </div>
                                            </div>
                                          </th>
                                          <th class="earn-td-block" style="text-align: right;"></th>
                                        </tr>
                                      </thead>
                                      <tbody class="earn-tbl-tbody">
                                        <tr class="earn-tbl-row earn-tbl-row-level-0">
                                          <td class="earn-td-block">
                                            <a  target="_blank" href="#" class="earn-td-block-link">
                                              <div class="earn-td-block-link-img">
                                                <img class="earn-coin-img" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}">
                                                  
                                                <div  class="earn-coin-text">AXS</div>
                                              </div>
                                            </a>
                                          </td>
                                          <td class="earn-td-block">
                                            <div class="earn-product-text">Simple Earn</div>
                                          </td>
                                          <td class="earn-td-block">
                                            <div class="earn-amt-div">
                                              <div class="earn-amt-text">59.00%</div>
                                            </div>
                                          </td>
                                          <td class="earn-td-block">
                                            <div class="earn-duration-text">90 Days</div>
                                          </td>
                                          <td class="earn-td-block" style="text-align: right;">
                                            <div class="">
                                              <a  href="#" target="_blank" class="">
                                                <button type="button" class="btn-yellow border-0 shadow-none">Subscribe</button>
                                              </a>
                                            </div>
                                          </td>
                                        </tr>
                                        <tr class="earn-tbl-row earn-tbl-row-level-0">
                                          <td class="earn-td-block">
                                            <a  target="_blank" href="#" class="earn-td-block-link">
                                              <div class="earn-td-block-link-img">
                                               <img class="earn-coin-img" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}">
                                                <div  class="earn-coin-text">NEAR</div>
                                              </div>
                                            </a>
                                          </td>
                                          <td class="earn-td-block">
                                            <div class="earn-product-text">Simple Earn</div>
                                          </td>
                                          <td class="earn-td-block">
                                            <div class="earn-amt-div">
                                              <div class="earn-amt-text">30.49%</div>
                                            </div>
                                          </td>
                                          <td class="earn-td-block">
                                            <div class="earn-duration-text">120 Days</div>
                                          </td>
                                          <td class="earn-td-block" style="text-align: right;">
                                            <div class="">
                                              <a  href="#" target="_blank" class="">
                                                <button type="button" class="btn-yellow border-0 shadow-none">Subscribe</button>
                                              </a>
                                            </div>
                                          </td>
                                        </tr>
                                        <tr class="earn-tbl-row earn-tbl-row-level-0">
                                          <td class="earn-td-block">
                                            <a  target="_blank" href="#" class="earn-td-block-link">
                                              <div class="earn-td-block-link-img">
                                                <img class="earn-coin-img" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}">
                                                <div  class="earn-coin-text">AXS</div>
                                              </div>
                                            </a>
                                          </td>
                                          <td class="earn-td-block">
                                            <div class="earn-product-text">Simple Earn</div>
                                          </td>
                                          <td class="earn-td-block">
                                            <div class="earn-amt-div">
                                              <div class="earn-amt-text">
                                                <div class="">24.00%</div>
                                              </div>
                                            </div>
                                          </td>
                                          <td class="earn-td-block">
                                            <div class="earn-duration-text">Flexible</div>
                                          </td>
                                          <td class="earn-td-block" style="text-align: right;">
                                            <div class="">
                                              <a  href="#" target="_blank" class="">
                                                <button type="button" class="btn-yellow border-0 shadow-none">Subscribe</button>
                                              </a>
                                            </div>
                                          </td>
                                        </tr>
                                        <tr class="earn-tbl-row earn-tbl-row-level-0">
                                          <td class="earn-td-block">
                                            <a  target="_blank" href="#" class="earn-td-block-link">
                                              <div class="earn-td-block-link-img">
                                                <img class="earn-coin-img" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}">
                                                <div  class="earn-coin-text">DOT</div>
                                              </div>
                                            </a>
                                          </td>
                                          <td class="earn-td-block">
                                            <div class="earn-product-text">Simple Earn</div>
                                          </td>
                                          <td class="earn-td-block">
                                            <div class="earn-amt-div">
                                              <div class="earn-amt-text">20.98%</div>
                                            </div>
                                          </td>
                                          <td class="earn-td-block">
                                            <div class="earn-duration-text">120 Days</div>
                                          </td>
                                          <td class="earn-td-block" style="text-align: right;">
                                            <div class="">
                                              <a  href="#" target="_blank" class="">
                                                <button type="button" class="btn-yellow border-0 shadow-none">Subscribe</button>
                                              </a>
                                            </div>
                                          </td>
                                        </tr>
                                        <tr class="earn-tbl-row earn-tbl-row-level-0">
                                          <td class="earn-td-block">
                                            <a  target="_blank" href="#" class="earn-td-block-link">
                                              <div class="earn-td-block-link-img">
                                               <img class="earn-coin-img" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}">
                                                <div  class="earn-coin-text">AVAX</div>
                                              </div>
                                            </a>
                                          </td>
                                          <td class="earn-td-block">
                                            <div class="earn-product-text">Simple Earn</div>
                                          </td>
                                          <td class="earn-td-block">
                                            <div class="earn-amt-div">
                                              <div class="earn-amt-text">18.90%</div>
                                            </div>
                                          </td>
                                          <td class="earn-td-block">
                                            <div class="earn-duration-text">120 Days</div>
                                          </td>
                                          <td class="earn-td-block" style="text-align: right;">
                                            <div class="">
                                              <a  href="#" target="_blank" class="">
                                                <button type="button" class="btn-yellow border-0 shadow-none">Subscribe</button>
                                              </a>
                                            </div>
                                          </td>
                                        </tr>
                                        <tr class="earn-tbl-row earn-tbl-row-level-0">
                                          <td class="earn-td-block">
                                            <a  target="_blank" href="#" class="earn-td-block-link">
                                              <div class="earn-td-block-link-img">
                                                <img class="earn-coin-img" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}">
                                                <div  class="earn-coin-text">ADA</div>
                                              </div>
                                            </a>
                                          </td>
                                          <td class="earn-td-block">
                                            <div class="earn-product-text">Simple Earn</div>
                                          </td>
                                          <td class="earn-td-block">
                                            <div class="earn-amt-div">
                                              <div class="earn-amt-text">9.85%</div>
                                            </div>
                                          </td>
                                          <td class="earn-td-block">
                                            <div class="earn-duration-text">90 Days</div>
                                          </td>
                                          <td class="earn-td-block" style="text-align: right;">
                                            <div class="">
                                              <a  href="#" target="_blank" class="">
                                                <button type="button" class="btn-yellow border-0 shadow-none">Subscribe</button>
                                              </a>
                                            </div>
                                          </td>
                                        </tr>
                                        <tr  class="earn-tbl-row earn-tbl-row-level-0">
                                          <td class="earn-td-block">
                                            <a  target="_blank" href="#" class="earn-td-block-link">
                                              <div class="earn-td-block-link-img">
                                                <img class="earn-coin-img" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}">
                                                <div  class="earn-coin-text">USDT</div>
                                              </div>
                                            </a>
                                          </td>
                                          <td class="earn-td-block">
                                            <div class="earn-product-text">Simple Earn</div>
                                          </td>
                                          <td class="earn-td-block">
                                            <div class="earn-amt-div">
                                              <div class="earn-amt-text">
                                                <div class="">
                                                  <div class="earn-product-text">8.00%</div>
                                                </div>
                                              </div>
                                             
                                            </div>
                                          </td>
                                          <td class="earn-td-block">
                                            <div class="earn-duration-text">Flexible</div>
                                          </td>
                                          <td class="earn-td-block" style="text-align: right;">
                                            <div class="">
                                              <a  href="#" target="_blank" class="">
                                                <button type="button" class="btn-yellow border-0 shadow-none">Subscribe</button>
                                              </a>
                                            </div>
                                          </td>
                                        </tr>
                                        <tr class="earn-tbl-row earn-tbl-row-level-0">
                                          <td class="earn-td-block">
                                            <a  target="_blank" href="#" class="earn-td-block-link">
                                              <div class="earn-td-block-link-img">
                                                <img class="earn-coin-img" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}">
                                                <div  class="earn-coin-text">BUSD</div>
                                              </div>
                                            </a>
                                          </td>
                                          <td class="earn-td-block">
                                            <div class="earn-product-text">Simple Earn</div>
                                          </td>
                                          <td class="earn-td-block">
                                            <div class="earn-amt-div">
                                              <div class="earn-amt-text">
                                                <div class="">
                                                  <div class="earn-product-text">8.00%</div>
                                                </div>
                                              </div>
                                             
                                            </div>
                                          </td>
                                          <td class="earn-td-block">
                                            <div class="earn-duration-text">Flexible</div>
                                          </td>
                                          <td class="earn-td-block" style="text-align: right;">
                                            <div class="">
                                              <a  href="#" target="_blank" class="">
                                                <button type="button" class="btn-yellow border-0 shadow-none">Subscribe</button>
                                              </a>
                                            </div>
                                          </td>
                                        </tr>
                                      </tbody>
                                    </table>
                                  </div>
                               
                              </div>
 </div>
                        <div id="Polka_Zone" class="earn-record-sec" style="display: none;background:green;">
                              <div class="earn-tbl" style="width: 100%;">
                               
                                  <div class="table-responsive">
                                    <table style="table-layout: auto;">
                                      <colgroup>
                                        <col style="width: 17%;">
                                        <col style="width: 28%;">
                                        <col style="width: 18%;">
                                        <col style="width: 15%;">
                                        <col style="width: 22%;">
                                      </colgroup>
                                      <thead class="earn-tbl-thead">
                                        <tr>
                                          <th class="earn-td-block">
                                            <div class="earn-product-text">Coin</div>
                                          </th>
                                          <th class="earn-td-block">Product</th>
                                          <th class="earn-td-block">
                                            <div class="earn-amt-div">Est. APR <div class="svg-fillter-div">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="svg-fillter">
                                                  <path opacity="0.5" d="M9 10.153V8.5L12.25 5l3.25 3.501v1.652H9z" fill="#848E9C"></path>
                                                  <path d="M15.5 13.257v1.652l-3.25 3.5L9 14.91v-1.652h6.5z" fill="url(#sorting-down-color-s24_svg__paint0_linear)"></path>
                                                  <defs>
                                                    <linearGradient id="sorting-down-color-s24_svg__paint0_linear" x1="9" y1="18.41" x2="15.5" y2="18.41" gradientUnits="userSpaceOnUse">
                                                      <stop stop-color="#EFB80B"></stop>
                                                      <stop offset="1" stop-color="#FBDA3C"></stop>
                                                    </linearGradient>
                                                  </defs>
                                                </svg>
                                              </div>
                                            </div>
                                          </th>
                                          <th class="earn-td-block">
                                            <div class="earn-amt-div">Duration <div class="svg-fillter-div">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="svg-fillter">
                                                  <path d="M9 10.368v-1.4L11.968 6l2.968 2.968v1.4H9zM14.936 13v1.4l-2.968 2.968L9 14.4V13h5.936z" fill="#C1C6CD"></path>
                                                </svg>
                                              </div>
                                            </div>
                                          </th>
                                          <th class="earn-td-block" style="text-align: right;"></th>
                                        </tr>
                                      </thead>
                                      <tbody class="earn-tbl-tbody">
                                        <tr class="earn-tbl-row earn-tbl-row-level-0">
                                          <td class="earn-td-block">
                                            <a  target="_blank" href="#" class="earn-td-block-link">
                                              <div class="earn-td-block-link-img">
                                                <img class="earn-coin-img" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}">
                                                  
                                                <div  class="earn-coin-text">AXS</div>
                                              </div>
                                            </a>
                                          </td>
                                          <td class="earn-td-block">
                                            <div class="earn-product-text">Simple Earn</div>
                                          </td>
                                          <td class="earn-td-block">
                                            <div class="earn-amt-div">
                                              <div class="earn-amt-text">59.00%</div>
                                            </div>
                                          </td>
                                          <td class="earn-td-block">
                                            <div class="earn-duration-text">90 Days</div>
                                          </td>
                                          <td class="earn-td-block" style="text-align: right;">
                                            <div class="">
                                              <a  href="#" target="_blank" class="">
                                                <button type="button" class="btn-yellow border-0 shadow-none">Subscribe</button>
                                              </a>
                                            </div>
                                          </td>
                                        </tr>
                                        <tr class="earn-tbl-row earn-tbl-row-level-0">
                                          <td class="earn-td-block">
                                            <a  target="_blank" href="#" class="earn-td-block-link">
                                              <div class="earn-td-block-link-img">
                                               <img class="earn-coin-img" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}">
                                                <div  class="earn-coin-text">NEAR</div>
                                              </div>
                                            </a>
                                          </td>
                                          <td class="earn-td-block">
                                            <div class="earn-product-text">Simple Earn</div>
                                          </td>
                                          <td class="earn-td-block">
                                            <div class="earn-amt-div">
                                              <div class="earn-amt-text">30.49%</div>
                                            </div>
                                          </td>
                                          <td class="earn-td-block">
                                            <div class="earn-duration-text">120 Days</div>
                                          </td>
                                          <td class="earn-td-block" style="text-align: right;">
                                            <div class="">
                                              <a  href="#" target="_blank" class="">
                                                <button type="button" class="btn-yellow border-0 shadow-none">Subscribe</button>
                                              </a>
                                            </div>
                                          </td>
                                        </tr>
                                        <tr class="earn-tbl-row earn-tbl-row-level-0">
                                          <td class="earn-td-block">
                                            <a  target="_blank" href="#" class="earn-td-block-link">
                                              <div class="earn-td-block-link-img">
                                                <img class="earn-coin-img" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}">
                                                <div  class="earn-coin-text">AXS</div>
                                              </div>
                                            </a>
                                          </td>
                                          <td class="earn-td-block">
                                            <div class="earn-product-text">Simple Earn</div>
                                          </td>
                                          <td class="earn-td-block">
                                            <div class="earn-amt-div">
                                              <div class="earn-amt-text">
                                                <div class="">24.00%</div>
                                              </div>
                                            </div>
                                          </td>
                                          <td class="earn-td-block">
                                            <div class="earn-duration-text">Flexible</div>
                                          </td>
                                          <td class="earn-td-block" style="text-align: right;">
                                            <div class="">
                                              <a  href="#" target="_blank" class="">
                                                <button type="button" class="btn-yellow border-0 shadow-none">Subscribe</button>
                                              </a>
                                            </div>
                                          </td>
                                        </tr>
                                        <tr class="earn-tbl-row earn-tbl-row-level-0">
                                          <td class="earn-td-block">
                                            <a  target="_blank" href="#" class="earn-td-block-link">
                                              <div class="earn-td-block-link-img">
                                                <img class="earn-coin-img" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}">
                                                <div  class="earn-coin-text">DOT</div>
                                              </div>
                                            </a>
                                          </td>
                                          <td class="earn-td-block">
                                            <div class="earn-product-text">Simple Earn</div>
                                          </td>
                                          <td class="earn-td-block">
                                            <div class="earn-amt-div">
                                              <div class="earn-amt-text">20.98%</div>
                                            </div>
                                          </td>
                                          <td class="earn-td-block">
                                            <div class="earn-duration-text">120 Days</div>
                                          </td>
                                          <td class="earn-td-block" style="text-align: right;">
                                            <div class="">
                                              <a  href="#" target="_blank" class="">
                                                <button type="button" class="btn-yellow border-0 shadow-none">Subscribe</button>
                                              </a>
                                            </div>
                                          </td>
                                        </tr>
                                        <tr class="earn-tbl-row earn-tbl-row-level-0">
                                          <td class="earn-td-block">
                                            <a  target="_blank" href="#" class="earn-td-block-link">
                                              <div class="earn-td-block-link-img">
                                               <img class="earn-coin-img" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}">
                                                <div  class="earn-coin-text">AVAX</div>
                                              </div>
                                            </a>
                                          </td>
                                          <td class="earn-td-block">
                                            <div class="earn-product-text">Simple Earn</div>
                                          </td>
                                          <td class="earn-td-block">
                                            <div class="earn-amt-div">
                                              <div class="earn-amt-text">18.90%</div>
                                            </div>
                                          </td>
                                          <td class="earn-td-block">
                                            <div class="earn-duration-text">120 Days</div>
                                          </td>
                                          <td class="earn-td-block" style="text-align: right;">
                                            <div class="">
                                              <a  href="#" target="_blank" class="">
                                                <button type="button" class="btn-yellow border-0 shadow-none">Subscribe</button>
                                              </a>
                                            </div>
                                          </td>
                                        </tr>
                                        <tr class="earn-tbl-row earn-tbl-row-level-0">
                                          <td class="earn-td-block">
                                            <a  target="_blank" href="#" class="earn-td-block-link">
                                              <div class="earn-td-block-link-img">
                                                <img class="earn-coin-img" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}">
                                                <div  class="earn-coin-text">ADA</div>
                                              </div>
                                            </a>
                                          </td>
                                          <td class="earn-td-block">
                                            <div class="earn-product-text">Simple Earn</div>
                                          </td>
                                          <td class="earn-td-block">
                                            <div class="earn-amt-div">
                                              <div class="earn-amt-text">9.85%</div>
                                            </div>
                                          </td>
                                          <td class="earn-td-block">
                                            <div class="earn-duration-text">90 Days</div>
                                          </td>
                                          <td class="earn-td-block" style="text-align: right;">
                                            <div class="">
                                              <a  href="#" target="_blank" class="">
                                                <button type="button" class="btn-yellow border-0 shadow-none">Subscribe</button>
                                              </a>
                                            </div>
                                          </td>
                                        </tr>
                                        <tr  class="earn-tbl-row earn-tbl-row-level-0">
                                          <td class="earn-td-block">
                                            <a  target="_blank" href="#" class="earn-td-block-link">
                                              <div class="earn-td-block-link-img">
                                                <img class="earn-coin-img" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}">
                                                <div  class="earn-coin-text">USDT</div>
                                              </div>
                                            </a>
                                          </td>
                                          <td class="earn-td-block">
                                            <div class="earn-product-text">Simple Earn</div>
                                          </td>
                                          <td class="earn-td-block">
                                            <div class="earn-amt-div">
                                              <div class="earn-amt-text">
                                                <div class="">
                                                  <div class="earn-product-text">8.00%</div>
                                                </div>
                                              </div>
                                            
                                            </div>
                                          </td>
                                          <td class="earn-td-block">
                                            <div class="earn-duration-text">Flexible</div>
                                          </td>
                                          <td class="earn-td-block" style="text-align: right;">
                                            <div class="">
                                              <a  href="#" target="_blank" class="">
                                                <button type="button" class="btn-yellow border-0 shadow-none">Subscribe</button>
                                              </a>
                                            </div>
                                          </td>
                                        </tr>
                                        <tr class="earn-tbl-row earn-tbl-row-level-0">
                                          <td class="earn-td-block">
                                            <a  target="_blank" href="#" class="earn-td-block-link">
                                              <div class="earn-td-block-link-img">
                                                <img class="earn-coin-img" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}">
                                                <div  class="earn-coin-text">BUSD</div>
                                              </div>
                                            </a>
                                          </td>
                                          <td class="earn-td-block">
                                            <div class="earn-product-text">Simple Earn</div>
                                          </td>
                                          <td class="earn-td-block">
                                            <div class="earn-amt-div">
                                              <div class="earn-amt-text">
                                                <div class="">
                                                  <div class="earn-product-text">8.00%</div>
                                                </div>
                                              </div>
                                             
                                            </div>
                                          </td>
                                          <td class="earn-td-block">
                                            <div class="earn-duration-text">Flexible</div>
                                          </td>
                                          <td class="earn-td-block" style="text-align: right;">
                                            <div class="">
                                              <a  href="#" target="_blank" class="">
                                                <button type="button" class="btn-yellow border-0 shadow-none">Subscribe</button>
                                              </a>
                                            </div>
                                          </td>
                                        </tr>
                                      </tbody>
                                    </table>
                                  </div>
                               
                              </div>
</div>
                        <div id="Solana_Zone" class="earn-record-sec" style="display: none;background:purple;">
                              <div class="earn-tbl" style="width: 100%;">
                               
                                  <div class="table-responsive">
                                    <table style="table-layout: auto;">
                                      <colgroup>
                                        <col style="width: 17%;">
                                        <col style="width: 28%;">
                                        <col style="width: 18%;">
                                        <col style="width: 15%;">
                                        <col style="width: 22%;">
                                      </colgroup>
                                      <thead class="earn-tbl-thead">
                                        <tr>
                                          <th class="earn-td-block">
                                            <div class="earn-product-text">Coin</div>
                                          </th>
                                          <th class="earn-td-block">Product</th>
                                          <th class="earn-td-block">
                                            <div class="earn-amt-div">Est. APR <div class="svg-fillter-div">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="svg-fillter">
                                                  <path opacity="0.5" d="M9 10.153V8.5L12.25 5l3.25 3.501v1.652H9z" fill="#848E9C"></path>
                                                  <path d="M15.5 13.257v1.652l-3.25 3.5L9 14.91v-1.652h6.5z" fill="url(#sorting-down-color-s24_svg__paint0_linear)"></path>
                                                  <defs>
                                                    <linearGradient id="sorting-down-color-s24_svg__paint0_linear" x1="9" y1="18.41" x2="15.5" y2="18.41" gradientUnits="userSpaceOnUse">
                                                      <stop stop-color="#EFB80B"></stop>
                                                      <stop offset="1" stop-color="#FBDA3C"></stop>
                                                    </linearGradient>
                                                  </defs>
                                                </svg>
                                              </div>
                                            </div>
                                          </th>
                                          <th class="earn-td-block">
                                            <div class="earn-amt-div">Duration <div class="svg-fillter-div">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="svg-fillter">
                                                  <path d="M9 10.368v-1.4L11.968 6l2.968 2.968v1.4H9zM14.936 13v1.4l-2.968 2.968L9 14.4V13h5.936z" fill="#C1C6CD"></path>
                                                </svg>
                                              </div>
                                            </div>
                                          </th>
                                          <th class="earn-td-block" style="text-align: right;"></th>
                                        </tr>
                                      </thead>
                                      <tbody class="earn-tbl-tbody">
                                        <tr class="earn-tbl-row earn-tbl-row-level-0">
                                          <td class="earn-td-block">
                                            <a  target="_blank" href="#" class="earn-td-block-link">
                                              <div class="earn-td-block-link-img">
                                                <img class="earn-coin-img" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}">
                                                  
                                                <div  class="earn-coin-text">AXS</div>
                                              </div>
                                            </a>
                                          </td>
                                          <td class="earn-td-block">
                                            <div class="earn-product-text">Simple Earn</div>
                                          </td>
                                          <td class="earn-td-block">
                                            <div class="earn-amt-div">
                                              <div class="earn-amt-text">59.00%</div>
                                            </div>
                                          </td>
                                          <td class="earn-td-block">
                                            <div class="earn-duration-text">90 Days</div>
                                          </td>
                                          <td class="earn-td-block" style="text-align: right;">
                                            <div class="">
                                              <a  href="#" target="_blank" class="">
                                                <button type="button" class="btn-yellow border-0 shadow-none">Subscribe</button>
                                              </a>
                                            </div>
                                          </td>
                                        </tr>
                                        <tr class="earn-tbl-row earn-tbl-row-level-0">
                                          <td class="earn-td-block">
                                            <a  target="_blank" href="#" class="earn-td-block-link">
                                              <div class="earn-td-block-link-img">
                                               <img class="earn-coin-img" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}">
                                                <div  class="earn-coin-text">NEAR</div>
                                              </div>
                                            </a>
                                          </td>
                                          <td class="earn-td-block">
                                            <div class="earn-product-text">Simple Earn</div>
                                          </td>
                                          <td class="earn-td-block">
                                            <div class="earn-amt-div">
                                              <div class="earn-amt-text">30.49%</div>
                                            </div>
                                          </td>
                                          <td class="earn-td-block">
                                            <div class="earn-duration-text">120 Days</div>
                                          </td>
                                          <td class="earn-td-block" style="text-align: right;">
                                            <div class="">
                                              <a  href="#" target="_blank" class="">
                                                <button type="button" class="btn-yellow border-0 shadow-none">Subscribe</button>
                                              </a>
                                            </div>
                                          </td>
                                        </tr>
                                        <tr class="earn-tbl-row earn-tbl-row-level-0">
                                          <td class="earn-td-block">
                                            <a  target="_blank" href="#" class="earn-td-block-link">
                                              <div class="earn-td-block-link-img">
                                                <img class="earn-coin-img" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}">
                                                <div  class="earn-coin-text">AXS</div>
                                              </div>
                                            </a>
                                          </td>
                                          <td class="earn-td-block">
                                            <div class="earn-product-text">Simple Earn</div>
                                          </td>
                                          <td class="earn-td-block">
                                            <div class="earn-amt-div">
                                              <div class="earn-amt-text">
                                                <div class="">24.00%</div>
                                              </div>
                                            </div>
                                          </td>
                                          <td class="earn-td-block">
                                            <div class="earn-duration-text">Flexible</div>
                                          </td>
                                          <td class="earn-td-block" style="text-align: right;">
                                            <div class="">
                                              <a  href="#" target="_blank" class="">
                                                <button type="button" class="btn-yellow border-0 shadow-none">Subscribe</button>
                                              </a>
                                            </div>
                                          </td>
                                        </tr>
                                        <tr class="earn-tbl-row earn-tbl-row-level-0">
                                          <td class="earn-td-block">
                                            <a  target="_blank" href="#" class="earn-td-block-link">
                                              <div class="earn-td-block-link-img">
                                                <img class="earn-coin-img" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}">
                                                <div  class="earn-coin-text">DOT</div>
                                              </div>
                                            </a>
                                          </td>
                                          <td class="earn-td-block">
                                            <div class="earn-product-text">Simple Earn</div>
                                          </td>
                                          <td class="earn-td-block">
                                            <div class="earn-amt-div">
                                              <div class="earn-amt-text">20.98%</div>
                                            </div>
                                          </td>
                                          <td class="earn-td-block">
                                            <div class="earn-duration-text">120 Days</div>
                                          </td>
                                          <td class="earn-td-block" style="text-align: right;">
                                            <div class="">
                                              <a  href="#" target="_blank" class="">
                                                <button type="button" class="btn-yellow border-0 shadow-none">Subscribe</button>
                                              </a>
                                            </div>
                                          </td>
                                        </tr>
                                        <tr class="earn-tbl-row earn-tbl-row-level-0">
                                          <td class="earn-td-block">
                                            <a  target="_blank" href="#" class="earn-td-block-link">
                                              <div class="earn-td-block-link-img">
                                               <img class="earn-coin-img" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}">
                                                <div  class="earn-coin-text">AVAX</div>
                                              </div>
                                            </a>
                                          </td>
                                          <td class="earn-td-block">
                                            <div class="earn-product-text">Simple Earn</div>
                                          </td>
                                          <td class="earn-td-block">
                                            <div class="earn-amt-div">
                                              <div class="earn-amt-text">18.90%</div>
                                            </div>
                                          </td>
                                          <td class="earn-td-block">
                                            <div class="earn-duration-text">120 Days</div>
                                          </td>
                                          <td class="earn-td-block" style="text-align: right;">
                                            <div class="">
                                              <a  href="#" target="_blank" class="">
                                                <button type="button" class="btn-yellow border-0 shadow-none">Subscribe</button>
                                              </a>
                                            </div>
                                          </td>
                                        </tr>
                                        <tr class="earn-tbl-row earn-tbl-row-level-0">
                                          <td class="earn-td-block">
                                            <a  target="_blank" href="#" class="earn-td-block-link">
                                              <div class="earn-td-block-link-img">
                                                <img class="earn-coin-img" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}">
                                                <div  class="earn-coin-text">ADA</div>
                                              </div>
                                            </a>
                                          </td>
                                          <td class="earn-td-block">
                                            <div class="earn-product-text">Simple Earn</div>
                                          </td>
                                          <td class="earn-td-block">
                                            <div class="earn-amt-div">
                                              <div class="earn-amt-text">9.85%</div>
                                            </div>
                                          </td>
                                          <td class="earn-td-block">
                                            <div class="earn-duration-text">90 Days</div>
                                          </td>
                                          <td class="earn-td-block" style="text-align: right;">
                                            <div class="">
                                              <a  href="#" target="_blank" class="">
                                                <button type="button" class="btn-yellow border-0 shadow-none">Subscribe</button>
                                              </a>
                                            </div>
                                          </td>
                                        </tr>
                                        <tr  class="earn-tbl-row earn-tbl-row-level-0">
                                          <td class="earn-td-block">
                                            <a  target="_blank" href="#" class="earn-td-block-link">
                                              <div class="earn-td-block-link-img">
                                                <img class="earn-coin-img" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}">
                                                <div  class="earn-coin-text">USDT</div>
                                              </div>
                                            </a>
                                          </td>
                                          <td class="earn-td-block">
                                            <div class="earn-product-text">Simple Earn</div>
                                          </td>
                                          <td class="earn-td-block">
                                            <div class="earn-amt-div">
                                              <div class="earn-amt-text">
                                                <div class="">
                                                  <div class="earn-product-text">8.00%</div>
                                                </div>
                                              </div>
                                              
                                            </div>
                                          </td>
                                          <td class="earn-td-block">
                                            <div class="earn-duration-text">Flexible</div>
                                          </td>
                                          <td class="earn-td-block" style="text-align: right;">
                                            <div class="">
                                              <a  href="#" target="_blank" class="">
                                                <button type="button" class="btn-yellow border-0 shadow-none">Subscribe</button>
                                              </a>
                                            </div>
                                          </td>
                                        </tr>
                                        <tr class="earn-tbl-row earn-tbl-row-level-0">
                                          <td class="earn-td-block">
                                            <a  target="_blank" href="#" class="earn-td-block-link">
                                              <div class="earn-td-block-link-img">
                                                <img class="earn-coin-img" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}">
                                                <div  class="earn-coin-text">BUSD</div>
                                              </div>
                                            </a>
                                          </td>
                                          <td class="earn-td-block">
                                            <div class="earn-product-text">Simple Earn</div>
                                          </td>
                                          <td class="earn-td-block">
                                            <div class="earn-amt-div">
                                              <div class="earn-amt-text">
                                                <div class="">
                                                  <div class="earn-product-text">8.00%</div>
                                                </div>
                                              </div>
                                            
                                            </div>
                                          </td>
                                          <td class="earn-td-block">
                                            <div class="earn-duration-text">Flexible</div>
                                          </td>
                                          <td class="earn-td-block" style="text-align: right;">
                                            <div class="">
                                              <a  href="#" target="_blank" class="">
                                                <button type="button" class="btn-yellow border-0 shadow-none">Subscribe</button>
                                              </a>
                                            </div>
                                          </td>
                                        </tr>
                                      </tbody>
                                    </table>
                                  </div>
                               
                              </div>
 </div>
			              
			               
                           
			                
                            
                            
                            
			              
			              
			              
			              
			              
			              
			                </div>
			            <div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">
				                2
			            </div>
			            <div class="tab-pane fade" id="nav-contact" role="tabpanel" aria-labelledby="nav-contact-tab">
			                   <section class="bg-white investment-table pt-0 pb-0">

    <div class="investment-top">
      <div class="investment-top-left">
        <div  class="investment-top-title">Auto-Invest</div>
        <div  class="investment-top-subtitle">#Start growing your assets on autopilot</div>
      </div>
      <div class="search-box-div">
        <div class=" search-box-inner">
          <div class="WM-input-prefix">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="svg-search">
              <path fill-rule="evenodd" clip-rule="evenodd" d="M11 6a5 5 0 110 10 5 5 0 010-10zm0-3a8 8 0 017.021 11.838l3.07 3.07-1.59 1.591-1.591 1.591-3.07-3.07A8 8 0 1111 3z" fill="currentColor"></path>
            </svg>
          </div>
          <input type="input" value="" placeholder="Search Coin" class="search-box-input">
        </div>
      </div>
    </div>
    <div class="investment-desc-div">
      <div class="investment-Portfolio">
        <div class="Portfolio-inner">
          <div class="Portfolio-inner-left">
            <img src="{{ asset('public/assets/img/chart-pie-g.svg') }}" class="Portfolio-inner-icon">
            <div class="Portfolio-inner-content-box">
              <div class="Portfolio-inner-title">Portfolio Auto-Invest</div>
              <div class="Portfolio-inner-subtitle">Diversify your crypto holdings and increase coverage.</div>
            </div>
          </div>
          <div class="Portfolio-inner-right">
            <div class="Portfolio-Available-Coins">
              <div class="Available-Coins-inner">
                <div class="Available-Coins-img-box">
                  <img class="coin-list-img" src="{{ asset('public/assets/img/133e0469-3a96-4e3a-9c42-b4c5a4f8def8.png') }}">
                </div>
                <div class="Available-Coins-img-box">
                  <img class="coin-list-img" src="{{ asset('public/assets/img/6caae4f1-f4c6-4486-b05b-442dd559f51f.jpg') }}">
                </div>
                <div class="Available-Coins-img-box">
                  <img class="coin-list-img" src="{{ asset('public/assets/img/133e0469-3a96-4e3a-9c42-b4c5a4f8def8.png') }}">
                </div>
                <div class="Available-Coins-img-box">
                  <img class="coin-list-img" src="{{ asset('public/assets/img/8f181a53-bacb-4a3a-a66a-e586a7b7b61a.png') }}">
                </div>
               
              </div>
              <div class="Available-Coins-div">
                <div class="Available-coins">63 Available Coins</div>
                <div class="Coins-bottom-text-2">63
                  +
                </div>
              </div>
            </div>
            <div class="d-flex">
              <button type="button" class="btn-yellow border-0 shadow-none">
              Create a plan
              </button>
            </div>
          </div>
        </div>
      </div>
      <div class="lot-heading-div">
        <div class="lot-name">Product</div>
        <div class="lot-status">Historical ROI <div class="d-inline-block">
           
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="svg-info">
              <path fill-rule="evenodd" clip-rule="evenodd" d="M12 4c4.411 0 8 3.589 8 8s-3.589 8-8 8-8-3.589-8-8 3.589-8 8-8zm0-2C6.477 2 2 6.477 2 12s4.477 10 10 10 10-4.477 10-10S17.523 2 12 2zm.997 9.004h-2.009v6h2.009v-6zm-2.009-4h2.009v2.009h-2.009v-2.01z" fill="currentColor"></path>
            </svg>
          </div>
        </div>
        <div class="lot-price-heading">Spot Price</div>
        <div class="flex-width-box"></div>
      </div>
      <div class="lot-status-row">
        <div class="lot-name">
          <div class="lot-name-inner">
            <img class="coin-list-img" src="{{ asset('public/assets/img/6caae4f1-f4c6-4486-b05b-442dd559f51f.jpg') }}">
            <div  class="lot-name-text">WM</div>
          </div>
        </div>
        <div class="lot-investment-div">
          <div  class="text-profit">541.97%</div>
          <div class="lot-duration-div">
            
            <div  class="box-border-yellow">3YR</div>
            <div  class="box-border-gray">1YR</div>
            <div  class="box-border-gray">6M</div>
            <div  class="box-border-gray">3M</div>
            <div  class="box-border-gray">7D</div>
          </div>
            <div class="mt-24">
            <div class="d-inline-block">
             
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="svg-data-chart">
                <path fill-rule="evenodd" clip-rule="evenodd" d="M4 18h18V4h-2l-7 7H8l-4 4v3z" fill="url(#chart-line-g_svg__paint0_linear)"></path>
                <path d="M4 4H2v16h20v-2H4V4z" fill="#76808F"></path>
                <defs>
                  <linearGradient id="chart-line-g_svg__paint0_linear" x1="13" y1="18" x2="13" y2="4" gradientUnits="userSpaceOnUse">
                    <stop stop-color="#F0B90B"></stop>
                    <stop offset="1" stop-color="#F8D33A"></stop>
                  </linearGradient>
                </defs>
              </svg>
            </div>
          </div>
        </div>
        <div class="lot-price-heading">
          <div  class="lot-price">270.20</div>
        </div>
        <div class="flex-width-box">
          <button type="button" class="btn-yellow border-0 shadow-none">
          Create a plan
          </button>
        </div>
      </div>
     
     
     
      <div class="lot-status-row">
        <div class="lot-name">
          <div class="lot-name-inner">
            <img class="coin-list-img" src="{{ asset('public/assets/img/6caae4f1-f4c6-4486-b05b-442dd559f51f.jpg') }}">
            <div  class="lot-name-text">APE</div>
          </div>
        </div>
        <div class="lot-investment-div">
          <div  class="text-loss">-27.66%</div>
          <div class="lot-duration-div">
           
            <div  class="box-border-yellow">3YR</div>
            <div  class="box-border-gray">1YR</div>
            <div  class="box-border-gray">6M</div>
            <div  class="box-border-gray">3M</div>
            <div  class="box-border-gray">7D</div>
          </div>
          <div class="mt-24">
            <div class="d-inline-block">
             
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="svg-data-chart">
                <path fill-rule="evenodd" clip-rule="evenodd" d="M4 18h18V4h-2l-7 7H8l-4 4v3z" fill="url(#chart-line-g_svg__paint0_linear)"></path>
                <path d="M4 4H2v16h20v-2H4V4z" fill="#76808F"></path>
                <defs>
                  <linearGradient id="chart-line-g_svg__paint0_linear" x1="13" y1="18" x2="13" y2="4" gradientUnits="userSpaceOnUse">
                    <stop stop-color="#F0B90B"></stop>
                    <stop offset="1" stop-color="#F8D33A"></stop>
                  </linearGradient>
                </defs>
              </svg>
            </div>
          </div>
        </div>
        <div class="lot-price-heading">
          <div  class="lot-price">4.52</div>
        </div>
        <div class="flex-width-box">
          <button type="button" class="btn-yellow border-0 shadow-none">
          Create a plan
          </button>
        </div>
      </div>
      <div class="lot-status-row">
        <div class="lot-name">
          <div class="lot-name-inner">
            <img class="coin-list-img" src="{{ asset('public/assets/img/6caae4f1-f4c6-4486-b05b-442dd559f51f.jpg') }}">
            <div  class="lot-name-text">WM</div>
          </div>
        </div>
        <div class="lot-investment-div">
          <div  class="text-profit">541.97%</div>
          <div class="lot-duration-div">
            
            <div  class="box-border-yellow">3YR</div>
            <div  class="box-border-gray">1YR</div>
            <div  class="box-border-gray">6M</div>
            <div  class="box-border-gray">3M</div>
            <div  class="box-border-gray">7D</div>
          </div>
            <div class="mt-24">
            <div class="d-inline-block">
             
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="svg-data-chart">
                <path fill-rule="evenodd" clip-rule="evenodd" d="M4 18h18V4h-2l-7 7H8l-4 4v3z" fill="url(#chart-line-g_svg__paint0_linear)"></path>
                <path d="M4 4H2v16h20v-2H4V4z" fill="#76808F"></path>
                <defs>
                  <linearGradient id="chart-line-g_svg__paint0_linear" x1="13" y1="18" x2="13" y2="4" gradientUnits="userSpaceOnUse">
                    <stop stop-color="#F0B90B"></stop>
                    <stop offset="1" stop-color="#F8D33A"></stop>
                  </linearGradient>
                </defs>
              </svg>
            </div>
          </div>
        </div>
        <div class="lot-price-heading">
          <div  class="lot-price">270.20</div>
        </div>
        <div class="flex-width-box">
          <button type="button" class="btn-yellow border-0 shadow-none">
          Create a plan
          </button>
        </div>
      </div>
     
     
     
      <div class="lot-status-row">
        <div class="lot-name">
          <div class="lot-name-inner">
            <img class="coin-list-img" src="{{ asset('public/assets/img/6caae4f1-f4c6-4486-b05b-442dd559f51f.jpg') }}">
            <div  class="lot-name-text">APE</div>
          </div>
        </div>
        <div class="lot-investment-div">
          <div  class="text-loss">-27.66%</div>
          <div class="lot-duration-div">
           
            <div  class="box-border-yellow">3YR</div>
            <div  class="box-border-gray">1YR</div>
            <div  class="box-border-gray">6M</div>
            <div  class="box-border-gray">3M</div>
            <div  class="box-border-gray">7D</div>
          </div>
          <div class="mt-24">
            <div class="d-inline-block">
             
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="svg-data-chart">
                <path fill-rule="evenodd" clip-rule="evenodd" d="M4 18h18V4h-2l-7 7H8l-4 4v3z" fill="url(#chart-line-g_svg__paint0_linear)"></path>
                <path d="M4 4H2v16h20v-2H4V4z" fill="#76808F"></path>
                <defs>
                  <linearGradient id="chart-line-g_svg__paint0_linear" x1="13" y1="18" x2="13" y2="4" gradientUnits="userSpaceOnUse">
                    <stop stop-color="#F0B90B"></stop>
                    <stop offset="1" stop-color="#F8D33A"></stop>
                  </linearGradient>
                </defs>
              </svg>
            </div>
          </div>
        </div>
        <div class="lot-price-heading">
          <div  class="lot-price">4.52</div>
        </div>
        <div class="flex-width-box">
          <button type="button" class="btn-yellow border-0 shadow-none">
          Create a plan
          </button>
        </div>
      </div><div class="lot-status-row">
        <div class="lot-name">
          <div class="lot-name-inner">
            <img class="coin-list-img" src="{{ asset('public/assets/img/6caae4f1-f4c6-4486-b05b-442dd559f51f.jpg') }}">
            <div  class="lot-name-text">WM</div>
          </div>
        </div>
        <div class="lot-investment-div">
          <div  class="text-profit">541.97%</div>
          <div class="lot-duration-div">
            
            <div  class="box-border-yellow">3YR</div>
            <div  class="box-border-gray">1YR</div>
            <div  class="box-border-gray">6M</div>
            <div  class="box-border-gray">3M</div>
            <div  class="box-border-gray">7D</div>
          </div>
            <div class="mt-24">
            <div class="d-inline-block">
             
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="svg-data-chart">
                <path fill-rule="evenodd" clip-rule="evenodd" d="M4 18h18V4h-2l-7 7H8l-4 4v3z" fill="url(#chart-line-g_svg__paint0_linear)"></path>
                <path d="M4 4H2v16h20v-2H4V4z" fill="#76808F"></path>
                <defs>
                  <linearGradient id="chart-line-g_svg__paint0_linear" x1="13" y1="18" x2="13" y2="4" gradientUnits="userSpaceOnUse">
                    <stop stop-color="#F0B90B"></stop>
                    <stop offset="1" stop-color="#F8D33A"></stop>
                  </linearGradient>
                </defs>
              </svg>
            </div>
          </div>
        </div>
        <div class="lot-price-heading">
          <div  class="lot-price">270.20</div>
        </div>
        <div class="flex-width-box">
          <button type="button" class="btn-yellow border-0 shadow-none">
          Create a plan
          </button>
        </div>
      </div>
     
     
     
      <div class="lot-status-row">
        <div class="lot-name">
          <div class="lot-name-inner">
            <img class="coin-list-img" src="{{ asset('public/assets/img/6caae4f1-f4c6-4486-b05b-442dd559f51f.jpg') }}">
            <div  class="lot-name-text">APE</div>
          </div>
        </div>
        <div class="lot-investment-div">
          <div  class="text-loss">-27.66%</div>
          <div class="lot-duration-div">
           
            <div  class="box-border-yellow">3YR</div>
            <div  class="box-border-gray">1YR</div>
            <div  class="box-border-gray">6M</div>
            <div  class="box-border-gray">3M</div>
            <div  class="box-border-gray">7D</div>
          </div>
          <div class="mt-24">
            <div class="d-inline-block">
             
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="svg-data-chart">
                <path fill-rule="evenodd" clip-rule="evenodd" d="M4 18h18V4h-2l-7 7H8l-4 4v3z" fill="url(#chart-line-g_svg__paint0_linear)"></path>
                <path d="M4 4H2v16h20v-2H4V4z" fill="#76808F"></path>
                <defs>
                  <linearGradient id="chart-line-g_svg__paint0_linear" x1="13" y1="18" x2="13" y2="4" gradientUnits="userSpaceOnUse">
                    <stop stop-color="#F0B90B"></stop>
                    <stop offset="1" stop-color="#F8D33A"></stop>
                  </linearGradient>
                </defs>
              </svg>
            </div>
          </div>
        </div>
        <div class="lot-price-heading">
          <div  class="lot-price">4.52</div>
        </div>
        <div class="flex-width-box">
          <button type="button" class="btn-yellow border-0 shadow-none">
          Create a plan
          </button>
        </div>
      </div><div class="lot-status-row">
        <div class="lot-name">
          <div class="lot-name-inner">
            <img class="coin-list-img" src="{{ asset('public/assets/img/6caae4f1-f4c6-4486-b05b-442dd559f51f.jpg') }}">
            <div  class="lot-name-text">WM</div>
          </div>
        </div>
        <div class="lot-investment-div">
          <div  class="text-profit">541.97%</div>
          <div class="lot-duration-div">
            
            <div  class="box-border-yellow">3YR</div>
            <div  class="box-border-gray">1YR</div>
            <div  class="box-border-gray">6M</div>
            <div  class="box-border-gray">3M</div>
            <div  class="box-border-gray">7D</div>
          </div>
            <div class="mt-24">
            <div class="d-inline-block">
             
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="svg-data-chart">
                <path fill-rule="evenodd" clip-rule="evenodd" d="M4 18h18V4h-2l-7 7H8l-4 4v3z" fill="url(#chart-line-g_svg__paint0_linear)"></path>
                <path d="M4 4H2v16h20v-2H4V4z" fill="#76808F"></path>
                <defs>
                  <linearGradient id="chart-line-g_svg__paint0_linear" x1="13" y1="18" x2="13" y2="4" gradientUnits="userSpaceOnUse">
                    <stop stop-color="#F0B90B"></stop>
                    <stop offset="1" stop-color="#F8D33A"></stop>
                  </linearGradient>
                </defs>
              </svg>
            </div>
          </div>
        </div>
        <div class="lot-price-heading">
          <div  class="lot-price">270.20</div>
        </div>
        <div class="flex-width-box">
          <button type="button" class="btn-yellow border-0 shadow-none">
          Create a plan
          </button>
        </div>
      </div>
     
     
     
      <div class="lot-status-row">
        <div class="lot-name">
          <div class="lot-name-inner">
            <img class="coin-list-img" src="{{ asset('public/assets/img/6caae4f1-f4c6-4486-b05b-442dd559f51f.jpg') }}">
            <div  class="lot-name-text">APE</div>
          </div>
        </div>
        <div class="lot-investment-div">
          <div  class="text-loss">-27.66%</div>
          <div class="lot-duration-div">
           
            <div  class="box-border-yellow">3YR</div>
            <div  class="box-border-gray">1YR</div>
            <div  class="box-border-gray">6M</div>
            <div  class="box-border-gray">3M</div>
            <div  class="box-border-gray">7D</div>
          </div>
          <div class="mt-24">
            <div class="d-inline-block">
             
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="svg-data-chart">
                <path fill-rule="evenodd" clip-rule="evenodd" d="M4 18h18V4h-2l-7 7H8l-4 4v3z" fill="url(#chart-line-g_svg__paint0_linear)"></path>
                <path d="M4 4H2v16h20v-2H4V4z" fill="#76808F"></path>
                <defs>
                  <linearGradient id="chart-line-g_svg__paint0_linear" x1="13" y1="18" x2="13" y2="4" gradientUnits="userSpaceOnUse">
                    <stop stop-color="#F0B90B"></stop>
                    <stop offset="1" stop-color="#F8D33A"></stop>
                  </linearGradient>
                </defs>
              </svg>
            </div>
          </div>
        </div>
        <div class="lot-price-heading">
          <div  class="lot-price">4.52</div>
        </div>
        <div class="flex-width-box">
          <button type="button" class="btn-yellow border-0 shadow-none">
          Create a plan
          </button>
        </div>
      </div><div class="lot-status-row">
        <div class="lot-name">
          <div class="lot-name-inner">
            <img class="coin-list-img" src="{{ asset('public/assets/img/6caae4f1-f4c6-4486-b05b-442dd559f51f.jpg') }}">
            <div  class="lot-name-text">WM</div>
          </div>
        </div>
        <div class="lot-investment-div">
          <div  class="text-profit">541.97%</div>
          <div class="lot-duration-div">
            
            <div  class="box-border-yellow">3YR</div>
            <div  class="box-border-gray">1YR</div>
            <div  class="box-border-gray">6M</div>
            <div  class="box-border-gray">3M</div>
            <div  class="box-border-gray">7D</div>
          </div>
            <div class="mt-24">
            <div class="d-inline-block">
             
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="svg-data-chart">
                <path fill-rule="evenodd" clip-rule="evenodd" d="M4 18h18V4h-2l-7 7H8l-4 4v3z" fill="url(#chart-line-g_svg__paint0_linear)"></path>
                <path d="M4 4H2v16h20v-2H4V4z" fill="#76808F"></path>
                <defs>
                  <linearGradient id="chart-line-g_svg__paint0_linear" x1="13" y1="18" x2="13" y2="4" gradientUnits="userSpaceOnUse">
                    <stop stop-color="#F0B90B"></stop>
                    <stop offset="1" stop-color="#F8D33A"></stop>
                  </linearGradient>
                </defs>
              </svg>
            </div>
          </div>
        </div>
        <div class="lot-price-heading">
          <div  class="lot-price">270.20</div>
        </div>
        <div class="flex-width-box">
          <button type="button" class="btn-yellow border-0 shadow-none">
          Create a plan
          </button>
        </div>
      </div>
     
     
     
      <div class="lot-status-row">
        <div class="lot-name">
          <div class="lot-name-inner">
            <img class="coin-list-img" src="{{ asset('public/assets/img/6caae4f1-f4c6-4486-b05b-442dd559f51f.jpg') }}">
            <div  class="lot-name-text">APE</div>
          </div>
        </div>
        <div class="lot-investment-div">
          <div  class="text-loss">-27.66%</div>
          <div class="lot-duration-div">
           
            <div  class="box-border-yellow">3YR</div>
            <div  class="box-border-gray">1YR</div>
            <div  class="box-border-gray">6M</div>
            <div  class="box-border-gray">3M</div>
            <div  class="box-border-gray">7D</div>
          </div>
          <div class="mt-24">
            <div class="d-inline-block">
             
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="svg-data-chart">
                <path fill-rule="evenodd" clip-rule="evenodd" d="M4 18h18V4h-2l-7 7H8l-4 4v3z" fill="url(#chart-line-g_svg__paint0_linear)"></path>
                <path d="M4 4H2v16h20v-2H4V4z" fill="#76808F"></path>
                <defs>
                  <linearGradient id="chart-line-g_svg__paint0_linear" x1="13" y1="18" x2="13" y2="4" gradientUnits="userSpaceOnUse">
                    <stop stop-color="#F0B90B"></stop>
                    <stop offset="1" stop-color="#F8D33A"></stop>
                  </linearGradient>
                </defs>
              </svg>
            </div>
          </div>
        </div>
        <div class="lot-price-heading">
          <div  class="lot-price">4.52</div>
        </div>
        <div class="flex-width-box">
          <button type="button" class="btn-yellow border-0 shadow-none">
          Create a plan
          </button>
        </div>
      </div>
      
      <div class="">
  <div class="investment-table-mob">
    <div class="investment-table-inner">
      <div class="lot-name-inner">
        <img class="investment-table-img-mob" src="image/admin_mgs_image_upload/20220218/94863af2-c980-42cf-a139-7b9f462a36c2.png">
        <div  class="lot-name-text">WM</div>
      </div>
      <div class="investment-table-desc">
        <div class="investment-table-desc-text">
          <div class="spot-price-text-mob">
            <div class="Available-Coins-inner">Historical ROI <div class="d-inline-block">
              
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="svg-info">
                  <path fill-rule="evenodd" clip-rule="evenodd" d="M12 4c4.411 0 8 3.589 8 8s-3.589 8-8 8-8-3.589-8-8 3.589-8 8-8zm0-2C6.477 2 2 6.477 2 12s4.477 10 10 10 10-4.477 10-10S17.523 2 12 2zm.997 9.004h-2.009v6h2.009v-6zm-2.009-4h2.009v2.009h-2.009v-2.01z" fill="currentColor"></path>
                </svg>
              </div>
            </div>
          </div>
          <div class="spot-price-div-mob">
            <div class="spot-price-div-mob-inner">
              <div  class="text-profit-mob">541.97%</div>
              <div class="duration-box-mob-main">
                <div  class="duration-box-mob-active">3YR</div>
                <div  class="duration-box-mob">1YR</div>
                <div  class="duration-box-mob">6M</div>
                <div  class="duration-box-mob">3M</div>
                <div  class="duration-box-mob">7D</div>
              </div>
             <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="svg-data-chart-mob"><path fill-rule="evenodd" clip-rule="evenodd" d="M4 18h18V4h-2l-7 7H8l-4 4v3z" fill="url(#chart-line-g_svg__paint0_linear)"></path><path d="M4 4H2v16h20v-2H4V4z" fill="#76808F"></path><defs><linearGradient id="chart-line-g_svg__paint0_linear" x1="13" y1="18" x2="13" y2="4" gradientUnits="userSpaceOnUse"><stop stop-color="#F0B90B"></stop><stop offset="1" stop-color="#F8D33A"></stop></linearGradient></defs></svg>
            </div>
          </div>
        </div>
        <div class="desc-price-div">
          <div class="spot-price-text-mob">Spot Price</div>
          <div class="spot-price-div-mob">
            <div  class="lot-price">270.70</div>
          </div>
        </div>
      </div>
    </div>
    <div class="Available-Coins-inner">
      <button type="button" class="btn-yellow border-0 shadow-none">
      Create a plan
      </button>
    </div>
  </div>
  <div class="investment-table-mob">
    <div class="investment-table-inner">
      <div class="lot-name-inner">
        <img class="investment-table-img-mob" src="image/admin_mgs_image_upload/20201110/87496d50-2408-43e1-ad4c-78b47b448a6a.png">
        <div  class="lot-name-text">BTC</div>
      </div>
      <div class="investment-table-desc">
        <div class="investment-table-desc-text">
          <div class="spot-price-text-mob">
            <div class="Available-Coins-inner">Historical ROI <div class="d-inline-block">
              
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="svg-info">
                  <path fill-rule="evenodd" clip-rule="evenodd" d="M12 4c4.411 0 8 3.589 8 8s-3.589 8-8 8-8-3.589-8-8 3.589-8 8-8zm0-2C6.477 2 2 6.477 2 12s4.477 10 10 10 10-4.477 10-10S17.523 2 12 2zm.997 9.004h-2.009v6h2.009v-6zm-2.009-4h2.009v2.009h-2.009v-2.01z" fill="currentColor"></path>
                </svg>
              </div>
            </div>
          </div>
          <div class="spot-price-div-mob">
            <div class="spot-price-div-mob-inner">
              <div  class="text-profit-mob">13.76%</div>
              <div class="duration-box-mob-main">
                <div  class="duration-box-mob-active">3YR</div>
                <div  class="duration-box-mob">1YR</div>
                <div  class="duration-box-mob">6M</div>
                <div  class="duration-box-mob">3M</div>
                <div  class="duration-box-mob">7D</div>
              </div>
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="svg-data-chart-mob">
                <path fill-rule="evenodd" clip-rule="evenodd" d="M4 18h18V4h-2l-7 7H8l-4 4v3z" fill="url(#chart-line-g_svg__paint0_linear)"></path>
                <path d="M4 4H2v16h20v-2H4V4z" fill="#76808F"></path>
                <defs>
                  <linearGradient id="chart-line-g_svg__paint0_linear" x1="13" y1="18" x2="13" y2="4" gradientUnits="userSpaceOnUse">
                    <stop stop-color="#F0B90B"></stop>
                    <stop offset="1" stop-color="#F8D33A"></stop>
                  </linearGradient>
                </defs>
              </svg>
            </div>
          </div>
        </div>
        <div class="desc-price-div">
          <div class="spot-price-text-mob">Spot Price</div>
          <div class="spot-price-div-mob">
            <div  class="lot-price">19,164.94</div>
          </div>
        </div>
      </div>
    </div>
    <div class="Available-Coins-inner">
      <button type="button" class="btn-yellow border-0 shadow-none">
      Create a plan
      </button>
    </div>
  </div>
  <div class="investment-table-mob">
    <div class="investment-table-inner">
      <div class="lot-name-inner">
        <img class="investment-table-img-mob" src="image/admin_mgs_image_upload/20201110/3a8c9fe6-2a76-4ace-aa07-415d994de6f0.png">
        <div  class="lot-name-text">ETH</div>
      </div>
      <div class="investment-table-desc">
        <div class="investment-table-desc-text">
          <div class="spot-price-text-mob">
            <div class="Available-Coins-inner">Historical ROI <div class="d-inline-block">
           
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="svg-info">
                  <path fill-rule="evenodd" clip-rule="evenodd" d="M12 4c4.411 0 8 3.589 8 8s-3.589 8-8 8-8-3.589-8-8 3.589-8 8-8zm0-2C6.477 2 2 6.477 2 12s4.477 10 10 10 10-4.477 10-10S17.523 2 12 2zm.997 9.004h-2.009v6h2.009v-6zm-2.009-4h2.009v2.009h-2.009v-2.01z" fill="currentColor"></path>
                </svg>
              </div>
            </div>
          </div>
          <div class="spot-price-div-mob">
            <div class="spot-price-div-mob-inner">
              <div  class="text-profit-mob">168.24%</div>
              <div class="duration-box-mob-main">
                <div  class="duration-box-mob-active">3YR</div>
                <div  class="duration-box-mob">1YR</div>
                <div  class="duration-box-mob">6M</div>
                <div  class="duration-box-mob">3M</div>
                <div  class="duration-box-mob">7D</div>
              </div>
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="svg-data-chart-mob">
                <path fill-rule="evenodd" clip-rule="evenodd" d="M4 18h18V4h-2l-7 7H8l-4 4v3z" fill="url(#chart-line-g_svg__paint0_linear)"></path>
                <path d="M4 4H2v16h20v-2H4V4z" fill="#76808F"></path>
                <defs>
                  <linearGradient id="chart-line-g_svg__paint0_linear" x1="13" y1="18" x2="13" y2="4" gradientUnits="userSpaceOnUse">
                    <stop stop-color="#F0B90B"></stop>
                    <stop offset="1" stop-color="#F8D33A"></stop>
                  </linearGradient>
                </defs>
              </svg>
            </div>
          </div>
        </div>
        <div class="desc-price-div">
          <div class="spot-price-text-mob">Spot Price</div>
          <div class="spot-price-div-mob">
            <div  class="lot-price">1,288.80</div>
          </div>
        </div>
      </div>
    </div>
    <div class="Available-Coins-inner">
      <button type="button" class="btn-yellow border-0 shadow-none">
      Create a plan
      </button>
    </div>
  </div>
  <div class="investment-table-mob">
    <div class="investment-table-inner">
      <div class="lot-name-inner">
        <img class="investment-table-img-mob" src="images/20200724/8f181a53-bacb-4a3a-a66a-e586a7b7b61a.png">
        <div  class="lot-name-text">RUNE</div>
      </div>
      <div class="investment-table-desc">
        <div class="investment-table-desc-text">
          <div class="spot-price-text-mob">
            <div class="Available-Coins-inner">Historical ROI <div class="d-inline-block">
             
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="svg-info">
                  <path fill-rule="evenodd" clip-rule="evenodd" d="M12 4c4.411 0 8 3.589 8 8s-3.589 8-8 8-8-3.589-8-8 3.589-8 8-8zm0-2C6.477 2 2 6.477 2 12s4.477 10 10 10 10-4.477 10-10S17.523 2 12 2zm.997 9.004h-2.009v6h2.009v-6zm-2.009-4h2.009v2.009h-2.009v-2.01z" fill="currentColor"></path>
                </svg>
              </div>
            </div>
          </div>
          <div class="spot-price-div-mob">
            <div class="spot-price-div-mob-inner">
              <div  class="text-loss-mob">-33.86%</div>
              <div class="duration-box-mob-main">
                <div  class="duration-box-mob-active">3YR</div>
                <div  class="duration-box-mob">1YR</div>
                <div  class="duration-box-mob">6M</div>
                <div  class="duration-box-mob">3M</div>
                <div  class="duration-box-mob">7D</div>
              </div>
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="svg-data-chart-mob">
                <path fill-rule="evenodd" clip-rule="evenodd" d="M4 18h18V4h-2l-7 7H8l-4 4v3z" fill="url(#chart-line-g_svg__paint0_linear)"></path>
                <path d="M4 4H2v16h20v-2H4V4z" fill="#76808F"></path>
                <defs>
                  <linearGradient id="chart-line-g_svg__paint0_linear" x1="13" y1="18" x2="13" y2="4" gradientUnits="userSpaceOnUse">
                    <stop stop-color="#F0B90B"></stop>
                    <stop offset="1" stop-color="#F8D33A"></stop>
                  </linearGradient>
                </defs>
              </svg>
            </div>
          </div>
        </div>
        <div class="desc-price-div">
          <div class="spot-price-text-mob">Spot Price</div>
          <div class="spot-price-div-mob">
            <div  class="lot-price">1.47</div>
          </div>
        </div>
      </div>
    </div>
    <div class="Available-Coins-inner">
      <button type="button" class="btn-yellow border-0 shadow-none">
      Create a plan
      </button>
    </div>
  </div>
  <div class="investment-table-mob">
    <div class="investment-table-inner">
      <div class="lot-name-inner">
        <img class="investment-table-img-mob" src="images/20200410/6caae4f1-f4c6-4486-b05b-442dd559f51f.jpg">
        <div  class="lot-name-text">SOL</div>
      </div>
      <div class="investment-table-desc">
        <div class="investment-table-desc-text">
          <div class="spot-price-text-mob">
            <div class="Available-Coins-inner">Historical ROI <div class="d-inline-block">
           
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="svg-info">
                  <path fill-rule="evenodd" clip-rule="evenodd" d="M12 4c4.411 0 8 3.589 8 8s-3.589 8-8 8-8-3.589-8-8 3.589-8 8-8zm0-2C6.477 2 2 6.477 2 12s4.477 10 10 10 10-4.477 10-10S17.523 2 12 2zm.997 9.004h-2.009v6h2.009v-6zm-2.009-4h2.009v2.009h-2.009v-2.01z" fill="currentColor"></path>
                </svg>
              </div>
            </div>
          </div>
          <div class="spot-price-div-mob">
            <div class="spot-price-div-mob-inner">
              <div  class="text-profit-mob">246.97%</div>
              <div class="duration-box-mob-main">
                <div  class="duration-box-mob-active">3YR</div>
                <div  class="duration-box-mob">1YR</div>
                <div  class="duration-box-mob">6M</div>
                <div  class="duration-box-mob">3M</div>
                <div  class="duration-box-mob">7D</div>
              </div>
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="svg-data-chart-mob">
                <path fill-rule="evenodd" clip-rule="evenodd" d="M4 18h18V4h-2l-7 7H8l-4 4v3z" fill="url(#chart-line-g_svg__paint0_linear)"></path>
                <path d="M4 4H2v16h20v-2H4V4z" fill="#76808F"></path>
                <defs>
                  <linearGradient id="chart-line-g_svg__paint0_linear" x1="13" y1="18" x2="13" y2="4" gradientUnits="userSpaceOnUse">
                    <stop stop-color="#F0B90B"></stop>
                    <stop offset="1" stop-color="#F8D33A"></stop>
                  </linearGradient>
                </defs>
              </svg>
            </div>
          </div>
        </div>
        <div class="desc-price-div">
          <div class="spot-price-text-mob">Spot Price</div>
          <div class="spot-price-div-mob">
            <div  class="lot-price">29.95</div>
          </div>
        </div>
      </div>
    </div>
    <div class="Available-Coins-inner">
      <button type="button" class="btn-yellow border-0 shadow-none">
      Create a plan
      </button>
    </div>
  </div>
</div>
      <div  class="view-more-div">View More Auto-Invest Products 
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="svg-chevron-down">
          <path d="M13.5 12L7 18.6 8.4 20l8-8-8-8L7 5.4l6.5 6.6z" fill="currentColor"></path>
        </svg>
      </div>
    </div>

</section>
    
			            </div>
		            </div>
		                
		      </div>
          </div>
        </div>
    </section>
    
    
    
    <section class="sign-up p-5 bg-light-blue">
   <div class="container">
      <div class="row">
         <div class="col-md-12 col-sm-12 col-xs-12 text-center">
            <h3 class="app-heading">  Newsletter
            </h3>
            <span>You deserve easy access to cryptocurrencies Join our newsletter &amp; stay up-to-date with WealthMark</span>
         </div>
      </div>
      <div class="row">
         <div class="col-md-12 col-lg-12 col-sm-12 pt-4 ">
            <div class="subscribe">
               <form>
                  <div class=""> 
                     <input type="email" name="email" id="email" placeholder="Enter your email address" autocomplete="off">
                  </div>
                  &nbsp;   &nbsp;
                  <div class="">
                     <a href="javascript:void(0)" class="btn-yellow"> <span> <i class="bi-arrow-right"> </i> </span><span> Subscribe </span></a>
                  </div>
               </form>
            </div>
         </div>
      </div>
   </div>
</section>
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
<section class="wm-pay-accordian-section">
    <div class="container">
        <div class="outlet-main-div">
                 <div class="wm-outlet-div">
                           
                            <div class="sec-title text-center mb-2">
                           <h2 class="heading-h2">FAQs</h2>
                            </div>
                           
                        </div>
                         <div class="wm-outlet-div text-right justify-content-end">
                           
                            <a href="#" class="learn-more btn-6">
                           <span>Learn More </span>
                           <span><i class="bi bi-chevron-right"></i></span>
                        </a>
                           
                        </div>
                        </div>
    </div>
    <div class="container">
  <div class="accordion" id="accordionExample">
  <div class="card">
    <div class="card-head" id="headingOne">
      <h2 class="mb-0 collapsed" data-toggle="collapse" data-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
     What is DeFi Staking?
      </h2>
    </div>

    <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
      <div class="card-body">
      <div class="text">  DeFi (Decentralized Finance) is a way of providing financial services to users through smart contracts. Existing DeFi projects aim to provide higher annualized earnings for specific currencies.</div>
      </div>
    </div>
  </div>
  <div class="card">
    <div class="card-head" id="headingTwo">
      <h2 class="mb-0 collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
  About Wealthmark DeFi Staking
      </h2>
    </div>
    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
      <div class="card-body">
       <div class="text">There's a relatively high threshold for users of DeFi products. Wealthmark DeFi Staking acts on behalf of users to participate in certain DeFi products, obtains and distributes realized earnings, and helps users to participate in DeFi products with a single click.</div>
      
      </div>
    </div>
  </div>
  <div class="card">
    <div class="card-head" id="headingThree">
      <h2 class="mb-0 collapsed" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
     What are the advantages of DeFi Staking?
      </h2>
    </div>
    <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
      <div class="card-body">
        <div class="text">1. Easy to use: You don't need to manage private keys, acquire resources, make trades, or perform other complicated tasks to participate in DeFi Staking. Wealthmark's one-stop service allows users to obtain generous online rewards without keeping an on-chain wallet. 2. No gas fee: Wealthmark Staking deposits users’ funds into smart contracts on users’ behalf, saving users on-chain gas fees.</div>
      </div>
    </div>
  </div>
  
  
  <div class="card">
    <div class="card-head" id="headingFour">
      <h2 class="mb-0 collapsed" data-toggle="collapse" data-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
   After I participate in DeFi Staking, how is the earnings cycle calculated?
      </h2>
    </div>
    <div id="collapseFour" class="collapse" aria-labelledby="headingFour" data-parent="#accordionExample">
      <div class="card-body">
  <div class="text">Once funds are successfully allocated to DeFi Staking, earnings are calculated beginning at 00:00 (UTC) the following day. The minimum earnings calculation period is one day; earnings for a period of less than one day will not be included in the earnings distribution.</div>     
      </div>
    </div>
  </div>
  
  
</div>
</div>
</section>



    
  @include('template.country_language')
    @include('template.web_footer') 
    	<script type="text/javascript">
			$(document).ready(function() {
				var country = ["Search Coin", "Bangladesh", "Denmark", "Hong Kong", "Indonesia", "Netherlands", "New Zealand", "South Africa"];
				$("#country").select2({
				  data: country
				});
			});
		</script>
		
		<script>
		    var divs = [ "Popular_Coins" , "BfB" , "BNB_Chain_Zone" , "Polka_Zone" , "Solana_Zone"];
var visibleDivId = null;
function toggleVisibility(divId) {
  if(visibleDivId === divId) {
   
  } else {
    visibleDivId = divId;
  }
  hideNonVisibleDivs();
}
function hideNonVisibleDivs() {
    
  var i, divId, div;
  for(i = 0; i < divs.length; i++) {
    divId = divs[i];
    div = document.getElementById(divId);
    if(visibleDivId === divId) {
      div.style.display = "block";
    } else {
      div.style.display = "none";
    }
  }
}
		</script>
		
         <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/js/bootstrap.min.js"></script> 
        <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.1/css/select2.min.css" rel="stylesheet" />
		<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.1/js/select2.min.js"></script>
  
    </body>
</html>