  <!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
   <head>
      <meta charset="utf-8">
      <meta content="width=device-width, initial-scale=1.0" name="viewport">
      <title>Wealth Mark | Create Entity Account</title>
  @include('template.web_css')
      
  
 <style>
 
 .auto-invesment{
 background:#263674;
 }
 </style>
  
  
   </head>
   
 <body class="bg-white">
     
     @include('template.mobile_menu')
        @include('template.web_menu')
    
    
        
   <section  class="breadcrumbs shadow-sm auto-invesment pb-0">
          <div class="container-fluid">
              <div class="row justify-content-center">
                 <div class="col-lg-4  d-flex flex-column justify-content-center pt-lg-0 order-2 order-lg-1 align-items-center" data-aos="fade-up" data-aos-delay="200">
                 <h3 class="top-heading">Auto-Invest</h3>
                 <p class="top-p">Accumulate Crypto on Autopilot.</p>
               
                 </div>
                 <div class="d-none d-md-block col-lg-5 offset-lg-1 order-1 order-lg-2 hero-img mt-3 mb-5" data-aos="zoom-in" data-aos-delay="200">
                   
                   <div class="asset-overview login-box-main">
                          <div class="login-box-bg">
                            <div class="login-box">
                              <img src="{{ asset('public/assets/img/account.png') }}" class="login-box-img">
                              <div class="login-box-txt">Log in to view holding details</div>
                              <button type="button" class="btn btn-yellow">Log In</button>
                            </div>
                          </div>
                        </div>
                 </div>
              </div>
            </div>
      </section>
    
 
    
    
    <section class="Auto-Invest-Plan">
        <div class="container">
            <div class="row">
                <div class="col-md-12 d-flex">
                    <div class="Auto-Invest-div-left">
                          <div  class="Auto-Invest-div-title">Create your own Auto-Invest Plan</div>
                          <div  class="Auto-Invest-div-subtitle">Regularly invest in cryptocurrency with a pre-determined amount and accumulate your crypto holdings</div>
                          <div class="Auto-Invest-div-inner">
                            <div class="Auto-Invest-div-inner-number">1</div>
                            <div class="Auto-Invest-div-inner-text-div">
                              <div class="Auto-Invest-yellow-line"></div>
                              <div class="Auto-Invest-title-sm">Start creating your Auto-Invest Plan</div>
                              <div class="Auto-Invest-subtitle-sm">Pick a coin you want to invest in, decide your investment amount and schedule a recurring plan.</div>
                            </div>
                            <div class="Auto-Invest-div-inner-number">2</div>
                            <div class="Auto-Invest-div-inner-text-div-2">
                              <div class="Auto-Invest-yellow-line"></div>
                              <div class="Auto-Invest-title-sm">Enjoy the Auto-Invest plan while earning passive income</div>
                              <div class="Auto-Invest-subtitle-sm">Once invested, you can receive daily earnings from Simple Earn and redeem your funds any time you wish.</div>
                            </div>
                            <img src="{{ asset('public/assets/img/circle-plus.svg') }}" class="Auto-Invest-sideimg">
                          </div>
                        </div>
                       <img src="{{ asset('public/assets/img/auto-invest-banner.svg') }}" class="Auto-Invest-Plan-img"> 
                </div>
            </div>
        </div>
        
    </section>
    
    
    
    <section class=" bg-white investment-table">
  <div class="container">
    <div class="investment-top">
      <div class="investment-top-left">
        <div  class="investment-top-title">Auto-Invest</div>
        <div  class="investment-top-subtitle">#Start growing your assets on autopilot</div>
      </div>
      <div class="search-box-div">
        <div class=" search-box-inner">
          <div class="WM-input-prefix">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="svg-search">
              <path fill-rule="evenodd" clip-rule="evenodd" d="M11 6a5 5 0 110 10 5 5 0 010-10zm0-3a8 8 0 017.021 11.838l3.07 3.07-1.59 1.591-1.591 1.591-3.07-3.07A8 8 0 1111 3z" fill="currentColor"></path>
            </svg>
          </div>
          <input type="input" value="" placeholder="Search Coin" class="search-box-input">
        </div>
      </div>
    </div>
    <div class="investment-desc-div">
      <div class="investment-Portfolio">
        <div class="Portfolio-inner">
          <div class="Portfolio-inner-left">
            <img src="{{ asset('public/assets/img/chart-pie-g.svg') }}" class="Portfolio-inner-icon">
            <div class="Portfolio-inner-content-box">
              <div class="Portfolio-inner-title">Portfolio Auto-Invest</div>
              <div class="Portfolio-inner-subtitle">Diversify your crypto holdings and increase coverage.</div>
            </div>
          </div>
          <div class="Portfolio-inner-right">
            <div class="Portfolio-Available-Coins">
              <div class="Available-Coins-inner">
                <div class="Available-Coins-img-box">
                  <img class="coin-list-img" src="{{ asset('public/assets/img/133e0469-3a96-4e3a-9c42-b4c5a4f8def8.png') }}">
                </div>
                <div class="Available-Coins-img-box">
                  <img class="coin-list-img" src="{{ asset('public/assets/img/6caae4f1-f4c6-4486-b05b-442dd559f51f.jpg') }}">
                </div>
                <div class="Available-Coins-img-box">
                  <img class="coin-list-img" src="{{ asset('public/assets/img/133e0469-3a96-4e3a-9c42-b4c5a4f8def8.png') }}">
                </div>
                <div class="Available-Coins-img-box">
                  <img class="coin-list-img" src="{{ asset('public/assets/img/8f181a53-bacb-4a3a-a66a-e586a7b7b61a.png') }}">
                </div>
               
              </div>
              <div class="Available-Coins-div">
                <div class="Available-coins">63 Available Coins</div>
                <div class="Coins-bottom-text-2">63
                  +
                </div>
              </div>
            </div>
            <div class="d-flex">
              <button type="button" class="btn-yellow border-0 shadow-none">
              Create a plan
              </button>
            </div>
          </div>
        </div>
      </div>
      <div class="lot-heading-div">
        <div class="lot-name">Product</div>
        <div class="lot-status">Historical ROI <div class="d-inline-block">
           
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="svg-info">
              <path fill-rule="evenodd" clip-rule="evenodd" d="M12 4c4.411 0 8 3.589 8 8s-3.589 8-8 8-8-3.589-8-8 3.589-8 8-8zm0-2C6.477 2 2 6.477 2 12s4.477 10 10 10 10-4.477 10-10S17.523 2 12 2zm.997 9.004h-2.009v6h2.009v-6zm-2.009-4h2.009v2.009h-2.009v-2.01z" fill="currentColor"></path>
            </svg>
          </div>
        </div>
        <div class="lot-price-heading">Spot Price</div>
        <div class="flex-width-box"></div>
      </div>
      <div class="lot-status-row">
        <div class="lot-name">
          <div class="lot-name-inner">
            <img class="coin-list-img" src="{{ asset('public/assets/img/6caae4f1-f4c6-4486-b05b-442dd559f51f.jpg') }}">
            <div  class="lot-name-text">WM</div>
          </div>
        </div>
        <div class="lot-investment-div">
          <div  class="text-profit">541.97%</div>
          <div class="lot-duration-div">
            
            <div  class="box-border-yellow">3YR</div>
            <div  class="box-border-gray">1YR</div>
            <div  class="box-border-gray">6M</div>
            <div  class="box-border-gray">3M</div>
            <div  class="box-border-gray">7D</div>
          </div>
            <div class="mt-24">
            <div class="d-inline-block">
             
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="svg-data-chart">
                <path fill-rule="evenodd" clip-rule="evenodd" d="M4 18h18V4h-2l-7 7H8l-4 4v3z" fill="url(#chart-line-g_svg__paint0_linear)"></path>
                <path d="M4 4H2v16h20v-2H4V4z" fill="#76808F"></path>
                <defs>
                  <linearGradient id="chart-line-g_svg__paint0_linear" x1="13" y1="18" x2="13" y2="4" gradientUnits="userSpaceOnUse">
                    <stop stop-color="#F0B90B"></stop>
                    <stop offset="1" stop-color="#F8D33A"></stop>
                  </linearGradient>
                </defs>
              </svg>
            </div>
          </div>
        </div>
        <div class="lot-price-heading">
          <div  class="lot-price">270.20</div>
        </div>
        <div class="flex-width-box">
          <button type="button" class="btn-yellow border-0 shadow-none">
          Create a plan
          </button>
        </div>
      </div>
     
     
     
      <div class="lot-status-row">
        <div class="lot-name">
          <div class="lot-name-inner">
            <img class="coin-list-img" src="{{ asset('public/assets/img/6caae4f1-f4c6-4486-b05b-442dd559f51f.jpg') }}">
            <div  class="lot-name-text">APE</div>
          </div>
        </div>
        <div class="lot-investment-div">
          <div  class="text-loss">-27.66%</div>
          <div class="lot-duration-div">
           
            <div  class="box-border-yellow">3YR</div>
            <div  class="box-border-gray">1YR</div>
            <div  class="box-border-gray">6M</div>
            <div  class="box-border-gray">3M</div>
            <div  class="box-border-gray">7D</div>
          </div>
          <div class="mt-24">
            <div class="d-inline-block">
             
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="svg-data-chart">
                <path fill-rule="evenodd" clip-rule="evenodd" d="M4 18h18V4h-2l-7 7H8l-4 4v3z" fill="url(#chart-line-g_svg__paint0_linear)"></path>
                <path d="M4 4H2v16h20v-2H4V4z" fill="#76808F"></path>
                <defs>
                  <linearGradient id="chart-line-g_svg__paint0_linear" x1="13" y1="18" x2="13" y2="4" gradientUnits="userSpaceOnUse">
                    <stop stop-color="#F0B90B"></stop>
                    <stop offset="1" stop-color="#F8D33A"></stop>
                  </linearGradient>
                </defs>
              </svg>
            </div>
          </div>
        </div>
        <div class="lot-price-heading">
          <div  class="lot-price">4.52</div>
        </div>
        <div class="flex-width-box">
          <button type="button" class="btn-yellow border-0 shadow-none">
          Create a plan
          </button>
        </div>
      </div>
      <div class="lot-status-row">
        <div class="lot-name">
          <div class="lot-name-inner">
            <img class="coin-list-img" src="{{ asset('public/assets/img/6caae4f1-f4c6-4486-b05b-442dd559f51f.jpg') }}">
            <div  class="lot-name-text">WM</div>
          </div>
        </div>
        <div class="lot-investment-div">
          <div  class="text-profit">541.97%</div>
          <div class="lot-duration-div">
            
            <div  class="box-border-yellow">3YR</div>
            <div  class="box-border-gray">1YR</div>
            <div  class="box-border-gray">6M</div>
            <div  class="box-border-gray">3M</div>
            <div  class="box-border-gray">7D</div>
          </div>
            <div class="mt-24">
            <div class="d-inline-block">
             
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="svg-data-chart">
                <path fill-rule="evenodd" clip-rule="evenodd" d="M4 18h18V4h-2l-7 7H8l-4 4v3z" fill="url(#chart-line-g_svg__paint0_linear)"></path>
                <path d="M4 4H2v16h20v-2H4V4z" fill="#76808F"></path>
                <defs>
                  <linearGradient id="chart-line-g_svg__paint0_linear" x1="13" y1="18" x2="13" y2="4" gradientUnits="userSpaceOnUse">
                    <stop stop-color="#F0B90B"></stop>
                    <stop offset="1" stop-color="#F8D33A"></stop>
                  </linearGradient>
                </defs>
              </svg>
            </div>
          </div>
        </div>
        <div class="lot-price-heading">
          <div  class="lot-price">270.20</div>
        </div>
        <div class="flex-width-box">
          <button type="button" class="btn-yellow border-0 shadow-none">
          Create a plan
          </button>
        </div>
      </div>
     
     
     
      <div class="lot-status-row">
        <div class="lot-name">
          <div class="lot-name-inner">
            <img class="coin-list-img" src="{{ asset('public/assets/img/6caae4f1-f4c6-4486-b05b-442dd559f51f.jpg') }}">
            <div  class="lot-name-text">APE</div>
          </div>
        </div>
        <div class="lot-investment-div">
          <div  class="text-loss">-27.66%</div>
          <div class="lot-duration-div">
           
            <div  class="box-border-yellow">3YR</div>
            <div  class="box-border-gray">1YR</div>
            <div  class="box-border-gray">6M</div>
            <div  class="box-border-gray">3M</div>
            <div  class="box-border-gray">7D</div>
          </div>
          <div class="mt-24">
            <div class="d-inline-block">
             
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="svg-data-chart">
                <path fill-rule="evenodd" clip-rule="evenodd" d="M4 18h18V4h-2l-7 7H8l-4 4v3z" fill="url(#chart-line-g_svg__paint0_linear)"></path>
                <path d="M4 4H2v16h20v-2H4V4z" fill="#76808F"></path>
                <defs>
                  <linearGradient id="chart-line-g_svg__paint0_linear" x1="13" y1="18" x2="13" y2="4" gradientUnits="userSpaceOnUse">
                    <stop stop-color="#F0B90B"></stop>
                    <stop offset="1" stop-color="#F8D33A"></stop>
                  </linearGradient>
                </defs>
              </svg>
            </div>
          </div>
        </div>
        <div class="lot-price-heading">
          <div  class="lot-price">4.52</div>
        </div>
        <div class="flex-width-box">
          <button type="button" class="btn-yellow border-0 shadow-none">
          Create a plan
          </button>
        </div>
      </div><div class="lot-status-row">
        <div class="lot-name">
          <div class="lot-name-inner">
            <img class="coin-list-img" src="{{ asset('public/assets/img/6caae4f1-f4c6-4486-b05b-442dd559f51f.jpg') }}">
            <div  class="lot-name-text">WM</div>
          </div>
        </div>
        <div class="lot-investment-div">
          <div  class="text-profit">541.97%</div>
          <div class="lot-duration-div">
            
            <div  class="box-border-yellow">3YR</div>
            <div  class="box-border-gray">1YR</div>
            <div  class="box-border-gray">6M</div>
            <div  class="box-border-gray">3M</div>
            <div  class="box-border-gray">7D</div>
          </div>
            <div class="mt-24">
            <div class="d-inline-block">
             
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="svg-data-chart">
                <path fill-rule="evenodd" clip-rule="evenodd" d="M4 18h18V4h-2l-7 7H8l-4 4v3z" fill="url(#chart-line-g_svg__paint0_linear)"></path>
                <path d="M4 4H2v16h20v-2H4V4z" fill="#76808F"></path>
                <defs>
                  <linearGradient id="chart-line-g_svg__paint0_linear" x1="13" y1="18" x2="13" y2="4" gradientUnits="userSpaceOnUse">
                    <stop stop-color="#F0B90B"></stop>
                    <stop offset="1" stop-color="#F8D33A"></stop>
                  </linearGradient>
                </defs>
              </svg>
            </div>
          </div>
        </div>
        <div class="lot-price-heading">
          <div  class="lot-price">270.20</div>
        </div>
        <div class="flex-width-box">
          <button type="button" class="btn-yellow border-0 shadow-none">
          Create a plan
          </button>
        </div>
      </div>
     
     
     
      <div class="lot-status-row">
        <div class="lot-name">
          <div class="lot-name-inner">
            <img class="coin-list-img" src="{{ asset('public/assets/img/6caae4f1-f4c6-4486-b05b-442dd559f51f.jpg') }}">
            <div  class="lot-name-text">APE</div>
          </div>
        </div>
        <div class="lot-investment-div">
          <div  class="text-loss">-27.66%</div>
          <div class="lot-duration-div">
           
            <div  class="box-border-yellow">3YR</div>
            <div  class="box-border-gray">1YR</div>
            <div  class="box-border-gray">6M</div>
            <div  class="box-border-gray">3M</div>
            <div  class="box-border-gray">7D</div>
          </div>
          <div class="mt-24">
            <div class="d-inline-block">
             
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="svg-data-chart">
                <path fill-rule="evenodd" clip-rule="evenodd" d="M4 18h18V4h-2l-7 7H8l-4 4v3z" fill="url(#chart-line-g_svg__paint0_linear)"></path>
                <path d="M4 4H2v16h20v-2H4V4z" fill="#76808F"></path>
                <defs>
                  <linearGradient id="chart-line-g_svg__paint0_linear" x1="13" y1="18" x2="13" y2="4" gradientUnits="userSpaceOnUse">
                    <stop stop-color="#F0B90B"></stop>
                    <stop offset="1" stop-color="#F8D33A"></stop>
                  </linearGradient>
                </defs>
              </svg>
            </div>
          </div>
        </div>
        <div class="lot-price-heading">
          <div  class="lot-price">4.52</div>
        </div>
        <div class="flex-width-box">
          <button type="button" class="btn-yellow border-0 shadow-none">
          Create a plan
          </button>
        </div>
      </div><div class="lot-status-row">
        <div class="lot-name">
          <div class="lot-name-inner">
            <img class="coin-list-img" src="{{ asset('public/assets/img/6caae4f1-f4c6-4486-b05b-442dd559f51f.jpg') }}">
            <div  class="lot-name-text">WM</div>
          </div>
        </div>
        <div class="lot-investment-div">
          <div  class="text-profit">541.97%</div>
          <div class="lot-duration-div">
            
            <div  class="box-border-yellow">3YR</div>
            <div  class="box-border-gray">1YR</div>
            <div  class="box-border-gray">6M</div>
            <div  class="box-border-gray">3M</div>
            <div  class="box-border-gray">7D</div>
          </div>
            <div class="mt-24">
            <div class="d-inline-block">
             
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="svg-data-chart">
                <path fill-rule="evenodd" clip-rule="evenodd" d="M4 18h18V4h-2l-7 7H8l-4 4v3z" fill="url(#chart-line-g_svg__paint0_linear)"></path>
                <path d="M4 4H2v16h20v-2H4V4z" fill="#76808F"></path>
                <defs>
                  <linearGradient id="chart-line-g_svg__paint0_linear" x1="13" y1="18" x2="13" y2="4" gradientUnits="userSpaceOnUse">
                    <stop stop-color="#F0B90B"></stop>
                    <stop offset="1" stop-color="#F8D33A"></stop>
                  </linearGradient>
                </defs>
              </svg>
            </div>
          </div>
        </div>
        <div class="lot-price-heading">
          <div  class="lot-price">270.20</div>
        </div>
        <div class="flex-width-box">
          <button type="button" class="btn-yellow border-0 shadow-none">
          Create a plan
          </button>
        </div>
      </div>
     
     
     
      <div class="lot-status-row">
        <div class="lot-name">
          <div class="lot-name-inner">
            <img class="coin-list-img" src="{{ asset('public/assets/img/6caae4f1-f4c6-4486-b05b-442dd559f51f.jpg') }}">
            <div  class="lot-name-text">APE</div>
          </div>
        </div>
        <div class="lot-investment-div">
          <div  class="text-loss">-27.66%</div>
          <div class="lot-duration-div">
           
            <div  class="box-border-yellow">3YR</div>
            <div  class="box-border-gray">1YR</div>
            <div  class="box-border-gray">6M</div>
            <div  class="box-border-gray">3M</div>
            <div  class="box-border-gray">7D</div>
          </div>
          <div class="mt-24">
            <div class="d-inline-block">
             
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="svg-data-chart">
                <path fill-rule="evenodd" clip-rule="evenodd" d="M4 18h18V4h-2l-7 7H8l-4 4v3z" fill="url(#chart-line-g_svg__paint0_linear)"></path>
                <path d="M4 4H2v16h20v-2H4V4z" fill="#76808F"></path>
                <defs>
                  <linearGradient id="chart-line-g_svg__paint0_linear" x1="13" y1="18" x2="13" y2="4" gradientUnits="userSpaceOnUse">
                    <stop stop-color="#F0B90B"></stop>
                    <stop offset="1" stop-color="#F8D33A"></stop>
                  </linearGradient>
                </defs>
              </svg>
            </div>
          </div>
        </div>
        <div class="lot-price-heading">
          <div  class="lot-price">4.52</div>
        </div>
        <div class="flex-width-box">
          <button type="button" class="btn-yellow border-0 shadow-none">
          Create a plan
          </button>
        </div>
      </div><div class="lot-status-row">
        <div class="lot-name">
          <div class="lot-name-inner">
            <img class="coin-list-img" src="{{ asset('public/assets/img/6caae4f1-f4c6-4486-b05b-442dd559f51f.jpg') }}">
            <div  class="lot-name-text">WM</div>
          </div>
        </div>
        <div class="lot-investment-div">
          <div  class="text-profit">541.97%</div>
          <div class="lot-duration-div">
            
            <div  class="box-border-yellow">3YR</div>
            <div  class="box-border-gray">1YR</div>
            <div  class="box-border-gray">6M</div>
            <div  class="box-border-gray">3M</div>
            <div  class="box-border-gray">7D</div>
          </div>
            <div class="mt-24">
            <div class="d-inline-block">
             
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="svg-data-chart">
                <path fill-rule="evenodd" clip-rule="evenodd" d="M4 18h18V4h-2l-7 7H8l-4 4v3z" fill="url(#chart-line-g_svg__paint0_linear)"></path>
                <path d="M4 4H2v16h20v-2H4V4z" fill="#76808F"></path>
                <defs>
                  <linearGradient id="chart-line-g_svg__paint0_linear" x1="13" y1="18" x2="13" y2="4" gradientUnits="userSpaceOnUse">
                    <stop stop-color="#F0B90B"></stop>
                    <stop offset="1" stop-color="#F8D33A"></stop>
                  </linearGradient>
                </defs>
              </svg>
            </div>
          </div>
        </div>
        <div class="lot-price-heading">
          <div  class="lot-price">270.20</div>
        </div>
        <div class="flex-width-box">
          <button type="button" class="btn-yellow border-0 shadow-none">
          Create a plan
          </button>
        </div>
      </div>
     
     
     
      <div class="lot-status-row">
        <div class="lot-name">
          <div class="lot-name-inner">
            <img class="coin-list-img" src="{{ asset('public/assets/img/6caae4f1-f4c6-4486-b05b-442dd559f51f.jpg') }}">
            <div  class="lot-name-text">APE</div>
          </div>
        </div>
        <div class="lot-investment-div">
          <div  class="text-loss">-27.66%</div>
          <div class="lot-duration-div">
           
            <div  class="box-border-yellow">3YR</div>
            <div  class="box-border-gray">1YR</div>
            <div  class="box-border-gray">6M</div>
            <div  class="box-border-gray">3M</div>
            <div  class="box-border-gray">7D</div>
          </div>
          <div class="mt-24">
            <div class="d-inline-block">
             
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="svg-data-chart">
                <path fill-rule="evenodd" clip-rule="evenodd" d="M4 18h18V4h-2l-7 7H8l-4 4v3z" fill="url(#chart-line-g_svg__paint0_linear)"></path>
                <path d="M4 4H2v16h20v-2H4V4z" fill="#76808F"></path>
                <defs>
                  <linearGradient id="chart-line-g_svg__paint0_linear" x1="13" y1="18" x2="13" y2="4" gradientUnits="userSpaceOnUse">
                    <stop stop-color="#F0B90B"></stop>
                    <stop offset="1" stop-color="#F8D33A"></stop>
                  </linearGradient>
                </defs>
              </svg>
            </div>
          </div>
        </div>
        <div class="lot-price-heading">
          <div  class="lot-price">4.52</div>
        </div>
        <div class="flex-width-box">
          <button type="button" class="btn-yellow border-0 shadow-none">
          Create a plan
          </button>
        </div>
      </div>
      
      <div class="css-vurnku">
  <div class="investment-table-mob">
    <div class="investment-table-inner">
      <div class="lot-name-inner">
        <img class="investment-table-img-mob" src="image/admin_mgs_image_upload/20220218/94863af2-c980-42cf-a139-7b9f462a36c2.png">
        <div  class="lot-name-text">WM</div>
      </div>
      <div class="investment-table-desc">
        <div class="investment-table-desc-text">
          <div class="spot-price-text-mob">
            <div class="Available-Coins-inner">Historical ROI <div class="d-inline-block">
              
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="svg-info">
                  <path fill-rule="evenodd" clip-rule="evenodd" d="M12 4c4.411 0 8 3.589 8 8s-3.589 8-8 8-8-3.589-8-8 3.589-8 8-8zm0-2C6.477 2 2 6.477 2 12s4.477 10 10 10 10-4.477 10-10S17.523 2 12 2zm.997 9.004h-2.009v6h2.009v-6zm-2.009-4h2.009v2.009h-2.009v-2.01z" fill="currentColor"></path>
                </svg>
              </div>
            </div>
          </div>
          <div class="spot-price-div-mob">
            <div class="spot-price-div-mob-inner">
              <div  class="text-profit-mob">541.97%</div>
              <div class="duration-box-mob-main">
                <div  class="duration-box-mob-active">3YR</div>
                <div  class="duration-box-mob">1YR</div>
                <div  class="duration-box-mob">6M</div>
                <div  class="duration-box-mob">3M</div>
                <div  class="duration-box-mob">7D</div>
              </div>
             <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="svg-data-chart-mob"><path fill-rule="evenodd" clip-rule="evenodd" d="M4 18h18V4h-2l-7 7H8l-4 4v3z" fill="url(#chart-line-g_svg__paint0_linear)"></path><path d="M4 4H2v16h20v-2H4V4z" fill="#76808F"></path><defs><linearGradient id="chart-line-g_svg__paint0_linear" x1="13" y1="18" x2="13" y2="4" gradientUnits="userSpaceOnUse"><stop stop-color="#F0B90B"></stop><stop offset="1" stop-color="#F8D33A"></stop></linearGradient></defs></svg>
            </div>
          </div>
        </div>
        <div class="desc-price-div">
          <div class="spot-price-text-mob">Spot Price</div>
          <div class="spot-price-div-mob">
            <div  class="lot-price">270.70</div>
          </div>
        </div>
      </div>
    </div>
    <div class="Available-Coins-inner">
      <button type="button" class="btn-yellow border-0 shadow-none">
      Create a plan
      </button>
    </div>
  </div>
  <div class="investment-table-mob">
    <div class="investment-table-inner">
      <div class="lot-name-inner">
        <img class="investment-table-img-mob" src="image/admin_mgs_image_upload/20201110/87496d50-2408-43e1-ad4c-78b47b448a6a.png">
        <div  class="lot-name-text">BTC</div>
      </div>
      <div class="investment-table-desc">
        <div class="investment-table-desc-text">
          <div class="spot-price-text-mob">
            <div class="Available-Coins-inner">Historical ROI <div class="d-inline-block">
              
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="svg-info">
                  <path fill-rule="evenodd" clip-rule="evenodd" d="M12 4c4.411 0 8 3.589 8 8s-3.589 8-8 8-8-3.589-8-8 3.589-8 8-8zm0-2C6.477 2 2 6.477 2 12s4.477 10 10 10 10-4.477 10-10S17.523 2 12 2zm.997 9.004h-2.009v6h2.009v-6zm-2.009-4h2.009v2.009h-2.009v-2.01z" fill="currentColor"></path>
                </svg>
              </div>
            </div>
          </div>
          <div class="spot-price-div-mob">
            <div class="spot-price-div-mob-inner">
              <div  class="text-profit-mob">13.76%</div>
              <div class="duration-box-mob-main">
                <div  class="duration-box-mob-active">3YR</div>
                <div  class="duration-box-mob">1YR</div>
                <div  class="duration-box-mob">6M</div>
                <div  class="duration-box-mob">3M</div>
                <div  class="duration-box-mob">7D</div>
              </div>
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="svg-data-chart-mob">
                <path fill-rule="evenodd" clip-rule="evenodd" d="M4 18h18V4h-2l-7 7H8l-4 4v3z" fill="url(#chart-line-g_svg__paint0_linear)"></path>
                <path d="M4 4H2v16h20v-2H4V4z" fill="#76808F"></path>
                <defs>
                  <linearGradient id="chart-line-g_svg__paint0_linear" x1="13" y1="18" x2="13" y2="4" gradientUnits="userSpaceOnUse">
                    <stop stop-color="#F0B90B"></stop>
                    <stop offset="1" stop-color="#F8D33A"></stop>
                  </linearGradient>
                </defs>
              </svg>
            </div>
          </div>
        </div>
        <div class="desc-price-div">
          <div class="spot-price-text-mob">Spot Price</div>
          <div class="spot-price-div-mob">
            <div  class="lot-price">19,164.94</div>
          </div>
        </div>
      </div>
    </div>
    <div class="Available-Coins-inner">
      <button type="button" class="btn-yellow border-0 shadow-none">
      Create a plan
      </button>
    </div>
  </div>
  <div class="investment-table-mob">
    <div class="investment-table-inner">
      <div class="lot-name-inner">
        <img class="investment-table-img-mob" src="image/admin_mgs_image_upload/20201110/3a8c9fe6-2a76-4ace-aa07-415d994de6f0.png">
        <div  class="lot-name-text">ETH</div>
      </div>
      <div class="investment-table-desc">
        <div class="investment-table-desc-text">
          <div class="spot-price-text-mob">
            <div class="Available-Coins-inner">Historical ROI <div class="d-inline-block">
           
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="svg-info">
                  <path fill-rule="evenodd" clip-rule="evenodd" d="M12 4c4.411 0 8 3.589 8 8s-3.589 8-8 8-8-3.589-8-8 3.589-8 8-8zm0-2C6.477 2 2 6.477 2 12s4.477 10 10 10 10-4.477 10-10S17.523 2 12 2zm.997 9.004h-2.009v6h2.009v-6zm-2.009-4h2.009v2.009h-2.009v-2.01z" fill="currentColor"></path>
                </svg>
              </div>
            </div>
          </div>
          <div class="spot-price-div-mob">
            <div class="spot-price-div-mob-inner">
              <div  class="text-profit-mob">168.24%</div>
              <div class="duration-box-mob-main">
                <div  class="duration-box-mob-active">3YR</div>
                <div  class="duration-box-mob">1YR</div>
                <div  class="duration-box-mob">6M</div>
                <div  class="duration-box-mob">3M</div>
                <div  class="duration-box-mob">7D</div>
              </div>
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="svg-data-chart-mob">
                <path fill-rule="evenodd" clip-rule="evenodd" d="M4 18h18V4h-2l-7 7H8l-4 4v3z" fill="url(#chart-line-g_svg__paint0_linear)"></path>
                <path d="M4 4H2v16h20v-2H4V4z" fill="#76808F"></path>
                <defs>
                  <linearGradient id="chart-line-g_svg__paint0_linear" x1="13" y1="18" x2="13" y2="4" gradientUnits="userSpaceOnUse">
                    <stop stop-color="#F0B90B"></stop>
                    <stop offset="1" stop-color="#F8D33A"></stop>
                  </linearGradient>
                </defs>
              </svg>
            </div>
          </div>
        </div>
        <div class="desc-price-div">
          <div class="spot-price-text-mob">Spot Price</div>
          <div class="spot-price-div-mob">
            <div  class="lot-price">1,288.80</div>
          </div>
        </div>
      </div>
    </div>
    <div class="Available-Coins-inner">
      <button type="button" class="btn-yellow border-0 shadow-none">
      Create a plan
      </button>
    </div>
  </div>
  <div class="investment-table-mob">
    <div class="investment-table-inner">
      <div class="lot-name-inner">
        <img class="investment-table-img-mob" src="images/20200724/8f181a53-bacb-4a3a-a66a-e586a7b7b61a.png">
        <div  class="lot-name-text">RUNE</div>
      </div>
      <div class="investment-table-desc">
        <div class="investment-table-desc-text">
          <div class="spot-price-text-mob">
            <div class="Available-Coins-inner">Historical ROI <div class="d-inline-block">
             
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="svg-info">
                  <path fill-rule="evenodd" clip-rule="evenodd" d="M12 4c4.411 0 8 3.589 8 8s-3.589 8-8 8-8-3.589-8-8 3.589-8 8-8zm0-2C6.477 2 2 6.477 2 12s4.477 10 10 10 10-4.477 10-10S17.523 2 12 2zm.997 9.004h-2.009v6h2.009v-6zm-2.009-4h2.009v2.009h-2.009v-2.01z" fill="currentColor"></path>
                </svg>
              </div>
            </div>
          </div>
          <div class="spot-price-div-mob">
            <div class="spot-price-div-mob-inner">
              <div  class="text-loss-mob">-33.86%</div>
              <div class="duration-box-mob-main">
                <div  class="duration-box-mob-active">3YR</div>
                <div  class="duration-box-mob">1YR</div>
                <div  class="duration-box-mob">6M</div>
                <div  class="duration-box-mob">3M</div>
                <div  class="duration-box-mob">7D</div>
              </div>
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="svg-data-chart-mob">
                <path fill-rule="evenodd" clip-rule="evenodd" d="M4 18h18V4h-2l-7 7H8l-4 4v3z" fill="url(#chart-line-g_svg__paint0_linear)"></path>
                <path d="M4 4H2v16h20v-2H4V4z" fill="#76808F"></path>
                <defs>
                  <linearGradient id="chart-line-g_svg__paint0_linear" x1="13" y1="18" x2="13" y2="4" gradientUnits="userSpaceOnUse">
                    <stop stop-color="#F0B90B"></stop>
                    <stop offset="1" stop-color="#F8D33A"></stop>
                  </linearGradient>
                </defs>
              </svg>
            </div>
          </div>
        </div>
        <div class="desc-price-div">
          <div class="spot-price-text-mob">Spot Price</div>
          <div class="spot-price-div-mob">
            <div  class="lot-price">1.47</div>
          </div>
        </div>
      </div>
    </div>
    <div class="Available-Coins-inner">
      <button type="button" class="btn-yellow border-0 shadow-none">
      Create a plan
      </button>
    </div>
  </div>
  <div class="investment-table-mob">
    <div class="investment-table-inner">
      <div class="lot-name-inner">
        <img class="investment-table-img-mob" src="images/20200410/6caae4f1-f4c6-4486-b05b-442dd559f51f.jpg">
        <div  class="lot-name-text">SOL</div>
      </div>
      <div class="investment-table-desc">
        <div class="investment-table-desc-text">
          <div class="spot-price-text-mob">
            <div class="Available-Coins-inner">Historical ROI <div class="d-inline-block">
           
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="svg-info">
                  <path fill-rule="evenodd" clip-rule="evenodd" d="M12 4c4.411 0 8 3.589 8 8s-3.589 8-8 8-8-3.589-8-8 3.589-8 8-8zm0-2C6.477 2 2 6.477 2 12s4.477 10 10 10 10-4.477 10-10S17.523 2 12 2zm.997 9.004h-2.009v6h2.009v-6zm-2.009-4h2.009v2.009h-2.009v-2.01z" fill="currentColor"></path>
                </svg>
              </div>
            </div>
          </div>
          <div class="spot-price-div-mob">
            <div class="spot-price-div-mob-inner">
              <div  class="text-profit-mob">246.97%</div>
              <div class="duration-box-mob-main">
                <div  class="duration-box-mob-active">3YR</div>
                <div  class="duration-box-mob">1YR</div>
                <div  class="duration-box-mob">6M</div>
                <div  class="duration-box-mob">3M</div>
                <div  class="duration-box-mob">7D</div>
              </div>
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="svg-data-chart-mob">
                <path fill-rule="evenodd" clip-rule="evenodd" d="M4 18h18V4h-2l-7 7H8l-4 4v3z" fill="url(#chart-line-g_svg__paint0_linear)"></path>
                <path d="M4 4H2v16h20v-2H4V4z" fill="#76808F"></path>
                <defs>
                  <linearGradient id="chart-line-g_svg__paint0_linear" x1="13" y1="18" x2="13" y2="4" gradientUnits="userSpaceOnUse">
                    <stop stop-color="#F0B90B"></stop>
                    <stop offset="1" stop-color="#F8D33A"></stop>
                  </linearGradient>
                </defs>
              </svg>
            </div>
          </div>
        </div>
        <div class="desc-price-div">
          <div class="spot-price-text-mob">Spot Price</div>
          <div class="spot-price-div-mob">
            <div  class="lot-price">29.95</div>
          </div>
        </div>
      </div>
    </div>
    <div class="Available-Coins-inner">
      <button type="button" class="btn-yellow border-0 shadow-none">
      Create a plan
      </button>
    </div>
  </div>
</div>
      <div  class="view-more-div">View More Auto-Invest Products 
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="svg-chevron-down">
          <path d="M13.5 12L7 18.6 8.4 20l8-8-8-8L7 5.4l6.5 6.6z" fill="currentColor"></path>
        </svg>
      </div>
    </div>
  </div>
</section>
    
    
    
<section class="wm-pay-accordian-section">
    <div class="container">
        <div class="outlet-main-div">
                 <div class="wm-outlet-div">
                           
                            <div class="sec-title text-center mb-2">
                           <h2 class="heading-h2">FAQs</h2>
                            </div>
                           
                        </div>
                         <div class="wm-outlet-div text-right justify-content-end">
                           
                            <a href="#" class="learn-more btn-6">
                           <span>Learn More </span>
                           <span><i class="bi bi-chevron-right"></i></span>
                        </a>
                           
                        </div>
                        </div>
    </div>
    <div class="container">
  <div class="accordion" id="accordionExample">
  <div class="card">
    <div class="card-head" id="headingOne">
      <h2 class="mb-0 collapsed" data-toggle="collapse" data-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
         What is Auto-Invest?
      </h2>
    </div>

    <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
      <div class="card-body">
      <div class="text">   Auto-Invest allows you to automate crypto investment and earn passive income. It is a dollar-cost averaging (DCA) investment strategy. You can choose the cryptocurrency you want to purchase on a regular basis. Your purchased crypto will be automatically deposited into your Flexible account, so you can earn passive income with your investments.</div>
      </div>
    </div>
  </div>
  <div class="card">
    <div class="card-head" id="headingTwo">
      <h2 class="mb-0 collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
      What happens to my Auto-Invest purchase when I don’t have sufficient balance in my Spot Wallet?
      </h2>
    </div>
    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
      <div class="card-body">
       <div class="text"> Wealthmark Pay currently supports more than 40 cryptocurrencies.</div>
       <div class="text">
          If you have enabled the [Use Flexible Balance] function, when the balance in your Spot Wallet is insufficient to cover the Auto-Invest plan purchase, the system will automatically redeem the assets from your Flexible plans to complete the purchase.
If you don't enable the function, the purchase will fail. The system will try to make another purchase on the next Auto-Invest date.
       </div>
      </div>
    </div>
  </div>
  <div class="card">
    <div class="card-head" id="headingThree">
      <h2 class="mb-0 collapsed" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
        How many Auto-Invest plans can I subscribe to?
      </h2>
    </div>
    <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
      <div class="card-body">
        <div class="text"> There is no maximum limit to the number of Auto-Invest plans you can subscribe to.</div>
      </div>
    </div>
  </div>
  
  
  <div class="card">
    <div class="card-head" id="headingFour">
      <h2 class="mb-0 collapsed" data-toggle="collapse" data-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
       How to pause or stop my Auto-Invest plans?
      </h2>
    </div>
    <div id="collapseFour" class="collapse" aria-labelledby="headingFour" data-parent="#accordionExample">
      <div class="card-body">
  <div class="text">You can go to [Wallet] - [Earn] and click [Auto-Invest Plan] to view your plans. 
To pause or resume a plan, toggle the button under [On/Off]. To stop a plan permanently, click [Remove Plan]. </div>     
      </div>
    </div>
  </div>
  
  
</div>
</div>
</section>

   
  @include('template.country_language')
    @include('template.web_footer') 

 <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/js/bootstrap.min.js"></script> 


  
    </body>
</html>