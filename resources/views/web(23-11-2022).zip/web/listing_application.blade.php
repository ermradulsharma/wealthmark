<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <title>Wealth Mark | {{ Request::segment(2) }}</title>
    @include('template.web_css')
    <link rel='stylesheet' href="{{('../public/assets/css/deepak_custom.css') }}">
</head>

<body>
    @include('template.mobile_menu')
    @include('template.web_menu')

    <section class="lsiting-application-block" id="listing-application-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 colxs-12 d-flex justify-content-center align-items-center">

                    <form id="regForm" action="#">
                        <h2 class="text-center">Fill the Information & Submit Details</h2>
                        <h6 class="text-center fw-bold blue-text blink_listing-heading">(Listing a Coin on Wealth Mark)
                        </h6>
                        <br />
                        <div class="tab">
                            <div class="form-group mb-4">
                                <label for="Project Name">Project Name</label>
                                <input type="text" class="form-control" id="project-name"
                                    aria-describedby="ProjectName">
                            </div>
                            <div class="form-group mb-4">
                                <label for="full-coin">Token/Coin Full Name</label>
                                <input type="text" class="form-control" id="coin-full-name"
                                    aria-describedby="Token/CoinFullName">
                            </div>

                            <div class="form-group mb-4">
                                <label for="coin-symbol">Token/Coin Symbol</label>
                                <input type="text" class="form-control" aria-describedby="coin-symbol">
                            </div>
                            <div class="form-group mb-4">
                                <label for="email">Email</label>
                                <input type="text" class="form-control" id="email-id" aria-describedby="email">
                            </div>
                        </div>

                        <div class="tab">
                            <div class="form-group mb-4">
                                <p class="alert alert-warning">Please make sure to click the below links and upload the
                                    additional information required through the Wealth Mark listing form and Wealth Mark info
                                    webpage. </p>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="listing-detail-box-img">
                                        <img src="{{ asset('public/assets/img/listing-icon.png') }}" class="img-fluid"
                                            alt="gift Card Image">
                                    </div>
                                </div>
                                <div class="col-md-8">
                                    <div class="listing-detail-box">
                                        <h5>Wealth Mark Listing Application </h5>
                                        <a href="#" class="text-warning mb-1">http://docs.google.com/forms/...
                                        </a><br />
                                        <input type="checkbox" class="mb-1" /> &nbsp;I have completed requried Google
                                        form.<br />
                                        <h6>Confirm by ticking the above once you have finish uploading all information,
                                            then click the Apply button to complete yor application. </h6>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="tab">
                            <div class="form-group mb-5">
                                <div class="row">
                                    <div class="col-md-12 col-lg-12 col-sm-12 text-center">
                                        <div class="listing-check-icon mt-5">
                                            <svg  width="16" height="16"
                                                fill="currentColor" class="bi bi-check" viewBox="0 0 16 16">
                                                <path
                                                    d="M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425a.267.267 0 0 1 .02-.022z" />
                                            </svg>
                                        </div>
                                        <h3>Application Submitted Successfully </h3>
                                        <p>Your application is pending review. Application that pass the initial review
                                            will be contracted at ta later date, as outlined during the submission
                                            process. </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div style="overflow:auto;">
                            <div style="float:right;">
                                <button type="button" id="prevBtn" onclick="nextPrev(-1)">Previous</button>
                                <button type="button" id="nextBtn" onclick="nextPrev(1)">Next</button>
                            </div>
                        </div>

                        <div style="text-align:center;margin-top:40px;">
                            <span class="step"></span>
                            <span class="step"></span>
                            <span class="step"></span>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>


    <script>
    var currentTab = 0; // Current tab is set to be the first tab (0)
    showTab(currentTab); // Display the current tab

    function showTab(n) {
        // This function will display the specified tab of the form...
        var x = document.getElementsByClassName("tab");
        x[n].style.display = "block";
        //... and fix the Previous/Next buttons:
        if (n == 0) {
            document.getElementById("prevBtn").style.display = "none";
        } else {
            document.getElementById("prevBtn").style.display = "inline";
        }
        if (n == (x.length - 1)) {
            document.getElementById("nextBtn").innerHTML = "Submit";
        } else {
            document.getElementById("nextBtn").innerHTML = "Next";
        }
        //... and run a function that will display the correct step indicator:
        fixStepIndicator(n)
    }

    function nextPrev(n) {
        // This function will figure out which tab to display
        var x = document.getElementsByClassName("tab");
        // Exit the function if any field in the current tab is invalid:
        if (n == 1 && !validateForm()) return false;
        // Hide the current tab:
        x[currentTab].style.display = "none";
        // Increase or decrease the current tab by 1:
        currentTab = currentTab + n;
        // if you have reached the end of the form...
        if (currentTab >= x.length) {
            // ... the form gets submitted:
            document.getElementById("regForm").submit();
            return false;
        }
        // Otherwise, display the correct tab:
        showTab(currentTab);
    }

    function validateForm() {
        // This function deals with validation of the form fields
        var x, y, i, valid = true;
        x = document.getElementsByClassName("tab");
        y = x[currentTab].getElementsByTagName("input");
        // A loop that checks every input field in the current tab:
        for (i = 0; i < y.length; i++) {
            // If a field is empty...
            if (y[i].value == "") {
                // add an "invalid" class to the field:
                y[i].className += " invalid";
                // and set the current valid status to false
                valid = false;
            }
        }
        // If the valid status is true, mark the step as finished and valid:
        if (valid) {
            document.getElementsByClassName("step")[currentTab].className += " finish";
        }
        return valid; // return the valid status
    }

    function fixStepIndicator(n) {
        // This function removes the "active" class of all steps...
        var i, x = document.getElementsByClassName("step");
        for (i = 0; i < x.length; i++) {
            x[i].className = x[i].className.replace(" active", "");
        }
        //... and adds the "active" class on the current step:
        x[n].className += " active";
    }
    </script>

    @include('template.country_language')
    @include('template.web_footer')
</body>

</html>