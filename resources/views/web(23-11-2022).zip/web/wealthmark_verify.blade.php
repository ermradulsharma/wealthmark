<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <title>Wealth Mark | {{ Request::segment(2) }}</title>
    @include('template.web_css')
    <link rel='stylesheet' href="{{('../public/assets/css/deepak_custom.css') }}">
</head>

<body>
    @include('template.mobile_menu')
    @include('template.web_menu')

    <section class="wealthmark-verify-block" id="wealthmark-verify-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="d-flex justify-content-center align-items-center">
                        <img src="{{ asset('public/assets/img/wealthmark-logo.svg') }}" class="img-fluid"
                            alt="gift Card Image">
                        <h3>Wealth Mark Verify</h3>
                    </div>
                    <br />
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 input-group mb-3" id="wealthmark-verify-box-input">
                        <input type="text" class="form-control" placeholder="Enter Query"
                            aria-label="Recipient's username" aria-describedby="wealthmark-verify">
                        <span class="input-group-text" id="wealthmark-verify">Search</span>
                        <span class="verify-para">Please use Wealth Mark Verify to check whether the source officially
                            represents Wealth Mark. website link, email address, phone number, WeChat ID, Twitter
                            account or Telegram ID. <svg  viewBox="0 0 24 24" fill="none" class="vm-svg-verify"><path fill-rule="evenodd" clip-rule="evenodd" d="M12 21a9 9 0 100-18 9 9 0 000 18zM10.75 8.5V6h2.5v2.5h-2.5zm0 9.5v-7h2.5v7h-2.5z" fill="currentColor"></path></svg></span>
                        <span class="verify-para">*Please do not contact any unofficial/non-verified sources or reveal
                            your account details to them. For further queries, please contact <span
                                class="yellow-text">Wealth Mark Support</span> </span>
                    </div>

                </div>
            </div>
        </div>
    </section>

    <section class="security-tips-block pt-0" id="security-tips-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="sec-title text-left mb-5">
                        <span class="title">Know About</span>
                        <h2 class="heading-h2">Security Tips</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-3 col-lg-3 col-xs-12 col-sm-6">
                    <div class="security-tips-box">
                        <svg  viewBox="0 0 96 96" fill="none" class="css-rj8c7">
                            <path opacity="0.3" fill-rule="evenodd" clip-rule="evenodd"
                                d="M12.001 68.043l36 23.957V8h-36v60.043z" fill="url(#security_svg__paint0)"></path>
                            <path opacity="0.3" fill-rule="evenodd" clip-rule="evenodd" d="M48.001 8v84l36-24V8h-36z"
                                fill="#AEB4BC"></path>
                            <path d="M74 64.667L48 82 22 64.667V18h52v46.667z" fill="url(#security_svg__paint1)"></path>
                            <path d="M34 46l14-14 14 14-14 14-14-14z" fill="url(#security_svg__paint2)"></path>
                            <path opacity="0.3" d="M14 88l4 4 4-4-4-4-4 4z" fill="#AEB4BC"></path>
                            <path d="M88 21h3v-3h-3v3z" fill="#E6E8EA"></path>
                            <path opacity="0.3" d="M4 2.5L6.5 5 9 2.5 6.5 0 4 2.5z" fill="#AEB4BC"></path>
                            <defs>
                                <linearGradient id="security_svg__paint0" x1="48.001" y1="92" x2="48.001" y2="8"
                                    gradientUnits="userSpaceOnUse">
                                    <stop stop-color="#AEB4BC" stop-opacity="0.1"></stop>
                                    <stop offset="0.701" stop-color="#AEB4BC"></stop>
                                </linearGradient>
                                <linearGradient id="security_svg__paint1" x1="48" y1="82" x2="48" y2="18"
                                    gradientUnits="userSpaceOnUse">
                                    <stop offset="0.333" stop-color="#F0B90B"></stop>
                                    <stop offset="1" stop-color="#FBDA3C"></stop>
                                </linearGradient>
                                <linearGradient id="security_svg__paint2" x1="48" y1="32" x2="48" y2="60"
                                    gradientUnits="userSpaceOnUse">
                                    <stop stop-color="#929AA5"></stop>
                                    <stop offset="1" stop-color="#76808F"></stop>
                                </linearGradient>
                            </defs>
                        </svg>
                        <h4>General Security Principles </h4>
                        <svg  viewBox="0 0 24 24" fill="none" class="css-5v8nu4">
                            <path d="M12 16.172L16.172 12 12 7.828V5l7 7-7 7v-2.828z" fill="#76808F"></path>
                            <path d="M6 19l7-7-7-7v14z" fill="url(#chevron-double-right-g_svg__paint0_linear)"></path>
                            <defs>
                                <linearGradient id="chevron-double-right-g_svg__paint0_linear" x1="9.5" y1="19" x2="9.5"
                                    y2="5" gradientUnits="userSpaceOnUse">
                                    <stop stop-color="#F0B90B"></stop>
                                    <stop offset="1" stop-color="#F8D33A"></stop>
                                </linearGradient>
                            </defs>
                        </svg>
                        <p class="verify-show-txt">Wealthmark is a leading player in the Crypto ecosystem; Since its inception it has risen to provide its users with an ostentatious and secure platform.</p>
                    </div>
                </div>
                <div class="col-md-3 col-lg-3 col-xs-12 col-sm-6">
                    <div class="security-tips-box">
                    <svg  viewBox="0 0 96 96" fill="none" class="css-rj8c7"><path d="M73 80H23V16h50v64z" fill="url(#mobile-scam_svg__paint0)"></path><path opacity="0.3" fill-rule="evenodd" clip-rule="evenodd" d="M55 12H41V8h14v4z" fill="#AEB4BC"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M73 16H23V4h50v12zm-32-4h14V8H41v4z" fill="url(#mobile-scam_svg__paint1)"></path><path d="M73 92H23V80h50v12z" fill="url(#mobile-scam_svg__paint2)"></path><path opacity="0.3" d="M6 52l5 5 5-5-5-5-5 5zM78 23.5l3.5 3.5 3.5-3.5-3.5-3.5-3.5 3.5zM85 62h3v-3h-3v3z" fill="#AEB4BC"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M48 30c-8.837 0-16 7.164-16 16v11h8v7h16v-7h8V46c0-8.836-7.164-16-16-16zm-3 21h-5v-8h5v8zm11 0h-5v-8h5v8z" fill="#76808F"></path><defs><linearGradient id="mobile-scam_svg__paint0" x1="23" y1="48" x2="73" y2="48" gradientUnits="userSpaceOnUse"><stop stop-color="#F0B90B"></stop><stop offset="1" stop-color="#F8D33A"></stop></linearGradient><linearGradient id="mobile-scam_svg__paint1" x1="48" y1="4" x2="48" y2="92" gradientUnits="userSpaceOnUse"><stop stop-color="#929AA5"></stop><stop offset="1" stop-color="#76808F"></stop></linearGradient><linearGradient id="mobile-scam_svg__paint2" x1="48" y1="4" x2="48" y2="92" gradientUnits="userSpaceOnUse"><stop stop-color="#929AA5"></stop><stop offset="1" stop-color="#76808F"></stop></linearGradient></defs></svg>
                        <h4>Commnon Scams on Mobile Devices</h4>
                        <svg  viewBox="0 0 24 24" fill="none" class="css-5v8nu4">
                            <path d="M12 16.172L16.172 12 12 7.828V5l7 7-7 7v-2.828z" fill="#76808F"></path>
                            <path d="M6 19l7-7-7-7v14z" fill="url(#chevron-double-right-g_svg__paint0_linear)"></path>
                            <defs>
                                <linearGradient id="chevron-double-right-g_svg__paint0_linear" x1="9.5" y1="19" x2="9.5"
                                    y2="5" gradientUnits="userSpaceOnUse">
                                    <stop stop-color="#F0B90B"></stop>
                                    <stop offset="1" stop-color="#F8D33A"></stop>
                                </linearGradient>
                            </defs>
                        </svg>
                        <p class="verify-show-txt">Wealthmark is a leading player in the Crypto ecosystem; Since its inception it has risen to provide its users with an ostentatious and secure platform.</p>
                    </div>
                </div>
                <div class="col-md-3 col-lg-3 col-xs-12 col-sm-6">
                    <div class="security-tips-box">
                    <svg  viewBox="0 0 96 96" fill="none" class="css-rj8c7"><path opacity="0.3" d="M16 16l4 4 4-4-4-4-4 4zM87 32.5l2.5 2.5 2.5-2.5-2.5-2.5-2.5 2.5z" fill="#AEB4BC"></path><path d="M34 94h3v-3h-3v3z" fill="#E6E8EA"></path><path d="M16 48l32 32 32-32v40H16V48z" fill="url(#phishing_svg__paint0)"></path><path opacity="0.3" d="M80 40v8L48 80 16 48v-8h64z" fill="#AEB4BC"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M31 40c0 9.389 7.611 17 17 17v-6c-6.075 0-11-4.925-11-11h11L31 23v17z" fill="url(#phishing_svg__paint1)"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M59 32.586c-4.617-1.306-8-5.55-8-10.586 0-5.035 3.383-9.28 8-10.586V8h6v3.414c4.617 1.306 8 5.55 8 10.586 0 5.035-3.383 9.28-8 10.586V40h-6v-7.414zM62 27a5 5 0 110-10 5 5 0 010 10z" fill="url(#phishing_svg__paint2)"></path><path d="M59 4h6v14h-6V4z" fill="#76808F"></path><defs><linearGradient id="phishing_svg__paint0" x1="48" y1="48" x2="48" y2="88" gradientUnits="userSpaceOnUse"><stop stop-color="#929AA5"></stop><stop offset="1" stop-color="#76808F"></stop></linearGradient><linearGradient id="phishing_svg__paint1" x1="39.5" y1="57" x2="39.5" y2="23" gradientUnits="userSpaceOnUse"><stop stop-color="#F0B90B"></stop><stop offset="1" stop-color="#F8D33A"></stop></linearGradient><linearGradient id="phishing_svg__paint2" x1="62" y1="40" x2="62" y2="8" gradientUnits="userSpaceOnUse"><stop stop-color="#F0B90B"></stop><stop offset="1" stop-color="#F8D33A"></stop></linearGradient></defs></svg>
                        <h4>Wealth Marks Phishing?</h4>
                        <svg  viewBox="0 0 24 24" fill="none" class="css-5v8nu4">
                            <path d="M12 16.172L16.172 12 12 7.828V5l7 7-7 7v-2.828z" fill="#76808F"></path>
                            <path d="M6 19l7-7-7-7v14z" fill="url(#chevron-double-right-g_svg__paint0_linear)"></path>
                            <defs>
                                <linearGradient id="chevron-double-right-g_svg__paint0_linear" x1="9.5" y1="19" x2="9.5"
                                    y2="5" gradientUnits="userSpaceOnUse">
                                    <stop stop-color="#F0B90B"></stop>
                                    <stop offset="1" stop-color="#F8D33A"></stop>
                                </linearGradient>
                            </defs>
                        </svg>
                        <p class="verify-show-txt">Wealthmark is a leading player in the Crypto ecosystem; Since its inception it has risen to provide its users with an ostentatious and secure platform.</p>
                    </div>
                </div>
                <div class="col-md-3 col-lg-3 col-xs-12 col-sm-6">
                    <div class="security-tips-box">
                        <svg  viewBox="0 0 96 96" fill="none" class="css-rj8c7">
                            <path opacity="0.3" fill-rule="evenodd" clip-rule="evenodd"
                                d="M12.001 68.043l36 23.957V8h-36v60.043z" fill="url(#security_svg__paint0)"></path>
                            <path opacity="0.3" fill-rule="evenodd" clip-rule="evenodd" d="M48.001 8v84l36-24V8h-36z"
                                fill="#AEB4BC"></path>
                            <path d="M74 64.667L48 82 22 64.667V18h52v46.667z" fill="url(#security_svg__paint1)"></path>
                            <path d="M34 46l14-14 14 14-14 14-14-14z" fill="url(#security_svg__paint2)"></path>
                            <path opacity="0.3" d="M14 88l4 4 4-4-4-4-4 4z" fill="#AEB4BC"></path>
                            <path d="M88 21h3v-3h-3v3z" fill="#E6E8EA"></path>
                            <path opacity="0.3" d="M4 2.5L6.5 5 9 2.5 6.5 0 4 2.5z" fill="#AEB4BC"></path>
                            <defs>
                                <linearGradient id="security_svg__paint0" x1="48.001" y1="92" x2="48.001" y2="8"
                                    gradientUnits="userSpaceOnUse">
                                    <stop stop-color="#AEB4BC" stop-opacity="0.1"></stop>
                                    <stop offset="0.701" stop-color="#AEB4BC"></stop>
                                </linearGradient>
                                <linearGradient id="security_svg__paint1" x1="48" y1="82" x2="48" y2="18"
                                    gradientUnits="userSpaceOnUse">
                                    <stop offset="0.333" stop-color="#F0B90B"></stop>
                                    <stop offset="1" stop-color="#FBDA3C"></stop>
                                </linearGradient>
                                <linearGradient id="security_svg__paint2" x1="48" y1="32" x2="48" y2="60"
                                    gradientUnits="userSpaceOnUse">
                                    <stop stop-color="#929AA5"></stop>
                                    <stop offset="1" stop-color="#76808F"></stop>
                                </linearGradient>
                            </defs>
                        </svg>
                        <h4>General Security Principles </h4>
                        <svg  viewBox="0 0 24 24" fill="none" class="css-5v8nu4">
                            <path d="M12 16.172L16.172 12 12 7.828V5l7 7-7 7v-2.828z" fill="#76808F"></path>
                            <path d="M6 19l7-7-7-7v14z" fill="url(#chevron-double-right-g_svg__paint0_linear)"></path>
                            <defs>
                                <linearGradient id="chevron-double-right-g_svg__paint0_linear" x1="9.5" y1="19" x2="9.5"
                                    y2="5" gradientUnits="userSpaceOnUse">
                                    <stop stop-color="#F0B90B"></stop>
                                    <stop offset="1" stop-color="#F8D33A"></stop>
                                </linearGradient>
                            </defs>
                        </svg>
                        <p class="verify-show-txt">Wealthmark is a leading player in the Crypto ecosystem; Since its inception it has risen to provide its users with an ostentatious and secure platform.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>


    @include('template.country_language')
    @include('template.web_footer')
</body>

</html>