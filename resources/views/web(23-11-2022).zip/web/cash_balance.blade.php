<html>
<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <title>Wealth Mark | {{ Request::segment(2) }}</title>
    @include('template.web_css')
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="http://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>

    <link rel='stylesheet' href="{{('../public/assets/css/deepak_custom.css') }}">
    </head>

    <body>
        @include('template.mobile_menu')
        @include('template.web_menu')

        <section class="buy-sell-tab-box" id="buy-sell-tab-section">
            <div class="container">
                <div class="row">

                    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 d-flex justify-content-center align-items-center">
                        <div class="cash-balance-buy-sell-tab">
                            <nav class="cash-balance-navbar">
                                <div class="nav nav-tabs" id="nav-tab" role="tablist">
                                    <button class="nav-link active" id="nav-home-tab" data-bs-toggle="tab"
                                        data-bs-target="#nav-home" type="button" role="tab" aria-controls="nav-home"
                                        aria-selected="true">Buy</button>
                                    <button class="nav-link" id="nav-profile-tab" data-bs-toggle="tab"
                                        data-bs-target="#nav-profile" type="button" role="tab"
                                        aria-controls="nav-profile" aria-selected="false">Sell</button>
                                </div>
                            </nav>
                            <div class="tab-content casb-balance-tab-content" id="nav-tabContent">
                                <div class="tab-pane fade show active" id="nav-home" role="tabpanel"
                                    aria-labelledby="nav-home-tab">
                                    <div class="first-row row">
                                        <div class="col-md-12">
                                            <p class="text-center">Estimate price:1 BTC ≈ 19,821.88 EUR &#11139;</p>
                                        </div>
                                    </div>
                                    <div class="spend-row row">
                                        <div class="col-md-9">
                                            <div class="buy-tab-inner-box">
                                                <p>Spend </p>
                                                <input type="text" class="form-control"
                                                    placeholder="15.00 - 12500.00" />
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="buy-tab-inner-box">
                                                <a class="btn btn-yellow shadow mt-4" data-bs-toggle="modal"
                                                    data-bs-target="#buy-tab-select-currency">EUR &#129189;</a>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="spend-row row mt-3">
                                        <div class="col-md-9">
                                            <div class="buy-tab-inner-box">
                                                <p>Receive </p>
                                                <input type="text" class="form-control" placeholder="0.00" />
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="buy-tab-inner-box">
                                                <a class="btn btn-yellow shadow mt-4" data-bs-toggle="modal"
                                                    data-bs-target="#select-crypto-modal">BTC &#129189;</a>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="spend-row row mt-3">
                                        <div class="col-md-12">
                                            <div class="buy-tab-inner-box">
                                                <h5>Recurring Buy</h5>
                                                <p>Recurring buy <span>BTC</span> for <span>3 years</span>, got
                                                    <span>16.00%</span> ROI.
                                                </p>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                                <div class="tab-pane fade" id="nav-profile" role="tabpanel"
                                    aria-labelledby="nav-profile-tab">
                                    <div class="first-row row">
                                        <div class="col-md-12">
                                            <p class="text-center">Estimate price:1 BTC ≈ 19,821.88 EUR &#11139;</p>
                                        </div>
                                    </div>
                                    <div class="spend-row row">
                                        <div class="col-md-9">
                                            <div class="buy-tab-inner-box">
                                                <p>Spend </p>
                                                <input type="text" class="form-control"
                                                    placeholder="15.00 - 12500.00" />
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="buy-tab-inner-box">
                                                <a class="btn btn-yellow shadow mt-4" data-bs-toggle="modal"
                                                    data-bs-target="#buy-tab-select-currency">EUR &#129189;</a>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="spend-row row mt-3">
                                        <div class="col-md-9">
                                            <div class="buy-tab-inner-box">
                                                <p>Receive </p>
                                                <input type="text" class="form-control" placeholder="0.00" />
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="buy-tab-inner-box">
                                                <a class="btn btn-yellow shadow mt-4" data-bs-toggle="modal"
                                                    data-bs-target="#select-crypto-modal">BTC &#129189;</a>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="spend-row row mt-3">
                                        <div class="col-md-12">
                                            <div class="buy-tab-inner-box">
                                                <h5>Recurring Buy</h5>
                                                <p>Recurring buy <span>BTC</span> for <span>3 years</span>, got
                                                    <span>16.00%</span> ROI.
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <a class="btn btn-yellow shadow mt-3 mb-3 cash-balance-login-btn">LogIn/Sign Up </a>
                            </div>

                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 d-flex justify-content-center align-items-center">
                        <img src="{{ asset('public/assets/img/trading-banner.png') }}"
                            class="img-fluid animated casb-balance-banner-img" alt="responsible image">
                    </div>
                </div>
            </div>
        </section>

        <section class="trade-crypto-steps-box" id="trade-crypto-steps">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-xs-12 col-sm-12 sec-title text-left popular-head-block">
                        <span class="title">Know About</span>
                        <h2 class="heading-h2">Buy & Sell Crypto in <span class="yellow-text">3 Steps</span></h2>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-4 col-md-4 col-sm-6 col-xs-6">
                        <div class="steps-inner-box">
                            <div class="show-number">
                                <img src="{{ asset('public/assets/img/crypto-steps-1.svg') }}" class="img-fluid"
                                    alt="gift Card Image">
                            </div>
                            <h4>Register for an account </h4>
                            <p>As the world’s leading digital asset exchange by real trading volume, Wealth Mark’s
                                orders
                                account
                                for &gt;50% market volume on the majority of listings.
                                account
                                for &gt;50% market volume on the majority. </p>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-4 col-sm-6 col-xs-6">
                        <div class="steps-inner-box">
                            <div class="show-number">
                                <img src="{{ asset('public/assets/img/crypto-steps-2.svg') }}" class="img-fluid"
                                    alt="gift Card Image">
                            </div>
                            <h4>Verify your identity </h4>
                            <p>As the world’s leading digital asset exchange by real trading volume, Wealth Mark’s
                                orders
                                account
                                for &gt;50% market volume on the majority of listings.
                                account
                                for &gt;50% market volume on the majority. </p>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-4 col-sm-6 col-xs-6">
                        <div class="steps-inner-box">
                            <div class="show-number">
                                <img src="{{ asset('public/assets/img/crypto-steps-3.svg') }}" class="img-fluid"
                                    alt="gift Card Image">
                            </div>
                            <h4>Buy Crypto! </h4>
                            <p>As the world’s leading digital asset exchange by real trading volume, Wealth Mark’s
                                orders
                                account
                                for &gt;50% market volume on the majority of listings.
                                account
                                for &gt;50% market volume on the majority. </p>
                        </div>
                    </div>

                </div>

            </div>
        </section>

        <section class="about-fund-account-box" id="about-fund-account">
            <div class="container">
                <div class="row cash-balance-currency-row">
                    <div class="col-12 col-md-6 col-lg-5 col-sm-12 col-xs-12 order-2 order-lg-1">
                        <div class="sec-title text-left">
                            <span class="title">Know About</span>
                            <h2 class="heading-h2">Your Account with <span class="yellow-text">Traditional Currencies</span></h2>
                        </div>
                        <p>Users can easily buy Bitcoin and other cryptocurrencies using a wide range of payment
                            options, including bank transfer, credit or debit card, and cash. There’s a payment option
                            for everyone on Wealth Mark.</p>
                        <p>We work only with verified and trusted partners to give you a secure and seamless
                            crypto-buying experience.
                        </p>
                        <p>Wealth Mark accepts a wide range of currencies and makes it easy for you to buy crypto using
                            <span class="text-warning">USD , EUR, CNY, AUD, INR, RUB</span>, and other <span
                                class="text-warning">fiat currencies</span>. You can also use a wide range of accepted
                            stablecoins such as Wealth Mark USD (BUSD), Coinbase USD Coin (USDC), and Tether (USDT) to
                            buy crypto.
                        </p>
                        <p>Once you complete the purchase, we will deposit your new crypto directly to your Wealth Mark
                            wallet - a safe and simple way to manage your crypto assets. You can immediately trade your
                            purchased crypto on the many products and services on the Wealth Mark Platform. </p>
                        <div class="read-more-block mt-4">
                            <a href="#" class="btn btn-yellow shadow mt-3">Get Started</a>
                        </div>
                    </div>
                    <div class="col-12 col-md-6 col-lg-7 col-sm-12 col-xs-12 order-1 order-lg-2 img-hover3">
                        <img src="{{ asset('public/assets/img/traditional-currencies.svg') }}" class="img-fluid"
                            alt="gift Card Image">

                    </div>
                </div>

            </div>
        </section>

        <section class="crypto-conversion-box" id="crypto-conversion">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 col-xs-12 col-sm-12 sec-title text-left">
                        <span class="title">Know About</span>
                        <h2 class="heading-h2"><span class="yellow-text">Top Cryptocurrency</span> Conversions</h2>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
                        <div class="conversion-box">
                            <img src="{{ asset('public/assets/img/conversion-1.svg') }}" class="img-fluid"
                                alt="conversion">&nbsp; Buy with USD
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
                        <div class="conversion-box">
                            <img src="{{ asset('public/assets/img/conversion-2.svg') }}" class="img-fluid"
                                alt="conversion">&nbsp; Buy with USD
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
                        <div class="conversion-box">
                            <img src="{{ asset('public/assets/img/conversion-3.svg') }}" class="img-fluid"
                                alt="conversion">&nbsp; Buy with USD
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
                        <div class="conversion-box">
                            <img src="{{ asset('public/assets/img/conversion-4.svg') }}" class="img-fluid"
                                alt="conversion">&nbsp; Buy with USD
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
                        <div class="conversion-box">
                            <img src="{{ asset('public/assets/img/conversion-5.svg') }}" class="img-fluid"
                                alt="conversion">&nbsp; Buy with USD
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
                        <div class="conversion-box">
                            <img src="{{ asset('public/assets/img/conversion-6.svg') }}" class="img-fluid"
                                alt="conversion">&nbsp; Buy with USD
                        </div>
                    </div>
                </div>

                <hr />
                <div class="row mt-4">
                    <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
                        <div class="conversion-box">
                            <img src="{{ asset('public/assets/img/conversion-1.svg') }}" class="img-fluid"
                                alt="conversion">&nbsp; Buy with USD
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
                        <div class="conversion-box">
                            <img src="{{ asset('public/assets/img/conversion-2.svg') }}" class="img-fluid"
                                alt="conversion">&nbsp; Buy with USD
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
                        <div class="conversion-box">
                            <img src="{{ asset('public/assets/img/conversion-3.svg') }}" class="img-fluid"
                                alt="conversion">&nbsp; Buy with USD
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
                        <div class="conversion-box">
                            <img src="{{ asset('public/assets/img/conversion-4.svg') }}" class="img-fluid"
                                alt="conversion">&nbsp; Buy with USD
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
                        <div class="conversion-box">
                            <img src="{{ asset('public/assets/img/conversion-5.svg') }}" class="img-fluid"
                                alt="conversion">&nbsp; Buy with USD
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
                        <div class="conversion-box">
                            <img src="{{ asset('public/assets/img/conversion-6.svg') }}" class="img-fluid"
                                alt="conversion">&nbsp; Buy with USD
                        </div>
                    </div>
                </div>
                <hr />
                <div class="row mt-4">
                    <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
                        <div class="conversion-box">
                            <img src="{{ asset('public/assets/img/conversion-1.svg') }}" class="img-fluid"
                                alt="conversion">&nbsp; Buy with USD
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
                        <div class="conversion-box">
                            <img src="{{ asset('public/assets/img/conversion-2.svg') }}" class="img-fluid"
                                alt="conversion">&nbsp; Buy with USD
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
                        <div class="conversion-box">
                            <img src="{{ asset('public/assets/img/conversion-3.svg') }}" class="img-fluid"
                                alt="conversion">&nbsp; Buy with USD
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
                        <div class="conversion-box">
                            <img src="{{ asset('public/assets/img/conversion-4.svg') }}" class="img-fluid"
                                alt="conversion">&nbsp; Buy with USD
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
                        <div class="conversion-box">
                            <img src="{{ asset('public/assets/img/conversion-5.svg') }}" class="img-fluid"
                                alt="conversion">&nbsp; Buy with USD
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
                        <div class="conversion-box">
                            <img src="{{ asset('public/assets/img/conversion-6.svg') }}" class="img-fluid"
                                alt="conversion">&nbsp; Buy with USD
                        </div>
                    </div>
                </div>
                <hr />
                <div class="row mt-5">
                    <div class="col-md-12 col-lg-12 col-xs-12 colsm-12">
                        <div class="conversion-box">
                            <img src="{{ asset('public/assets/img/conversion-1.svg') }}" class="img-fluid"
                                alt="conversion"> Buy with USD
                        </div>
                    </div>
                </div>

            </div>
        </section>

        <section class="about-fund-account-box" id="about-fund-account">
            <div class="container">
                <div class="row cash-balance-currency-row">
                    <div class="col-12 col-md-6 col-lg-5 col-sm-12 col-xs-12 order-2 order-lg-1">
                        <div class="sec-title text-left">
                            <span class="title">Know About</span>
                            <h2 class="heading-h2">Get Discovered</h2>
                        </div>
                        <p>To explore general partnerships with Wealth Mark for new cash-crypto exchanges and or existing
                            cash-crypto exchanges, please submit your application on "Fiat Services Vendor Application
                            Form".</p>
                        <div class="read-more-block mt-4">
                            <a href="#" class="btn btn-yellow shadow mt-3">Get Started</a>
                        </div>
                    </div>
                    <div class="col-12 col-md-6 col-lg-7 col-sm-12 col-xs-12 order-1 order-lg-2 img-hover3">
                        <img src="{{ asset('public/assets/img/get-discoverd-img.svg') }}" class="img-fluid"
                            alt="gift Card Image">

                    </div>
                </div>

            </div>
        </section>

        <!-- Modal -->
        <div class="modal fade" id="buy-tab-select-currency" data-bs-backdrop="static" data-bs-keyboard="false"
            tabindex="-1" aria-labelledby="buy-tab-select-currencyLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="buy-tab-select-currencyLabel">Select Currency</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-12 col-lg-12 col-xs-12 col-sm-12">
                                <input type="text" class="form-control" placeholder="Search" />
                            </div>
                            <div class="col-md-12 col-lg-12 col-xs-12 col-sm-12">
                                <div class="select-country-group">
                                    <div class="select-currency-tab">
                                        <img src="{{ asset('public/assets/img/currency-1.png') }}" class="img-fluid"
                                            alt="cash-balance-img" />
                                        <div class="currency-detail">
                                            <h5>AED </h5>
                                            <span>United Arab Emirates dirham </span>
                                        </div>
                                    </div>
                                    <div class="select-currency-tab">
                                        <img src="{{ asset('public/assets/img/currency-2.png') }}" class="img-fluid"
                                            alt="cash-balance-img" />
                                        <div class="currency-detail">
                                            <h5>AED </h5>
                                            <span>United Arab Emirates dirham </span>
                                        </div>
                                    </div>
                                    <div class="select-currency-tab">
                                        <img src="{{ asset('public/assets/img/currency-3.png') }}" class="img-fluid"
                                            alt="cash-balance-img" />
                                        <div class="currency-detail">
                                            <h5>AED </h5>
                                            <span>United Arab Emirates dirham </span>
                                        </div>
                                    </div>
                                    <div class="select-currency-tab">
                                        <img src="{{ asset('public/assets/img/currency-4.png') }}" class="img-fluid"
                                            alt="cash-balance-img" />
                                        <div class="currency-detail">
                                            <h5>AED </h5>
                                            <span>United Arab Emirates dirham </span>
                                        </div>
                                    </div>
                                    <div class="select-currency-tab">
                                        <img src="{{ asset('public/assets/img/currency-5.png') }}" class="img-fluid"
                                            alt="cash-balance-img" />
                                        <div class="currency-detail">
                                            <h5>AED </h5>
                                            <span>United Arab Emirates dirham </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade" id="select-crypto-modal" data-bs-backdrop="static" data-bs-keyboard="false"
            tabindex="-1" aria-labelledby="select-crypto-modalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="select-crypto-modalLabel">Select Crypto</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>

                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-12 col-lg-12 col-xs-12 col-sm-12">
                                <input type="text" class="form-control" placeholder="Search" />
                            </div>
                            <div class="col-md-12 col-lg-12 col-xs-12 col-sm-12">
                                <div class="select-crypto">
                                    <div class="select-currency-tab">
                                        <img src="{{ asset('public/assets/img/currency-5.png') }}" class="img-fluid"
                                            alt="cash-balance-img" />
                                        <div class="currency-detail">
                                            <h5>AED </h5>
                                            <span>United Arab Emirates dirham </span>
                                        </div>
                                        <div class="currency-txt">
                                            <h5>70.14275000 </h5>
                                            <span class="text-danger">-2.014</span>
                                        </div>
                                    </div>
                                    <div class="select-currency-tab">
                                        <img src="{{ asset('public/assets/img/currency-3.png') }}" class="img-fluid"
                                            alt="cash-balance-img" />
                                        <div class="currency-detail">
                                            <h5>AED </h5>
                                            <span>United Arab Emirates dirham </span>
                                        </div>
                                        <div class="currency-txt">
                                            <h5>70.14275000 </h5>
                                            <span class="text-danger">-2.014</span>
                                        </div>
                                    </div>
                                    <div class="select-currency-tab">
                                        <img src="{{ asset('public/assets/img/currency-1.png') }}" class="img-fluid"
                                            alt="cash-balance-img" />
                                        <div class="currency-detail">
                                            <h5>AED </h5>
                                            <span>United Arab Emirates dirham </span>
                                        </div>
                                        <div class="currency-txt">
                                            <h5>70.14275000 </h5>
                                            <span class="text-danger">-2.014</span>
                                        </div>
                                    </div>
                                    <div class="select-currency-tab">
                                        <img src="{{ asset('public/assets/img/currency-2.png') }}" class="img-fluid"
                                            alt="cash-balance-img" />
                                        <div class="currency-detail">
                                            <h5>AED </h5>
                                            <span>United Arab Emirates dirham </span>
                                        </div>
                                        <div class="currency-txt">
                                            <h5>70.14275000 </h5>
                                            <span class="text-danger">-2.014</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>

        <!-- sell tab popup modal -->
        <div class="modal fade" id="sell-tab-select-currency" data-bs-backdrop="static" data-bs-keyboard="false"
            tabindex="-1" aria-labelledby="sell-tab-select-currencyLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="sell-tab-select-currencyLabel">Select Currency</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-12 col-lg-12 col-xs-12 col-sm-12">
                                <input type="text" class="form-control" placeholder="Search" />
                            </div>
                            <div class="col-md-12 col-lg-12 col-xs-12 col-sm-12">
                                <div class="select-country-group">
                                    <div class="select-currency-tab">
                                        <img src="{{ asset('public/assets/img/currency-1.png') }}" class="img-fluid"
                                            alt="cash-balance-img" />
                                        <div class="currency-detail">
                                            <h5>AED </h5>
                                            <span>United Arab Emirates dirham </span>
                                        </div>
                                    </div>
                                    <div class="select-currency-tab">
                                        <img src="{{ asset('public/assets/img/currency-2.png') }}" class="img-fluid"
                                            alt="cash-balance-img" />
                                        <div class="currency-detail">
                                            <h5>AED </h5>
                                            <span>United Arab Emirates dirham </span>
                                        </div>
                                    </div>
                                    <div class="select-currency-tab">
                                        <img src="{{ asset('public/assets/img/currency-3.png') }}" class="img-fluid"
                                            alt="cash-balance-img" />
                                        <div class="currency-detail">
                                            <h5>AED </h5>
                                            <span>United Arab Emirates dirham </span>
                                        </div>
                                    </div>
                                    <div class="select-currency-tab">
                                        <img src="{{ asset('public/assets/img/currency-4.png') }}" class="img-fluid"
                                            alt="cash-balance-img" />
                                        <div class="currency-detail">
                                            <h5>AED </h5>
                                            <span>United Arab Emirates dirham </span>
                                        </div>
                                    </div>
                                    <div class="select-currency-tab">
                                        <img src="{{ asset('public/assets/img/currency-5.png') }}" class="img-fluid"
                                            alt="cash-balance-img" />
                                        <div class="currency-detail">
                                            <h5>AED </h5>
                                            <span>United Arab Emirates dirham </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade" id="sell-select-crypto-modal" data-bs-backdrop="static" data-bs-keyboard="false"
            tabindex="-1" aria-labelledby="sell-select-crypto-modalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="sell-select-crypto-modalLabel">Select Crypto</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>

                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-12 col-lg-12 col-xs-12 col-sm-12">
                                <input type="text" class="form-control" placeholder="Search" />
                            </div>
                            <div class="col-md-12 col-lg-12 col-xs-12 col-sm-12">
                                <div class="select-crypto">
                                    <div class="select-currency-tab">
                                        <img src="{{ asset('public/assets/img/currency-5.png') }}" class="img-fluid"
                                            alt="cash-balance-img" />
                                        <div class="currency-detail">
                                            <h5>AED </h5>
                                            <span>United Arab Emirates dirham </span>
                                        </div>
                                        <div class="currency-txt">
                                            <h5>70.14275000 </h5>
                                            <span class="text-danger">-2.014</span>
                                        </div>
                                    </div>
                                    <div class="select-currency-tab">
                                        <img src="{{ asset('public/assets/img/currency-3.png') }}" class="img-fluid"
                                            alt="cash-balance-img" />
                                        <div class="currency-detail">
                                            <h5>AED </h5>
                                            <span>United Arab Emirates dirham </span>
                                        </div>
                                        <div class="currency-txt">
                                            <h5>70.14275000 </h5>
                                            <span class="text-danger">-2.014</span>
                                        </div>
                                    </div>
                                    <div class="select-currency-tab">
                                        <img src="{{ asset('public/assets/img/currency-1.png') }}" class="img-fluid"
                                            alt="cash-balance-img" />
                                        <div class="currency-detail">
                                            <h5>AED </h5>
                                            <span>United Arab Emirates dirham </span>
                                        </div>
                                        <div class="currency-txt">
                                            <h5>70.14275000 </h5>
                                            <span class="text-danger">-2.014</span>
                                        </div>
                                    </div>
                                    <div class="select-currency-tab">
                                        <img src="{{ asset('public/assets/img/currency-2.png') }}" class="img-fluid"
                                            alt="cash-balance-img" />
                                        <div class="currency-detail">
                                            <h5>AED </h5>
                                            <span>United Arab Emirates dirham </span>
                                        </div>
                                        <div class="currency-txt">
                                            <h5>70.14275000 </h5>
                                            <span class="text-danger">-2.014</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>

        @include('template.country_language')
        @include('template.web_footer')
    </body>

    </html>