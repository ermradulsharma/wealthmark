<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <title>Wealth Mark | {{ Request::segment(2) }}</title>
    @include('template.web_css')
    <link rel='stylesheet' href="{{('../public/assets/css/deepak_custom.css') }}">
    <link rel='stylesheet' href="{{('../public/assets/css/style_main.css') }}">
</head>

<body>
    @include('template.mobile_menu')
    @include('template.web_menu')


    <section class="execution-solutions shadow-sm">
        <div class="container mt-3">
            <div class="row execution-solutions-section-row">
                <div class="col-md-6 col-lg-6 col-sm-12 col-xs-12 pt-lg-0 order-2 order-lg-1" data-aos="fade-up"
                    data-aos-delay="200">
                    <h1 class="text-blue execution-heading-main">Welcome to the Wealthmark Execution Solutions</h1>
                    <p class="top-p text-yellow">At Wealthmanrk, we believe that everyone should have the freedom to
                        earn, hold, spend, share and give their money - no matter who you are or where you come
                        from.<br /> <a href="#" class="btn btn-blue"> Hurry Up!! </a> </p>
                </div>
                <div class="col-md-6 col-lg-6 col-sm-12 col-xs-12 order-1 order-lg-2 hero-img" data-aos="zoom-in"
                    data-aos-delay="200">
                    <img src="{{ asset('public/assets/img/execution-solutions-img.jpg') }}" class="img-fluid animated"
                        alt="">
                </div>
            </div>
        </div>
    </section>

    <section class="executions-solutions">
        <div class="container">
            <div class="sec-title text-left mb-3">

                <h2 class="heading-h2">Freedom to choose how you pay</h2>

            </div>
            <div class="row">

                <div class="col-md-4 col-sm-4">
                    <div class="serviceBox">
                        <div class="service-icon">
                            <i class="bi bi-credit-card"></i>
                        </div>
                        <div class="service-content">
                            <h3 class="title">Zero fees</h3>
                            <div class="text mb-0 text-center">Lorem ipsum dolor sit amet, consectetur adipiscing elit,
                                sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim
                                veniam</div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-4">
                    <div class="serviceBox orange">
                        <div class="service-icon">
                            <i class="bi bi-lightning-charge"></i>
                        </div>
                        <div class="service-content">
                            <h3 class="title">Lightning fast payments</h3>
                            <div class="text mb-0 text-center"> Lorem ipsum dolor sit amet, consectetur adipiscing elit,
                                sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim
                                veniam </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-4">
                    <div class="serviceBox">
                        <div class="service-icon">
                            <i class="bi bi-coin"></i>
                        </div>
                        <div class="service-content">
                            <h3 class="title">200+ crypto currencies</h3>
                            <div class="text mb-0 text-center"> Lorem ipsum dolor sit amet, consectetur adipiscing elit,
                                sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim
                                veniam</div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>


    <section class="wm-marketplace">
        <div class="container">
            <div class="row align-items-center p-2">
                <div class="col-md-6 col-sm-6  order-lg-last text-center">
                    <img src="{{ asset('public/assets/img/execution-img-1.svg') }}" class="img-fluid animated"
                        alt="gift Card Image">

                </div>
                <div class="col-md-6 col-sm-6">
                    <div class="sec-title text-left mb-2">

                        <h2 class="heading-h2">Execution Solutions <span class="yellow-text">with Wealthmark Cashback
                            </span>
                        </h2>

                    </div>
                    <div class="text">
                        At Wealthmanrk, we believe that everyone should have the freedom to earn, hold, spend, share and
                        give their money - no matter who you are or where you come from.
                    </div>

                    <a href="#" class="learn-more btn-6">
                        <span>Learn More </span>
                        <span><i class="bi bi-chevron-right"></i></span>
                    </a>

                </div>


            </div>

            <div class="row align-items-center p-2">
                <div class="col-md-6 col-sm-6 text-center">
                    <img src="{{ asset('public/assets/img/execution-img-1.svg') }}" class="img-fluid animated"
                        alt="gift Card Image">
                </div>
                <div class="col-md-6 col-sm-6">
                    <div class="sec-title text-left mb-2">

                        <h2 class="heading-h2"> <span class="yellow-text"> Lowest Fees </span>on Execution Solutions
                        </h2>

                    </div>
                    <div class="text">
                        At Wealthmanrk, we believe that everyone should have the freedom to earn, hold, spend, share and
                        give their money - no matter who you are or where you come from.
                    </div>
                    <div class="text">
                        *Third-party fees may still be applicable
                    </div>

                    <a href="#" class="learn-more btn-6">
                        <span>Learn More </span>
                        <span><i class="bi bi-chevron-right"></i></span>
                    </a>

                </div>


            </div>

            <div class="row align-items-center p-2">
                <div class="col-md-6 col-sm-6  order-lg-last text-center">
                    <img src="{{ asset('public/assets/img/execution-img-1.svg') }}" class="img-fluid animated"
                        alt="gift Card Image">
                </div>
                <div class="col-md-6 col-sm-6">
                    <div class="sec-title text-left mb-2">

                        <h2 class="heading-h2"> <span class="yellow-text">Execution </span> when need</h2>

                    </div>
                    <div class="text">
                        At Wealthmanrk, we believe that everyone should have the freedom to earn, hold, spend, share and
                        give their money - no matter who you are or where you come from.
                    </div>

                    <a href="#" class="learn-more btn-6">
                        <span>Learn More </span>
                        <span><i class="bi bi-chevron-right"></i></span>
                    </a>

                </div>


            </div>
            <div class="row align-items-center p-2">
                <div class="col-md-6 col-sm-6 text-center">
                    <img src="{{ asset('public/assets/img/execution-img-4.svg') }}" class="img-fluid animated"
                        alt="gift Card Image">
                </div>
                <div class="col-md-6 col-sm-6">
                    <div class="sec-title text-left mb-2">

                        <h2 class="heading-h2">All Types of <span class="yellow-text">Solutions </span></h2>

                    </div>
                    <div class="text">
                        At Wealthmanrk, we believe that everyone should have the freedom to earn, hold, spend, share and
                        give their money - no matter who you are or where you come from.
                    </div>

                    <a href="#" class="learn-more btn-6">
                        <span>User Protection Commitment &gt; </span>
                        <span><i class="bi bi-chevron-right"></i></span>
                    </a>

                </div>


            </div>


        </div>
    </section>

    <section class="execution_solutions-faq">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-xs-6 col-sm-6 sec-title text-left popular-head-block">
                            <span class="title">Know About</span>
                            <h2 class="heading-h2">Execution <span class="yellow-text"> Solutions FAQ</span></h2>
                        </div>
                    </div>

                    <div class="row">
                        <div class="faq-inner-block" id="faq-inner-section">
                            <div class="col-md-12">
                            <div class="accordion" id="accordian-api">
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingOne">
                                    <button class="accordion-button" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                        1. What is Wealthmark Pay?
                                    </button>
                                </h2>
                                <div id="collapseOne" class="accordion-collapse collapse show"
                                    aria-labelledby="headingOne" data-bs-parent="#accordian-api">
                                    <div class="accordion-body">
                                        <strong>This is the first item's accordion body.</strong> It is shown by
                                        default, until the collapse plugin adds the appropriate classes that we use to
                                        style each element. These classes control the overall appearance, as well as the
                                        showing and hiding via CSS transitions. You can modify any of this with custom
                                        CSS or overriding our default variables. It's also worth noting that just about
                                        any HTML can go within the <code>.accordion-body</code>, though the transition
                                        does limit overflow.
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingTwo">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                        2. Can I pay with Bitcoin, Wealthmark and other cryptocurrencies supported by
                                        Wealthmark?
                                    </button>
                                </h2>
                                <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo"
                                    data-bs-parent="#accordian-api">
                                    <div class="accordion-body">
                                        <strong>You can access your Wealthmark Pay Wallet by clicking [Wallets] -
                                            [Funding] - [Pay] on your Wealthmark App.
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingThree">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapseThree" aria-expanded="false"
                                        aria-controls="collapseThree">
                                        3. How long does it take for a Wealthmark Pay transaction to be completed?
                                    </button>
                                </h2>
                                <div id="collapseThree" class="accordion-collapse collapse"
                                    aria-labelledby="headingThree" data-bs-parent="#accordian-api">
                                    <div class="accordion-body">
                                        <strong>Wealthmark Pay transactions are usually confirmed instantly.
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingfour">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapsefour" aria-expanded="false"
                                        aria-controls="collapsefour">
                                        4. Can I pay with Bitcoin, Wealthmark and other cryptocurrencies supported by
                                        Wealthmark?
                                    </button>
                                </h2>
                                <div id="collapsefour" class="accordion-collapse collapse" aria-labelledby="headingfour"
                                    data-bs-parent="#accordian-api">
                                    <div class="accordion-body">
                                        <strong>You can access your Wealthmark Pay Wallet by clicking [Wallets] -
                                            [Funding] - [Pay] on your Wealthmark App.
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingfive">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapsefive" aria-expanded="false"
                                        aria-controls="collapsefive">
                                        5. How long does it take for a Wealthmark Pay transaction to be completed?
                                    </button>
                                </h2>
                                <div id="collapsefive" class="accordion-collapse collapse" aria-labelledby="headingfive"
                                    data-bs-parent="#accordian-api">
                                    <div class="accordion-body">
                                        <strong>Wealthmark Pay transactions are usually confirmed instantly.
                                    </div>
                                </div>
                            </div>
                        </div>  
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    </section>




    @include('template.country_language')
    @include('template.web_footer')
</body>

</html>