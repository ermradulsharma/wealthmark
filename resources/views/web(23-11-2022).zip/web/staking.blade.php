  <!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
   <head>
      <meta charset="utf-8">
      <meta content="width=device-width, initial-scale=1.0" name="viewport">
      <title>Wealth Mark | Create Entity Account</title>
  @include('template.web_css')
      
  
 <style>
     #header{
         background:white;
         
     }
    
 </style>
  
  
   </head>
   
 <body class="bg-white">
     
     @include('template.mobile_menu')
        @include('template.web_menu')
    
    <section  class="breadcrumbs shadow-sm auto-invesment pt-5 pb-5">
          <div class="container-fluid">
              <div class="row justify-content-center align-items-center text-center">
                 <div class="col-lg-5 p-3 " data-aos="fade-up" data-aos-delay="200">
                 <h3 class="top-heading mb-0 text-center">Wealthmark DeFi Staking</h3>
                 <p class="top-p text-center">Dedicated to increasing user staking income</p>
               
                 </div>
                
              </div>
            </div>
      </section>
    
 
    
    
    
    
 <section class="bg-white Staking">
  <div class="container">
    <div class="staking-top">
      <div class="search-div">
        <input  placeholder="Choose/Search Coin" style="color:inherit;flex:1 1 auto">
        <svg viewBox="0 0 24 24" fill="none" class="svg-search">
          <path d="M3 10.982c0 3.845 3.137 6.982 6.982 6.982 1.518 0 3.036-.506 4.149-1.416L18.583 21 20 19.583l-4.452-4.452c.81-1.113 1.416-2.631 1.416-4.149 0-1.922-.81-3.643-2.023-4.958C13.726 4.81 11.905 4 9.982 4 6.137 4 3 7.137 3 10.982zM13.423 7.44a4.819 4.819 0 011.416 3.441c0 1.315-.506 2.53-1.416 3.44a4.819 4.819 0 01-3.44 1.417 4.819 4.819 0 01-3.441-1.417c-1.012-.81-1.518-2.023-1.518-3.339 0-1.315.506-2.53 1.416-3.44.911-1.012 2.227-1.518 3.542-1.518 1.316 0 2.53.506 3.44 1.416z" fill="currentColor"></path>
        </svg>
      </div>
      <label class="lbl-fillter-optn">
        <div class="lbl-fillter-check-div">
          <input type="checkbox"  name="remember" >
          
        </div>
        <div class="lbl-fillter-text">Display available only</div>
      </label>
      <label class="lbl-fillter-optn">
        <div class="lbl-fillter-check-div">
          <input type="checkbox"   name="remember">
        
        </div>
        <div class="lbl-fillter-text">Match My Assets</div>
      </label>
    </div>
 
      <div class="stating-2">
        <div class="stating-2-inner">
          <div class="Staking-History-otpn">
            <div class="stating-heading-div">
              <div class="stating-heading-div-inner">
                <div class="d-flex" STYLE="position:relative">
                  <span class="stating-heading--">DeFi Staking</span>
                  <div class="height-4px"></div>
                </div>
              </div>
            </div>
            <div class="play-video">
              <div class="Staking-History-otpn">
                <div  style="position: relative;height: 24px;width: 155.969px;">
                  <div class="play-video-inner">
                    <div class="play-video-icon-div">
                      <svg viewBox="0 0 24 24" fill="none" class="svg-video">
                        <path d="M12 3.35c-4.8 0-8.8 3.9-8.8 8.8 0 4.8 3.9 8.8 8.8 8.8s8.8-3.9 8.8-8.8c0-4.8-4-8.8-8.8-8.8zm0 15.6c-3.7 0-6.8-3-6.8-6.8 0-3.7 3-6.8 6.8-6.8s6.8 3 6.8 6.8c0 3.7-3.1 6.8-6.8 6.8z" fill="currentColor"></path>
                        <path d="M16.5 12.15l-6.8-3.9v7.8l6.8-3.9z" fill="currentColor"></path>
                      </svg>
                    </div>
                    <div class="play-video-text-div">Video Guide <svg viewBox="0 0 24 24" fill="none" class="svg-chevron-right">
                        <path d="M13.5 12L7 18.6 8.4 20l8-8-8-8L7 5.4l6.5 6.6z" fill="currentColor"></path>
                      </svg>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
         
        </div>
      </div>
      <div class="staking-tbl-heaading-div">
        <div class="staking-tbl-heaading">Token</div>
        <div class="staking-tbl-heaading">Est. APR</div>
        <div class="staking-tbl-heaading">Duration (days)
        <div class="div____" data-bs-toggle="tooltip" data-bs-placement="top" title="" data-bs-original-title="The actual period that assets are transferred back to your Spot wallet">
           
            <svg viewBox="0 0 24 24" fill="none" class="svg-info">
              <path fill-rule="evenodd" clip-rule="evenodd" d="M12 4c4.411 0 8 3.589 8 8s-3.589 8-8 8-8-3.589-8-8 3.589-8 8-8zm0-2C6.477 2 2 6.477 2 12s4.477 10 10 10 10-4.477 10-10S17.523 2 12 2zm.997 9.004h-2.009v6h2.009v-6zm-2.009-4h2.009v2.009h-2.009v-2.01z" fill="currentColor"></path>
            </svg>
          </div>
        </div>
        <div class="staking-min-amt">Minimum Locked Amount</div>
        <div class="flex-div-blank">
          <div class="width-90px"></div>
        </div>
      </div>
      <div class="staking-tbl-record-row">
        <div class="d-flex justify-content-between align-items-center px-5 w-100">
          <div class="staking-desc-div">
            <div class="staking-lbl-div">
              <img src="{{ asset('public/assets/img/empty-label.png') }}" class="staking-lbl-bgimg">
              <div class="staking-lbl-bgtxt">
                <div class="lbl-bgtxt-inner">VENUS</div>
              </div>
            </div>
            <div class="staking-coin-img-div">
              <img class="staking-coin-img" src="{{ asset('public/assets/img/359ca651-a084-4010-92d8-4eaff96e6384.png') }}">
            </div>LTC
          </div>
          <div class="staking-est-amt">1.4%</div>
          <div class="staking-duration">
            <div class="d-flex flex-wrap w-100">
              <button type="button" class=" s-duration-btn-yellow">Flexible Lock</button>
            </div>
          </div>
          <div class="staking-min-amt">0.001LTC</div>
          <div class="staking-btn-div">
            <button type="button"  class="btn btn-yellow shadow-none border-0">Stake Now</button>
          </div>
        </div>
      </div>
      <div class="staking-tbl-record-row">
        <div class="d-flex justify-content-between align-items-center px-5 w-100">
          <div class="staking-desc-div">
            <div class="staking-lbl-div">
              <img src="{{ asset('public/assets/img/empty-label.png') }}" class="staking-lbl-bgimg">
              <div class="staking-lbl-bgtxt">
                <div class="lbl-bgtxt-inner">VENUS</div>
              </div>
            </div>
            <div class="staking-coin-img-div">
              <img class="staking-coin-img" src="{{ asset('public/assets/img/4766a9cc-8545-4c2b-bfa4-cad2be91c135.png') }}">
            </div>XRP
          </div>
          <div class="staking-est-amt">1.39%</div>
          <div class="staking-duration">
            <div class="d-flex flex-wrap w-100">
              <button type="button" class=" s-duration-btn-yellow">Flexible Lock</button>
            </div>
          </div>
          <div class="staking-min-amt">0.001XRP</div>
          <div class="staking-btn-div">
            <button type="button" class="btn btn-yellow shadow-none border-0">Stake Now</button>
          </div>
        </div>
      </div>
      <div class="staking-tbl-record-row">
        <div class="d-flex justify-content-between align-items-center px-5 w-100">
          <div class="staking-desc-div">
            <div class="staking-lbl-div">
              <img src="{{ asset('public/assets/img/empty-label.png') }}" class="staking-lbl-bgimg">
              <div class="staking-lbl-bgtxt">
                <div class="lbl-bgtxt-inner">VENUS</div>
              </div>
            </div>
            <div class="staking-coin-img-div">
              <img class="staking-coin-img" src="{{ asset('public/assets/img/3222a10d-5618-4100-8476-ee7fe0a6fb12.png') }}">
            </div>BUSD
          </div>
          <div class="staking-est-amt">5%</div>
          <div class="staking-duration">
            <div class="d-flex flex-wrap w-100">
              <button type="button" class=" s-duration-btn-yellow">Flexible Lock</button>
              <button type="button" class=" s-duration-btn-gry">120</button>
            </div>
          </div>
          <div class="staking-min-amt">0.0001BUSD</div>
          <div class="staking-btn-div">
            <button type="button"  class="btn btn-yellow shadow-none border-0">Stake Now</button>
          </div>
        </div>
      </div>
      <div class="staking-tbl-record-row">
        <div class="d-flex justify-content-between align-items-center px-5 w-100">
          <div class="staking-desc-div">
            <div class="staking-lbl-div">
              <img src="{{ asset('public/assets/img/empty-label.png') }}" class="staking-lbl-bgimg">
              <div class="staking-lbl-bgtxt">
                <div class="lbl-bgtxt-inner">VENUS</div>
              </div>
            </div>
            <div class="staking-coin-img-div">
              <img class="staking-coin-img" src="{{ asset('public/assets/img/3a8c9fe6-2a76-4ace-aa07-415d994de6f0.png') }}">
            </div>ETH
          </div>
          <div class="staking-est-amt">3.9%</div>
          <div class="staking-duration">
            <div class="d-flex flex-wrap w-100">
              <button type="button" class="s-duration-btn-yellow">Flexible Lock</button>
              <button type="button" class="s-duration-btn-gry">120</button>
            </div>
          </div>
          <div class="staking-min-amt">0.001ETH</div>
          <div class="staking-btn-div">
            <div class="sold-out-div">Sold out</div>
            <button type="button" class=" staking-check-btn">Check</button>
          </div>
        </div>
      </div>
      <div class="staking-tbl-record-row">
        <div class="d-flex justify-content-between align-items-center px-5 w-100">
          <div class="staking-desc-div">
            <div class="staking-lbl-div">
              <img src="{{ asset('public/assets/img/empty-label.png') }}" class="staking-lbl-bgimg">
              <div class="staking-lbl-bgtxt">
                <div class="lbl-bgtxt-inner">VENUS</div>
              </div>
            </div>
            <div class="staking-coin-img-div">
              <img class="staking-coin-img" src="{{ asset('public/assets/img/87496d50-2408-43e1-ad4c-78b47b448a6a.png') }}">
            </div>BTC
          </div>
          <div class="staking-est-amt">3.1%</div>
          <div class="staking-duration">
            <div class="d-flex flex-wrap w-100">
              <button type="button" class="s-duration-btn-gry">Flexible Lock</button>
              <button type="button" class="s-duration-btn-yellow">60</button>
            </div>
          </div>
          <div class="staking-min-amt">0.0001BTC</div>
          <div class="staking-btn-div">
            <div class="sold-out-div">Sold out</div>
            <button type="button"  class=" staking-check-btn">Check</button>
          </div>
        </div>
      </div>
      
      
      
      
      
      <!-------------------------mob------------------------------>
      <div class="hide-on-desktop">
      <div class="staking-assets">
  <div class="staking-assets-main">DeFi Staking Asset
  <svg viewBox="0 0 24 24" fill="none" class="svg-chevron-right">
      <path d="M14.65 12.24l-4.24 4.24L9 15.06l2.82-2.82L9 9.42 10.41 8l4.24 4.24z" fill="currentColor"></path>
    </svg>
  </div>
  <div class="bg-border"></div>
  <div class="Staking-History">DeFi Staking History <div class="Staking-History-otpn">Subscription <svg viewBox="0 0 24 24" fill="none" class="svg-chevron-right">
        <path d="M14.65 12.24l-4.24 4.24L9 15.06l2.82-2.82L9 9.42 10.41 8l4.24 4.24z" fill="currentColor"></path>
      </svg>
    </div>
    <div class="Staking-History-otpn">Redemption <svg viewBox="0 0 24 24" fill="none" class="svg-chevron-right">
        <path d="M14.65 12.24l-4.24 4.24L9 15.06l2.82-2.82L9 9.42 10.41 8l4.24 4.24z" fill="currentColor"></path>
      </svg>
    </div>
    <div class="Staking-History-otpn">Interest <svg viewBox="0 0 24 24" fill="none" class="svg-chevron-right">
        <path d="M14.65 12.24l-4.24 4.24L9 15.06l2.82-2.82L9 9.42 10.41 8l4.24 4.24z" fill="currentColor"></path>
      </svg>
    </div>
  </div>
</div>
      
      
      <div>
  <div class="staking-tbl-record-row-mob">
    <div class="record-div-mob">
      <div class="record-div-mob-inner">
        <img class="staking-coin-img" src="{{ asset('public/assets/img/359ca651-a084-4010-92d8-4eaff96e6384.png') }}">
        <div class="coin-name-mob">LTC</div>
      </div>
      <div class="bg-lbl-mob">VENUS</div>
    </div>
    <div class="staking-desc-div-mob">
      <div class="d-flex align-items center">
        <div class="staking-est-month">APR</div>
        <div class="staking-est-amt-mob">1.4%</div>
      </div>
      <div class="d-flex align-items center">
        <div class="staking-view-text">View</div>
        <svg viewBox="0 0 24 24" fill="none" class="svg-down-arrow-bold">
          <path fill-rule="evenodd" clip-rule="evenodd" d="M12.11 12.178L16 8.287l1.768 1.768-5.657 5.657-1.768-1.768-3.889-3.889 1.768-1.768 3.889 3.89z" fill="currentColor"></path>
        </svg>
      </div>
    </div>
  </div>
  <div class="staking-tbl-record-row-mob">
    <div class="record-div-mob">
      <div class="record-div-mob-inner">
        <img class="staking-coin-img" src="{{ asset('public/assets/img/4766a9cc-8545-4c2b-bfa4-cad2be91c135.png') }}">
        <div class="coin-name-mob">XRP</div>
      </div>
      <div class="bg-lbl-mob">VENUS</div>
    </div>
    <div class="staking-desc-div-mob">
      <div class="d-flex align-items center">
        <div class="staking-est-month">APR</div>
        <div class="staking-est-amt-mob">1.39%</div>
      </div>
      <div class="d-flex align-items center">
        <div class="staking-view-text">View</div>
        <svg viewBox="0 0 24 24" fill="none" class="svg-down-arrow-bold">
          <path fill-rule="evenodd" clip-rule="evenodd" d="M12.11 12.178L16 8.287l1.768 1.768-5.657 5.657-1.768-1.768-3.889-3.889 1.768-1.768 3.889 3.89z" fill="currentColor"></path>
        </svg>
      </div>
    </div>
  </div>
  <div class="staking-tbl-record-row-mob">
    <div class="record-div-mob">
      <div class="record-div-mob-inner">
        <img class="staking-coin-img" src="{{ asset('public/assets/img/3222a10d-5618-4100-8476-ee7fe0a6fb12.png') }}">
        <div class="coin-name-mob">BUSD</div>
      </div>
      <div class="bg-lbl-mob">VENUS</div>
    </div>
    <div class="staking-desc-div-mob">
      <div class="d-flex align-items center">
        <div class="staking-est-month">APR</div>
        <div class="staking-est-amt-mob">4.6%~5%</div>
      </div>
      <div class="d-flex align-items center">
        <div class="staking-view-text">View</div>
        <svg viewBox="0 0 24 24" fill="none" class="svg-down-arrow-bold">
          <path fill-rule="evenodd" clip-rule="evenodd" d="M12.11 12.178L16 8.287l1.768 1.768-5.657 5.657-1.768-1.768-3.889-3.889 1.768-1.768 3.889 3.89z" fill="currentColor"></path>
        </svg>
      </div>
    </div>
  </div>
  <div class="staking-tbl-record-row-mob">
    <div class="record-div-mob">
      <div class="record-div-mob-inner">
        <img class="staking-coin-img" src="{{ asset('public/assets/img/3a8c9fe6-2a76-4ace-aa07-415d994de6f0.png') }}">
        <div class="coin-name-mob">ETH</div>
      </div>
      <div class="bg-lbl-mob">VENUS</div>
    </div>
    <div class="staking-desc-div-mob">
      <div class="d-flex align-items center">
        <div class="staking-est-month">APR</div>
        <div class="staking-est-amt-mob">0.92%~3.9%</div>
      </div>
      <div class="d-flex align-items center">
        <div class="staking-view-text">View</div>
        <svg viewBox="0 0 24 24" fill="none" class="svg-down-arrow-bold">
          <path fill-rule="evenodd" clip-rule="evenodd" d="M12.11 12.178L16 8.287l1.768 1.768-5.657 5.657-1.768-1.768-3.889-3.889 1.768-1.768 3.889 3.89z" fill="currentColor"></path>
        </svg>
      </div>
    </div>
  </div>
  <div class="staking-tbl-record-row-mob">
    <div class="record-div-mob">
      <div class="record-div-mob-inner">
        <img class="staking-coin-img" src="{{ asset('public/assets/img/87496d50-2408-43e1-ad4c-78b47b448a6a.png') }}">
        <div class="coin-name-mob">BTC</div>
      </div>
      <div class="bg-lbl-mob">VENUS</div>
    </div>
    <div class="staking-desc-div-mob">
      <div class="d-flex align-items center">
        <div class="staking-est-month">APR</div>
        <div class="staking-est-amt-mob">0.64%~3.1%</div>
      </div>
      <div class="d-flex align-items center">
        <div class="staking-view-text">View</div>
        <svg viewBox="0 0 24 24" fill="none" class="svg-down-arrow-bold">
          <path fill-rule="evenodd" clip-rule="evenodd" d="M12.11 12.178L16 8.287l1.768 1.768-5.657 5.657-1.768-1.768-3.889-3.889 1.768-1.768 3.889 3.89z" fill="currentColor"></path>
        </svg>
      </div>
    </div>
  </div>
</div>
      
      </div>
      
      
      
      
      
      <div class="view-more-div">
          <div class="pagination-div">
                   <button type="button" class="mirror pagination-back" aria-label="Previous page" disabled="">
                     <svg viewBox="0 0 24 24" fill="none" class="custom-modal-close-icon">
                       <path fill-rule="evenodd" clip-rule="evenodd" d="M11.934 12l3.89 3.89-1.769 1.767L8.398 12l1.768-1.768 3.89-3.889 1.767 1.768-3.889 3.89z" fill="currentColor"></path>
                     </svg>
                   </button>
                   <button type="button" aria-label="Page number 1" class="pagination-active" disabled="">1</button>
                   <button type="button" aria-label="Page number 2" class="pagination-all">2</button>
                   <button type="button" aria-label="Page number 3" class="pagination-all">3</button>
                   <button type="button" aria-label="Page number 4" class="pagination-all">4</button>
                   <button type="button" aria-label="Page number 5" class="pagination-all">5</button>
                   <button type="button" class="mirror pagination-next" aria-label="Next page">
                     <svg viewBox="0 0 24 24" fill="none" class="custom-modal-close-icon">
                       <path fill-rule="evenodd" clip-rule="evenodd" d="M12.288 12l-3.89 3.89 1.768 1.767L15.823 12l-1.768-1.768-3.889-3.889-1.768 1.768 3.89 3.89z" fill="currentColor"></path>
                     </svg>
                   </button>
                 </div>
      </div>
    </div>
  
  
</section>
    
    
    
    
    
    





    
<section class="wm-pay-accordian-section">
    <div class="container">
        <div class="outlet-main-div">
                 <div class="wm-outlet-div">
                           
                            <div class="sec-title text-center mb-2">
                           <h2 class="heading-h2">FAQs</h2>
                            </div>
                           
                        </div>
                         <div class="wm-outlet-div text-right justify-content-end">
                           
                            <a href="#" class="learn-more btn-6">
                           <span>Learn More </span>
                           <span><i class="bi bi-chevron-right"></i></span>
                        </a>
                           
                        </div>
                        </div>
    </div>
    <div class="container">
  <div class="accordion" id="accordionExample">
  <div class="card">
    <div class="card-head" id="headingOne">
      <h2 class="mb-0 collapsed" data-toggle="collapse" data-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
     What is DeFi Staking?
      </h2>
    </div>

    <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
      <div class="card-body">
      <div class="text">  DeFi (Decentralized Finance) is a way of providing financial services to users through smart contracts. Existing DeFi projects aim to provide higher annualized earnings for specific currencies.</div>
      </div>
    </div>
  </div>
  <div class="card">
    <div class="card-head" id="headingTwo">
      <h2 class="mb-0 collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
  About Wealthmark DeFi Staking
      </h2>
    </div>
    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
      <div class="card-body">
       <div class="text">There's a relatively high threshold for users of DeFi products. Wealthmark DeFi Staking acts on behalf of users to participate in certain DeFi products, obtains and distributes realized earnings, and helps users to participate in DeFi products with a single click.</div>
      
      </div>
    </div>
  </div>
  <div class="card">
    <div class="card-head" id="headingThree">
      <h2 class="mb-0 collapsed" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
     What are the advantages of DeFi Staking?
      </h2>
    </div>
    <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
      <div class="card-body">
        <div class="text">1. Easy to use: You don't need to manage private keys, acquire resources, make trades, or perform other complicated tasks to participate in DeFi Staking. Wealthmark's one-stop service allows users to obtain generous online rewards without keeping an on-chain wallet. 2. No gas fee: Wealthmark Staking deposits users’ funds into smart contracts on users’ behalf, saving users on-chain gas fees.</div>
      </div>
    </div>
  </div>
  
  
  <div class="card">
    <div class="card-head" id="headingFour">
      <h2 class="mb-0 collapsed" data-toggle="collapse" data-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
   After I participate in DeFi Staking, how is the earnings cycle calculated?
      </h2>
    </div>
    <div id="collapseFour" class="collapse" aria-labelledby="headingFour" data-parent="#accordionExample">
      <div class="card-body">
  <div class="text">Once funds are successfully allocated to DeFi Staking, earnings are calculated beginning at 00:00 (UTC) the following day. The minimum earnings calculation period is one day; earnings for a period of less than one day will not be included in the earnings distribution.</div>     
      </div>
    </div>
  </div>
  
  
</div>
</div>
</section>




  @include('template.country_language')
    @include('template.web_footer') 
    
     <!--<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>-->
 <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/js/bootstrap.min.js"></script> 
  
    </body>
</html>