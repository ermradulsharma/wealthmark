<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <title>Wealth Mark | {{ Request::segment(2) }}</title>
    @include('template.web_css')
    <link rel='stylesheet' href="{{('../public/assets/css/deepak_custom.css') }}">
</head>
<body>
    @include('template.mobile_menu')
    @include('template.web_menu')
    <section class="help-support-search">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-lg-12 col-sm-6 colxs-6">
                    <div class="sec-title text-left mb-5">
                        <span class="title">Know About</span>
                        <h2 class="heading-h2">Search FAQ</h2>
                    </div>
                    <div class="input-group">
                        <input type="text" class="form-control" placeholder="Search Help Articles"
                            aria-label="Search Help Articles" aria-describedby="basic-addon2">
                        <span class="input-group-text" id="basic-addon2">Search</span>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="self-service-section" id="self-service-box">
        <div class="container">
            <div class="row">
            <div class="sec-title text-left mb-5">
                        <span class="title">Know About</span>
                        <h2 class="heading-h2">Self-Service</h2>
                    </div>
                <div class="col-md-2 col-lg-2 col-sm-6 colxs-6">
                    <div class="services-inner-box">
                        <svg  viewBox="0 0 96 96" fill="none" class="css-sg71kl">
                            <path opacity="0.3" fill-rule="evenodd" clip-rule="evenodd"
                                d="M48.001 53v39l36-24V8h-36v43H51v2h-2.999zM57 16h-4v-4h4v4zm10 13l-2-2 2-2 2 2-2 2zm-2 24v-2h8v2h-8zm-11-2h8v2h-8v-2z"
                                fill="#AEB4BC"></path>
                            <path opacity="0.3" fill-rule="evenodd" clip-rule="evenodd"
                                d="M12.001 68.043l36 23.957V53H43v-2h5.001V8h-36v60.043zM35 71l4 4 4-4-4-4-4 4zm-4-31a3 3 0 00-3 3v3h-2v-3a5 5 0 0110 0v3h-2v-3a3 3 0 00-3-3z"
                                fill="url(#security-password_svg__paint0_linear_26712_54930)"></path>
                            <path fill-rule="evenodd" clip-rule="evenodd"
                                d="M77 34H19v27h58V34zm-49 9a3 3 0 116 0v3h2v-3a5 5 0 00-10 0v3h2v-3zm23 8h-8v2h8v-2zm14 0h8v2h-8v-2zm-3 0h-8v2h8v-2z"
                                fill="url(#security-password_svg__paint1_linear_26712_54930)"></path>
                            <path d="M23 56h16V46H23v10z" fill="url(#security-password_svg__paint2_linear_26712_54930)">
                            </path>
                            <path d="M32 53v-4h-2v4h2z" fill="url(#security-password_svg__paint3_linear_26712_54930)">
                            </path>
                            <defs>
                                <linearGradient id="security-password_svg__paint0_linear_26712_54930" x1="48.001"
                                    y1="92" x2="48.001" y2="8" gradientUnits="userSpaceOnUse">
                                    <stop stop-color="#AEB4BC" stop-opacity="0.1"></stop>
                                    <stop offset="0.701" stop-color="#AEB4BC"></stop>
                                </linearGradient>
                                <linearGradient id="security-password_svg__paint1_linear_26712_54930" x1="48" y1="34"
                                    x2="48" y2="61" gradientUnits="userSpaceOnUse">
                                    <stop stop-color="#929AA5"></stop>
                                    <stop offset="1" stop-color="#76808F"></stop>
                                </linearGradient>
                                <linearGradient id="security-password_svg__paint2_linear_26712_54930" x1="31" y1="56"
                                    x2="31" y2="46" gradientUnits="userSpaceOnUse">
                                    <stop stop-color="#F0B90B"></stop>
                                    <stop offset="1" stop-color="#F8D33A"></stop>
                                </linearGradient>
                                <linearGradient id="security-password_svg__paint3_linear_26712_54930" x1="31" y1="49"
                                    x2="31" y2="53" gradientUnits="userSpaceOnUse">
                                    <stop stop-color="#929AA5"></stop>
                                    <stop offset="1" stop-color="#76808F"></stop>
                                </linearGradient>
                            </defs>
                        </svg>
                        <p>Reset Account Password </p>
                    </div>
                </div>
                <div class="col-md-2 col-lg-2 col-sm-6 colxs-6">
                    <div class="services-inner-box">
                        <svg width="65" height="64" viewBox="0 0 65 64" fill="none" font-size="64px">
                            <path fill-rule="evenodd" clip-rule="evenodd"
                                d="M49.733 56H8.4V26.667h41.333V38l3.334 3.333-3.334 3.334V56zm-18-22.667v16H26.4v-16h5.333z"
                                fill="url(#paint0_linear)"></path>
                            <path fill-rule="evenodd" clip-rule="evenodd"
                                d="M48.4 50.667A9.333 9.333 0 0048.4 32a9.337 9.337 0 00-8.947 6.667H26.4v10.666h5.333V44h7.72a9.338 9.338 0 008.947 6.667zm-4-9.334l4 4 4-4-4-4-4 4zM15.733 20c0-7.364 5.97-13.333 13.334-13.333S42.4 12.637 42.4 20h-5.333a8 8 0 10-16 0v6.667h-5.334V20z"
                                fill="#76808F"></path>
                            <defs>
                                <linearGradient id="paint0_linear" x1="30.7332" y1="56" x2="30.7332" y2="26.6667"
                                    gradientUnits="userSpaceOnUse">
                                    <stop stop-color="#F0B90B"></stop>
                                    <stop offset="1" stop-color="#F8D33A"></stop>
                                </linearGradient>
                            </defs>
                        </svg>
                        <p>Unlock Personal Account </p>
                    </div>
                </div>
                <div class="col-md-2 col-lg-2 col-sm-6 colxs-6">
                    <div class="services-inner-box">
                        <svg  viewBox="0 0 96 97" fill="none" class="css-sg71kl">
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M84.001 68.131l-36 23.957v-84h36v60.043z"
                                fill="#E6E8EA"></path>
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M48.001 8.088v84l-36-24v-60h36z"
                                fill="url(#security-authenticator-sms-light_svg__paint0_linear)"></path>
                            <path d="M65 65.09H32v-43h33v43z"
                                fill="url(#security-authenticator-sms-light_svg__paint1_linear)"></path>
                            <path d="M32 72.09h33v-7H32v7z"
                                fill="url(#security-authenticator-sms-light_svg__paint2_linear)"></path>
                            <path d="M32 22.09h33v-7H32v7z"
                                fill="url(#security-authenticator-sms-light_svg__paint3_linear)"></path>
                            <path d="M77 27.09H39v20h9v12l12-12h17v-20z"
                                fill="url(#security-authenticator-sms-light_svg__paint4_linear)"></path>
                            <path d="M73 31.09H43v4h30v-4z"
                                fill="url(#security-authenticator-sms-light_svg__paint5_linear)"></path>
                            <path d="M65.001 39.09H43v4h22.001v-4z"
                                fill="url(#security-authenticator-sms-light_svg__paint6_linear)"></path>
                            <path
                                d="M18 46.59l4.5 4.5 4.5-4.5-4.5-4.5-4.5 4.5zM73 17.59l2.5 2.5 2.5-2.5-2.5-2.5-2.5 2.5zM71.001 57.088h3v-3h-3v3z"
                                fill="#fff"></path>
                            <defs>
                                <linearGradient id="security-authenticator-sms-light_svg__paint0_linear" x1="48.001"
                                    y1="8.088" x2="48.001" y2="92.088" gradientUnits="userSpaceOnUse">
                                    <stop stop-color="#FAFAFA"></stop>
                                    <stop offset="1" stop-color="#E6E8EA"></stop>
                                </linearGradient>
                                <linearGradient id="security-authenticator-sms-light_svg__paint1_linear" x1="32"
                                    y1="43.589" x2="65" y2="43.589" gradientUnits="userSpaceOnUse">
                                    <stop stop-color="#F0B90B"></stop>
                                    <stop offset="1" stop-color="#F8D33A"></stop>
                                </linearGradient>
                                <linearGradient id="security-authenticator-sms-light_svg__paint2_linear" x1="65"
                                    y1="43.589" x2="32" y2="43.589" gradientUnits="userSpaceOnUse">
                                    <stop stop-color="#929AA5"></stop>
                                    <stop offset="1" stop-color="#76808F"></stop>
                                </linearGradient>
                                <linearGradient id="security-authenticator-sms-light_svg__paint3_linear" x1="65"
                                    y1="43.589" x2="32" y2="43.589" gradientUnits="userSpaceOnUse">
                                    <stop stop-color="#929AA5"></stop>
                                    <stop offset="1" stop-color="#76808F"></stop>
                                </linearGradient>
                                <linearGradient id="security-authenticator-sms-light_svg__paint4_linear" x1="77"
                                    y1="43.089" x2="39" y2="43.089" gradientUnits="userSpaceOnUse">
                                    <stop stop-color="#929AA5"></stop>
                                    <stop offset="1" stop-color="#76808F"></stop>
                                </linearGradient>
                                <linearGradient id="security-authenticator-sms-light_svg__paint5_linear" x1="43"
                                    y1="37.089" x2="73" y2="37.089" gradientUnits="userSpaceOnUse">
                                    <stop stop-color="#F0B90B"></stop>
                                    <stop offset="1" stop-color="#F8D33A"></stop>
                                </linearGradient>
                                <linearGradient id="security-authenticator-sms-light_svg__paint6_linear" x1="43"
                                    y1="37.089" x2="73" y2="37.089" gradientUnits="userSpaceOnUse">
                                    <stop stop-color="#F0B90B"></stop>
                                    <stop offset="1" stop-color="#F8D33A"></stop>
                                </linearGradient>
                            </defs>
                        </svg>
                        <p>Reset Security Verfification</p>
                    </div>
                </div>
                <div class="col-md-2 col-lg-2 col-sm-6 colxs-6">
                    <div class="services-inner-box">
                        <svg  viewBox="0 0 96 96" fill="none" class="css-sg71kl">
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M48 8v84L12 68V8h36z"
                                fill="url(#security-email-light_svg__paint0_linear)"></path>
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M84 68.043L48 92V8h36v60.043z"
                                fill="#E6E8EA"></path>
                            <path fill="url(#security-email-light_svg__paint1_linear)" d="M22 22h52v41H22z"></path>
                            <path d="M37 70l4 4 4-4-4-4-4 4zM54 15l3 3 3-3-3-3-3 3zM78 53h3v-3h-3v3z" fill="#fff">
                            </path>
                            <path fill-rule="evenodd" clip-rule="evenodd"
                                d="M39.706 44.829L22 62.535v-5.657L36.878 42l2.828 2.829zM56.294 44.829L74 62.535v-5.657L59.122 42l-2.828 2.829z"
                                fill="#E6E8EA"></path>
                            <path d="M48 55l26-26v-7H22v7l26 26z" fill="url(#security-email-light_svg__paint2_linear)">
                            </path>
                            <defs>
                                <linearGradient id="security-email-light_svg__paint0_linear" x1="48" y1="8" x2="48"
                                    y2="92" gradientUnits="userSpaceOnUse">
                                    <stop stop-color="#FAFAFA"></stop>
                                    <stop offset="1" stop-color="#E6E8EA"></stop>
                                </linearGradient>
                                <linearGradient id="security-email-light_svg__paint1_linear" x1="48" y1="22" x2="48"
                                    y2="63" gradientUnits="userSpaceOnUse">
                                    <stop stop-color="#929AA5"></stop>
                                    <stop offset="1" stop-color="#76808F"></stop>
                                </linearGradient>
                                <linearGradient id="security-email-light_svg__paint2_linear" x1="48" y1="55" x2="48"
                                    y2="22" gradientUnits="userSpaceOnUse">
                                    <stop stop-color="#F0B90B"></stop>
                                    <stop offset="1" stop-color="#F8D33A"></stop>
                                </linearGradient>
                            </defs>
                        </svg>
                        <p>Change Email Address</p>
                    </div>
                </div>
                <div class="col-md-2 col-lg-2 col-sm-6 colxs-6">
                    <div class="services-inner-box">
                        <svg  viewBox="0 0 96 97" fill="none" class="css-sg71kl">
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M12.001 68.131l36 23.957v-84h-36v60.043z"
                                fill="url(#security-authenticator-google-light_svg__paint0_linear)"></path>
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M48.001 8.088v84l36-24v-60h-36z"
                                fill="#E6E8EA"></path>
                            <circle cx="48.001" cy="32.088" r="16"
                                fill="url(#security-authenticator-google-light_svg__paint1_linear)"></circle>
                            <path
                                d="M48.001 16.088c-8.837 0-16 7.164-16 16a15.95 15.95 0 004.686 11.314l11.314-11.314v-16z"
                                fill="url(#security-authenticator-google-light_svg__paint2_linear)"></path>
                            <path
                                d="M19.001 44.088l4 4 4-4-4-4-4 4zM73.001 36.588l2.5 2.5 2.5-2.5-2.5-2.5-2.5 2.5zM60.001 16.088h4v-4h-4v4z"
                                fill="#fff"></path>
                            <path d="M24 68.088h48v-16H24v16z"
                                fill="url(#security-authenticator-google-light_svg__paint3_linear)"></path>
                            <path d="M51.001 58.088h15v4h-15v-4z"
                                fill="url(#security-authenticator-google-light_svg__paint4_linear)"></path>
                            <path d="M30.001 58.088h15v4h-15v-4z"
                                fill="url(#security-authenticator-google-light_svg__paint5_linear)"></path>
                            <defs>
                                <linearGradient id="security-authenticator-google-light_svg__paint0_linear" x1="48.001"
                                    y1="92.088" x2="48.001" y2="8.088" gradientUnits="userSpaceOnUse">
                                    <stop stop-color="#FAFAFA"></stop>
                                    <stop offset="1" stop-color="#E6E8EA"></stop>
                                </linearGradient>
                                <linearGradient id="security-authenticator-google-light_svg__paint1_linear" x1="48.001"
                                    y1="16.088" x2="48.001" y2="48.088" gradientUnits="userSpaceOnUse">
                                    <stop stop-color="#929AA5"></stop>
                                    <stop offset="1" stop-color="#76808F"></stop>
                                </linearGradient>
                                <linearGradient id="security-authenticator-google-light_svg__paint2_linear" x1="40.001"
                                    y1="16.088" x2="40.001" y2="43.402" gradientUnits="userSpaceOnUse">
                                    <stop stop-color="#F0B90B"></stop>
                                    <stop offset="1" stop-color="#F8D33A"></stop>
                                </linearGradient>
                                <linearGradient id="security-authenticator-google-light_svg__paint3_linear" x1="72"
                                    y1="60.088" x2="24" y2="60.088" gradientUnits="userSpaceOnUse">
                                    <stop stop-color="#929AA5"></stop>
                                    <stop offset="1" stop-color="#76808F"></stop>
                                </linearGradient>
                                <linearGradient id="security-authenticator-google-light_svg__paint4_linear" x1="30.001"
                                    y1="60.088" x2="66.001" y2="60.088" gradientUnits="userSpaceOnUse">
                                    <stop stop-color="#F0B90B"></stop>
                                    <stop offset="1" stop-color="#F8D33A"></stop>
                                </linearGradient>
                                <linearGradient id="security-authenticator-google-light_svg__paint5_linear" x1="30.001"
                                    y1="60.088" x2="66.001" y2="60.088" gradientUnits="userSpaceOnUse">
                                    <stop stop-color="#F0B90B"></stop>
                                    <stop offset="1" stop-color="#F8D33A"></stop>
                                </linearGradient>
                            </defs>
                        </svg>
                        <p>Reset Google Authenticator</p>
                    </div>
                </div>
                <div class="col-md-2 col-lg-2 col-sm-6 colxs-6">
                    <div class="services-inner-box">
                        <svg  viewBox="0 0 96 96" fill="none" class="css-sg71kl">
                            <circle r="20" transform="matrix(1 0 0 -1 48 48)" fill="#F8D33A"></circle>
                            <circle r="13.684" transform="matrix(1 0 0 -1 48 48.002)"
                                fill="url(#recover-deposit_svg__paint0_linear_26712_54999)"></circle>
                            <path d="M40.632 48L48 55.37 55.368 48 48 40.632 40.632 48z" fill="#F0B90B"></path>
                            <path opacity="0.3"
                                d="M48 8c22.091 0 40 17.909 40 40S70.091 88 48 88v-8c17.673 0 32-14.327 32-32 0-17.673-14.327-32-32-32V8zM82 11l3 3 3-3-3-3-3 3zM39 76l2 2 2-2-2-2-2 2zM8 25h3v-3H8v3z"
                                fill="#AEB4BC"></path>
                            <path
                                d="M8 48C8 25.909 25.909 8 48 8v8c-17.673 0-32 14.327-32 32 0 8.838 3.577 16.832 9.373 22.627L31 65v17H14l5.716-5.716C12.48 69.05 8 59.044 8 48z"
                                fill="url(#recover-deposit_svg__paint1_linear_26712_54999)"></path>
                            <defs>
                                <linearGradient id="recover-deposit_svg__paint0_linear_26712_54999" x1="13.684" y1="0"
                                    x2="13.684" y2="27.368" gradientUnits="userSpaceOnUse">
                                    <stop stop-color="#F0B90B"></stop>
                                    <stop offset="1" stop-color="#F8D33A"></stop>
                                </linearGradient>
                                <linearGradient id="recover-deposit_svg__paint1_linear_26712_54999" x1="28" y1="8"
                                    x2="28" y2="82" gradientUnits="userSpaceOnUse">
                                    <stop stop-color="#929AA5"></stop>
                                    <stop offset="1" stop-color="#76808F"></stop>
                                </linearGradient>
                            </defs>
                        </svg>
                        <p>Crypto Deposit Not Credited</p>
                    </div>
                </div>
            </div>


        </div>
    </section>

    <section class="fee-rate-section">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <div class="sec-title">
                        <span class="title">Know About</span>
                        <h2 class="heading-h2">FAQ</h2>
                    </div>
                    <div class="text">Select a team most relevant to your interests and experience to view job openings
                    </div>

                </div>
            </div>

            <div class="fees-faq-main-box">
                <a href="#" class="faq-inner-box">
                    <svg  viewBox="0 0 24 24" fill="none" class="faq-inner-svg">
                        <path transform="matrix(1 0 0 -1 3 19)" fill="url(#business-development-g_svg__paint0)"
                            d="M0 0h3v4H0z"></path>
                        <path fill="#76808F" d="M8 11h3v10H8zM13 6h3v15h-3zM18 3h3v18h-3z"></path>
                        <path transform="matrix(1 0 0 -1 8 21)" fill="url(#business-development-g_svg__paint1)"
                            d="M0 0h3v6H0z"></path>
                        <path transform="matrix(1 0 0 -1 13 21)" fill="url(#business-development-g_svg__paint2)"
                            d="M0 0h3v10H0z"></path>
                        <path transform="matrix(1 0 0 -1 18 21)" fill="url(#business-development-g_svg__paint3)"
                            d="M0 0h3v15H0z"></path>
                        <path fill="#76808F" d="M3 19h18v2H3zM3 3h2v2H3zM3 7h2v2H3zM3 11h2v2H3z"></path>
                        <defs>
                            <linearGradient id="business-development-g_svg__paint0" x1="1.5" y1="0" x2="1.5" y2="4"
                                gradientUnits="userSpaceOnUse">
                                <stop stop-color="#F0B90B"></stop>
                                <stop offset="1" stop-color="#F8D33A"></stop>
                            </linearGradient>
                            <linearGradient id="business-development-g_svg__paint1" x1="1.5" y1="0" x2="1.5" y2="6"
                                gradientUnits="userSpaceOnUse">
                                <stop stop-color="#F0B90B"></stop>
                                <stop offset="1" stop-color="#F8D33A"></stop>
                            </linearGradient>
                            <linearGradient id="business-development-g_svg__paint2" x1="1.5" y1="0" x2="1.5" y2="10"
                                gradientUnits="userSpaceOnUse">
                                <stop stop-color="#F0B90B"></stop>
                                <stop offset="1" stop-color="#F8D33A"></stop>
                            </linearGradient>
                            <linearGradient id="business-development-g_svg__paint3" x1="1.5" y1="0" x2="1.5" y2="15"
                                gradientUnits="userSpaceOnUse">
                                <stop stop-color="#F0B90B"></stop>
                                <stop offset="1" stop-color="#F8D33A"></stop>
                            </linearGradient>
                        </defs>
                    </svg>
                    <div class="faq-inner-box-div">
                        <div class="faq-inner-box-div-txt">Account Functions</div>
                    </div>
                </a>
                <a href="#" class="faq-inner-box">
                    <svg  viewBox="0 0 50 50" fill="none" class="faq-inner-svg">
                        <path
                            d="M26.786 8.333c8.054 0 14.584 6.53 14.584 14.584h4.166c0-10.356-8.394-18.75-18.75-18.75v4.166z"
                            fill="#76808F"></path>
                        <path
                            d="M35.416 14.583V37.5h-4.167V21.696l-6.755 6.756-2.947-2.947 6.756-6.755H12.499v-4.167h22.917zM4.88 42.172l8.334-8.333 2.946 2.946-8.333 8.334-2.946-2.947z"
                            fill="#76808F"></path>
                        <path
                            d="M10.268 39.731c8.136 8.136 21.327 8.136 29.463 0L10.268 10.27c-8.136 8.136-8.136 21.327 0 29.462z"
                            fill="url(#communications-g_svg__paint0_linear_2218_19589)"></path>
                        <defs>
                            <linearGradient id="communications-g_svg__paint0_linear_2218_19589" x1="21.948" y1="45.833"
                                x2="21.948" y2="10.269" gradientUnits="userSpaceOnUse">
                                <stop stop-color="#F0B90B"></stop>
                                <stop offset="1" stop-color="#F8D33A"></stop>
                            </linearGradient>
                        </defs>
                    </svg>
                    <div class="faq-inner-box-div">
                        <div class="faq-inner-box-div-txt">Tutorial</div>
                    </div>
                </a>
                <a href="#" class="faq-inner-box">
                    <svg  viewBox="0 0 24 24" fill="none" class="faq-inner-svg">
                        <path d="M6 10a6 6 0 1112 0v7h2v-7a8 8 0 10-16 0v7h2v-7zM12 18a2.5 2.5 0 110 5 2.5 2.5 0 010-5z"
                            fill="#76808F"></path>
                        <path d="M.5 13.5A3.5 3.5 0 004 17v-7a3.5 3.5 0 00-3.5 3.5z"
                            fill="url(#customer-service-g_svg__paint0_linear)"></path>
                        <path d="M23.5 13.5A3.5 3.5 0 0120 17v-7a3.5 3.5 0 013.5 3.5z"
                            fill="url(#customer-service-g_svg__paint1_linear)"></path>
                        <defs>
                            <linearGradient id="customer-service-g_svg__paint0_linear" x1="12" y1="17" x2="12" y2="10"
                                gradientUnits="userSpaceOnUse">
                                <stop stop-color="#F0B90B"></stop>
                                <stop offset="1" stop-color="#F8D33A"></stop>
                            </linearGradient>
                            <linearGradient id="customer-service-g_svg__paint1_linear" x1="12" y1="17" x2="12" y2="10"
                                gradientUnits="userSpaceOnUse">
                                <stop stop-color="#F0B90B"></stop>
                                <stop offset="1" stop-color="#F8D33A"></stop>
                            </linearGradient>
                        </defs>
                    </svg>
                    <div class="faq-inner-box-div">
                        <div class="faq-inner-box-div-txt">Wealth Mark Fan Token</div>
                    </div>
                </a>
                <a href="#" class="faq-inner-box">
                    <svg  viewBox="0 0 24 24" fill="none" class="faq-inner-svg">
                        <path fill-rule="evenodd" clip-rule="evenodd"
                            d="M22 19.879l-5.94-5.94L15 15l-1.06 1.062L19.879 22 22 19.879z" fill="#76808F"></path>
                        <path fill-rule="evenodd" clip-rule="evenodd"
                            d="M15.94 10a6 6 0 10-12 0 6 6 0 0012 0zm-6-8a8 8 0 110 16 8 8 0 010-16z"
                            fill="url(#zoom-in-g_svg__paint0_linear)"></path>
                        <path d="M9 11v3h2v-3h3V9h-3V6H9v3H6v2h3z" fill="#76808F"></path>
                        <defs>
                            <linearGradient id="zoom-in-g_svg__paint0_linear" x1="9.939" y1="18" x2="9.939" y2="2"
                                gradientUnits="userSpaceOnUse">
                                <stop stop-color="#F0B90B"></stop>
                                <stop offset="1" stop-color="#F8D33A"></stop>
                            </linearGradient>
                        </defs>
                    </svg>
                    <div class="faq-inner-box-div">
                        <div class="faq-inner-box-div-txt">Wealth Mark Earn</div>
                    </div>
                </a>
                <a href="#" class="faq-inner-box">
                    <svg  viewBox="0 0 24 24" fill="none" class="faq-inner-svg">
                        <circle r="10" transform="matrix(1 0 0 -1 12 12)"
                            fill="url(#circled-play-g_svg__paint0_linear)"></circle>
                        <path d="M17 12L9 7v10l8-5z" fill="#76808F"></path>
                        <defs>
                            <linearGradient id="circled-play-g_svg__paint0_linear" x1="10" y1="0" x2="10" y2="20"
                                gradientUnits="userSpaceOnUse">
                                <stop stop-color="#F0B90B"></stop>
                                <stop offset="1" stop-color="#F8D33A"></stop>
                            </linearGradient>
                        </defs>
                    </svg>
                    <div class="faq-inner-box-div">
                        <div class="faq-inner-box-div-txt">Crypto Deposit/Withdrawal</div>
                    </div>
                </a>
                <a href="#" class="faq-inner-box">
                    <svg  viewBox="0 0 50 50" fill="none" class="faq-inner-svg">
                        <path fill-rule="evenodd" clip-rule="evenodd"
                            d="M45.833 8.333H4.166v33.334h41.667V8.333zm-6.25 22.917H22.916v4.167h16.667V31.25z"
                            fill="url(#programming-g_svg__paint0_linear_2218_19591)"></path>
                        <path
                            d="M4.166 8.333h41.667V12.5H4.166V8.333zM9.048 19.107l2.946-2.946L20.833 25l-8.839 8.839-2.946-2.947L14.94 25l-5.892-5.893z"
                            fill="#76808F"></path>
                        <defs>
                            <linearGradient id="programming-g_svg__paint0_linear_2218_19591" x1="24.999" y1="41.667"
                                x2="24.999" y2="8.333" gradientUnits="userSpaceOnUse">
                                <stop stop-color="#F0B90B"></stop>
                                <stop offset="1" stop-color="#F8D33A"></stop>
                            </linearGradient>
                        </defs>
                    </svg>
                    <div class="faq-inner-box-div">
                        <div class="faq-inner-box-div-txt">Buy Crypto (Fiat/P2P)</div>
                    </div>
                </a>
                <a href="#" class="faq-inner-box">
                    <svg  viewBox="0 0 24 24" fill="none" class="faq-inner-svg">
                        <circle r="10" transform="matrix(1 0 0 -1 12 12)" fill="url(#payment-g_svg__paint0_linear)">
                        </circle>
                        <path
                            d="M13.088 20v-1.782c2.468-.408 3.62-1.949 3.62-3.768 0-1.893-1.244-2.951-3.843-3.545V7.824c.89.204 1.485.612 1.93 1.113l1.69-1.522c-.817-.928-1.912-1.503-3.397-1.67V4h-2.116v1.745c-2.395.278-3.675 1.578-3.675 3.526 0 1.8 1.132 3.026 3.916 3.601v3.341c-1.04-.148-1.912-.65-2.617-1.392l-1.67 1.522c.927 1.021 2.171 1.782 4.046 1.95V20h2.116zM9.858 9.197c0-.724.408-1.225 1.355-1.41v2.747c-.947-.26-1.355-.631-1.355-1.337zm4.288 5.457c0 .706-.409 1.281-1.281 1.522v-2.932c1.058.315 1.28.872 1.28 1.41z"
                            fill="#76808F"></path>
                        <defs>
                            <linearGradient id="payment-g_svg__paint0_linear" x1="10" y1="0" x2="10" y2="20"
                                gradientUnits="userSpaceOnUse">
                                <stop stop-color="#F0B90B"></stop>
                                <stop offset="1" stop-color="#F8D33A"></stop>
                            </linearGradient>
                        </defs>
                    </svg>
                    <div class="faq-inner-box-div">
                        <div class="faq-inner-box-div-txt">Spot & Margin Trading</div>
                    </div>
                </a>
                <a href="#" class="faq-inner-box">
                    <svg  viewBox="0 0 50 50" fill="none" class="faq-inner-svg">
                        <path
                            d="M11.459 12.5l-9.375 9.375h18.75L11.459 12.5zM38.541 12.5l-9.375 9.375h18.75L38.541 12.5z"
                            fill="#76808F"></path>
                        <path
                            d="M22.917 4.167h4.167v4.166h18.75V12.5h-18.75v29.167h-4.167V12.5H4.167V8.333h18.75V4.167z"
                            fill="url(#compliance-g_svg__paint0_linear_2218_19592)"></path>
                        <path d="M11.459 31.25a9.375 9.375 0 009.375-9.375H2.084a9.375 9.375 0 009.375 9.375z"
                            fill="url(#compliance-g_svg__paint1_linear_2218_19592)"></path>
                        <path d="M38.542 31.25a9.375 9.375 0 009.375-9.375h-18.75a9.375 9.375 0 009.375 9.375z"
                            fill="url(#compliance-g_svg__paint2_linear_2218_19592)"></path>
                        <path fill="#76808F"
                            d="M22.916 12.5h4.167V8.333h-4.167zM10.416 41.667h29.167v-6.25H10.416v6.25z"></path>
                        <defs>
                            <linearGradient id="compliance-g_svg__paint0_linear_2218_19592" x1="25.001" y1="41.667"
                                x2="25.001" y2="4.167" gradientUnits="userSpaceOnUse">
                                <stop stop-color="#F0B90B"></stop>
                                <stop offset="1" stop-color="#F8D33A"></stop>
                            </linearGradient>
                            <linearGradient id="compliance-g_svg__paint1_linear_2218_19592" x1="25.001" y1="41.667"
                                x2="25.001" y2="4.167" gradientUnits="userSpaceOnUse">
                                <stop stop-color="#F0B90B"></stop>
                                <stop offset="1" stop-color="#F8D33A"></stop>
                            </linearGradient>
                            <linearGradient id="compliance-g_svg__paint2_linear_2218_19592" x1="25.001" y1="41.667"
                                x2="25.001" y2="4.167" gradientUnits="userSpaceOnUse">
                                <stop stop-color="#F0B90B"></stop>
                                <stop offset="1" stop-color="#F8D33A"></stop>
                            </linearGradient>
                        </defs>
                    </svg>
                    <div class="faq-inner-box-div">
                        <div class="faq-inner-box-div-txt">Crypto Derivatives</div>
                    </div>
                </a>
                <a href="#" class="faq-inner-box">
                    <svg  viewBox="0 0 24 24" fill="none" class="faq-inner-svg">
                        <path d="M3 13h2V8H3v5z" fill="#76808F"></path>
                        <path d="M17 6H5v9H17l4 4V2l-4 4z" fill="url(#announcement-g_svg__paint0_linear)"></path>
                        <path d="M14 15H7v7h4v-5h3v-2z" fill="#76808F"></path>
                        <defs>
                            <linearGradient id="announcement-g_svg__paint0_linear" x1="13.001" y1="19" x2="13.001"
                                y2="2" gradientUnits="userSpaceOnUse">
                                <stop stop-color="#F0B90B"></stop>
                                <stop offset="1" stop-color="#F8D33A"></stop>
                            </linearGradient>
                        </defs>
                    </svg>
                    <div class="faq-inner-box-div">
                        <div class="faq-inner-box-div-txt">Finance</div>
                    </div>
                </a>
                <a href="#" class="faq-inner-box">
                    <svg  viewBox="0 0 24 24" fill="none" class="faq-inner-svg">
                        <path fill-rule="evenodd" clip-rule="evenodd"
                            d="M14.987 4.391l2.066 1.195 2.672-.16 1.818 3.149-1.474 2.232v2.386l1.474 2.232-1.818 3.15-2.672-.16-2.066 1.194L13.792 22h-3.636L8.96 19.609l-2.066-1.195-2.672.16-1.818-3.149 1.474-2.232v-2.386L2.404 8.575l1.818-3.15 2.672.16L8.96 4.392 10.155 2h3.637l1.195 2.391zm-2.99 2.155a5.454 5.454 0 110 10.909 5.454 5.454 0 010-10.91z"
                            fill="url(#settings-cog-g_svg__paint0_linear)"></path>
                        <path d="M9.27 12l2.727-2.727L14.725 12l-2.728 2.727L9.27 12z" fill="#76808F"></path>
                        <defs>
                            <linearGradient id="settings-cog-g_svg__paint0_linear" x1="11.974" y1="22" x2="11.974"
                                y2="2" gradientUnits="userSpaceOnUse">
                                <stop stop-color="#F0B90B"></stop>
                                <stop offset="1" stop-color="#F8D33A"></stop>
                            </linearGradient>
                        </defs>
                    </svg>
                    <div class="faq-inner-box-div">
                        <div class="faq-inner-box-div-txt">Other Topics</div>
                    </div>
                </a>
                <a href="#" class="faq-inner-box">
                    <svg  viewBox="0 0 50 50" fill="none" class="faq-inner-svg">
                        <path fill-rule="evenodd" clip-rule="evenodd" d="M4.166 8.333h37.5v25h-37.5v-25z"
                            fill="url(#product-design-g_svg__paint0_linear_2218_19595)"></path>
                        <path fill-rule="evenodd" clip-rule="evenodd"
                            d="M45.833 14.583L18.75 41.667h27.083V14.583zm-4.166 10.06L28.809 37.5h12.858V24.642z"
                            fill="#76808F"></path>
                        <path fill="#fff" d="M10.416 14.583h22.917v4.167H10.416z"></path>
                        <path d="M33.334 14.583v6.25L10.417 43.75l-6.25-6.25 22.917-22.917h6.25z" fill="#76808F"></path>
                        <defs>
                            <linearGradient id="product-design-g_svg__paint0_linear_2218_19595" x1="22.916" y1="33.333"
                                x2="22.916" y2="8.333" gradientUnits="userSpaceOnUse">
                                <stop stop-color="#F0B90B"></stop>
                                <stop offset="1" stop-color="#F8D33A"></stop>
                            </linearGradient>
                        </defs>
                    </svg>
                    <div class="faq-inner-box-div">
                        <div class="faq-inner-box-div-txt">Product &amp; Design</div>
                    </div>
                </a>
                <a href="#" class="faq-inner-box">
                    <svg  viewBox="0 0 24 24" fill="none" class="faq-inner-svg">
                        <path fill-rule="evenodd" clip-rule="evenodd" d="M4 18h18V4h-2l-7 7H8l-4 4v3z"
                            fill="url(#chart-line-g_svg__paint0_linear)"></path>
                        <path d="M4 4H2v16h20v-2H4V4z" fill="#76808F"></path>
                        <defs>
                            <linearGradient id="chart-line-g_svg__paint0_linear" x1="13" y1="18" x2="13" y2="4"
                                gradientUnits="userSpaceOnUse">
                                <stop stop-color="#F0B90B"></stop>
                                <stop offset="1" stop-color="#F8D33A"></stop>
                            </linearGradient>
                        </defs>
                    </svg>
                    <div class="faq-inner-box-div">
                        <div class="faq-inner-box-div-txt">VIP</div>
                    </div>
                </a>
                <a href="#" class="faq-inner-box">
                    <svg  viewBox="0 0 24 24" fill="none" class="faq-inner-svg">
                        <path d="M4 22h16V9H4v13z" fill="url(#lock-close-g_svg__paint0_linear)"></path>
                        <path d="M9 6a3 3 0 116 0v3h2V6A5 5 0 007 6v3h2V6zM13 19v-7h-2v7h2z" fill="#76808F"></path>
                        <defs>
                            <linearGradient id="lock-close-g_svg__paint0_linear" x1="12" y1="22" x2="12" y2="9"
                                gradientUnits="userSpaceOnUse">
                                <stop stop-color="#F0B90B"></stop>
                                <stop offset="1" stop-color="#F8D33A"></stop>
                            </linearGradient>
                        </defs>
                    </svg>
                    <div class="faq-inner-box-div">
                        <div class="faq-inner-box-div-txt">NFT</div>
                    </div>
                </a>
                <a href="#" class="faq-inner-box">
                    <svg  viewBox="0 0 50 50" fill="none" class="faq-inner-svg">
                        <path
                            d="M16.667 23.958v7.292H9.376a7.292 7.292 0 117.291-7.292zM36.458 2.083C30.13 2.083 25 7.213 25 13.542h22.917c0-6.329-5.13-11.459-11.459-11.459z"
                            fill="#76808F"></path>
                        <path
                            d="M13.772 28.356c-4.475 4.475-4.475 11.73 0 16.205l16.205-16.205c-4.475-4.475-11.73-4.475-16.205 0z"
                            fill="#76808F"></path>
                        <path d="M36.458 25C30.13 25 25 19.87 25 13.542h22.917C47.917 19.87 42.787 25 36.458 25z"
                            fill="url(#hr-g_svg__paint0_linear_2218_19597)"></path>
                        <path
                            d="M29.978 44.56c-4.475 4.475-11.73 4.475-16.205 0l16.205-16.204c4.475 4.475 4.475 11.73 0 16.205z"
                            fill="url(#hr-g_svg__paint1_linear_2218_19597)"></path>
                        <path d="M18.75 9.375h10.417v4.167H18.75V9.375z" fill="#76808F"></path>
                        <defs>
                            <linearGradient id="hr-g_svg__paint0_linear_2218_19597" x1="25" y1="19.271" x2="47.917"
                                y2="19.271" gradientUnits="userSpaceOnUse">
                                <stop stop-color="#F0B90B"></stop>
                                <stop offset="1" stop-color="#F8D33A"></stop>
                            </linearGradient>
                            <linearGradient id="hr-g_svg__paint1_linear_2218_19597" x1="23.554" y1="47.917" x2="23.554"
                                y2="28.356" gradientUnits="userSpaceOnUse">
                                <stop stop-color="#F0B90B"></stop>
                                <stop offset="1" stop-color="#F8D33A"></stop>
                            </linearGradient>
                        </defs>
                    </svg>
                    <div class="faq-inner-box-div">
                        <div class="faq-inner-box-div-txt">Wealth Mark Link</div>
                    </div>
                </a>
                <a href="#" class="faq-inner-box">
                    <svg  viewBox="0 0 50 50" fill="none" class="faq-inner-svg">
                        <path fill-rule="evenodd" clip-rule="evenodd"
                            d="M29.167 19.792a7.292 7.292 0 1114.583 0 7.292 7.292 0 01-14.583 0z"
                            fill="url(#users-g_svg__paint0_linear_2218_19600)"></path>
                        <path d="M39.584 31.25h-6.25v10.417h12.5V37.5a6.25 6.25 0 00-6.25-6.25z" fill="#76808F"></path>
                        <path fill-rule="evenodd" clip-rule="evenodd"
                            d="M7.291 15.625A9.375 9.375 0 1116.666 25a9.375 9.375 0 01-9.375-9.375z"
                            fill="url(#users-g_svg__paint1_linear_2218_19600)"></path>
                        <path
                            d="M29.166 37.5a8.333 8.333 0 00-8.333-8.333h-8.334A8.333 8.333 0 004.166 37.5v4.167h25V37.5z"
                            fill="#76808F"></path>
                        <defs>
                            <linearGradient id="users-g_svg__paint0_linear_2218_19600" x1="36.458" y1="27.083"
                                x2="36.458" y2="12.5" gradientUnits="userSpaceOnUse">
                                <stop stop-color="#F0B90B"></stop>
                                <stop offset="1" stop-color="#F8D33A"></stop>
                            </linearGradient>
                            <linearGradient id="users-g_svg__paint1_linear_2218_19600" x1="16.666" y1="25" x2="16.666"
                                y2="6.25" gradientUnits="userSpaceOnUse">
                                <stop stop-color="#F0B90B"></stop>
                                <stop offset="1" stop-color="#F8D33A"></stop>
                            </linearGradient>
                        </defs>
                    </svg>
                    <div class="faq-inner-box-div">
                        <div class="faq-inner-box-div-txt">Wealth Mark Finace</div>
                    </div>
                </a>
            </div>
        </div>
    </section>

    <section class="announcements-block" id="announcemnet-section">
        <div class="container">
            <div class="row">
            <div class="sec-title">
                        <span class="title">Know About</span>
                        <h2 class="heading-h2">Announcement</h2>
                    </div>
            </div>
            <div class="row"> 
                <div class="col-md-3 col-lg-3 col-sm-6 col-xs-12"> 
                    <div class="announcements-inner-box alert alert-warning"> 
                        <img src="{{ asset('public/assets/img/announcement-icon-1.png') }}" class="img-fluid" alt="gift Card Image" />
                        New Cryptocurrency Listing
                    </div>
                </div>
                <div class="col-md-3 col-lg-3 col-sm-6 col-xs-12"> 
                    <div class="announcements-inner-box alert alert-warning"> 
                        <img src="{{ asset('public/assets/img/announcement-icon-2.png') }}" class="img-fluid" alt="gift Card Image" />
                        Latest Wealth Mark News
                    </div>
                </div>
                <div class="col-md-3 col-lg-3 col-sm-6 col-xs-12"> 
                    <div class="announcements-inner-box alert alert-warning"> 
                        <img src="{{ asset('public/assets/img/announcement-icon-3.png') }}" class="img-fluid" alt="gift Card Image" />
                        Latest Activities
                    </div>
                </div>
                <div class="col-md-3 col-lg-3 col-sm-6 col-xs-12"> 
                    <div class="announcements-inner-box alert alert-warning"> 
                        <img src="{{ asset('public/assets/img/announcement-icon-4.png') }}" class="img-fluid" alt="gift Card Image" />
                        New Fiat Listings
                    </div>
                </div>
            </div>
            <div class="row mt-2"> 
                <div class="col-md-3 col-lg-3 col-sm-6 col-xs-12"> 
                    <div class="announcements-inner-box alert alert-warning"> 
                        <img src="{{ asset('public/assets/img/announcement-icon-5.png') }}" class="img-fluid" alt="gift Card Image" />
                        Delisting
                    </div>
                </div>
                <div class="col-md-3 col-lg-3 col-sm-6 col-xs-12"> 
                    <div class="announcements-inner-box alert alert-warning"> 
                        <img src="{{ asset('public/assets/img/announcement-icon-6.png') }}" class="img-fluid" alt="gift Card Image" />
                        Wallet Maintenance Updates
                    </div>
                </div>
                <div class="col-md-3 col-lg-3 col-sm-6 col-xs-12"> 
                    <div class="announcements-inner-box alert alert-warning"> 
                        <img src="{{ asset('public/assets/img/announcement-icon-7.png') }}" class="img-fluid" alt="gift Card Image" />
                        API Updates
                    </div>
                </div>
                <div class="col-md-3 col-lg-3 col-sm-6 col-xs-12"> 
                    <div class="announcements-inner-box alert alert-warning"> 
                        <img src="{{ asset('public/assets/img/announcement-icon-1.png') }}" class="img-fluid" alt="gift Card Image" />
                        Crypto Airdrop
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="announcements-listing-block pt-0" id="announcements-listing-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <div class="sec-title text-left">
                        <span class="title">Know About</span>
                        <h2 class="heading-h2">Latest Articles</h2>
                    </div>
                </div>
            </div>
            <div class="row mb-4">
                <div class="col-md-4 col-lg-4 col-sm-6 col-xs-12">
                    <div class="flip-box listing-topic-box">
                        <div class="flip-box-inner">
                            <div class="flip-box-front">
                            <img src="{{ asset('public/assets/img/support-article-icon-1.png') }}" class="img-fluid" alt="gift Card Image" />
                                <h4>Wealth Mark Options System Upgrade Notice </h4>
                                <p>Check out the latest coin listings and pairs on Launchpad, Launchpool, Spot, Margin,
                                    and Futures markets.<a class="text-warning">(2022-11-07) </a> </p>
                            </div>
                            <div class="flip-box-back">
                                <p><span class="text-uppercase title">Wealthmark</span> is a leading player in the
                                    Crypto ecosystem; Since its inception it has risen to provide its users with an
                                    ostentatious </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-lg-4 col-sm-6 col-xs-12">
                    <div class="flip-box listing-topic-box">
                        <div class="flip-box-inner">
                            <div class="flip-box-front">
                            <img src="{{ asset('public/assets/img/support-article-icon-2.png') }}" class="img-fluid" alt="gift Card Image" />
                                <h4>Get Started on Wealth Mark Lite to Buy and Sell Your Crypto</h4>
                                <p>Check out the latest coin listings and pairs on Launchpad, Launchpool, Spot, Margin,
                                    and Futures markets.<a class="text-warning">(2021-01-27) </a> </p>
                            </div>
                            <div class="flip-box-back">
                                <p><span class="text-uppercase title">Wealthmark</span> is a leading player in the
                                    Crypto ecosystem; Since its inception it has risen to provide its users with an
                                    ostentatious </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-lg-4 col-sm-6 col-xs-12">
                    <div class="flip-box listing-topic-box">
                        <div class="flip-box-inner">
                            <div class="flip-box-front">
                            <img src="{{ asset('public/assets/img/support-article-icon-3.png') }}" class="img-fluid" alt="gift Card Image" />
                                <h4>Wealth Mark Adds New Assets to Simple Earn Flexible Products </h4>
                                <p>Check out the latest coin listings and pairs on Launchpad, Launchpool, Spot, Margin,
                                    and Futures markets.<a class="text-warning">(2022-11-03)</a> </p>
                            </div>
                            <div class="flip-box-back">
                                <p><span class="text-uppercase title">Wealthmark</span> is a leading player in the
                                    Crypto ecosystem; Since its inception it has risen to provide its users with an
                                    ostentatious </p>
                            </div>
                        </div>
                    </div>
                </div>


                <div class="col-md-4 col-lg-4 col-sm-6 col-xs-12">
                    <div class="flip-box listing-topic-box">
                        <div class="flip-box-inner">
                            <div class="flip-box-front">
                            <img src="{{ asset('public/assets/img/support-article-icon-4.png') }}" class="img-fluid" alt="gift Card Image" />
                                <h4>Make Your First Wealth Mark Options Trade & Share Up to 21,000 USDT</h4>
                                <p>Check out the latest coin listings and pairs on Launchpad, Launchpool, Spot, Margin,
                                    and Futures markets.<a class="text-warning"> 2022-11-03 </a> </p>
                            </div>
                            <div class="flip-box-back">
                                <p><span class="text-uppercase title">Wealthmark</span> is a leading player in the
                                    Crypto ecosystem; Since its inception it has risen to provide its users with an
                                    ostentatious </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-lg-4 col-sm-6 col-xs-12">
                    <div class="flip-box listing-topic-box">
                        <div class="flip-box-inner">
                            <div class="flip-box-front">
                            <img src="{{ asset('public/assets/img/support-article-icon-5.png') }}" class="img-fluid" alt="gift Card Image" />
                                <h4>Send Crypto with Wealth Mark Pay to Receive Up to 2,999</h4>
                                <p>Check out the latest coin listings and pairs on Launchpad, Launchpool, Spot, Margin,
                                    and Futures markets.<a class="text-warning">2022-01-20</a> </p>
                            </div>
                            <div class="flip-box-back">
                                <p><span class="text-uppercase title">Wealthmark</span> is a leading player in the
                                    Crypto ecosystem; Since its inception it has risen to provide its users with an
                                    ostentatious </p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-4 col-lg-4 col-sm-6 col-xs-12">
                    <div class="flip-box listing-topic-box">
                        <div class="flip-box-inner">
                            <div class="flip-box-front">
                            <img src="{{ asset('public/assets/img/support-article-icon-6.png') }}" class="img-fluid" alt="gift Card Image" />
                                <h4>How Do I Deposit/Withdraw Cryptocurrency on Wealth Mark</h4>
                                <p>Check out the latest coin listings and pairs on Launchpad, Launchpool, Spot, Margin,
                                    and Futures markets.<a class="text-warning">2022-10-20 </a> </p>
                            </div>
                            <div class="flip-box-back">
                                <p><span class="text-uppercase title">Wealthmark</span> is a leading player in the
                                    Crypto ecosystem; Since its inception it has risen to provide its users with an
                                    ostentatious </p>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

        </div>
    </section>
    

    @include('template.country_language')
    @include('template.web_footer')
</body>

</html>