<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <title>Wealth Mark | {{ Request::segment(2) }}</title>
    @include('template.web_css')
    <link rel='stylesheet' href="{{('../public/assets/css/deepak_custom.css') }}">
    <link rel='stylesheet' href="{{('../public/assets/css/style_main.css') }}">
</head>

<body>
    @include('template.mobile_menu')
    @include('template.web_menu')


    <section id="nft-banner-section">
        <div class="container css-14d8xok">
            <div class="row">
                <div class="col-md-6 col-lg-6 col-sm-12 col-xs-12 order-2 order-lg-1">
                    <div class="nft-banner-block">
                        <h4 class="nft-banner-head blue-text">Welcome to the Wealthmark NFT Area  </h4>
                        <p class="mt-4">With Wealth Mark NFT’s beginner-friendly minting feature, verified Wealth Mark
                            users can create their own NFTs in just a few clicks! Start minting your own NFTs with
                            Wealth Mark NFT today!</p>
                        <a class="btn btn-yellow shadow mt-4">Learn More </a>
                    </div>
                </div>
                <div class="col-md-6 col-lg-6 col-sm-12 col-xs-12 order-1 order-lg-2">
                    <div class="nft-banner-blocks">
                        <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel">
                            <div class="carousel-indicators">
                                <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0"
                                    class="active" aria-current="true" aria-label="Slide 1"></button>
                                <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1"
                                    aria-label="Slide 2"></button>
                                <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2"
                                    aria-label="Slide 3"></button>
                            </div>
                            <div class="carousel-inner">
                                <div class="carousel-item active">
                                    <img src="{{ asset('public/assets/img/nft-bg-banner-3.png') }}" class="img-fluid"
                                        alt="NFT image" />
                                </div>
                                <div class="carousel-item">
                                    <img src="{{ asset('public/assets/img/nft-bg-banner-1.png') }}" class="img-fluid"
                                        alt="NFT image" />
                                </div>
                                <div class="carousel-item">
                                    <img src="{{ asset('public/assets/img/nft-bg-banner-2.png') }}" class="img-fluid"
                                        alt="NFT image" />
                                </div>
                            </div>
                            <button class="carousel-control-prev" type="button"
                                data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
                                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                <span class="visually-hidden">Previous</span>
                            </button>
                            <button class="carousel-control-next" type="button"
                                data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
                                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                <span class="visually-hidden">Next</span>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="nft-recommended-box" id="nft-recommended-section">
        <div class="container" id="featureContainer">
            <div class="row">
                <div class="sec-title">
                    <span class="title">Know About</span>
                    <h2 class="heading-h2">Recommended collections</h2>
                </div>
            </div>

            <div class="row mx-auto my-auto justify-content-center">
                <div id="featureCarousel" class="carousel slide" data-bs-ride="carousel">
                    <div class="float-end pe-md-4 mb-4">
                        <a class="indicator" href="#featureCarousel" role="button" data-bs-slide="prev">
                            <span> &#8249;</span>
                        </a> &nbsp;&nbsp;
                        <a class="w-aut indicator" href="#featureCarousel" role="button" data-bs-slide="next">
                            <span> &#8250; </span>
                        </a>&nbsp;
                        <a>
                            &nbsp; <span> More </span>
                        </a>

                    </div>

                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#home"
                                type="button" role="tab" aria-controls="home" aria-selected="true">NFTs</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile"
                                type="button" role="tab" aria-controls="profile" aria-selected="false">Mystery
                                Boxes</button>
                        </li>
                    </ul>
                    <div class="tab-content" id="myTabContent">
                        <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                            <div class="carousel-inner" role="listbox">
                                <div class="carousel-item active">
                                    <div class="col-md-4 col-lg-4 col-sm-6 col-xs-12 nft-collection-sub-block">
                                        <div class="nft-collection-block text-center">
                                            <img loading="lazy" class="mx-auto d-block img-fluid"
                                                src="{{ asset('public/assets/img/nft-collection-1.png') }}"
                                                alt="NFT image">

                                        </div>
                                        <div class="nft-collection-content">
                                            <div class="row">
                                                <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                                    <div class="nft-recommended-collection">
                                                        <img loading="lazy" class="mx-auto d-block img-fluid"
                                                            src="{{ asset('public/assets/img/bull-btn-icon-nft.png') }}"
                                                            alt="NFT image">
                                                    </div>
                                                </div>
                                                <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                                    <div class="nft-recommended-collection">
                                                        <h4 class="text-center"> BULL BTC CLUB
                                                            <div class="css-1aebr02">
                                                                <div class="bn-tooltip-box css-1yof1af"
                                                                    style="position: absolute; left: -179px; top: -64px; transition: opacity 120ms ease-in-out 0s, transform 120ms ease-in-out 0s; opacity: 0; transform: translate3d(0px, -6px, 0px); visibility: hidden;"
                                                                    data-popper-reference-hidden="false"
                                                                    data-popper-escaped="false"
                                                                    data-popper-placement="top">
                                                                    <div data-bn-type="text" class="css-1o96y9d">This
                                                                        NFT is part of a premier collection. <a
                                                                            data-bn-type="link"
                                                                            href="/en-IN/support/faq/777d6487fb7b491696571e3cbf3518f7"
                                                                            target="_blank" class="css-m2io66">Learn
                                                                            more</a></div>
                                                                    <div class="bn-tooltip-arrow css-1u9esp9"
                                                                        data-popper-arrow="true"
                                                                        style="position: absolute; left: 186px;"></div>
                                                                    <i class="gap-fill"></i>
                                                                </div><svg viewBox="0 0 24 24" fill="none"
                                                                    class="css-14nfsts">
                                                                    <path fill-rule="evenodd" clip-rule="evenodd"
                                                                        d="M15.824 5.34L14.43 2.927 12.02 4.32 9.608 2.928 8.216 5.339H5.43v2.785L3.02 9.516l1.392 2.412-1.392 2.411 2.411 1.392v2.785h2.785l1.392 2.412 2.412-1.393 2.411 1.393 1.393-2.412h2.784v-2.784l2.412-1.393-1.393-2.411 1.393-2.412-2.412-1.392V5.339h-2.784zm-4.964 7.107l4.432-4.431 1.767 1.767-6.199 6.2-3.92-3.92 1.769-1.767 2.151 2.152z"
                                                                        fill="currentColor"></path>
                                                                </svg>
                                                            </div>
                                                        </h4>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="row">
                                                <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12">
                                                    <div class="nft-recommended-collection">
                                                        <p>Volume <b>4,030,641.99 USD </b> </p>
                                                    </div>
                                                </div>
                                                <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12">
                                                    <div class="nft-recommended-collection">
                                                        <p>Floor Price <b>3.84 USD </b> </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                                <div class="carousel-item">
                                    <div class="col-md-4 col-lg-4 col-sm-6 col-xs-12 nft-collection-sub-block">
                                        <div class="nft-collection-block text-center">
                                            <img loading="lazy" class="mx-auto d-block img-fluid"
                                                src="{{ asset('public/assets/img/nft-collection-2.png') }}"
                                                alt="NFT image">

                                        </div>
                                        <div class="nft-collection-content">
                                            <div class="row">
                                                <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                                    <div class="nft-recommended-collection">
                                                        <img loading="lazy" class="mx-auto d-block img-fluid"
                                                            src="{{ asset('public/assets/img/bull-btn-icon-nft.png') }}"
                                                            alt="NFT image">
                                                    </div>
                                                </div>
                                                <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                                    <div class="nft-recommended-collection">
                                                        <h4 class="text-center"> BULL BTC CLUB
                                                            <svg viewBox="0 0 24 24" fill="none" class="css-14nfsts">
                                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                                    d="M15.824 5.34L14.43 2.927 12.02 4.32 9.608 2.928 8.216 5.339H5.43v2.785L3.02 9.516l1.392 2.412-1.392 2.411 2.411 1.392v2.785h2.785l1.392 2.412 2.412-1.393 2.411 1.393 1.393-2.412h2.784v-2.784l2.412-1.393-1.393-2.411 1.393-2.412-2.412-1.392V5.339h-2.784zm-4.964 7.107l4.432-4.431 1.767 1.767-6.199 6.2-3.92-3.92 1.769-1.767 2.151 2.152z"
                                                                    fill="currentColor"></path>
                                                            </svg>
                                                        </h4>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="row">
                                                <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12">
                                                    <div class="nft-recommended-collection">
                                                        <p>Volume <b>4,030,641.99 USD </b> </p>
                                                    </div>
                                                </div>
                                                <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12">
                                                    <div class="nft-recommended-collection">
                                                        <p>Floor Price <b>3.84 USD </b> </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>

                                <div class="carousel-item">
                                    <div class="col-md-4 col-lg-4 col-sm-6 col-xs-12 nft-collection-sub-block">
                                        <div class="nft-collection-block text-center">
                                            <img loading="lazy" class="mx-auto d-block img-fluid"
                                                src="{{ asset('public/assets/img/nft-collection-5.png') }}"
                                                alt="NFT image">

                                        </div>
                                        <div class="nft-collection-content">
                                            <div class="row">
                                                <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                                    <div class="nft-recommended-collection">
                                                        <img loading="lazy" class="mx-auto d-block img-fluid"
                                                            src="{{ asset('public/assets/img/bull-btn-icon-nft.png') }}"
                                                            alt="NFT image">
                                                    </div>
                                                </div>
                                                <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                                    <div class="nft-recommended-collection">
                                                        <h4 class="text-center"> BULL BTC CLUB <svg viewBox="0 0 24 24"
                                                                fill="none" class="css-14nfsts">
                                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                                    d="M15.824 5.34L14.43 2.927 12.02 4.32 9.608 2.928 8.216 5.339H5.43v2.785L3.02 9.516l1.392 2.412-1.392 2.411 2.411 1.392v2.785h2.785l1.392 2.412 2.412-1.393 2.411 1.393 1.393-2.412h2.784v-2.784l2.412-1.393-1.393-2.411 1.393-2.412-2.412-1.392V5.339h-2.784zm-4.964 7.107l4.432-4.431 1.767 1.767-6.199 6.2-3.92-3.92 1.769-1.767 2.151 2.152z"
                                                                    fill="currentColor"></path>
                                                            </svg></h4>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="row">
                                                <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12">
                                                    <div class="nft-recommended-collection">
                                                        <p>Volume <b>4,030,641.99 USD </b> </p>
                                                    </div>
                                                </div>
                                                <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12">
                                                    <div class="nft-recommended-collection">
                                                        <p>Floor Price <b>3.84 USD </b> </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>

                                <div class="carousel-item">
                                    <div class="col-md-4 col-lg-4 col-sm-6 col-xs-12 nft-collection-sub-block">
                                        <div class="nft-collection-block text-center">
                                            <img loading="lazy" class="mx-auto d-block img-fluid"
                                                src="{{ asset('public/assets/img/nft-collection-3.png') }}"
                                                alt="NFT image">

                                        </div>
                                        <div class="nft-collection-content">
                                            <div class="row">
                                                <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                                    <div class="nft-recommended-collection">
                                                        <img loading="lazy" class="mx-auto d-block img-fluid"
                                                            src="{{ asset('public/assets/img/bull-btn-icon-nft.png') }}"
                                                            alt="NFT image">
                                                    </div>
                                                </div>
                                                <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                                    <div class="nft-recommended-collection">
                                                        <h4 class="text-center"> BULL BTC CLUB <svg viewBox="0 0 24 24"
                                                                fill="none" class="css-14nfsts">
                                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                                    d="M15.824 5.34L14.43 2.927 12.02 4.32 9.608 2.928 8.216 5.339H5.43v2.785L3.02 9.516l1.392 2.412-1.392 2.411 2.411 1.392v2.785h2.785l1.392 2.412 2.412-1.393 2.411 1.393 1.393-2.412h2.784v-2.784l2.412-1.393-1.393-2.411 1.393-2.412-2.412-1.392V5.339h-2.784zm-4.964 7.107l4.432-4.431 1.767 1.767-6.199 6.2-3.92-3.92 1.769-1.767 2.151 2.152z"
                                                                    fill="currentColor"></path>
                                                            </svg></h4>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="row">
                                                <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12">
                                                    <div class="nft-recommended-collection">
                                                        <p>Volume <b>4,030,641.99 USD </b> </p>
                                                    </div>
                                                </div>
                                                <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12">
                                                    <div class="nft-recommended-collection">
                                                        <p>Floor Price <b>3.84 USD </b> </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>

                                <div class="carousel-item">
                                    <div class="col-md-4 col-lg-4 col-sm-6 col-xs-12 nft-collection-sub-block">
                                        <div class="nft-collection-block text-center">
                                            <img loading="lazy" class="mx-auto d-block img-fluid"
                                                src="{{ asset('public/assets/img/nft-collection-6.png') }}"
                                                alt="NFT image">

                                        </div>
                                        <div class="nft-collection-content">
                                            <div class="row">
                                                <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                                    <div class="nft-recommended-collection">
                                                        <img loading="lazy" class="mx-auto d-block img-fluid"
                                                            src="{{ asset('public/assets/img/bull-btn-icon-nft.png') }}"
                                                            alt="NFT image">
                                                    </div>
                                                </div>
                                                <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                                    <div class="nft-recommended-collection">
                                                        <h4 class="text-center"> BULL BTC CLUB <svg viewBox="0 0 24 24"
                                                                fill="none" class="css-14nfsts">
                                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                                    d="M15.824 5.34L14.43 2.927 12.02 4.32 9.608 2.928 8.216 5.339H5.43v2.785L3.02 9.516l1.392 2.412-1.392 2.411 2.411 1.392v2.785h2.785l1.392 2.412 2.412-1.393 2.411 1.393 1.393-2.412h2.784v-2.784l2.412-1.393-1.393-2.411 1.393-2.412-2.412-1.392V5.339h-2.784zm-4.964 7.107l4.432-4.431 1.767 1.767-6.199 6.2-3.92-3.92 1.769-1.767 2.151 2.152z"
                                                                    fill="currentColor"></path>
                                                            </svg></h4>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="row">
                                                <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12">
                                                    <div class="nft-recommended-collection">
                                                        <p>Volume <b>4,030,641.99 USD </b> </p>
                                                    </div>
                                                </div>
                                                <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12">
                                                    <div class="nft-recommended-collection">
                                                        <p>Floor Price <b>3.84 USD </b> </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>


                            </div>
                        </div>
                        <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">

                            <div class="carousel-inner" role="listbox">
                                <div class="carousel-item active">
                                    <div class="col-md-4 col-lg-4 col-sm-6 col-xs-12 nft-collection-sub-block">
                                        <div class="nft-collection-block text-center">
                                            <img loading="lazy" class="mx-auto d-block img-fluid"
                                                src="{{ asset('public/assets/img/nft-collection-1.png') }}"
                                                alt="NFT image">

                                        </div>
                                        <div class="nft-collection-content">
                                            <div class="row">
                                                <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                                    <div class="nft-recommended-collection">
                                                        <img loading="lazy" class="mx-auto d-block img-fluid"
                                                            src="{{ asset('public/assets/img/bull-btn-icon-nft.png') }}"
                                                            alt="NFT image">
                                                    </div>
                                                </div>
                                                <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                                    <div class="nft-recommended-collection">
                                                        <h4 class="text-center"> BULL BTC CLUB <svg viewBox="0 0 24 24"
                                                                fill="none" class="css-14nfsts">
                                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                                    d="M15.824 5.34L14.43 2.927 12.02 4.32 9.608 2.928 8.216 5.339H5.43v2.785L3.02 9.516l1.392 2.412-1.392 2.411 2.411 1.392v2.785h2.785l1.392 2.412 2.412-1.393 2.411 1.393 1.393-2.412h2.784v-2.784l2.412-1.393-1.393-2.411 1.393-2.412-2.412-1.392V5.339h-2.784zm-4.964 7.107l4.432-4.431 1.767 1.767-6.199 6.2-3.92-3.92 1.769-1.767 2.151 2.152z"
                                                                    fill="currentColor"></path>
                                                            </svg>
                                                            <div class="css-1aebr02">
                                                                <div class="bn-tooltip-box css-1yof1af"
                                                                    style="position: absolute; left: -179px; top: -64px; transition: opacity 120ms ease-in-out 0s, transform 120ms ease-in-out 0s; opacity: 0; transform: translate3d(0px, -6px, 0px); visibility: hidden;"
                                                                    data-popper-reference-hidden="false"
                                                                    data-popper-escaped="false"
                                                                    data-popper-placement="top">
                                                                    <div data-bn-type="text" class="css-1o96y9d">This
                                                                        NFT is part of a premier collection. <a
                                                                            data-bn-type="link"
                                                                            href="/en-IN/support/faq/777d6487fb7b491696571e3cbf3518f7"
                                                                            target="_blank" class="css-m2io66">Learn
                                                                            more</a></div>
                                                                    <div class="bn-tooltip-arrow css-1u9esp9"
                                                                        data-popper-arrow="true"
                                                                        style="position: absolute; left: 186px;"></div>
                                                                    <i class="gap-fill"></i>
                                                                </div><svg viewBox="0 0 24 24" fill="none"
                                                                    class="css-14nfsts">
                                                                    <path fill-rule="evenodd" clip-rule="evenodd"
                                                                        d="M15.824 5.34L14.43 2.927 12.02 4.32 9.608 2.928 8.216 5.339H5.43v2.785L3.02 9.516l1.392 2.412-1.392 2.411 2.411 1.392v2.785h2.785l1.392 2.412 2.412-1.393 2.411 1.393 1.393-2.412h2.784v-2.784l2.412-1.393-1.393-2.411 1.393-2.412-2.412-1.392V5.339h-2.784zm-4.964 7.107l4.432-4.431 1.767 1.767-6.199 6.2-3.92-3.92 1.769-1.767 2.151 2.152z"
                                                                        fill="currentColor"></path>
                                                                </svg>
                                                            </div>
                                                        </h4>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="row">
                                                <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12">
                                                    <div class="nft-recommended-collection">
                                                        <p>Volume <b>4,030,641.99 USD </b> </p>
                                                    </div>
                                                </div>
                                                <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12">
                                                    <div class="nft-recommended-collection">
                                                        <p>Floor Price <b>3.84 USD </b> </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                                <div class="carousel-item">
                                    <div class="col-md-4 col-lg-4 col-sm-6 col-xs-12 nft-collection-sub-block">
                                        <div class="nft-collection-block text-center">
                                            <img loading="lazy" class="mx-auto d-block img-fluid"
                                                src="{{ asset('public/assets/img/nft-collection-2.png') }}"
                                                alt="NFT image">

                                        </div>
                                        <div class="nft-collection-content">
                                            <div class="row">
                                                <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                                    <div class="nft-recommended-collection">
                                                        <img loading="lazy" class="mx-auto d-block img-fluid"
                                                            src="{{ asset('public/assets/img/bull-btn-icon-nft.png') }}"
                                                            alt="NFT image">
                                                    </div>
                                                </div>
                                                <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                                    <div class="nft-recommended-collection">
                                                        <h4 class="text-center"> BULL BTC CLUB <svg viewBox="0 0 24 24"
                                                                fill="none" class="css-14nfsts">
                                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                                    d="M15.824 5.34L14.43 2.927 12.02 4.32 9.608 2.928 8.216 5.339H5.43v2.785L3.02 9.516l1.392 2.412-1.392 2.411 2.411 1.392v2.785h2.785l1.392 2.412 2.412-1.393 2.411 1.393 1.393-2.412h2.784v-2.784l2.412-1.393-1.393-2.411 1.393-2.412-2.412-1.392V5.339h-2.784zm-4.964 7.107l4.432-4.431 1.767 1.767-6.199 6.2-3.92-3.92 1.769-1.767 2.151 2.152z"
                                                                    fill="currentColor"></path>
                                                            </svg></h4>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="row">
                                                <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12">
                                                    <div class="nft-recommended-collection">
                                                        <p>Volume <b>4,030,641.99 USD </b> </p>
                                                    </div>
                                                </div>
                                                <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12">
                                                    <div class="nft-recommended-collection">
                                                        <p>Floor Price <b>3.84 USD </b> </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>

                                <div class="carousel-item">
                                    <div class="col-md-4 col-lg-4 col-sm-6 col-xs-12 nft-collection-sub-block">
                                        <div class="nft-collection-block text-center">
                                            <img loading="lazy" class="mx-auto d-block img-fluid"
                                                src="{{ asset('public/assets/img/nft-collection-5.png') }}"
                                                alt="NFT image">

                                        </div>
                                        <div class="nft-collection-content">
                                            <div class="row">
                                                <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                                    <div class="nft-recommended-collection">
                                                        <img loading="lazy" class="mx-auto d-block img-fluid"
                                                            src="{{ asset('public/assets/img/bull-btn-icon-nft.png') }}"
                                                            alt="NFT image">
                                                    </div>
                                                </div>
                                                <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                                    <div class="nft-recommended-collection">
                                                        <h4 class="text-center"> BULL BTC CLUB <svg viewBox="0 0 24 24"
                                                                fill="none" class="css-14nfsts">
                                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                                    d="M15.824 5.34L14.43 2.927 12.02 4.32 9.608 2.928 8.216 5.339H5.43v2.785L3.02 9.516l1.392 2.412-1.392 2.411 2.411 1.392v2.785h2.785l1.392 2.412 2.412-1.393 2.411 1.393 1.393-2.412h2.784v-2.784l2.412-1.393-1.393-2.411 1.393-2.412-2.412-1.392V5.339h-2.784zm-4.964 7.107l4.432-4.431 1.767 1.767-6.199 6.2-3.92-3.92 1.769-1.767 2.151 2.152z"
                                                                    fill="currentColor"></path>
                                                            </svg></h4>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="row">
                                                <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12">
                                                    <div class="nft-recommended-collection">
                                                        <p>Volume <b>4,030,641.99 USD </b> </p>
                                                    </div>
                                                </div>
                                                <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12">
                                                    <div class="nft-recommended-collection">
                                                        <p>Floor Price <b>3.84 USD </b> </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>

                                <div class="carousel-item">
                                    <div class="col-md-4 col-lg-4 col-sm-6 col-xs-12 nft-collection-sub-block">
                                        <div class="nft-collection-block text-center">
                                            <img loading="lazy" class="mx-auto d-block img-fluid"
                                                src="{{ asset('public/assets/img/nft-collection-3.png') }}"
                                                alt="NFT image">

                                        </div>
                                        <div class="nft-collection-content">
                                            <div class="row">
                                                <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                                    <div class="nft-recommended-collection">
                                                        <img loading="lazy" class="mx-auto d-block img-fluid"
                                                            src="{{ asset('public/assets/img/bull-btn-icon-nft.png') }}"
                                                            alt="NFT image">
                                                    </div>
                                                </div>
                                                <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                                    <div class="nft-recommended-collection">
                                                        <h4 class="text-center"> BULL BTC CLUB <svg viewBox="0 0 24 24"
                                                                fill="none" class="css-14nfsts">
                                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                                    d="M15.824 5.34L14.43 2.927 12.02 4.32 9.608 2.928 8.216 5.339H5.43v2.785L3.02 9.516l1.392 2.412-1.392 2.411 2.411 1.392v2.785h2.785l1.392 2.412 2.412-1.393 2.411 1.393 1.393-2.412h2.784v-2.784l2.412-1.393-1.393-2.411 1.393-2.412-2.412-1.392V5.339h-2.784zm-4.964 7.107l4.432-4.431 1.767 1.767-6.199 6.2-3.92-3.92 1.769-1.767 2.151 2.152z"
                                                                    fill="currentColor"></path>
                                                            </svg></h4>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="row">
                                                <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12">
                                                    <div class="nft-recommended-collection">
                                                        <p>Volume <b>4,030,641.99 USD </b> </p>
                                                    </div>
                                                </div>
                                                <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12">
                                                    <div class="nft-recommended-collection">
                                                        <p>Floor Price <b>3.84 USD </b> </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>

                                <div class="carousel-item">
                                    <div class="col-md-4 col-lg-4 col-sm-6 col-xs-12 nft-collection-sub-block">
                                        <div class="nft-collection-block text-center">
                                            <img loading="lazy" class="mx-auto d-block img-fluid"
                                                src="{{ asset('public/assets/img/nft-collection-6.png') }}"
                                                alt="NFT image">

                                        </div>
                                        <div class="nft-collection-content">
                                            <div class="row">
                                                <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                                    <div class="nft-recommended-collection">
                                                        <img loading="lazy" class="mx-auto d-block img-fluid"
                                                            src="{{ asset('public/assets/img/bull-btn-icon-nft.png') }}"
                                                            alt="NFT image">
                                                    </div>
                                                </div>
                                                <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                                    <div class="nft-recommended-collection">
                                                        <h4 class="text-center"> BULL BTC CLUB <svg viewBox="0 0 24 24"
                                                                fill="none" class="css-14nfsts">
                                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                                    d="M15.824 5.34L14.43 2.927 12.02 4.32 9.608 2.928 8.216 5.339H5.43v2.785L3.02 9.516l1.392 2.412-1.392 2.411 2.411 1.392v2.785h2.785l1.392 2.412 2.412-1.393 2.411 1.393 1.393-2.412h2.784v-2.784l2.412-1.393-1.393-2.411 1.393-2.412-2.412-1.392V5.339h-2.784zm-4.964 7.107l4.432-4.431 1.767 1.767-6.199 6.2-3.92-3.92 1.769-1.767 2.151 2.152z"
                                                                    fill="currentColor"></path>
                                                            </svg></h4>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="row">
                                                <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12">
                                                    <div class="nft-recommended-collection">
                                                        <p>Volume <b>4,030,641.99 USD </b> </p>
                                                    </div>
                                                </div>
                                                <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12">
                                                    <div class="nft-recommended-collection">
                                                        <p>Floor Price <b>3.84 USD </b> </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>


                            </div>
                        </div>
                    </div>


                </div>
            </div>
        </div>
    </section>

    <section class="seven-collection-table-block" id="seven-collection-table-block">
        <div class="container" id="featureContainer">
            <div class="row">
                <div class="sec-title">
                    <span class="title">Know About</span>
                    <h2 class="heading-h2">Top Collections <span class="yellow-text">7 days</span></h2>
                </div>
            </div>

            <ul class="nav nav-tabs mb-2" id="nft-top-collection" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active" id="home-nft-top-collection-tab" data-bs-toggle="tab"
                        data-bs-target="#home-nft-top-collection" type="button" role="tab"
                        aria-controls="home-nft-top-collection" aria-selected="true">NFT</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="profile-nft-top-collection-tab" data-bs-toggle="tab"
                        data-bs-target="#profile-nft-top-collection" type="button" role="tab"
                        aria-controls="profile-nft-top-collection" aria-selected="false">Mystery Boxes</button>
                </li>
            </ul>
            <div class="tab-content" id="nft-top-collectionContent">
                <div class="tab-pane fade show active" id="home-nft-top-collection" role="tabpanel"
                    aria-labelledby="home-nft-top-collection-tab">
                  <div class="table-responsive"> 
                  <table class="table table-borderless border-hovered">
                        <thead>
                            <tr>
                                <th scope="col">Collection</th>
                                <th scope="col">Volume (USD)</th>
                                <th scope="col">Floor Price (USD)</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>
                                    <div class="nft-first-column">
                                        <img src="{{ asset('public/assets/img/first-i.png') }}" class="img-fluid"
                                            alt="NFT image" />
                                        <img src="{{ asset('public/assets/img/top-collection-user.png') }}"
                                            class="img-fluid" alt="NFT image" />
                                        <p class="nft-collection-head">BULL BTC CLUB </p>
                                        <div>
                                            <svg viewBox="0 0 24 24" fill="none" class="css-14nfsts">
                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                    d="M15.824 5.34L14.43 2.927 12.02 4.32 9.608 2.928 8.216 5.339H5.43v2.785L3.02 9.516l1.392 2.412-1.392 2.411 2.411 1.392v2.785h2.785l1.392 2.412 2.412-1.393 2.411 1.393 1.393-2.412h2.784v-2.784l2.412-1.393-1.393-2.411 1.393-2.412-2.412-1.392V5.339h-2.784zm-4.964 7.107l4.432-4.431 1.767 1.767-6.199 6.2-3.92-3.92 1.769-1.767 2.151 2.152z"
                                                    fill="currentColor"></path>
                                            </svg>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <p>359,006.36 &nbsp;<span class="text-danger">-12.05 </span></p>
                                </td>
                                <td>
                                    <p>4 </p>
                                </td>
                            </tr>

                            <tr>
                                <td>
                                    <div class="nft-first-column">
                                        <img src="{{ asset('public/assets/img/second-i.png') }}" class="img-fluid"
                                            alt="NFT image" />
                                        <img src="{{ asset('public/assets/img/top-collection-user.png') }}"
                                            class="img-fluid" alt="NFT image" />
                                        <p class="nft-collection-head">BULL BTC CLUB </p>
                                        <div>
                                            <svg viewBox="0 0 24 24" fill="none" class="css-14nfsts">
                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                    d="M15.824 5.34L14.43 2.927 12.02 4.32 9.608 2.928 8.216 5.339H5.43v2.785L3.02 9.516l1.392 2.412-1.392 2.411 2.411 1.392v2.785h2.785l1.392 2.412 2.412-1.393 2.411 1.393 1.393-2.412h2.784v-2.784l2.412-1.393-1.393-2.411 1.393-2.412-2.412-1.392V5.339h-2.784zm-4.964 7.107l4.432-4.431 1.767 1.767-6.199 6.2-3.92-3.92 1.769-1.767 2.151 2.152z"
                                                    fill="currentColor"></path>
                                            </svg>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <p>359,006.36 &nbsp;<span class="text-success">42.05 </span></p>
                                </td>
                                <td>
                                    <p>4 </p>
                                </td>
                            </tr>

                            <tr>
                                <td>
                                    <div class="nft-first-column">
                                        <img src="{{ asset('public/assets/img/third-i.png') }}" class="img-fluid"
                                            alt="NFT image" />
                                        <img src="{{ asset('public/assets/img/top-collection-user.png') }}"
                                            class="img-fluid" alt="NFT image" />
                                        <p class="nft-collection-head">BULL BTC CLUB </p>
                                        <div>
                                            <svg viewBox="0 0 24 24" fill="none" class="css-14nfsts">
                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                    d="M15.824 5.34L14.43 2.927 12.02 4.32 9.608 2.928 8.216 5.339H5.43v2.785L3.02 9.516l1.392 2.412-1.392 2.411 2.411 1.392v2.785h2.785l1.392 2.412 2.412-1.393 2.411 1.393 1.393-2.412h2.784v-2.784l2.412-1.393-1.393-2.411 1.393-2.412-2.412-1.392V5.339h-2.784zm-4.964 7.107l4.432-4.431 1.767 1.767-6.199 6.2-3.92-3.92 1.769-1.767 2.151 2.152z"
                                                    fill="currentColor"></path>
                                            </svg>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <p>359,006.36 &nbsp;<span class="text-danger">-12.05 </span></p>
                                </td>
                                <td>
                                    <p>4 </p>
                                </td>
                            </tr>

                            <tr>
                                <td>
                                    <div class="nft-first-column">
                                        <img src="{{ asset('public/assets/img/first-i.png') }}" class="img-fluid"
                                            alt="NFT image" />
                                        <img src="{{ asset('public/assets/img/top-collection-user.png') }}"
                                            class="img-fluid" alt="NFT image" />
                                        <p class="nft-collection-head">BULL BTC CLUB </p>
                                        <div>
                                            <svg viewBox="0 0 24 24" fill="none" class="css-14nfsts">
                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                    d="M15.824 5.34L14.43 2.927 12.02 4.32 9.608 2.928 8.216 5.339H5.43v2.785L3.02 9.516l1.392 2.412-1.392 2.411 2.411 1.392v2.785h2.785l1.392 2.412 2.412-1.393 2.411 1.393 1.393-2.412h2.784v-2.784l2.412-1.393-1.393-2.411 1.393-2.412-2.412-1.392V5.339h-2.784zm-4.964 7.107l4.432-4.431 1.767 1.767-6.199 6.2-3.92-3.92 1.769-1.767 2.151 2.152z"
                                                    fill="currentColor"></path>
                                            </svg>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <p>359,006.36 &nbsp;<span class="text-danger">-12.05 </span></p>
                                </td>
                                <td>
                                    <p>4 </p>
                                </td>
                            </tr>

                            <tr>
                                <td>
                                    <div class="nft-first-column">
                                        <img src="{{ asset('public/assets/img/second-i.png') }}" class="img-fluid"
                                            alt="NFT image" />
                                        <img src="{{ asset('public/assets/img/top-collection-user.png') }}"
                                            class="img-fluid" alt="NFT image" />
                                        <p class="nft-collection-head">BULL BTC CLUB </p>
                                        <div>
                                            <svg viewBox="0 0 24 24" fill="none" class="css-14nfsts">
                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                    d="M15.824 5.34L14.43 2.927 12.02 4.32 9.608 2.928 8.216 5.339H5.43v2.785L3.02 9.516l1.392 2.412-1.392 2.411 2.411 1.392v2.785h2.785l1.392 2.412 2.412-1.393 2.411 1.393 1.393-2.412h2.784v-2.784l2.412-1.393-1.393-2.411 1.393-2.412-2.412-1.392V5.339h-2.784zm-4.964 7.107l4.432-4.431 1.767 1.767-6.199 6.2-3.92-3.92 1.769-1.767 2.151 2.152z"
                                                    fill="currentColor"></path>
                                            </svg>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <p>359,006.36 &nbsp;<span class="text-success">102.05 </span></p>
                                </td>
                                <td>
                                    <p>4 </p>
                                </td>
                            </tr>

                            <tr>
                                <td>
                                    <div class="nft-first-column">
                                        <img src="{{ asset('public/assets/img/third-i.png') }}" class="img-fluid"
                                            alt="NFT image" />
                                        <img src="{{ asset('public/assets/img/top-collection-user.png') }}"
                                            class="img-fluid" alt="NFT image" />
                                        <p class="nft-collection-head">BULL BTC CLUB </p>
                                        <div>
                                            <svg viewBox="0 0 24 24" fill="none" class="css-14nfsts">
                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                    d="M15.824 5.34L14.43 2.927 12.02 4.32 9.608 2.928 8.216 5.339H5.43v2.785L3.02 9.516l1.392 2.412-1.392 2.411 2.411 1.392v2.785h2.785l1.392 2.412 2.412-1.393 2.411 1.393 1.393-2.412h2.784v-2.784l2.412-1.393-1.393-2.411 1.393-2.412-2.412-1.392V5.339h-2.784zm-4.964 7.107l4.432-4.431 1.767 1.767-6.199 6.2-3.92-3.92 1.769-1.767 2.151 2.152z"
                                                    fill="currentColor"></path>
                                            </svg>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <p>359,006.36 &nbsp;<span class="text-danger">-12.05 </span></p>
                                </td>
                                <td>
                                    <p>4 </p>
                                </td>
                            </tr>

                            <tr>
                                <td>
                                    <div class="nft-first-column">
                                        <img src="{{ asset('public/assets/img/first-i.png') }}" class="img-fluid"
                                            alt="NFT image" />
                                        <img src="{{ asset('public/assets/img/top-collection-user.png') }}"
                                            class="img-fluid" alt="NFT image" />
                                        <p class="nft-collection-head">BULL BTC CLUB </p>
                                        <div>
                                            <svg viewBox="0 0 24 24" fill="none" class="css-14nfsts">
                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                    d="M15.824 5.34L14.43 2.927 12.02 4.32 9.608 2.928 8.216 5.339H5.43v2.785L3.02 9.516l1.392 2.412-1.392 2.411 2.411 1.392v2.785h2.785l1.392 2.412 2.412-1.393 2.411 1.393 1.393-2.412h2.784v-2.784l2.412-1.393-1.393-2.411 1.393-2.412-2.412-1.392V5.339h-2.784zm-4.964 7.107l4.432-4.431 1.767 1.767-6.199 6.2-3.92-3.92 1.769-1.767 2.151 2.152z"
                                                    fill="currentColor"></path>
                                            </svg>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <p>359,006.36 &nbsp;<span class="text-danger">-12.05 </span></p>
                                </td>
                                <td>
                                    <p>4 </p>
                                </td>
                            </tr>

                            <tr>
                                <td>
                                    <div class="nft-first-column">
                                        <img src="{{ asset('public/assets/img/second-i.png') }}" class="img-fluid"
                                            alt="NFT image" />
                                        <img src="{{ asset('public/assets/img/top-collection-user.png') }}"
                                            class="img-fluid" alt="NFT image" />
                                        <p class="nft-collection-head">BULL BTC CLUB </p>
                                        <div>
                                            <svg viewBox="0 0 24 24" fill="none" class="css-14nfsts">
                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                    d="M15.824 5.34L14.43 2.927 12.02 4.32 9.608 2.928 8.216 5.339H5.43v2.785L3.02 9.516l1.392 2.412-1.392 2.411 2.411 1.392v2.785h2.785l1.392 2.412 2.412-1.393 2.411 1.393 1.393-2.412h2.784v-2.784l2.412-1.393-1.393-2.411 1.393-2.412-2.412-1.392V5.339h-2.784zm-4.964 7.107l4.432-4.431 1.767 1.767-6.199 6.2-3.92-3.92 1.769-1.767 2.151 2.152z"
                                                    fill="currentColor"></path>
                                            </svg>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <p>359,006.36 &nbsp;<span class="text-success">82.05 </span></p>
                                </td>
                                <td>
                                    <p>4 </p>
                                </td>
                            </tr>

                            <tr>
                                <td>
                                    <div class="nft-first-column">
                                        <img src="{{ asset('public/assets/img/third-i.png') }}" class="img-fluid"
                                            alt="NFT image" />
                                        <img src="{{ asset('public/assets/img/top-collection-user.png') }}"
                                            class="img-fluid" alt="NFT image" />
                                        <p class="nft-collection-head">BULL BTC CLUB </p>
                                        <div>
                                            <svg viewBox="0 0 24 24" fill="none" class="css-14nfsts">
                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                    d="M15.824 5.34L14.43 2.927 12.02 4.32 9.608 2.928 8.216 5.339H5.43v2.785L3.02 9.516l1.392 2.412-1.392 2.411 2.411 1.392v2.785h2.785l1.392 2.412 2.412-1.393 2.411 1.393 1.393-2.412h2.784v-2.784l2.412-1.393-1.393-2.411 1.393-2.412-2.412-1.392V5.339h-2.784zm-4.964 7.107l4.432-4.431 1.767 1.767-6.199 6.2-3.92-3.92 1.769-1.767 2.151 2.152z"
                                                    fill="currentColor"></path>
                                            </svg>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <p>359,006.36 &nbsp;<span class="text-success">12.05 </span></p>
                                </td>
                                <td>
                                    <p>4 </p>
                                </td>
                            </tr>

                            <tr>
                                <td>
                                    <div class="nft-first-column">
                                        <img src="{{ asset('public/assets/img/first-i.png') }}" class="img-fluid"
                                            alt="NFT image" />
                                        <img src="{{ asset('public/assets/img/top-collection-user.png') }}"
                                            class="img-fluid" alt="NFT image" />
                                        <p class="nft-collection-head">BULL BTC CLUB </p>
                                        <div>
                                            <svg viewBox="0 0 24 24" fill="none" class="css-14nfsts">
                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                    d="M15.824 5.34L14.43 2.927 12.02 4.32 9.608 2.928 8.216 5.339H5.43v2.785L3.02 9.516l1.392 2.412-1.392 2.411 2.411 1.392v2.785h2.785l1.392 2.412 2.412-1.393 2.411 1.393 1.393-2.412h2.784v-2.784l2.412-1.393-1.393-2.411 1.393-2.412-2.412-1.392V5.339h-2.784zm-4.964 7.107l4.432-4.431 1.767 1.767-6.199 6.2-3.92-3.92 1.769-1.767 2.151 2.152z"
                                                    fill="currentColor"></path>
                                            </svg>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <p>359,006.36 &nbsp;<span class="text-danger">-12.05 </span></p>
                                </td>
                                <td>
                                    <p>4 </p>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                  </div>
                </div>
                <div class="tab-pane fade" id="profile-nft-top-collection" role="tabpanel"
                    aria-labelledby="profile-nft-top-collection-tab">
                  <div class="table-responsive">  
                  <table class="table table-borderless border-hovered">
                        <thead>
                            <tr>
                                <th scope="col">Collection</th>
                                <th scope="col">Volume (USD)</th>
                                <th scope="col">Floor Price (USD)</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>
                                    <div class="nft-first-column">
                                        <img src="{{ asset('public/assets/img/first-i.png') }}" class="img-fluid"
                                            alt="NFT image" />
                                        <img src="{{ asset('public/assets/img/top-collection-user.png') }}"
                                            class="img-fluid" alt="NFT image" />
                                        <p class="nft-collection-head">BULL BTC CLUB </p>
                                        <div>
                                            <svg viewBox="0 0 24 24" fill="none" class="css-14nfsts">
                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                    d="M15.824 5.34L14.43 2.927 12.02 4.32 9.608 2.928 8.216 5.339H5.43v2.785L3.02 9.516l1.392 2.412-1.392 2.411 2.411 1.392v2.785h2.785l1.392 2.412 2.412-1.393 2.411 1.393 1.393-2.412h2.784v-2.784l2.412-1.393-1.393-2.411 1.393-2.412-2.412-1.392V5.339h-2.784zm-4.964 7.107l4.432-4.431 1.767 1.767-6.199 6.2-3.92-3.92 1.769-1.767 2.151 2.152z"
                                                    fill="currentColor"></path>
                                            </svg>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <p>359,006.36 &nbsp;<span class="text-danger">-12.05 </span></p>
                                </td>
                                <td>
                                    <p>4 </p>
                                </td>
                            </tr>

                            <tr>
                                <td>
                                    <div class="nft-first-column">
                                        <img src="{{ asset('public/assets/img/second-i.png') }}" class="img-fluid"
                                            alt="NFT image" />
                                        <img src="{{ asset('public/assets/img/top-collection-user.png') }}"
                                            class="img-fluid" alt="NFT image" />
                                        <p class="nft-collection-head">BULL BTC CLUB </p>
                                        <div>
                                            <svg viewBox="0 0 24 24" fill="none" class="css-14nfsts">
                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                    d="M15.824 5.34L14.43 2.927 12.02 4.32 9.608 2.928 8.216 5.339H5.43v2.785L3.02 9.516l1.392 2.412-1.392 2.411 2.411 1.392v2.785h2.785l1.392 2.412 2.412-1.393 2.411 1.393 1.393-2.412h2.784v-2.784l2.412-1.393-1.393-2.411 1.393-2.412-2.412-1.392V5.339h-2.784zm-4.964 7.107l4.432-4.431 1.767 1.767-6.199 6.2-3.92-3.92 1.769-1.767 2.151 2.152z"
                                                    fill="currentColor"></path>
                                            </svg>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <p>359,006.36 &nbsp;<span class="text-success">42.05 </span></p>
                                </td>
                                <td>
                                    <p>4 </p>
                                </td>
                            </tr>

                            <tr>
                                <td>
                                    <div class="nft-first-column">
                                        <img src="{{ asset('public/assets/img/third-i.png') }}" class="img-fluid"
                                            alt="NFT image" />
                                        <img src="{{ asset('public/assets/img/top-collection-user.png') }}"
                                            class="img-fluid" alt="NFT image" />
                                        <p class="nft-collection-head">BULL BTC CLUB </p>
                                        <div>
                                            <svg viewBox="0 0 24 24" fill="none" class="css-14nfsts">
                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                    d="M15.824 5.34L14.43 2.927 12.02 4.32 9.608 2.928 8.216 5.339H5.43v2.785L3.02 9.516l1.392 2.412-1.392 2.411 2.411 1.392v2.785h2.785l1.392 2.412 2.412-1.393 2.411 1.393 1.393-2.412h2.784v-2.784l2.412-1.393-1.393-2.411 1.393-2.412-2.412-1.392V5.339h-2.784zm-4.964 7.107l4.432-4.431 1.767 1.767-6.199 6.2-3.92-3.92 1.769-1.767 2.151 2.152z"
                                                    fill="currentColor"></path>
                                            </svg>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <p>359,006.36 &nbsp;<span class="text-danger">-12.05 </span></p>
                                </td>
                                <td>
                                    <p>4 </p>
                                </td>
                            </tr>

                            <tr>
                                <td>
                                    <div class="nft-first-column">
                                        <img src="{{ asset('public/assets/img/first-i.png') }}" class="img-fluid"
                                            alt="NFT image" />
                                        <img src="{{ asset('public/assets/img/top-collection-user.png') }}"
                                            class="img-fluid" alt="NFT image" />
                                        <p class="nft-collection-head">BULL BTC CLUB </p>
                                        <div>
                                            <svg viewBox="0 0 24 24" fill="none" class="css-14nfsts">
                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                    d="M15.824 5.34L14.43 2.927 12.02 4.32 9.608 2.928 8.216 5.339H5.43v2.785L3.02 9.516l1.392 2.412-1.392 2.411 2.411 1.392v2.785h2.785l1.392 2.412 2.412-1.393 2.411 1.393 1.393-2.412h2.784v-2.784l2.412-1.393-1.393-2.411 1.393-2.412-2.412-1.392V5.339h-2.784zm-4.964 7.107l4.432-4.431 1.767 1.767-6.199 6.2-3.92-3.92 1.769-1.767 2.151 2.152z"
                                                    fill="currentColor"></path>
                                            </svg>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <p>359,006.36 &nbsp;<span class="text-danger">-12.05 </span></p>
                                </td>
                                <td>
                                    <p>4 </p>
                                </td>
                            </tr>

                            <tr>
                                <td>
                                    <div class="nft-first-column">
                                        <img src="{{ asset('public/assets/img/second-i.png') }}" class="img-fluid"
                                            alt="NFT image" />
                                        <img src="{{ asset('public/assets/img/top-collection-user.png') }}"
                                            class="img-fluid" alt="NFT image" />
                                        <p class="nft-collection-head">BULL BTC CLUB </p>
                                        <div>
                                            <svg viewBox="0 0 24 24" fill="none" class="css-14nfsts">
                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                    d="M15.824 5.34L14.43 2.927 12.02 4.32 9.608 2.928 8.216 5.339H5.43v2.785L3.02 9.516l1.392 2.412-1.392 2.411 2.411 1.392v2.785h2.785l1.392 2.412 2.412-1.393 2.411 1.393 1.393-2.412h2.784v-2.784l2.412-1.393-1.393-2.411 1.393-2.412-2.412-1.392V5.339h-2.784zm-4.964 7.107l4.432-4.431 1.767 1.767-6.199 6.2-3.92-3.92 1.769-1.767 2.151 2.152z"
                                                    fill="currentColor"></path>
                                            </svg>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <p>359,006.36 &nbsp;<span class="text-success">102.05 </span></p>
                                </td>
                                <td>
                                    <p>4 </p>
                                </td>
                            </tr>

                            <tr>
                                <td>
                                    <div class="nft-first-column">
                                        <img src="{{ asset('public/assets/img/third-i.png') }}" class="img-fluid"
                                            alt="NFT image" />
                                        <img src="{{ asset('public/assets/img/top-collection-user.png') }}"
                                            class="img-fluid" alt="NFT image" />
                                        <p class="nft-collection-head">BULL BTC CLUB </p>
                                        <div>
                                            <svg viewBox="0 0 24 24" fill="none" class="css-14nfsts">
                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                    d="M15.824 5.34L14.43 2.927 12.02 4.32 9.608 2.928 8.216 5.339H5.43v2.785L3.02 9.516l1.392 2.412-1.392 2.411 2.411 1.392v2.785h2.785l1.392 2.412 2.412-1.393 2.411 1.393 1.393-2.412h2.784v-2.784l2.412-1.393-1.393-2.411 1.393-2.412-2.412-1.392V5.339h-2.784zm-4.964 7.107l4.432-4.431 1.767 1.767-6.199 6.2-3.92-3.92 1.769-1.767 2.151 2.152z"
                                                    fill="currentColor"></path>
                                            </svg>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <p>359,006.36 &nbsp;<span class="text-danger">-12.05 </span></p>
                                </td>
                                <td>
                                    <p>4 </p>
                                </td>
                            </tr>

                            <tr>
                                <td>
                                    <div class="nft-first-column">
                                        <img src="{{ asset('public/assets/img/first-i.png') }}" class="img-fluid"
                                            alt="NFT image" />
                                        <img src="{{ asset('public/assets/img/top-collection-user.png') }}"
                                            class="img-fluid" alt="NFT image" />
                                        <p class="nft-collection-head">BULL BTC CLUB </p>
                                        <div>
                                            <svg viewBox="0 0 24 24" fill="none" class="css-14nfsts">
                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                    d="M15.824 5.34L14.43 2.927 12.02 4.32 9.608 2.928 8.216 5.339H5.43v2.785L3.02 9.516l1.392 2.412-1.392 2.411 2.411 1.392v2.785h2.785l1.392 2.412 2.412-1.393 2.411 1.393 1.393-2.412h2.784v-2.784l2.412-1.393-1.393-2.411 1.393-2.412-2.412-1.392V5.339h-2.784zm-4.964 7.107l4.432-4.431 1.767 1.767-6.199 6.2-3.92-3.92 1.769-1.767 2.151 2.152z"
                                                    fill="currentColor"></path>
                                            </svg>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <p>359,006.36 &nbsp;<span class="text-danger">-12.05 </span></p>
                                </td>
                                <td>
                                    <p>4 </p>
                                </td>
                            </tr>

                            <tr>
                                <td>
                                    <div class="nft-first-column">
                                        <img src="{{ asset('public/assets/img/second-i.png') }}" class="img-fluid"
                                            alt="NFT image" />
                                        <img src="{{ asset('public/assets/img/top-collection-user.png') }}"
                                            class="img-fluid" alt="NFT image" />
                                        <p class="nft-collection-head">BULL BTC CLUB </p>
                                        <div>
                                            <svg viewBox="0 0 24 24" fill="none" class="css-14nfsts">
                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                    d="M15.824 5.34L14.43 2.927 12.02 4.32 9.608 2.928 8.216 5.339H5.43v2.785L3.02 9.516l1.392 2.412-1.392 2.411 2.411 1.392v2.785h2.785l1.392 2.412 2.412-1.393 2.411 1.393 1.393-2.412h2.784v-2.784l2.412-1.393-1.393-2.411 1.393-2.412-2.412-1.392V5.339h-2.784zm-4.964 7.107l4.432-4.431 1.767 1.767-6.199 6.2-3.92-3.92 1.769-1.767 2.151 2.152z"
                                                    fill="currentColor"></path>
                                            </svg>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <p>359,006.36 &nbsp;<span class="text-success">82.05 </span></p>
                                </td>
                                <td>
                                    <p>4 </p>
                                </td>
                            </tr>

                            <tr>
                                <td>
                                    <div class="nft-first-column">
                                        <img src="{{ asset('public/assets/img/third-i.png') }}" class="img-fluid"
                                            alt="NFT image" />
                                        <img src="{{ asset('public/assets/img/top-collection-user.png') }}"
                                            class="img-fluid" alt="NFT image" />
                                        <p class="nft-collection-head">BULL BTC CLUB </p>
                                        <div>
                                            <svg viewBox="0 0 24 24" fill="none" class="css-14nfsts">
                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                    d="M15.824 5.34L14.43 2.927 12.02 4.32 9.608 2.928 8.216 5.339H5.43v2.785L3.02 9.516l1.392 2.412-1.392 2.411 2.411 1.392v2.785h2.785l1.392 2.412 2.412-1.393 2.411 1.393 1.393-2.412h2.784v-2.784l2.412-1.393-1.393-2.411 1.393-2.412-2.412-1.392V5.339h-2.784zm-4.964 7.107l4.432-4.431 1.767 1.767-6.199 6.2-3.92-3.92 1.769-1.767 2.151 2.152z"
                                                    fill="currentColor"></path>
                                            </svg>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <p>359,006.36 &nbsp;<span class="text-success">12.05 </span></p>
                                </td>
                                <td>
                                    <p>4 </p>
                                </td>
                            </tr>

                            <tr>
                                <td>
                                    <div class="nft-first-column">
                                        <img src="{{ asset('public/assets/img/first-i.png') }}" class="img-fluid"
                                            alt="NFT image" />
                                        <img src="{{ asset('public/assets/img/top-collection-user.png') }}"
                                            class="img-fluid" alt="NFT image" />
                                        <p class="nft-collection-head">BULL BTC CLUB </p>
                                        <div>
                                            <svg viewBox="0 0 24 24" fill="none" class="css-14nfsts">
                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                    d="M15.824 5.34L14.43 2.927 12.02 4.32 9.608 2.928 8.216 5.339H5.43v2.785L3.02 9.516l1.392 2.412-1.392 2.411 2.411 1.392v2.785h2.785l1.392 2.412 2.412-1.393 2.411 1.393 1.393-2.412h2.784v-2.784l2.412-1.393-1.393-2.411 1.393-2.412-2.412-1.392V5.339h-2.784zm-4.964 7.107l4.432-4.431 1.767 1.767-6.199 6.2-3.92-3.92 1.769-1.767 2.151 2.152z"
                                                    fill="currentColor"></path>
                                            </svg>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <p>359,006.36 &nbsp;<span class="text-danger">-12.05 </span></p>
                                </td>
                                <td>
                                    <p>4 </p>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                  </div>
                </div>
            </div>
        </div>
    </section>

    <section class="recommended-creators">
        <div class="container">
            <div class="row">
                <div class="sec-title">
                    <span class="title">Know About</span>
                    <h2 class="heading-h2">Recommended <span class="yellow-text">Creators</span></h2>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                    <div class="nft-creator-box">
                        <a href="#" target="_blank" class="become-marchent-a">
                            <div class="become-marchent">
                                <img loading="lazy" class="img-fluid mb-3"
                                    src="{{ asset('public/assets/img/creator-img-1.gif') }}" alt="NFT image">
                                <div class="become-marchent-txt-div">
                                    <div class="become-marchent-txt-div-bold">Become a Merchant</div>
                                    <div class="become-marchent-txt-div-normal">Accept cryptocurrency payments and tap
                                        into
                                        .</div>
                                </div>
                                <div class="become-marchent-svg-div">
                                    <svg viewBox="0 0 24 24" fill="none" cursor="pointer" class="wm-svg">
                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                            d="M11 8.5a3.5 3.5 0 11-7 0 3.5 3.5 0 017 0zM2 17a3 3 0 013-3h5a3 3 0 013 3v3H2v-3zm14.5-1v-3h-3v-3h3V7h3v3h3v3h-3v3h-3z"
                                            fill="currentColor"></path>
                                    </svg>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                    <div class="nft-creator-box">
                        <a href="#" target="_blank" class="become-marchent-a">
                            <div class="become-marchent">
                                <img loading="lazy" class="img-fluid mb-3"
                                    src="{{ asset('public/assets/img/creator-img-2.gif') }}" alt="NFT image">
                                <div class="become-marchent-txt-div">
                                    <div class="become-marchent-txt-div-bold">Become a Merchant</div>
                                    <div class="become-marchent-txt-div-normal">Accept cryptocurrency payments and tap
                                        into
                                        .</div>
                                </div>
                                <div class="become-marchent-svg-div">
                                    <svg viewBox="0 0 24 24" fill="none" cursor="pointer" class="wm-svg">
                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                            d="M11 8.5a3.5 3.5 0 11-7 0 3.5 3.5 0 017 0zM2 17a3 3 0 013-3h5a3 3 0 013 3v3H2v-3zm14.5-1v-3h-3v-3h3V7h3v3h3v3h-3v3h-3z"
                                            fill="currentColor"></path>
                                    </svg>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-lg-4  col-sm-6 col-xs-12 full-block">
                    <div class="nft-creator-box">
                        <a href="#" target="_blank" class="become-marchent-a">
                            <div class="become-marchent">
                                <img loading="lazy" class="img-fluid mb-3"
                                    src="{{ asset('public/assets/img/creator-img-3.gif') }}" alt="NFT image">
                                <div class="become-marchent-txt-div">
                                    <div class="become-marchent-txt-div-bold">Become a Merchant</div>
                                    <div class="become-marchent-txt-div-normal">Accept cryptocurrency payments and tap
                                        into
                                        .</div>
                                </div>
                                <div class="become-marchent-svg-div">
                                    <svg viewBox="0 0 24 24" fill="none" cursor="pointer" class="wm-svg">
                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                            d="M11 8.5a3.5 3.5 0 11-7 0 3.5 3.5 0 017 0zM2 17a3 3 0 013-3h5a3 3 0 013 3v3H2v-3zm14.5-1v-3h-3v-3h3V7h3v3h3v3h-3v3h-3z"
                                            fill="currentColor"></path>
                                    </svg>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                    <div class="nft-creator-box">
                        <a href="#" target="_blank" class="become-marchent-a">
                            <div class="become-marchent">
                                <img loading="lazy" class="img-fluid mb-3"
                                    src="{{ asset('public/assets/img/creator-img-4.gif') }}" alt="NFT image">
                                <div class="become-marchent-txt-div">
                                    <div class="become-marchent-txt-div-bold">Become a Merchant</div>
                                    <div class="become-marchent-txt-div-normal">Accept cryptocurrency payments and tap
                                        into
                                        .</div>
                                </div>
                                <div class="become-marchent-svg-div">
                                    <svg viewBox="0 0 24 24" fill="none" cursor="pointer" class="wm-svg">
                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                            d="M11 8.5a3.5 3.5 0 11-7 0 3.5 3.5 0 017 0zM2 17a3 3 0 013-3h5a3 3 0 013 3v3H2v-3zm14.5-1v-3h-3v-3h3V7h3v3h3v3h-3v3h-3z"
                                            fill="currentColor"></path>
                                    </svg>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                    <div class="nft-creator-box">
                        <a href="#" target="_blank" class="become-marchent-a">
                            <div class="become-marchent">
                                <img loading="lazy" class="img-fluid mb-3"
                                    src="{{ asset('public/assets/img/creator-img-5.gif') }}" alt="NFT image">
                                <div class="become-marchent-txt-div">
                                    <div class="become-marchent-txt-div-bold">Become a Merchant</div>
                                    <div class="become-marchent-txt-div-normal">Accept cryptocurrency payments and tap
                                        into
                                        .</div>
                                </div>
                                <div class="become-marchent-svg-div">
                                    <svg viewBox="0 0 24 24" fill="none" cursor="pointer" class="wm-svg">
                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                            d="M11 8.5a3.5 3.5 0 11-7 0 3.5 3.5 0 017 0zM2 17a3 3 0 013-3h5a3 3 0 013 3v3H2v-3zm14.5-1v-3h-3v-3h3V7h3v3h3v3h-3v3h-3z"
                                            fill="currentColor"></path>
                                    </svg>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-lg-4 col-sm-6 col-xs-12 full-block">
                    <div class="nft-creator-box">
                        <a href="#" target="_blank" class="become-marchent-a">
                            <div class="become-marchent">
                                <img loading="lazy" class="img-fluid mb-3"
                                    src="{{ asset('public/assets/img/creator-img-6.gif') }}" alt="NFT image">
                                <div class="become-marchent-txt-div">
                                    <div class="become-marchent-txt-div-bold">Become a Merchant</div>
                                    <div class="become-marchent-txt-div-normal">Accept cryptocurrency payments and tap
                                        into
                                        .</div>
                                </div>
                                <div class="become-marchent-svg-div">
                                    <svg viewBox="0 0 24 24" fill="none" cursor="pointer" class="wm-svg">
                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                            d="M11 8.5a3.5 3.5 0 11-7 0 3.5 3.5 0 017 0zM2 17a3 3 0 013-3h5a3 3 0 013 3v3H2v-3zm14.5-1v-3h-3v-3h3V7h3v3h3v3h-3v3h-3z"
                                            fill="currentColor"></path>
                                    </svg>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>

    </section>
    <section class="featured-nfts-box" id="featured-nfts-box">
        <div class="container">
            <div class="row">
                <div class="sec-title text-left">
                    <span class="title">Know About</span>
                    <h2 class="heading-h2">Featured NFTs</h2>
                </div>
            </div>
            <ul class="nav nav-tabs" id="featured-nfts-tab" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active" id="home-featured-nfts-tab" data-bs-toggle="tab"
                        data-bs-target="#home-featured-nfts" type="button" role="tab" aria-controls="home-featured-nfts"
                        aria-selected="true">Trending</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="profile-featured-nfts-tab" data-bs-toggle="tab"
                        data-bs-target="#profile-featured-nfts" type="button" role="tab"
                        aria-controls="profile-featured-nfts" aria-selected="false">Gaming</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="contact-featured-nfts-tab" data-bs-toggle="tab"
                        data-bs-target="#contact-featured-nfts" type="button" role="tab"
                        aria-controls="contact-featured-nfts" aria-selected="false">Today's Pick</button>
                </li>
            </ul>
            <div class="tab-content" id="featured-nfts-tabContent">
                <div class="tab-pane fade show active" id="home-featured-nfts" role="tabpanel"
                    aria-labelledby="home-featured-nfts-tab">
                    <div class="row">

                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                            <div class="card card2">
                                <div class="card-body">
                                    <div class="row mb-4">
                                        <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                            <img loading="lazy"
                                                src="{{ asset('public/assets/img/featured-nft-2.png') }}"
                                                alt="NFT image" class=" img-fluid">
                                        </div>
                                    </div>

                                    <div class="row mb-4">
                                        <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                            <p class="fw-bolder">BBC</p>
                                        </div>
                                    </div>
                                    <div class="row mb-1">
                                        <div class="col-md-8 col-sm-6 col-xs-6">
                                            <h5>BULL BTC CLUB:</h5>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <p>BSC</p>
                                        </div>
                                    </div>
                                    <div class="row mb-1">
                                        <div class="col-md-8 col-sm-6 col-xs-6">
                                            <h5>Price:</h5>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <p>300 BUSD<br />≈ $ 379.96</p>
                                        </div>
                                    </div>
                                    <div class="row mb-1">
                                        <div class="col-md-8 col-sm-6 col-xs-6">
                                            <h5>&#9200; In 1 Day</h5>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <p>&#9825; 155</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                            <div class="card card2">
                                <div class="card-body">
                                    <div class="row mb-4">
                                        <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                            <img loading="lazy"
                                                src="{{ asset('public/assets/img/featured-nft-3.png') }}"
                                                alt="NFT image" class=" img-fluid">
                                        </div>
                                    </div>

                                    <div class="row mb-4">
                                        <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                            <p class="fw-bolder">BBC</p>
                                        </div>
                                    </div>
                                    <div class="row mb-1">
                                        <div class="col-md-8 col-sm-6 col-xs-6">
                                            <h5>BULL BTC CLUB:</h5>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <p>BSC</p>
                                        </div>
                                    </div>
                                    <div class="row mb-1">
                                        <div class="col-md-8 col-sm-6 col-xs-6">
                                            <h5>Price:</h5>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <p>300 BUSD<br />≈ $ 379.96</p>
                                        </div>
                                    </div>
                                    <div class="row mb-1">
                                        <div class="col-md-8 col-sm-6 col-xs-6">
                                            <h5>&#9200; In 1 Day</h5>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <p>&#9825; 155</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                            <div class="card card2">
                                <div class="card-body">
                                    <div class="row mb-4">
                                        <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                            <img loading="lazy"
                                                src="{{ asset('public/assets/img/featured-nft-4.png') }}"
                                                alt="NFT image" class=" img-fluid">
                                        </div>
                                    </div>

                                    <div class="row mb-4">
                                        <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                            <p class="fw-bolder">BBC</p>
                                        </div>
                                    </div>
                                    <div class="row mb-1">
                                        <div class="col-md-8 col-sm-6 col-xs-6">
                                            <h5>BULL BTC CLUB:</h5>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <p>BSC</p>
                                        </div>
                                    </div>
                                    <div class="row mb-1">
                                        <div class="col-md-8 col-sm-6 col-xs-6">
                                            <h5>Price:</h5>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <p>300 BUSD<br />≈ $ 379.96</p>
                                        </div>
                                    </div>
                                    <div class="row mb-1">
                                        <div class="col-md-8 col-sm-6 col-xs-6">
                                            <h5>&#9200; In 1 Day</h5>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <p>&#9825; 155</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                            <div class="card card2">
                                <div class="card-body">
                                    <div class="row mb-4">
                                        <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                            <img loading="lazy" src="{{ asset('public/assets/img/featured-nft.png') }}"
                                                alt="NFT image" class=" img-fluid">
                                        </div>
                                    </div>

                                    <div class="row mb-4">
                                        <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                            <p class="fw-bolder">BBC</p>
                                        </div>
                                    </div>
                                    <div class="row mb-1">
                                        <div class="col-md-8 col-sm-6 col-xs-6">
                                            <h5>BULL BTC CLUB:</h5>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <p>BSC</p>
                                        </div>
                                    </div>
                                    <div class="row mb-1">
                                        <div class="col-md-8 col-sm-6 col-xs-6">
                                            <h5>Price:</h5>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <p>300 BUSD<br />≈ $ 379.96</p>
                                        </div>
                                    </div>
                                    <div class="row mb-1">
                                        <div class="col-md-8 col-sm-6 col-xs-6">
                                            <h5>&#9200; In 1 Day</h5>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <p>&#9825; 155</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                    </div>

                    <div class="row mt-3">

                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                            <div class="card card2">
                                <div class="card-body">
                                    <div class="row mb-4">
                                        <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                            <img loading="lazy"
                                                src="{{ asset('public/assets/img/featured-nft-2.png') }}"
                                                alt="NFT image" class=" img-fluid">
                                        </div>
                                    </div>

                                    <div class="row mb-4">
                                        <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                            <p class="fw-bolder">BBC</p>
                                        </div>
                                    </div>
                                    <div class="row mb-1">
                                        <div class="col-md-8 col-sm-6 col-xs-6">
                                            <h5>BULL BTC CLUB:</h5>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <p>BSC</p>
                                        </div>
                                    </div>
                                    <div class="row mb-1">
                                        <div class="col-md-8 col-sm-6 col-xs-6">
                                            <h5>Price:</h5>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <p>300 BUSD<br />≈ $ 379.96</p>
                                        </div>
                                    </div>
                                    <div class="row mb-1">
                                        <div class="col-md-8 col-sm-6 col-xs-6">
                                            <h5>&#9200; In 1 Day</h5>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <p>&#9825; 155</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                            <div class="card card2">
                                <div class="card-body">
                                    <div class="row mb-4">
                                        <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                            <img loading="lazy"
                                                src="{{ asset('public/assets/img/featured-nft-2.png') }}"
                                                alt="NFT image" class=" img-fluid">
                                        </div>
                                    </div>

                                    <div class="row mb-4">
                                        <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                            <p class="fw-bolder">BBC</p>
                                        </div>
                                    </div>
                                    <div class="row mb-1">
                                        <div class="col-md-8 col-sm-6 col-xs-6">
                                            <h5>BULL BTC CLUB:</h5>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <p>BSC</p>
                                        </div>
                                    </div>
                                    <div class="row mb-1">
                                        <div class="col-md-8 col-sm-6 col-xs-6">
                                            <h5>Price:</h5>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <p>300 BUSD<br />≈ $ 379.96</p>
                                        </div>
                                    </div>
                                    <div class="row mb-1">
                                        <div class="col-md-8 col-sm-6 col-xs-6">
                                            <h5>&#9200; In 1 Day</h5>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <p>&#9825; 155</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                            <div class="card card2">
                                <div class="card-body">
                                    <div class="row mb-4">
                                        <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                            <img loading="lazy"
                                                src="{{ asset('public/assets/img/featured-nft-3.png') }}"
                                                alt="NFT image" class=" img-fluid">
                                        </div>
                                    </div>

                                    <div class="row mb-4">
                                        <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                            <p class="fw-bolder">BBC</p>
                                        </div>
                                    </div>
                                    <div class="row mb-1">
                                        <div class="col-md-8 col-sm-6 col-xs-6">
                                            <h5>BULL BTC CLUB:</h5>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <p>BSC</p>
                                        </div>
                                    </div>
                                    <div class="row mb-1">
                                        <div class="col-md-8 col-sm-6 col-xs-6">
                                            <h5>Price:</h5>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <p>300 BUSD<br />≈ $ 379.96</p>
                                        </div>
                                    </div>
                                    <div class="row mb-1">
                                        <div class="col-md-8 col-sm-6 col-xs-6">
                                            <h5>&#9200; In 1 Day</h5>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <p>&#9825; 155</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                            <div class="card card2">
                                <div class="card-body">
                                    <div class="row mb-4">
                                        <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                            <img loading="lazy"
                                                src="{{ asset('public/assets/img/featured-nft-2.png') }}"
                                                alt="NFT image" class=" img-fluid">
                                        </div>
                                    </div>

                                    <div class="row mb-4">
                                        <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                            <p class="fw-bolder">BBC</p>
                                        </div>
                                    </div>
                                    <div class="row mb-1">
                                        <div class="col-md-8 col-sm-6 col-xs-6">
                                            <h5>BULL BTC CLUB:</h5>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <p>BSC</p>
                                        </div>
                                    </div>
                                    <div class="row mb-1">
                                        <div class="col-md-8 col-sm-6 col-xs-6">
                                            <h5>Price:</h5>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <p>300 BUSD<br />≈ $ 379.96</p>
                                        </div>
                                    </div>
                                    <div class="row mb-1">
                                        <div class="col-md-8 col-sm-6 col-xs-6">
                                            <h5>&#9200; In 1 Day</h5>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <p>&#9825; 155</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                    </div>
                </div>
                <div class="tab-pane fade" id="profile-featured-nfts" role="tabpanel"
                    aria-labelledby="profile-featured-nfts-tab">
                    <div class="row">

                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                            <div class="card card2">
                                <div class="card-body">
                                    <div class="row mb-4">
                                        <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                            <img loading="lazy"
                                                src="{{ asset('public/assets/img/nft-gaming-img.png') }}"
                                                alt="NFT image" class=" img-fluid">
                                        </div>
                                    </div>

                                    <div class="row mb-4">
                                        <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                            <p class="fw-bolder">BBC</p>
                                        </div>
                                    </div>
                                    <div class="row mb-1">
                                        <div class="col-md-8 col-sm-6 col-xs-6">
                                            <h5>BULL BTC CLUB:</h5>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <p>BSC</p>
                                        </div>
                                    </div>
                                    <div class="row mb-1">
                                        <div class="col-md-8 col-sm-6 col-xs-6">
                                            <h5>Price:</h5>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <p>300 BUSD<br />≈ $ 379.96</p>
                                        </div>
                                    </div>
                                    <div class="row mb-1">
                                        <div class="col-md-8 col-sm-6 col-xs-6">
                                            <h5>&#9200; In 1 Day</h5>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <p>&#9825; 155</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                            <div class="card card2">
                                <div class="card-body">
                                    <div class="row mb-4">
                                        <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                            <img loading="lazy"
                                                src="{{ asset('public/assets/img/nft-gaming-img.png') }}"
                                                alt="NFT image" class=" img-fluid">
                                        </div>
                                    </div>

                                    <div class="row mb-4">
                                        <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                            <p class="fw-bolder">BBC</p>
                                        </div>
                                    </div>
                                    <div class="row mb-1">
                                        <div class="col-md-8 col-sm-6 col-xs-6">
                                            <h5>BULL BTC CLUB:</h5>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <p>BSC</p>
                                        </div>
                                    </div>
                                    <div class="row mb-1">
                                        <div class="col-md-8 col-sm-6 col-xs-6">
                                            <h5>Price:</h5>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <p>300 BUSD<br />≈ $ 379.96</p>
                                        </div>
                                    </div>
                                    <div class="row mb-1">
                                        <div class="col-md-8 col-sm-6 col-xs-6">
                                            <h5>&#9200; In 1 Day</h5>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <p>&#9825; 155</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                            <div class="card card2">
                                <div class="card-body">
                                    <div class="row mb-4">
                                        <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                            <img loading="lazy"
                                                src="{{ asset('public/assets/img/nft-gaming-img.png') }}"
                                                alt="NFT image" class=" img-fluid">
                                        </div>
                                    </div>

                                    <div class="row mb-4">
                                        <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                            <p class="fw-bolder">BBC</p>
                                        </div>
                                    </div>
                                    <div class="row mb-1">
                                        <div class="col-md-8 col-sm-6 col-xs-6">
                                            <h5>BULL BTC CLUB:</h5>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <p>BSC</p>
                                        </div>
                                    </div>
                                    <div class="row mb-1">
                                        <div class="col-md-8 col-sm-6 col-xs-6">
                                            <h5>Price:</h5>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <p>300 BUSD<br />≈ $ 379.96</p>
                                        </div>
                                    </div>
                                    <div class="row mb-1">
                                        <div class="col-md-8 col-sm-6 col-xs-6">
                                            <h5>&#9200; In 1 Day</h5>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <p>&#9825; 155</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                            <div class="card card2">
                                <div class="card-body">
                                    <div class="row mb-4">
                                        <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                            <img loading="lazy"
                                                src="{{ asset('public/assets/img/nft-gaming-img.png') }}"
                                                alt="NFT image" class=" img-fluid">
                                        </div>
                                    </div>

                                    <div class="row mb-4">
                                        <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                            <p class="fw-bolder">BBC</p>
                                        </div>
                                    </div>
                                    <div class="row mb-1">
                                        <div class="col-md-8 col-sm-6 col-xs-6">
                                            <h5>BULL BTC CLUB:</h5>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <p>BSC</p>
                                        </div>
                                    </div>
                                    <div class="row mb-1">
                                        <div class="col-md-8 col-sm-6 col-xs-6">
                                            <h5>Price:</h5>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <p>300 BUSD<br />≈ $ 379.96</p>
                                        </div>
                                    </div>
                                    <div class="row mb-1">
                                        <div class="col-md-8 col-sm-6 col-xs-6">
                                            <h5>&#9200; In 1 Day</h5>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <p>&#9825; 155</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                    </div>

                    <div class="row mt-3">

                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                            <div class="card card2">
                                <div class="card-body">
                                    <div class="row mb-4">
                                        <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                            <img loading="lazy"
                                                src="{{ asset('public/assets/img/featured-nft-2.png') }}"
                                                alt="NFT image" class=" img-fluid">
                                        </div>
                                    </div>

                                    <div class="row mb-4">
                                        <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                            <p class="fw-bolder">BBC</p>
                                        </div>
                                    </div>
                                    <div class="row mb-1">
                                        <div class="col-md-8 col-sm-6 col-xs-6">
                                            <h5>BULL BTC CLUB:</h5>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <p>BSC</p>
                                        </div>
                                    </div>
                                    <div class="row mb-1">
                                        <div class="col-md-8 col-sm-6 col-xs-6">
                                            <h5>Price:</h5>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <p>300 BUSD<br />≈ $ 379.96</p>
                                        </div>
                                    </div>
                                    <div class="row mb-1">
                                        <div class="col-md-8 col-sm-6 col-xs-6">
                                            <h5>&#9200; In 1 Day</h5>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <p>&#9825; 155</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                            <div class="card card2">
                                <div class="card-body">
                                    <div class="row mb-4">
                                        <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                            <img loading="lazy"
                                                src="{{ asset('public/assets/img/featured-nft-2.png') }}"
                                                alt="NFT image" class=" img-fluid">
                                        </div>
                                    </div>

                                    <div class="row mb-4">
                                        <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                            <p class="fw-bolder">BBC</p>
                                        </div>
                                    </div>
                                    <div class="row mb-1">
                                        <div class="col-md-8 col-sm-6 col-xs-6">
                                            <h5>BULL BTC CLUB:</h5>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <p>BSC</p>
                                        </div>
                                    </div>
                                    <div class="row mb-1">
                                        <div class="col-md-8 col-sm-6 col-xs-6">
                                            <h5>Price:</h5>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <p>300 BUSD<br />≈ $ 379.96</p>
                                        </div>
                                    </div>
                                    <div class="row mb-1">
                                        <div class="col-md-8 col-sm-6 col-xs-6">
                                            <h5>&#9200; In 1 Day</h5>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <p>&#9825; 155</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                            <div class="card card2">
                                <div class="card-body">
                                    <div class="row mb-4">
                                        <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                            <img loading="lazy"
                                                src="{{ asset('public/assets/img/featured-nft-3.png') }}"
                                                alt="NFT image" class=" img-fluid">
                                        </div>
                                    </div>

                                    <div class="row mb-4">
                                        <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                            <p class="fw-bolder">BBC</p>
                                        </div>
                                    </div>
                                    <div class="row mb-1">
                                        <div class="col-md-8 col-sm-6 col-xs-6">
                                            <h5>BULL BTC CLUB:</h5>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <p>BSC</p>
                                        </div>
                                    </div>
                                    <div class="row mb-1">
                                        <div class="col-md-8 col-sm-6 col-xs-6">
                                            <h5>Price:</h5>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <p>300 BUSD<br />≈ $ 379.96</p>
                                        </div>
                                    </div>
                                    <div class="row mb-1">
                                        <div class="col-md-8 col-sm-6 col-xs-6">
                                            <h5>&#9200; In 1 Day</h5>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <p>&#9825; 155</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                            <div class="card card2">
                                <div class="card-body">
                                    <div class="row mb-4">
                                        <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                            <img loading="lazy"
                                                src="{{ asset('public/assets/img/featured-nft-2.png') }}"
                                                alt="NFT image" class=" img-fluid">
                                        </div>
                                    </div>

                                    <div class="row mb-4">
                                        <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                            <p class="fw-bolder">BBC</p>
                                        </div>
                                    </div>
                                    <div class="row mb-1">
                                        <div class="col-md-8 col-sm-6 col-xs-6">
                                            <h5>BULL BTC CLUB:</h5>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <p>BSC</p>
                                        </div>
                                    </div>
                                    <div class="row mb-1">
                                        <div class="col-md-8 col-sm-6 col-xs-6">
                                            <h5>Price:</h5>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <p>300 BUSD<br />≈ $ 379.96</p>
                                        </div>
                                    </div>
                                    <div class="row mb-1">
                                        <div class="col-md-8 col-sm-6 col-xs-6">
                                            <h5>&#9200; In 1 Day</h5>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <p>&#9825; 155</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                    </div>
                </div>
                <div class="tab-pane fade" id="contact-featured-nfts" role="tabpanel"
                    aria-labelledby="contact-featured-nfts-tab">
                    <div class="row">

                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                            <div class="card card2">
                                <div class="card-body">
                                    <div class="row mb-4">
                                        <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                            <img loading="lazy"
                                                src="{{ asset('public/assets/img/nft-todays-pic-1.png') }}"
                                                alt="NFT image" class=" img-fluid">
                                        </div>
                                    </div>

                                    <div class="row mb-4">
                                        <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                            <p class="fw-bolder">BBC</p>
                                        </div>
                                    </div>
                                    <div class="row mb-1">
                                        <div class="col-md-8 col-sm-6 col-xs-6">
                                            <h5>BULL BTC CLUB:</h5>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <p>BSC</p>
                                        </div>
                                    </div>
                                    <div class="row mb-1">
                                        <div class="col-md-8 col-sm-6 col-xs-6">
                                            <h5>Price:</h5>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <p>300 BUSD<br />≈ $ 379.96</p>
                                        </div>
                                    </div>
                                    <div class="row mb-1">
                                        <div class="col-md-8 col-sm-6 col-xs-6">
                                            <h5>&#9200; In 1 Day</h5>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <p>&#9825; 155</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                            <div class="card card2">
                                <div class="card-body">
                                    <div class="row mb-4">
                                        <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                            <img loading="lazy"
                                                src="{{ asset('public/assets/img/featured-nft-3.png') }}"
                                                alt="NFT image" class=" img-fluid">
                                        </div>
                                    </div>

                                    <div class="row mb-4">
                                        <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                            <p class="fw-bolder">BBC</p>
                                        </div>
                                    </div>
                                    <div class="row mb-1">
                                        <div class="col-md-8 col-sm-6 col-xs-6">
                                            <h5>BULL BTC CLUB:</h5>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <p>BSC</p>
                                        </div>
                                    </div>
                                    <div class="row mb-1">
                                        <div class="col-md-8 col-sm-6 col-xs-6">
                                            <h5>Price:</h5>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <p>300 BUSD<br />≈ $ 379.96</p>
                                        </div>
                                    </div>
                                    <div class="row mb-1">
                                        <div class="col-md-8 col-sm-6 col-xs-6">
                                            <h5>&#9200; In 1 Day</h5>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <p>&#9825; 155</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                            <div class="card card2">
                                <div class="card-body">
                                    <div class="row mb-4">
                                        <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                            <img loading="lazy"
                                                src="{{ asset('public/assets/img/featured-nft-4.png') }}"
                                                alt="NFT image" class=" img-fluid">
                                        </div>
                                    </div>

                                    <div class="row mb-4">
                                        <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                            <p class="fw-bolder">BBC</p>
                                        </div>
                                    </div>
                                    <div class="row mb-1">
                                        <div class="col-md-8 col-sm-6 col-xs-6">
                                            <h5>BULL BTC CLUB:</h5>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <p>BSC</p>
                                        </div>
                                    </div>
                                    <div class="row mb-1">
                                        <div class="col-md-8 col-sm-6 col-xs-6">
                                            <h5>Price:</h5>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <p>300 BUSD<br />≈ $ 379.96</p>
                                        </div>
                                    </div>
                                    <div class="row mb-1">
                                        <div class="col-md-8 col-sm-6 col-xs-6">
                                            <h5>&#9200; In 1 Day</h5>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <p>&#9825; 155</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                            <div class="card card2">
                                <div class="card-body">
                                    <div class="row mb-4">
                                        <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                            <img loading="lazy" src="{{ asset('public/assets/img/featured-nft.png') }}"
                                                alt="NFT image" class=" img-fluid">
                                        </div>
                                    </div>

                                    <div class="row mb-4">
                                        <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                            <p class="fw-bolder">BBC</p>
                                        </div>
                                    </div>
                                    <div class="row mb-1">
                                        <div class="col-md-8 col-sm-6 col-xs-6">
                                            <h5>BULL BTC CLUB:</h5>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <p>BSC</p>
                                        </div>
                                    </div>
                                    <div class="row mb-1">
                                        <div class="col-md-8 col-sm-6 col-xs-6">
                                            <h5>Price:</h5>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <p>300 BUSD<br />≈ $ 379.96</p>
                                        </div>
                                    </div>
                                    <div class="row mb-1">
                                        <div class="col-md-8 col-sm-6 col-xs-6">
                                            <h5>&#9200; In 1 Day</h5>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <p>&#9825; 155</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                    </div>

                    <div class="row mt-3">

                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                            <div class="card card2">
                                <div class="card-body">
                                    <div class="row mb-4">
                                        <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                            <img loading="lazy"
                                                src="{{ asset('public/assets/img/featured-nft-2.png') }}"
                                                alt="NFT image" class=" img-fluid">
                                        </div>
                                    </div>

                                    <div class="row mb-4">
                                        <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                            <p class="fw-bolder">BBC</p>
                                        </div>
                                    </div>
                                    <div class="row mb-1">
                                        <div class="col-md-8 col-sm-6 col-xs-6">
                                            <h5>BULL BTC CLUB:</h5>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <p>BSC</p>
                                        </div>
                                    </div>
                                    <div class="row mb-1">
                                        <div class="col-md-8 col-sm-6 col-xs-6">
                                            <h5>Price:</h5>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <p>300 BUSD<br />≈ $ 379.96</p>
                                        </div>
                                    </div>
                                    <div class="row mb-1">
                                        <div class="col-md-8 col-sm-6 col-xs-6">
                                            <h5>&#9200; In 1 Day</h5>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <p>&#9825; 155</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                            <div class="card card2">
                                <div class="card-body">
                                    <div class="row mb-4">
                                        <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                            <img loading="lazy"
                                                src="{{ asset('public/assets/img/featured-nft-2.png') }}"
                                                alt="NFT image" class=" img-fluid">
                                        </div>
                                    </div>

                                    <div class="row mb-4">
                                        <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                            <p class="fw-bolder">BBC</p>
                                        </div>
                                    </div>
                                    <div class="row mb-1">
                                        <div class="col-md-8 col-sm-6 col-xs-6">
                                            <h5>BULL BTC CLUB:</h5>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <p>BSC</p>
                                        </div>
                                    </div>
                                    <div class="row mb-1">
                                        <div class="col-md-8 col-sm-6 col-xs-6">
                                            <h5>Price:</h5>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <p>300 BUSD<br />≈ $ 379.96</p>
                                        </div>
                                    </div>
                                    <div class="row mb-1">
                                        <div class="col-md-8 col-sm-6 col-xs-6">
                                            <h5>&#9200; In 1 Day</h5>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <p>&#9825; 155</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                            <div class="card card2">
                                <div class="card-body">
                                    <div class="row mb-4">
                                        <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                            <img loading="lazy"
                                                src="{{ asset('public/assets/img/featured-nft-3.png') }}"
                                                alt="NFT image" class=" img-fluid">
                                        </div>
                                    </div>

                                    <div class="row mb-4">
                                        <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                            <p class="fw-bolder">BBC</p>
                                        </div>
                                    </div>
                                    <div class="row mb-1">
                                        <div class="col-md-8 col-sm-6 col-xs-6">
                                            <h5>BULL BTC CLUB:</h5>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <p>BSC</p>
                                        </div>
                                    </div>
                                    <div class="row mb-1">
                                        <div class="col-md-8 col-sm-6 col-xs-6">
                                            <h5>Price:</h5>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <p>300 BUSD<br />≈ $ 379.96</p>
                                        </div>
                                    </div>
                                    <div class="row mb-1">
                                        <div class="col-md-8 col-sm-6 col-xs-6">
                                            <h5>&#9200; In 1 Day</h5>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <p>&#9825; 155</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                            <div class="card card2">
                                <div class="card-body">
                                    <div class="row mb-4">
                                        <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                            <img loading="lazy"
                                                src="{{ asset('public/assets/img/featured-nft-2.png') }}"
                                                alt="NFT image" class=" img-fluid">
                                        </div>
                                    </div>

                                    <div class="row mb-4">
                                        <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                                            <p class="fw-bolder">BBC</p>
                                        </div>
                                    </div>
                                    <div class="row mb-1">
                                        <div class="col-md-8 col-sm-6 col-xs-6">
                                            <h5>BULL BTC CLUB:</h5>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <p>BSC</p>
                                        </div>
                                    </div>
                                    <div class="row mb-1">
                                        <div class="col-md-8 col-sm-6 col-xs-6">
                                            <h5>Price:</h5>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <p>300 BUSD<br />≈ $ 379.96</p>
                                        </div>
                                    </div>
                                    <div class="row mb-1">
                                        <div class="col-md-8 col-sm-6 col-xs-6">
                                            <h5>&#9200; In 1 Day</h5>
                                        </div>
                                        <div class="col-md-4 col-sm-6 col-xs-6">
                                            <p>&#9825; 155</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                    </div>
                </div>
            </div>

        </div>

    </section>

    <section class="wealth-mark-nft-block" id="wealthmark-nft-section">
        <div class="container">
            <div class="row">
                <div class="sec-title text-left">
                    <span class="title">Know About</span>
                    <h2 class="heading-h2">Wealth Mark<span class="yellow"> NFT</span></h2>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6 col-lg-6 col-sm-12 col-xs-12">
                    <div class="nft-video-block">
                        <iframe width="100%" height="400px" src="https://www.youtube.com/embed/VtLHngErlEM"
                            title="60 min | Relaxing Screensaver | Bokeh Warm Glowing Lights" frameborder="0"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                            allowfullscreen></iframe>
                    </div>
                </div>
                <div class="col-md-6 col-lg-6 col-sm-12 col-xs-12">
                    <div class="nft-content-block">
                        <h4>Events </h4>
                        <p class="mb-4">Exclusive premium events, from exhibitions to unique collectibles. </p>
                        <h4>Marketplace </h4>
                        <p class="mb-4">Mint, purchase and bid the world's premier NFTs.</p>
                        <h4>Mystery Box Playground </h4>
                        <p class="mb-4">A chance to win a variety of common, rare and unique NFTs.</p>
                        <a class="btn btn-yellow shadow mt-3">Full User Guidance </a>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <section class="nft-faq-block" id="nft-faq-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-6">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-xs-6 col-sm-6 sec-title text-left popular-head-block">
                            <span class="title">Know About</span>
                            <h2 class="heading-h2">NFT <span class="yellow-text">FAQ</span></h2>
                        </div>
                    </div>

                    <div class="row">
                        <div class="faq-inner-block" id="faq-inner-section">
                            <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                            <div class="accordion" id="accordian-api">
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingOne">
                                    <button class="accordion-button" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                        1. What is Wealthmark Pay?
                                    </button>
                                </h2>
                                <div id="collapseOne" class="accordion-collapse collapse show"
                                    aria-labelledby="headingOne" data-bs-parent="#accordian-api">
                                    <div class="accordion-body">
                                        <strong>This is the first item's accordion body.</strong> It is shown by
                                        default, until the collapse plugin adds the appropriate classes that we use to
                                        style each element. These classes control the overall appearance, as well as the
                                        showing and hiding via CSS transitions. You can modify any of this with custom
                                        CSS or overriding our default variables. It's also worth noting that just about
                                        any HTML can go within the <code>.accordion-body</code>, though the transition
                                        does limit overflow.
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingTwo">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                        2. Can I pay with Bitcoin, Wealthmark and other cryptocurrencies supported by
                                        Wealthmark?
                                    </button>
                                </h2>
                                <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo"
                                    data-bs-parent="#accordian-api">
                                    <div class="accordion-body">
                                        <strong>You can access your Wealthmark Pay Wallet by clicking [Wallets] -
                                            [Funding] - [Pay] on your Wealthmark App.
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingThree">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapseThree" aria-expanded="false"
                                        aria-controls="collapseThree">
                                        3. How long does it take for a Wealthmark Pay transaction to be completed?
                                    </button>
                                </h2>
                                <div id="collapseThree" class="accordion-collapse collapse"
                                    aria-labelledby="headingThree" data-bs-parent="#accordian-api">
                                    <div class="accordion-body">
                                        <strong>Wealthmark Pay transactions are usually confirmed instantly.
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingfour">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapsefour" aria-expanded="false"
                                        aria-controls="collapsefour">
                                        4. Can I pay with Bitcoin, Wealthmark and other cryptocurrencies supported by
                                        Wealthmark?
                                    </button>
                                </h2>
                                <div id="collapsefour" class="accordion-collapse collapse" aria-labelledby="headingfour"
                                    data-bs-parent="#accordian-api">
                                    <div class="accordion-body">
                                        <strong>You can access your Wealthmark Pay Wallet by clicking [Wallets] -
                                            [Funding] - [Pay] on your Wealthmark App.
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingfive">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapsefive" aria-expanded="false"
                                        aria-controls="collapsefive">
                                        5. How long does it take for a Wealthmark Pay transaction to be completed?
                                    </button>
                                </h2>
                                <div id="collapsefive" class="accordion-collapse collapse" aria-labelledby="headingfive"
                                    data-bs-parent="#accordian-api">
                                    <div class="accordion-body">
                                        <strong>Wealthmark Pay transactions are usually confirmed instantly.
                                    </div>
                                </div>
                            </div>
                        </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <script src="https://code.jquery.com/jquery-3.6.0.slim.min.js"></script>
    </script>
    <script>
    let items = document.querySelectorAll('#featureContainer .carousel .carousel-item');
    items.forEach((el) => {
        const minPerSlide = 4
        let next = el.nextElementSibling
        for (var i = 1; i < minPerSlide; i++) {
            if (!next) {
                // wrap carousel by using first child
                next = items[0]
            }
            let cloneChild = next.cloneNode(true)
            el.appendChild(cloneChild.children[0])
            next = next.nextElementSibling
        }
    })
    $(document).ready(function() {
        $('#featureCarousel').carousel({
            interval: false
        });
        $('#featureCarousel').carousel('pause');
    });
    </script>

    @include('template.country_language')
    @include('template.web_footer')
</body>

</html>