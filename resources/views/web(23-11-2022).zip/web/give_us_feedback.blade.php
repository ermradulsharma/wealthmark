<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <title>Wealth Mark | {{ Request::segment(2) }}</title>
    @include('template.web_css')
    <link rel='stylesheet' href="{{('../public/assets/css/deepak_custom.css') }}">
</head>

<body>
    @include('template.mobile_menu')
    @include('template.web_menu')
    <section class="feedback-section shadow community-top">
        <div class="container-fluid mt-3">
            <div class="row">
                <div class="col-lg-4 offset-lg-1 d-flex flex-column justify-content-center pt-lg-0 order-2 order-lg-1"
                    data-aos="fade-up" data-aos-delay="200">
                    <h1>FEEDBACK </h1>
                    <h3 class="top-heading">Your Voice feedback</h3>
                    <p class="text-white">Wealth Mark is always here to listen. Let's enhance our community together.</p>
                    <h3 class="text-white">Feedback already submitted?</h3>
                    <a class="btn btn-yellow feedback-history-btn yellow shadow">My Feedback History </a>

                </div>
                <div class="col-lg-5 offset-lg-1 order-1 order-lg-2 hero-img" data-aos="zoom-in" data-aos-delay="200">
                    <img src="https://wealthmark.io/public/assets/img/career-graphic.png" class="img-fluid" alt=""
                        style="width:100%">
                </div>
            </div>
        </div>
    </section>

    <section class="submit-feedback-block">
        <div class="container">
            <div class="row">
                <div class="sec-title text-left mb-5">
                    <h2 class="heading-h2">Submit Feedback</h2>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6 col-lg-6 ol-xs-12 col-sm-12">
                    <a href="#">
                    <div class="feedback-inner-box alert alert-warning">
                        <h4>
                            <svg  viewBox="0 0 20 20" fill="none" class="css-2xfqkd">
                                <path
                                    d="M19.95 11h-4.97c-.093 2.467-.534 4.718-1.223 6.442-.348.87-.776 1.647-1.287 2.25A10.008 10.008 0 0019.95 11z"
                                    fill="url(#language-g_svg__paint0_linear)"></path>
                                <path
                                    d="M12.47.307A10.008 10.008 0 0119.95 9h-4.97c-.093-2.467-.534-4.719-1.223-6.443-.348-.87-.776-1.646-1.287-2.25z"
                                    fill="url(#language-g_svg__paint1_linear)"></path>
                                <path
                                    d="M7.02 9c.094-2.257.499-4.247 1.08-5.7.334-.835.707-1.444 1.07-1.827C9.53 1.09 9.81 1 10 1c.189 0 .47.091.83.473.363.383.736.992 1.07 1.827.581 1.453.986 3.443 1.08 5.7H7.02z"
                                    fill="url(#language-g_svg__paint2_linear)"></path>
                                <path
                                    d="M12.98 11c-.094 2.256-.499 4.246-1.08 5.7-.334.835-.707 1.443-1.07 1.827-.36.381-.641.473-.83.473-.189 0-.47-.092-.83-.473-.363-.384-.736-.992-1.07-1.828-.581-1.453-.986-3.443-1.08-5.7h5.96z"
                                    fill="url(#language-g_svg__paint3_linear)"></path>
                                <path
                                    d="M7.53.307c-.511.604-.939 1.38-1.287 2.25C5.553 4.282 5.113 6.533 5.019 9H.049A10.008 10.008 0 017.53.307z"
                                    fill="url(#language-g_svg__paint4_linear)"></path>
                                <path
                                    d="M7.53 19.692A10.008 10.008 0 01.05 11h4.969c.094 2.467.534 4.718 1.224 6.442.348.87.776 1.647 1.287 2.25z"
                                    fill="url(#language-g_svg__paint5_linear)"></path>
                                <defs>
                                    <linearGradient id="language-g_svg__paint0_linear" x1="10" y1="19.692" x2="10"
                                        y2="0.307" gradientUnits="userSpaceOnUse">
                                        <stop stop-color="#F0B90B"></stop>
                                        <stop offset="1" stop-color="#F8D33A"></stop>
                                    </linearGradient>
                                    <linearGradient id="language-g_svg__paint1_linear" x1="10" y1="19.692" x2="10"
                                        y2="0.307" gradientUnits="userSpaceOnUse">
                                        <stop stop-color="#F0B90B"></stop>
                                        <stop offset="1" stop-color="#F8D33A"></stop>
                                    </linearGradient>
                                    <linearGradient id="language-g_svg__paint2_linear" x1="10" y1="19.692" x2="10"
                                        y2="0.307" gradientUnits="userSpaceOnUse">
                                        <stop stop-color="#F0B90B"></stop>
                                        <stop offset="1" stop-color="#F8D33A"></stop>
                                    </linearGradient>
                                    <linearGradient id="language-g_svg__paint3_linear" x1="10" y1="19.692" x2="10"
                                        y2="0.307" gradientUnits="userSpaceOnUse">
                                        <stop stop-color="#F0B90B"></stop>
                                        <stop offset="1" stop-color="#F8D33A"></stop>
                                    </linearGradient>
                                    <linearGradient id="language-g_svg__paint4_linear" x1="10" y1="19.692" x2="10"
                                        y2="0.307" gradientUnits="userSpaceOnUse">
                                        <stop stop-color="#F0B90B"></stop>
                                        <stop offset="1" stop-color="#F8D33A"></stop>
                                    </linearGradient>
                                    <linearGradient id="language-g_svg__paint5_linear" x1="10" y1="19.692" x2="10"
                                        y2="0.307" gradientUnits="userSpaceOnUse">
                                        <stop stop-color="#F0B90B"></stop>
                                        <stop offset="1" stop-color="#F8D33A"></stop>
                                    </linearGradient>
                                </defs>
                            </svg>Localization & Language </h4>
                        <p>Discover spelling or grammar mistakes, and misleading content. </p>
                    </div>
                    </a>
                </div>
                <div class="col-md-6 col-lg-6 ol-xs-12 col-sm-12">
                <a href="#"> 
                    <div class="feedback-inner-box alert alert-warning">
                        <h4>
                            <svg  viewBox="0 0 50 50" fill="none" class="css-2xfqkd">
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M4.166 8.333h37.5v25h-37.5v-25z"
                                    fill="url(#product-design-g_svg__paint0_linear_2218_19595)"></path>
                                <path fill-rule="evenodd" clip-rule="evenodd"
                                    d="M45.833 14.583L18.75 41.667h27.083V14.583zm-4.166 10.06L28.809 37.5h12.858V24.642z"
                                    fill="#76808F"></path>
                                <path fill="#fff" d="M10.416 14.583h22.917v4.167H10.416z"></path>
                                <path d="M33.334 14.583v6.25L10.417 43.75l-6.25-6.25 22.917-22.917h6.25z"
                                    fill="#76808F"></path>
                                <defs>
                                    <linearGradient id="product-design-g_svg__paint0_linear_2218_19595" x1="22.916"
                                        y1="33.333" x2="22.916" y2="8.333" gradientUnits="userSpaceOnUse">
                                        <stop stop-color="#F0B90B"></stop>
                                        <stop offset="1" stop-color="#F8D33A"></stop>
                                    </linearGradient>
                                </defs>
                            </svg>Localization & Language
                        </h4>
                        <p>Discover spelling or grammar mistakes, and misleading content. </p>
                    </div></a>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6 col-lg-6 ol-xs-12 col-sm-12">
                <a href="#">  
                    <div class="feedback-inner-box alert alert-warning">
                        <h4>
                            <svg  viewBox="0 0 24 24" fill="none" class="css-2xfqkd">
                                <path d="M12 23l-9-6V3h18v14.1L12 23z" fill="url(#security-g_svg__paint0_linear)">
                                </path>
                                <path d="M8 12l4-4 4 4-4 4-4-4z" fill="#76808F"></path>
                                <defs>
                                    <linearGradient id="security-g_svg__paint0_linear" x1="12" y1="23" x2="12" y2="3"
                                        gradientUnits="userSpaceOnUse">
                                        <stop stop-color="#F0B90B"></stop>
                                        <stop offset="1" stop-color="#F8D33A"></stop>
                                    </linearGradient>
                                </defs>
                            </svg>Localization & Language
                        </h4>
                        <p>Discover spelling or grammar mistakes, and misleading content. </p>
                    </div></a>
                </div>
                <div class="col-md-6 col-lg-6 ol-xs-12 col-sm-12">
                <a href="#">
                     <div class="feedback-inner-box alert alert-warning">
                        <h4>
                            <svg  viewBox="0 0 24 24" fill="none" class="css-2xfqkd">
                                <path d="M3 21h18V6l-3-3H3v18z" fill="url(#edit-g_svg__paint0_linear)"></path>
                                <path d="M6 18v-4.5l9.085-9.085 4.5 4.5L10.5 18H6zM21 7.5l2-2L18.5 1l-2 2L21 7.5z"
                                    fill="#76808F"></path>
                                <defs>
                                    <linearGradient id="edit-g_svg__paint0_linear" x1="12" y1="21" x2="12" y2="3"
                                        gradientUnits="userSpaceOnUse">
                                        <stop stop-color="#F0B90B"></stop>
                                        <stop offset="1" stop-color="#F8D33A"></stop>
                                    </linearGradient>
                                </defs>
                            </svg>
                            Localization & Language
                        </h4>
                        <p>Discover spelling or grammar mistakes, and misleading content. </p>
                    </div></a>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6 col-lg-6 ol-xs-12 col-sm-12">
                <a href="#">
                    <div class="feedback-inner-box alert alert-warning">
                        <h4>
                            <svg  viewBox="0 0 24 24" fill="none" class="css-2xfqkd">
                                <path fill-rule="evenodd" clip-rule="evenodd"
                                    d="M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-9-4l4 4-4 4-4-4 4-4z"
                                    fill="url(#coin-1-g_svg__paint0_linear_31554_26525)"></path>
                                <path fill="#76808F" d="M7.922 12.047L12 7.969l4.078 4.078L12 16.125z"></path>
                                <defs>
                                    <linearGradient id="coin-1-g_svg__paint0_linear_31554_26525" x1="12" y1="3" x2="12"
                                        y2="21" gradientUnits="userSpaceOnUse">
                                        <stop stop-color="#F0B90B"></stop>
                                        <stop offset="1" stop-color="#F8D33A"></stop>
                                    </linearGradient>
                                </defs>
                            </svg>
                            Localization & Language
                        </h4>
                        <p>Discover spelling or grammar mistakes, and misleading content. </p>
                    </div>
                </a>
                </div>
                <div class="col-md-6 col-lg-6 ol-xs-12 col-sm-12">
                <a href="#">
                    <div class="feedback-inner-box alert alert-warning">
                        <h4>
                            <svg  viewBox="0 0 20 20" fill="none" class="css-2xfqkd">
                                <path
                                    d="M19.95 11h-4.97c-.093 2.467-.534 4.718-1.223 6.442-.348.87-.776 1.647-1.287 2.25A10.008 10.008 0 0019.95 11z"
                                    fill="url(#language-g_svg__paint0_linear)"></path>
                                <path
                                    d="M12.47.307A10.008 10.008 0 0119.95 9h-4.97c-.093-2.467-.534-4.719-1.223-6.443-.348-.87-.776-1.646-1.287-2.25z"
                                    fill="url(#language-g_svg__paint1_linear)"></path>
                                <path
                                    d="M7.02 9c.094-2.257.499-4.247 1.08-5.7.334-.835.707-1.444 1.07-1.827C9.53 1.09 9.81 1 10 1c.189 0 .47.091.83.473.363.383.736.992 1.07 1.827.581 1.453.986 3.443 1.08 5.7H7.02z"
                                    fill="url(#language-g_svg__paint2_linear)"></path>
                                <path
                                    d="M12.98 11c-.094 2.256-.499 4.246-1.08 5.7-.334.835-.707 1.443-1.07 1.827-.36.381-.641.473-.83.473-.189 0-.47-.092-.83-.473-.363-.384-.736-.992-1.07-1.828-.581-1.453-.986-3.443-1.08-5.7h5.96z"
                                    fill="url(#language-g_svg__paint3_linear)"></path>
                                <path
                                    d="M7.53.307c-.511.604-.939 1.38-1.287 2.25C5.553 4.282 5.113 6.533 5.019 9H.049A10.008 10.008 0 017.53.307z"
                                    fill="url(#language-g_svg__paint4_linear)"></path>
                                <path
                                    d="M7.53 19.692A10.008 10.008 0 01.05 11h4.969c.094 2.467.534 4.718 1.224 6.442.348.87.776 1.647 1.287 2.25z"
                                    fill="url(#language-g_svg__paint5_linear)"></path>
                                <defs>
                                    <linearGradient id="language-g_svg__paint0_linear" x1="10" y1="19.692" x2="10"
                                        y2="0.307" gradientUnits="userSpaceOnUse">
                                        <stop stop-color="#F0B90B"></stop>
                                        <stop offset="1" stop-color="#F8D33A"></stop>
                                    </linearGradient>
                                    <linearGradient id="language-g_svg__paint1_linear" x1="10" y1="19.692" x2="10"
                                        y2="0.307" gradientUnits="userSpaceOnUse">
                                        <stop stop-color="#F0B90B"></stop>
                                        <stop offset="1" stop-color="#F8D33A"></stop>
                                    </linearGradient>
                                    <linearGradient id="language-g_svg__paint2_linear" x1="10" y1="19.692" x2="10"
                                        y2="0.307" gradientUnits="userSpaceOnUse">
                                        <stop stop-color="#F0B90B"></stop>
                                        <stop offset="1" stop-color="#F8D33A"></stop>
                                    </linearGradient>
                                    <linearGradient id="language-g_svg__paint3_linear" x1="10" y1="19.692" x2="10"
                                        y2="0.307" gradientUnits="userSpaceOnUse">
                                        <stop stop-color="#F0B90B"></stop>
                                        <stop offset="1" stop-color="#F8D33A"></stop>
                                    </linearGradient>
                                    <linearGradient id="language-g_svg__paint4_linear" x1="10" y1="19.692" x2="10"
                                        y2="0.307" gradientUnits="userSpaceOnUse">
                                        <stop stop-color="#F0B90B"></stop>
                                        <stop offset="1" stop-color="#F8D33A"></stop>
                                    </linearGradient>
                                    <linearGradient id="language-g_svg__paint5_linear" x1="10" y1="19.692" x2="10"
                                        y2="0.307" gradientUnits="userSpaceOnUse">
                                        <stop stop-color="#F0B90B"></stop>
                                        <stop offset="1" stop-color="#F8D33A"></stop>
                                    </linearGradient>
                                </defs>
                            </svg>Localization & Language
                        </h4>
                        <p>Discover spelling or grammar mistakes, and misleading content. </p>
                    </div></a>
                </div>
            </div>
        </div>
    </section>

    <section class="feedback-how-works" id="how-works-feedback">
        <div class="container">
            <div class="row">
                <div class="sec-title text-left mb-5">
                    <span class="title">Know About</span>
                    <h2 class="heading-h2">How does it works </h2>
                </div>
            </div>
            <div class="row"> 
                <div class="col-lg-2 col-md-2 col-sm-6 col-xs-12"> 
                    <div class="feedback-box"> 
                        <img src="{{ asset('public/assets/img/fh-it-work-icon-1.svg') }}" class="img-fluid" alt="gift Card Image" />
                        <h4>Give a feedback </h4>
                    </div>
                </div>
                <div class="col-lg-1 css-k9znh2"> </div>
                <div class="col-lg-2 col-md-2 col-sm-6 col-xs-12"> 
                    <div class="feedback-box"> 
                        <img src="{{ asset('public/assets/img/fh-it-work-icon-2.svg') }}" class="img-fluid" alt="gift Card Image" />
                        <h4>Give a feedback </h4>
                    </div>
                </div>
                <div class="col-lg-1 css-k9znh2 hidden-xs-block"> </div>
                <div class="col-lg-2 col-md-2 col-sm-6 col-xs-12"> 
                    <div class="feedback-box"> 
                        <img src="{{ asset('public/assets/img/fh-it-work-icon-3.svg') }}" class="img-fluid" alt="gift Card Image" />
                        <h4>Give a feedback </h4>
                    </div>
                </div>
                <div class="col-lg-1 css-k9znh2"> </div>
                <div class="col-lg-2 col-md-2 col-sm-6 col-xs-12"> 
                    <div class="feedback-box"> 
                        <img src="{{ asset('public/assets/img/fh-it-work-icon-4.svg') }}" class="img-fluid" alt="gift Card Image" />
                        <h4>Give a feedback </h4>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="footer-give-feedback-txt"> 
        <div class="container"> 
        <div class="row"> 
                    <div class="col-md-12 col-lg-12 col-xs-12 col-sm-12"> 
                            <p class="text-center">We treat security as our number one priority and we look forward to excelling our product further by building with you into the future. Discover flaws, or a potential product feature and track the status of eligible ideas.Let's get started! Click here to submit a suggestion or feedback <a class="text-warning">Submit feedback</a></p>
                    </div>
            </div>
        </div>
    </section>
    
    @include('template.country_language')
    @include('template.web_footer')
</body>

</html>