  <!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
   <head>
      <meta charset="utf-8">
      <meta content="width=device-width, initial-scale=1.0" name="viewport">
      <title>Wealth Mark | Create Entity Account</title>
  @include('template.web_css')
      
  
 <style>
     #header{
         background:white;
         
     }


	
 </style>
  
  
   </head>
   
 <body class="bg-white">
     
     @include('template.mobile_menu')
        @include('template.web_menu')
    
      <section class="breadcrumbs shadow-sm otc-trading-top">
          <div class="container-fluid">
              <div class="row align-items-center">
                 <div class="col-lg-4 col-sm-6 offset-lg-1 d-flex flex-column justify-content-center pt-lg-0 order-2 order-lg-1" data-aos="fade-up" data-aos-delay="200">
                 <h3 class="top-heading">Buy, trade, and hold 100+ crypto currencies</h3>
                 <p class="top-p">Sign up now to build your own portfolio</p>
                 <div>
                     <a href="#" class="btn btn-blue shadow mt-4"> Sign up</a>
                 </div>
                 </div>
                 <div class="col-lg-5 col-sm-6 offset-lg-1 order-1 order-lg-2 hero-img" data-aos="zoom-in" data-aos-delay="200">
                    <img src="{{ asset('public/assets/img/graphic-1-01.svg') }}" class="img-fluid animated" alt="" >
                 </div>
              </div>
           </div>
      </section>
      
      
      
      
      <section class="Onboarding_Procedure">
          <div class="container">
              <div class="row">
                  <div class="col-md-12">
                         <div class="sec-title text-left mb-2">
                            <span class="title">Welcome to Wealthmark</span>
                            <h2 class="heading-h2">Onboarding Procedure</h2>
                           
                        </div>
                  </div>
                  <div class="col-md-12">
                    
                        
                       <div class="otc-Onboarding-Procedure">
                          <div class="otc-Procedure-block">
                             <div class="otc-Procedure-block-inner">
                                <svg  viewBox="0 0 24 24" fill="none" class="otc-Procedure-block-profile">
                                   <path fill-rule="evenodd" clip-rule="evenodd" d="M12 3a9 9 0 110 18 9 9 0 010-18zm2.5 6.5a2.5 2.5 0 11-5 0 2.5 2.5 0 015 0zM12 13.996H8.667c-.696 0-1.292.77-1.542 1.52.608.947 2.333 2.464 4.875 2.486 2.542.022 4.306-1.64 4.875-2.486-.25-.75-.846-1.52-1.542-1.52H12z" fill="currentColor"></path>
                                </svg>
                                <div class="otc-Procedure-block-title">Signup</div>
                                <div class="otc-Procedure-block-sbtitle">Open Wealthmark account and finish KYC</div>
                             </div>
                          </div>
                          <div class="otc-Procedure-icon-div">
                             <svg  viewBox="0 0 24 24" fill="none" class="otc-Procedure-icon">
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M21 11.999l-7.071-7.071-1.768 1.768 4.055 4.054H2.999v2.5h13.216l-4.054 4.053 1.768 1.768L21 12v-.001z" fill="currentColor"></path>
                             </svg>
                          </div>
                          <div class="otc-Procedure-block">
                             <div class="otc-Procedure-block-inner">
                                <svg  viewBox="0 0 24 24" fill="none" class="otc-Procedure-block-profile">
                                   <path fill-rule="evenodd" clip-rule="evenodd" d="M21.002 17v-5a9.113 9.113 0 00-.055-1 9.001 9.001 0 00-17.945 1v5h5v-6H5.578a6.502 6.502 0 0112.848 0h-2.424v6h.899a6.988 6.988 0 01-3.289 1.814 2 2 0 10.217 2A9.007 9.007 0 0019.486 17h1.516z" fill="currentColor"></path>
                                </svg>
                                <div class="otc-Procedure-block-title">Communicate</div>
                                <div class="otc-Procedure-block-sbtitle">Request for quote from OTC traders</div>
                             </div>
                          </div>
                          <div class="otc-Procedure-icon-div">
                             <svg  viewBox="0 0 24 24" fill="none" class="otc-Procedure-icon">
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M21 11.999l-7.071-7.071-1.768 1.768 4.055 4.054H2.999v2.5h13.216l-4.054 4.053 1.768 1.768L21 12v-.001z" fill="currentColor"></path>
                             </svg>
                          </div>
                          <div class="otc-Procedure-block">
                             <div class="otc-Procedure-block-inner">
                                <svg  viewBox="0 0 24 24" fill="none" class="otc-Procedure-block-profile">
                                   <path fill-rule="evenodd" clip-rule="evenodd" d="M12 3a9 9 0 110 18 9 9 0 010-18zm2.164 15.5h-1.659v-1.538h-1.01V18.5h-1.66v-1.538H8.329V7.038h1.508V5.5h1.659v1.538h1.01V5.5h1.66v1.584c1.296.21 2.05 1.146 2.05 2.503 0 1.372-.618 1.96-1.93 2.127v.09c1.372.075 2.307.77 2.307 2.322 0 1.524-1.04 2.76-2.428 2.836V18.5zm-1.1-9.637h-2.58v2.247h2.58c.572 0 .92-.301.92-.874v-.498c0-.573-.348-.875-.92-.875zm.361 3.997h-2.94v2.277h2.94c.573 0 .935-.317.935-.89v-.498c0-.573-.362-.89-.935-.89z" fill="currentColor"></path>
                                </svg>
                                <div class="otc-Procedure-block-title">Confirm</div>
                                <div class="otc-Procedure-block-sbtitle">Agree on the price of the quote</div>
                             </div>
                          </div>
                          <div class="otc-Procedure-icon-div">
                             <svg  viewBox="0 0 24 24" fill="none" class="otc-Procedure-icon">
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M21 11.999l-7.071-7.071-1.768 1.768 4.055 4.054H2.999v2.5h13.216l-4.054 4.053 1.768 1.768L21 12v-.001z" fill="currentColor"></path>
                             </svg>
                          </div>
                          <div class="otc-Procedure-block">
                             <div class="otc-Procedure-block-inner">
                                <svg  viewBox="0 0 24 24" fill="none" class="otc-Procedure-block-profile">
                                   <path fill-rule="evenodd" clip-rule="evenodd" d="M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-4.934-4.483L10.2 13.383l-2.716-2.716-1.768 1.767 4.484 4.484 7.634-7.634-1.768-1.767z" fill="currentColor"></path>
                                </svg>
                                <div class="otc-Procedure-block-title">Settlement</div>
                                <div class="otc-Procedure-block-sbtitle">Trades directly settled into your wallet</div>
                             </div>
                          </div>
                       </div>
                    
                  </div>
                  
              </div>
          </div>
      </section>
      
      
      <section class="bg-light-blue">
          <div class="container">
              <div class="row align-items-center">
                 
                      <div class="col-md-4 col-sm-12">
                          <img src="{{ asset('public/assets/img/otc-landing-features-light.png') }}" class="img-fluid animated" alt="" >
                      </div>
                      <div class="col-md-8 col-sm-12">
                          <div class="why-otc-div">
                          <div class="why-otc-block">
                             <div class="why-otc-block-icn-div">
                                <svg width="41" height="40" viewBox="0 0 41 40" fill="none" >
                                   <path fill-rule="evenodd" clip-rule="evenodd" d="M35.5 5H25.5L35.5 15V5ZM5.5 35H15.5L5.5 25V35Z" fill="#76808F"></path>
                                   <path fill-rule="evenodd" clip-rule="evenodd" d="M20.4999 8.3335C26.9432 8.3335 32.1666 13.5568 32.1666 20.0002C32.1666 26.4435 26.9432 31.6668 20.4999 31.6668C14.0566 31.6668 8.83325 26.4435 8.83325 20.0002C8.83325 13.5568 14.0566 8.3335 20.4999 8.3335ZM20.4999 25.0002L15.4999 20.0002L20.4999 15.0002L25.4999 20.0002L20.4999 25.0002Z" fill="url(#paint0_linear_4006_5915)"></path>
                                   <path d="M25.5 35H35.5V25L25.5 35Z" fill="url(#paint1_linear_4006_5915)"></path>
                                   <path d="M15.5 5H5.5V15L15.5 5Z" fill="url(#paint2_linear_4006_5915)"></path>
                                   <defs>
                                      <linearGradient id="paint0_linear_4006_5915" x1="20.4999" y1="8.3335" x2="20.4999" y2="31.6668" gradientUnits="userSpaceOnUse">
                                         <stop stop-color="#F0B90B"></stop>
                                         <stop offset="1" stop-color="#F8D33A"></stop>
                                      </linearGradient>
                                      <linearGradient id="paint1_linear_4006_5915" x1="30.5" y1="25" x2="30.5" y2="35" gradientUnits="userSpaceOnUse">
                                         <stop stop-color="#F0B90B"></stop>
                                         <stop offset="1" stop-color="#F8D33A"></stop>
                                      </linearGradient>
                                      <linearGradient id="paint2_linear_4006_5915" x1="10.5" y1="5" x2="10.5" y2="15" gradientUnits="userSpaceOnUse">
                                         <stop stop-color="#F0B90B"></stop>
                                         <stop offset="1" stop-color="#F8D33A"></stop>
                                      </linearGradient>
                                   </defs>
                                </svg>
                             </div>
                             <div class="">
                                <div class="why-otc-block-title">Trade Any Asset to Any Asset</div>
                                <div class="why-otc-block-sbtitle">Support 350+ cryptos, stablecoins, and fiat pairs listed on the wealthmark or any synthetic cross pairs.</div>
                             </div>
                          </div>
                          <div class="why-otc-block">
                             <div class="why-otc-block-icn-div">
                                <svg  viewBox="0 0 24 24" fill="none" class="otc-Procedure-block-profile">
                                   <path fill-rule="evenodd" clip-rule="evenodd" d="M8.637 8.235l.894-.079.413 3.51 2.638 2.66H9.848l-2.813 2.802.746.747 1.513-1.502a3.425 3.425 0 014.845 0l-5.802 5.802H2V12.5a8.485 8.485 0 016.637-4.265zm9.238 6.091h-3.889l3.045-3.044c.536.889.844 1.93.844 3.044z" fill="#76808F"></path>
                                   <path fill-rule="evenodd" clip-rule="evenodd" d="M14.024 2a7.977 7.977 0 110 15.953 7.977 7.977 0 010-15.953zm0 11.395l-3.419-3.419 3.419-3.418 3.418 3.418-3.418 3.419z" fill="url(#pay-g_svg__paint0_linear_44536_181113)"></path>
                                   <path d="M14.14 16.36l-5.765 5.796H5.453V20.11l1.156-1.14 2.297-2.25c2.138-2.263 4.38-1.183 5.235-.36z" fill="#76808F"></path>
                                   <defs>
                                      <linearGradient id="pay-g_svg__paint0_linear_44536_181113" x1="14.024" y1="17.953" x2="14.024" y2="2" gradientUnits="userSpaceOnUse">
                                         <stop stop-color="#F0B90B"></stop>
                                         <stop offset="1" stop-color="#F8D33A"></stop>
                                      </linearGradient>
                                   </defs>
                                </svg>
                             </div>
                             <div class="">
                                <div class="why-otc-block-title">Fast &amp; Competitive Pricing</div>
                                <div class="why-otc-block-sbtitle">Access competitive and firm pricing without the need to trade on order books.</div>
                             </div>
                          </div>
                          <div class="why-otc-block">
                             <div class="why-otc-block-icn-div">
                                <svg  viewBox="0 0 20 20" fill="none" class="otc-Procedure-block-profile">
                                   <path d="M19.95 11h-4.97c-.093 2.467-.534 4.718-1.223 6.442-.348.87-.776 1.647-1.287 2.25A10.008 10.008 0 0019.95 11z" fill="url(#language-g_svg__paint0_linear)"></path>
                                   <path d="M12.47.307A10.008 10.008 0 0119.95 9h-4.97c-.093-2.467-.534-4.719-1.223-6.443-.348-.87-.776-1.646-1.287-2.25z" fill="url(#language-g_svg__paint1_linear)"></path>
                                   <path d="M7.02 9c.094-2.257.499-4.247 1.08-5.7.334-.835.707-1.444 1.07-1.827C9.53 1.09 9.81 1 10 1c.189 0 .47.091.83.473.363.383.736.992 1.07 1.827.581 1.453.986 3.443 1.08 5.7H7.02z" fill="url(#language-g_svg__paint2_linear)"></path>
                                   <path d="M12.98 11c-.094 2.256-.499 4.246-1.08 5.7-.334.835-.707 1.443-1.07 1.827-.36.381-.641.473-.83.473-.189 0-.47-.092-.83-.473-.363-.384-.736-.992-1.07-1.828-.581-1.453-.986-3.443-1.08-5.7h5.96z" fill="url(#language-g_svg__paint3_linear)"></path>
                                   <path d="M7.53.307c-.511.604-.939 1.38-1.287 2.25C5.553 4.282 5.113 6.533 5.019 9H.049A10.008 10.008 0 017.53.307z" fill="url(#language-g_svg__paint4_linear)"></path>
                                   <path d="M7.53 19.692A10.008 10.008 0 01.05 11h4.969c.094 2.467.534 4.718 1.224 6.442.348.87.776 1.647 1.287 2.25z" fill="url(#language-g_svg__paint5_linear)"></path>
                                   <defs>
                                      <linearGradient id="language-g_svg__paint0_linear" x1="10" y1="19.692" x2="10" y2="0.307" gradientUnits="userSpaceOnUse">
                                         <stop stop-color="#F0B90B"></stop>
                                         <stop offset="1" stop-color="#F8D33A"></stop>
                                      </linearGradient>
                                      <linearGradient id="language-g_svg__paint1_linear" x1="10" y1="19.692" x2="10" y2="0.307" gradientUnits="userSpaceOnUse">
                                         <stop stop-color="#F0B90B"></stop>
                                         <stop offset="1" stop-color="#F8D33A"></stop>
                                      </linearGradient>
                                      <linearGradient id="language-g_svg__paint2_linear" x1="10" y1="19.692" x2="10" y2="0.307" gradientUnits="userSpaceOnUse">
                                         <stop stop-color="#F0B90B"></stop>
                                         <stop offset="1" stop-color="#F8D33A"></stop>
                                      </linearGradient>
                                      <linearGradient id="language-g_svg__paint3_linear" x1="10" y1="19.692" x2="10" y2="0.307" gradientUnits="userSpaceOnUse">
                                         <stop stop-color="#F0B90B"></stop>
                                         <stop offset="1" stop-color="#F8D33A"></stop>
                                      </linearGradient>
                                      <linearGradient id="language-g_svg__paint4_linear" x1="10" y1="19.692" x2="10" y2="0.307" gradientUnits="userSpaceOnUse">
                                         <stop stop-color="#F0B90B"></stop>
                                         <stop offset="1" stop-color="#F8D33A"></stop>
                                      </linearGradient>
                                      <linearGradient id="language-g_svg__paint5_linear" x1="10" y1="19.692" x2="10" y2="0.307" gradientUnits="userSpaceOnUse">
                                         <stop stop-color="#F0B90B"></stop>
                                         <stop offset="1" stop-color="#F8D33A"></stop>
                                      </linearGradient>
                                   </defs>
                                </svg>
                             </div>
                             <div class="">
                                <div class="why-otc-block-title">Global Real-time Support</div>
                                <div class="why-otc-block-sbtitle">Powered by in-house technology, get real-time responses for immediate trading needs in fast markets.</div>
                             </div>
                          </div>
                          <div class="why-otc-block">
                             <div class="why-otc-block-icn-div">
                                <svg  viewBox="0 0 24 24" fill="none" class="otc-Procedure-block-profile">
                                   <path fill-rule="evenodd" clip-rule="evenodd" d="M18 15a5 5 0 100-10 5 5 0 000 10zm0-7l-2 2 2 2 2-2-2-2z" fill="url(#otc-g_svg__paint0_linear)"></path>
                                   <path d="M11 7a4 4 0 11-8 0 4 4 0 018 0zM13 19v-2.5A3.5 3.5 0 009.5 13H8v6H6v-6H4.5A3.5 3.5 0 001 16.5V21h21v-2h-9z" fill="#76808F"></path>
                                   <defs>
                                      <linearGradient id="otc-g_svg__paint0_linear" x1="18" y1="15" x2="18" y2="5" gradientUnits="userSpaceOnUse">
                                         <stop stop-color="#F0B90B"></stop>
                                         <stop offset="1" stop-color="#F8D33A"></stop>
                                      </linearGradient>
                                   </defs>
                                </svg>
                             </div>
                             <div class="">
                                <div class="why-otc-block-title">Best-In-Class Services</div>
                                <div class="why-otc-block-sbtitle">Access best-in-class service from our team with experience from top global investment banks and exchanges.</div>
                             </div>
                          </div>
                       </div>
                      </div>
                     
                 
                   
              </div>
          </div>
      </section>
      
      
      
      <section>
          <div class="container">
              <div class="row">
                        <div class="col-md-12  col-sm-12">
                            <div class="sec-title text-center">
                                <span class="title">Welcome to Wealthmark</span>
                                <h2 class="heading-h2">OTC Trading Terms</h2>
                            </div>
                        </div>
     
                        <div class="col-md-12 mt-2 otc-doc-div scrollbar-style">
                            <ul class="tabs">
                                <li class="tab-link btn-blue current" data-tab="tab-1"> Acceptance  </li>
                                <li class="tab-link btn-blue" data-tab="tab-2">Services in General </li>
                                <li class="tab-link btn-blue" data-tab="tab-3"> OTC Services </li>
                                <li class="tab-link btn-blue" data-tab="tab-4">Fees </li>
                                <li class="tab-link btn-blue" data-tab="tab-5"> Representations and Warranties</li>
                                <li class="tab-link btn-blue" data-tab="tab-6"> Limitation of Liability </li>
                            </ul>
                        </div>
                        <div class="col-md-12 mt-3 otc-content">
                            <div id="tab-1" class="table-content shadow-sm scrollbar-style current">
                                    <h4 class="mb-4">1. Acceptance of Wealthmark OTC Terms</h4>
                           <div class="text">By accessing and using the OTC services provided by Wealthmark (“OTC Services”) you agree to accept and comply with the terms and conditions stated below (“OTC Terms”). You further agree and understand that these OTC Terms are subject to the terms and conditions set forth in the Wealthmark Terms of Use. You should read the entire OTC Terms, together with the Wealthmark Terms of Use, carefully before accessing and using the OTC Services. In case of discrepancies between Wealthmark Terms of Use and these OTC Terms, these OTC Terms shall prevail. These OTC Terms govern your use of the OTC services provided by Wealthmark, which are described in greater detail herein. These OTC Terms are a prerequisite for your access to the OTC Services and you agree that you have read, understood, and accepted all of these OTC Terms contained herein.</div>
                        
              <div class="text">          As used in these OTC Terms, “Wealthmark” may refer to its owners, directors, investors, affiliates and employees.
         </div><div class="text">“Wealthmark” in each case refers to the entity which you are the customer of. Depending upon the context, “Wealthmark” may also refer to the services, products, website, content or other materials (collectively “Wealthmark Services”) provided by each respective entity listed above to you as its customer.
         </div><div class="text">Depending on your place of residence, you may not be able to use OTC Services, or your use may be limited. It is your responsibility to follow the rules and regulations applicable in your place of residence and/or place from which you access OTC Services. As long as you agree to and comply with the present OTC Terms as well as the Wealthmark Terms of Use, Wealthmark grants you a personal, non-exclusive, non-transferable, non-sub licensable and limited right to enter the Wealthmark platform and use OTC Services.
         </div><div class="text">Wealthmark reserves the right to change, add or remove parts of these OTC Terms at any time and at its sole discretion. You will be notified of any changes in advance through your Account. Upon such notification, it is your responsibility to review the amended OTC Terms. Your continued usage of OTC Services following the posting of a notice of changes to the OTC Terms signifies that you accept and agree to the changes, and that all subsequent actions by you will be subject to the amended OTC Terms.
         </div><div class="text">All capitalized terms in these OTC Terms shall have the same meaning as ascribed to them in the relevant Wealthmark Terms of Use.
         </div><div class="text">THIS OTC TERMS ARE A LEGAL CONTRACT BETWEEN YOU AND WEALTHMARK. YOU SHOULD TREAT IT AS ANY OTHER LEGAL CONTRACT BY READING ITS PROVISIONS CAREFULLY, AS THEY WILL AFFECT YOUR LEGAL RIGHTS. BY USING THE OTC SERVICES IN ANY MANNER, YOU ARE DEEMED TO HAVE READ, UNDERSTOOD AND AGREED TO BE BOUND BY ALL OF THE TERMS CONTAINED IN THESE OTC TERMS. YOU MAY NOT PICK AND CHOOSE WHICH TERMS APPLY TO YOU. IF YOU DO NOT AGREE WITH ALL OF THE TERMS IN THESE OTC TERMS, YOU MUST CEASE ALL ACCESS AND USE OF THE OTC SERVICES. NOTHING IN THESE OTC TERMS IS INTENDED TO CREATE ANY ENFORCEMENT RIGHTS BY THIRD PARTIES. IF YOU DO NOT UNDERSTAND ALL OF THE TERMS AND CONDITIONS IN THESE OTC TERMS, YOU SHOULD CONSULT WITH A LAWYER BEFORE USING THE OTC SERVICES.
         </div>
                          </div>
                            <div id="tab-2" class="table-content shadow-sm scrollbar-style">
                                 <h4 class=" mb-4">Wealthmark OTC Services in General</h4>
                       
                            <div class="text">    Wealthmark OTC Services are part of the Wealthmark platform that enables you to enter into over-the-counter Virtual Assets or Digital Assets purchase and sale transactions (“OTC Transaction”) without being subject to the trading rules of Wealthmark exchange and its central limit order book.
        </div> <div class="text"> OTC Services are provided to you on a request for quote basis (“OTC RFQ”) through a third-party software provider by entering into a transaction with Wealthmark’s liquidity providers (“OTC Counterparty”). You can access the OTC Services through your Account within the Wealthmark platform (“OTC Interface”).
         </div><div class="text">Wealthmark does not operate an OTC trading desk but is partnering up with OTC Counterparties to offer a self-service OTC product to Wealthmark clients. Wealthmark is solely providing the OTC Interface in order to enable OTC Services and facilitate Transactions between the Wealthmark clients and OTC Counterparties.
       </div>
                          </div>
                            <div id="tab-3" class="table-content shadow-sm scrollbar-style">
                           <h4 class=" mb-4">OTC Services</h4>
                      
                        <div class="text">     OTC Services will be available to you by default for Virtual Assets or Digital Assets where OTC trading functionality is available. OTC Services are provided on a pre-trade basis and require the full amount of relevant Virtual Assets or Digital Assets and/or fiat currency before requesting the quote for buying and/or selling Virtual Assets or Digital Assets over-the-counter (“Quote”). OTC Services may be subject to limitations and the minimum amount to be able to access OTC Services may apply.</div> 
                        <div class="text">  Trading through the OTC Services will be anonymous, and Wealthmark has policies and procedures reasonably designed to prevent the disclosure of your identity to any OTC Counterparty and vice versa. However, if ever Wealthmark or an affiliate of Wealthmark is the OTC Counterparty in a Transaction, disclosure that Wealthmark is acting as a principal in the Transaction will be made to you.</div>
                        <div class="text">  All communications related to the OTC Services (e.g., response to a Quote, Quote status, Transaction confirmation) is provided using the OTC Interface. Any other methods of communications used for OTC Services (e.g., instant message conversation, oral communications, emails) may be mutually agreed upon between you and Wealthmark</div>
                      
                      <h4 class="mb-4">a) Quote</h4>
                      <div class="text">You may submit a request for a Quote (“Quote Request”) through the OTC Interface. In response to your Quote Request, Wealthmark will request a Quote from one or more OTC Counterparties and provide you with a Quote. A Quote received is valid for a specific amount of time as shown in the OTC Interface. You may accept or reject the Quote. Any negotiation about the specific Quote is not possible.</div>
                      <div class="text">When you accept the Quote (“Accepted Quote”), the Transaction is pending until the terms of the Transaction are confirmed by the OTC Counterparty. Your Accepted Quote does not constitute any binding agreement and can be rejected by Wealthmark or the OTC Counterparty. The Transaction status is provided through the OTC Interface</div>
                      <div class="text">You agree that Wealthmark may, in its sole and absolute discretion, determine whether to process or decline to process a Quote Request, Quote, Accepted Quote or any other response to a Quote.</div>
                        <h4 class="mb-4">b) Execution</h4>
                      <div class="text">When the Accepted Quote is confirmed by the OTC Counterparty (“Confirmed Quote”), the Transaction is confirmed and becomes binding and final (the “Execution”). A Transaction for which Execution has occurred is an executed Transaction (the “Executed Transaction”) and may not be unwound unless all parties of the Transaction agree in writing otherwise and/or explicitly stated otherwise in these OTC Terms. Upon Execution, the terms of the Executed Transaction shall constitute a binding contract between you and the other relevant OTC Counterparty.</div>
                      <div class="text">However, if Wealthmark determines in its sole and absolute discretion that 
                       <ul class="docx-ul">
                           <li> (i) a Quote provided to you by Wealthmark, </li>
                            <li>(ii) Accepted Quote communicated to an OTC Counterparty and/or</li>
                             <li> (iii) Confirmed Quote contained an obvious error with respect to the terms, including but not limited to the price or amount of Virtual Assets or Digital Assets, set forth in that Quote, Accepted Quote and/or Confirmed Quote, Wealthmark shall have the right to cancel the Transaction by delivering notice of the cancellation to you and the OTC Counterparty at any time prior to Settlement (as defined in point 3.c) (“Transaction Cancellation”). In the absence of such an obvious error, the terms of a Quote accepted by you (Accepted Quote) and confirmed by the OTC Counterparty (Confirmed Quote) shall be conclusive
                        </li>
                       </ul>  
                       
                       </div>
                      
                         <h4 class="mb-4">c) Settlement</h4>
                        
                        <div class="text">Wealthmark will settle an Executed Transaction with you after the Execution by delivering the Virtual Assets or Digital Assets and/or fiat currencies owed to you under the Executed Transaction to your Account/wallet (“Settlement”) on Wealthmark website as the circumstances warrant. The Settlement depends on the settlement of the OTC Counterparty and it occurs when the OTC Counterparty settle the Executed Transaction. In such capacity Wealthmark is acting as an agent and reserves the right to delay the Settlement. You will be notified of the approximate but non-binding settlement time through the OTC Interface before you accept the Quote. However, Wealthmark has a right to directly settle the Executed Transaction from time to time and in that case Wealthmark is acting as a principal.</div>
                        <div class="text">OTC Counterparty settles the Executed Transaction in accordance with the terms agreed with Wealthmark. If OTC Counterparty fails to settle the Executed Transaction, Wealthmark reserves the right to reverse the Executed Transaction and you bear the risk of the settlement failure. When Wealthmark is acting as a principal, Wealthmark bears the risk of settlement failure.</div>
                        <div class="text">You shall not withdraw, attempt to withdraw, transfer, alienate or provide a lien to any third party on any Virtual Assets or Digital Asset or fiat currency held on your Account to satisfy your obligation under any Executed Transaction. Wealthmark will not be responsible for any failure to settle in accordance with the timing set out above as a result of technological failures such as the internet going down and being unavailable.</div>
                        <div class="text">You acknowledge and accept that in case of the Transaction Cancellation the Settlement does not occur and neither Wealthmark, a Wealthmark affiliate nor a respective OTC Counterparty is liable for any losses incurred as a result of the failure to settle the Executed Transaction.</div>
                        <div class="text">Notwithstanding the foregoing, Wealthmark reserves the right to reasonably determine whether an extraordinary event occurred that results in Wealthmark’s inability to honor the Executed Transaction. These events include, but are not limited to identified system failure, data feed error, interruption, delay, non-settlement by the OTC Counterparty, force majeure, or other circumstances. Wealthmark undertakes to immediately notify you about the extraordinary event resulting in the inability to honor the Executed Transaction. After such notification has been sent by Wealthmark, you agree that Wealthmark will not be required to honor the Executed Transaction and that any Executed Transaction affected by the extraordinary event is null and void. In case of extraordinary event from this paragraph, Wealthmark acts as an agent toward you, and you bear the risk of the settlement failure.</div>
                        
                      </div>
                            <div id="tab-4" class="table-content shadow-sm scrollbar-style">
                           <h4 class=" mb-4">4. Fees </h4>
                           <div class="text">OTC Services and specifically the Quotes are offered on the basis of a variable spread. Due to the volatile nature of Virtual Assets or Digital Assets, a typical spread cannot be determined in these OTC Terms, the OTC Interface or on the Wealthmark platform.</div>
                       
                      </div>
                            <div id="tab-5" class="table-content shadow-sm scrollbar-style">    
                                <h4 class=" mb-4">5. Representations and Warranties </h4>
                                <div class="text">You acknowledge and agree that when entering Transactions, you will be transacting for your own account, and in an arm’s-length role in relation to Wealthmark </div>
                                <div class="text">Wealthmark employs measures to ensure that OTC Services are accessible at all times without interruption. Notwithstanding this, Wealthmark cannot guarantee uninterrupted or error-free operation of OTC Services, or that Wealthmark will correct all defects or prevent third-party disruptions or unauthorized third-party access. In the event of such disruptions, OTC Services may not be accessible in part or in full. </div>
                                 <div class="text">Wealthmark makes no representations and warranties and makes no guarantees that any particular Virtual Assets or Digital Assets will be available for OTC trading on a continuous basis. Wealthmark reserves the right, at any time, with or without cause or prior notice, at its sole discretion to limit, suspend, or terminate all or part of the OTC Services or your access to the OTC Services and/or OTC Interface. </div>
                                 <div class="text">For the avoidance of doubt, Wealthmark shall not have any obligation to send any received Quote Request and/or Accepted Quote to prospective OTC Counterparties. You understand that you are solely responsible for maintaining any alternative arrangements that may be needed or desirable if any or all of the OTC Services becomes unavailable or disrupted </div>
                                 <div class="text"><b>WEALTHMARK MAKES NO REPRESENTATION OR WARRANTY THAT OTC SERVICES AS SUCH ARE APPROPRIATE FOR USE IN ALL LOCATIONS, OR THAT THE TRANSACTIONS AND SERVICES DESCRIBED HEREIN ARE AVAILABLE OR APPROPRIATE FOR ENTRY INTO OR USE IN ALL JURISDICTIONS OR BY ALL PARTIES. YOU SHOULD INFORM YOURSELF AS TO THE LEGAL REQUIREMENTS AND TAX CONSEQUENCES OF USING OTC SERVICES WITHIN ALL JURISDICTIONS APPLICABLE TO YOU. WEALTHMARK IS NOT RESPONSIBLE FOR TAX CONSEQUENCES TO YOU THAT ARISE BECAUSE OF USING OTC SERVICES PROVIDED BY WEALTHMARK</b> </div>
                           </div>
                            <div id="tab-6" class="table-content shadow-sm scrollbar-style">
                                <h4 class=" mb-4">Limitation of Liability </h4>
                           <div class="text">For the avoidance of doubt, the disclaimers of warranty, limitation of liability and indemnification and releases set out in the Wealthmark Terms of Use shall cover the OTC Services, and these OTC Terms and the Wealthmark Terms of Use shall be interpreted accordingly</div>
                           
                           </div>
                        </div>
          </div>
          </div>
      </section>
      
      
      
     
      <section class="bg-light-blue mb-5">
          <div class="container">
              <div class="row">
                    <div class="col-md-12  col-sm-12">
                            <div class="sec-title text-center">
                                <span class="title">Welcome to Wealthmark</span>
                                <h2 class="heading-h2">Settlement and Credit Lines</h2>
                                <div class="text">
                                    Get access to trading without the need for pre-funding and customized post-trade settlement solutions to optimize capital efficiency. With the flexibility of credit lines, start trading immediately before moving funds into wallets, or access funds within wallets to trade across the OTC product suite.
                                </div>
                            </div>
                    </div>
                      <div class="col-md-12  col-sm-12">
                            <img src="{{ asset('public/assets/img/otc-landing-settlement.png') }}" class="w-100 h-100">
                    </div>
                        
              </div>
          </div>
      </section>
      
      
  
      
      
      
      
      
      
      
        
      
    @include('template.country_language')
    @include('template.web_footer') 
     
<script>
       //   =========================	tab pills js=========================

	    $(document).ready(function(){
	
	        $('ul.tabs li').click(function(){
		        var tab_id = $(this).attr('data-tab');
		        $('ul.tabs li').removeClass('current');
		        $('.table-content').removeClass('current');

		        $(this).addClass('current');
		        $("#"+tab_id).addClass('current');
	       })

        })
        
         $('.tabs').on('click', function(){
      $('.tabs').removeClass('active');
      $(this).addClass('active');
    });
   //   =========================	tab pills js=========================
</script>
  
    </body>
</html>