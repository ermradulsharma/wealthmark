  <!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
   <head>
      <meta charset="utf-8">
      <meta content="width=device-width, initial-scale=1.0" name="viewport">
      <title>Wealth Mark | Create Entity Account</title>
  @include('template.web_css')
      
  
 <style>
     #header{
         background:white;
         
     }

.p2p-pro-bg-img{
    position:absolute;
}


.sec-icon {
  position: relative;
  display: inline-block;
  padding: 0;
  margin: 0 auto;
}

.sec-icon::before {
  content: "";
  position: absolute;
  height: 1px;
  left: -70px;
  margin-top: -5.5px;
  top: 60%;
  background: #333333;
  width: 50px;
}

.sec-icon::after {
  content: "";
  position: absolute;
  height: 1px;
  right: -70px;
  margin-top: -5.5px;
  top: 60%;
  background: #333;
  width: 50px;
}


.advertisers-service-sec span {
  color: rgb(255, 23, 131);
}
.advertisers-service-sec .col {
  padding: 0 1em 1em 1em;
  text-align: center;
}

.advertisers-service-sec .service-card {
  width: 100%;
  height: 100%;
  padding: 2em 1.5em;
  border-radius: 5px;
  box-shadow: 0 0 35px rgba(0, 0, 0, 0.12);
  cursor: pointer;
  transition: 0.5s;
  position: relative;
  z-index: 2;
  overflow: hidden;
  background: #fff;
}

.advertisers-service-sec .service-card::after {
  content: "";
  width: 100%;
  height: 100%;
  background: linear-gradient(#263674, #263674);
  position: absolute;
  left: 0%;
  top: -98%;
  z-index: -2;
  transition: all 0.4s cubic-bezier(0.77, -0.04, 0, 0.99);
}

.advertisers-service-sec h3 {
  font-size: 20px;
  text-transform: capitalize;
  margin: 1em 0;
  z-index: 3;
}

/*.advertisers-service-sec p {*/
/*  color: #575a7b;*/
/*  font-size: 15px;*/
/*  line-height: 1.6;*/
/*  letter-spacing: 0.03em;*/
/*  z-index: 3;*/
/*}*/

.advertisers-service-sec .icon-wrapper {
 
  position: relative;
  margin: auto;
  max-height: 100px;
  max-width: 100px;
  border-radius: 50%;
line-height:100px;
text-align:center;
}
.advertisers-service-sec .icon-wrapper img{
    max-width:60%;
    margin:auto;
}
.advertisers-service-sec .service-card:hover:after {
  top: 0%;
}

.service-card .icon-wrapper {
  background-color: #ffffff;
  border: 1px solid whitesmoke;
}

.advertisers-service-sec .service-card:hover .icon-wrapper {
  color: #0dcaf0;
}

.advertisers-service-sec .service-card:hover h3 {
  color: #ffffff;
}

.advertisers-service-sec .service-card:hover div.text {
  color: #fff;
}


 </style>
  
  
   </head>
   
 <body class="bg-white">
     
     @include('template.mobile_menu')
        @include('template.web_menu')
    
    
    
   
   <div class="bg-dark-blue p-2">
       <div class="container">
           <div class="row aligh-items-center justify-content-center">
               <div class="col-md-6">
                <a href="{{ url( app()->getLocale(), 'register') }}" class="reward-link">
                     <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="reward-gift-svg">
                          <path d="M13.5 6.379V3h-3v3.379l-2.94-2.94-2.12 2.122L7.878 8H4v3h6.75V8h2.5v3H20V8h-3.879l2.44-2.44-2.122-2.12L13.5 6.378zM4 13.5V20h6.75v-6.5H4zM13.25 20H20v-6.5h-6.75V20z" fill="currentColor"></path>
                    </svg>
                    <div class="reward-text">Register now and get verified - Enjoy Welcome Rewards up to $100!</div>
                    <div class="reward-div-arrow">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="reward-arrow-svg">
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M21 11.999l-7.071-7.071-1.768 1.768 4.055 4.054H2.999v2.5h13.216l-4.054 4.053 1.768 1.768L21 12v-.001z" fill="currentColor"></path>
                        </svg>
                    </div>
                </a>
               </div>
           </div>
       </div>
   </div>
       <section id="p2p" class="breadcrumbs shadow-sm">
          <div class="container-fluid">
              <div class="row">
                 <div class="col-lg-4 offset-lg-2 d-flex flex-column justify-content-center pt-lg-0 order-2 order-lg-1" data-aos="fade-up" data-aos-delay="200">
                 <h1 class="top-heading">Binance <span class="yellow-text"> P2Pro </span> Merchant Program</h1>
                 <h3 class="title">Exclusive program for licensed partners</h3>
                 <p class="top-p">Trusted by millions of users worldwide, Binance P2P provides a safe platform to conduct crypto trades in 300+ payment methods and 70+ fiat currencies. Users can easily buy, sell and trade crypto directly with other users, while setting their preferred prices and payment methods in an open crypto marketplace.</p>
                 <div>
                     <a href="#" class="btn btn-yellow shadow"> Apply Now </a>
                 </div>
                 </div>
                 <div class="col-lg-5 order-1 order-lg-2 hero-img" data-aos="zoom-in" data-aos-delay="200">
                    <img src="{{ asset('public/assets/img/graphic-1-01.svg') }}" class="img-fluid animated" alt="" style="width:100%">
                 </div>
              </div>
           </div>
            <!--<img src="{{ asset('public/assets/img/p2p/p2ppro.svg') }}" class="p2p-pro-bg-img" alt="" style="width:100%">-->
      </section>
      
   <!-- ADVERTISERS SERVICE CARD -->
<section id="advertisers" class="advertisers-service-sec pt-5 pb-5 bg-light-blue">
  <div class="container">
    <div class="row align-items-center justify-content-center">
      <div class="col-md-12 col-sm-12">
                    <div class="sec-title text-left">
                            
                            <h2 class="heading-h2">Discover how you can benefit from PRO status</h2>
                    </div>
                    
                         
              </div>
    </div>
    <div class="row mt-5 mt-md-4 row-cols-1 row-cols-sm-1 row-cols-md-3 justify-content-center">
      <div class="col">
        <div class="service-card">
          <div class="icon-wrapper shadow-sm">
             <img src="{{ asset('public/assets/img/p2p/pro-badge.svg') }}" class="img-fluid" alt="" style="width:100%">
          </div>
          <h3 class="yellow-text">Tracking Lead</h3>
           <div class="text">
            Lorem ipsum dolor, sit amet consectetur adipisicing elit.
            Quisquam consequatur necessitatibus eaque.
          </div>
        </div>
      </div>
      <div class="col">
        <div class="service-card ">
          <div class="icon-wrapper shadow-sm">
          <img src="{{ asset('public/assets/img/p2p/mail-open-dark.svg') }}" class="img-fluid" alt="" style="width:100%">
          </div>
          <h3 class="yellow-text">Advanced Targeting solution</h3>
           <div class="text">
            Lorem ipsum dolor, sit amet consectetur adipisicing elit.
            Quisquam consequatur necessitatibus eaque.
          </div>
        </div>
      </div>
      <div class="col">
        <div class="service-card">
          <div class="icon-wrapper shadow-sm">
         <img src="{{ asset('public/assets/img/p2p/team-dark.svg') }}" class="img-fluid" alt="" style="width:100%">
          </div>
          <h3 class="yellow-text">Global Reach & Quality Traffic</h3>
           <div class="text">
            Lorem ipsum dolor, sit amet consectetur adipisicing elit.
            Quisquam consequatur necessitatibus eaque.
          </div>
        </div>
      </div>
     
    </div>
  </div>
</section>

<section>
    <div class="container">
       <div class="row align-items-center justify-content-center mb-5">
              <div class="col-md-4 col-sm-6 mb-4">
                      <img src="{{ asset('public/assets/img/p2p/dedicated-cs.png') }}" class="img-fluid" alt="" style="">
              </div>
              <div class="col-md-6 col-sm-6">
                    <div class="sec-title text-left">
                            
                            <h2 class="heading-h2">Dedicated client support</h2>
                    </div>
                    
                         <div class="text">
                         As a P2Pro merchant you will benefit from individual support from our experienced team.
                            </div>
                            <div class="text">
                                Our team will provide you with express handling of appeals through additional communication channel, extra features for your account, and lower fees.
                            </div>
              </div>
          </div>
          
           <div class="row align-items-center justify-content-center">
              <div class="col-md-4 col-sm-6 order-md-last mb-4">
                      <img src="{{ asset('public/assets/img/p2p/apply-for-pro.png') }}" class="img-fluid" alt="" style="">
              </div>
              <div class="col-md-6 col-sm-6">
                    <div class="sec-title text-left">
                            
                            <h2 class="heading-h2">Apply for PRO merchant account</h2>
                    </div>
                    
                         <div class="text">
                      Are you an existing P2P merchant or new client with existing crypto-license and extensive experience in P2P trading?

                            </div>
                            <div class="text">
                                Please apply for our program for professional local exchangers and enjoy all the benefits of PRO merchant status on leading peer-to-peer platform!

                            </div>
                            <div class="mt-4">
                                <a href="" class="btn-yellow"> Apply Now</a>
                            </div>
              </div>
          </div>
        </div>
    </div>
</section>
<section class="bg-dark-blue">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">
               
                            
                            <h1 class="title mb-5 text-white">Start P2P trading now</h1>
                            <a href="#" class="btn-yellow"> Apply Now</a>
                   
            </div>
        </div>
    </div>
</section>
      
  @include('template.country_language')
    @include('template.web_footer') 
    
   
  
    </body>
</html>