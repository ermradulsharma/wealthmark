  <!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
   <head>
      <meta charset="utf-8">
      <meta content="width=device-width, initial-scale=1.0" name="viewport">
      <title>Wealth Mark | Create Entity Account</title>
  @include('template.web_css')
      
  
 <style>
     #header{
         background:white;
         
     }

 </style>
  
  
   </head>
   
 <body class="bg-white">
     
     @include('template.mobile_menu')
        @include('template.web_menu')
    
    
  
    
<div class="bg-light-blue">
    
    <div class="container">
        <div class="row">
            <div class="col-md-4 col-sm-6 col-xs-12">
                <div class="nav-tabs-list d-flex justify-content-between">
                      <a  href="{{ url( app()->getLocale(), 'about-us') }}" class="nav-tabs-a">About</a>
                      <a  href="{{ url( app()->getLocale(), 'careers') }}" class="nav-tabs-a active">Careers</a>
                      <a  href="{{ url( app()->getLocale(), 'press') }}" class="nav-tabs-a">Press</a>
                      <a  href="{{ url( app()->getLocale(), 'community') }}" class="nav-tabs-a">Community</a>
                </div>
            </div>
        </div>
    </div>
</div>
    
    
   <section  class="breadcrumbs shadow-sm career-section-breadcrumbs p-5">
          <div class="container-fluid">
              <div class="row">
                   <div class="col-lg-5 offset-lg-1">
                    <img src="{{ asset('public/assets/img/career-graphic.png') }}" class="img-fluid w-75" alt="" >
                 </div>
                 <div class="col-lg-4 offset-lg-1 d-flex flex-column justify-content-center pt-lg-0 order-2 order-lg-1 p-5" data-aos="fade-up" data-aos-delay="200">
                 <h3 class="top-heading">Careers at Wealthmark</h3>
                 <p class="top-p">Join our quest to increase the Freedom of Money</p>
               <div>
                     <a href="#" class="btn btn-yellow shadow"> View Openings</a>
                 </div>
                 </div>
                
              </div>
            </div>
      </section>
     
    <section class="about-our-values">
        <div class="container">
            <div class="row align-items-center">                
                <div class="col-lg-12 col-md-12 col-sm-12">
                     <div class="sec-title">
                            <span class="title">Welcome to Wealthmark</span>
                            <h2 class="heading-h2">Our Values</h2>
                        </div>
                        <div class="text">Wealthmark Core Values guide our behavior, decisions, and action, enabling unified collaboration across our diverse, international teams.                    </div>
                </div>
            </div>
             <div class="des-our-value">
                <div class="des-our-value-block-main">
                        <div class="des-our-value-block-left">
                            <h3>User-Focused</h3>
                             <div class="text">We protect our users by putting our users' needs first and delivering quality service.</div>
                        </div>
                    <div class="des-our-value-block-right">
                        <img src="{{ asset('public/assets/img/wm-user-focused.png') }}" class="des-our-value-img-max">
                    </div>
                </div>
                
                <div class="des-our-value-block-main">
                    <div class="des-our-value-block-left">
                        <h3>Collaboration</h3>
                         <div class="text">We communicate openly.</div>
                         <div class="text">We work as a team towards shared goals to build the ecosystem together.</div>
                    </div>
                    <div class="des-our-value-block-right">
                        <img src="{{ asset('public/assets/img/wm-collaboration.png') }}" class="des-our-value-img-max">
                        </div>
                    </div>
                    <div class="des-our-value-block-main">
                    <div class="des-our-value-block-left">
                        <h3>Hardcore</h3>
                            <div class="text">We are results driven. We get things done.</div>
                            <div class="text">We are passionate and work hard.</div>
                            <div class="text">When we fail, we learn fast, and pick ourselves up.</div>
                    </div>
                    <div class="des-our-value-block-right">
                        <img src="{{ asset('public/assets/img/wm-hardcore.png') }}" class="des-our-value-img-max">
                        </div>
                    </div>
                    <div class="des-our-value-block-main">
                    <div class="des-our-value-block-left">
                      <h3>Freedom</h3>
    <div class="text">We execute responsibly and autonomously.</div>
    <div class="text">We empower those around us.</div>
    <div class="text">Our team is diverse and we challenge the status quo.</div>
                    </div>
                    <div class="des-our-value-block-right">
                       <img src="{{ asset('public/assets/img/wm-freedom.png') }}" class="des-our-value-img-max">
                        </div>
                    </div>
                    <div class="des-our-value-block-main">
                    <div class="des-our-value-block-left">
                         <h3>Humility</h3>
    <div class="text">We accept critical feedback.</div>
    <div class="text">We treat everyone as equals.</div>
    <div class="text">We are modest about our success.</div>
                    </div>
                    <div class="des-our-value-block-right">
                        <img src="{{ asset('public/assets/img/wm-humility.png') }}" class="des-our-value-img-max">
                        </div>
                    </div>
                   
                
                
 
 
        </div>
    </section>
    <section class="Conters bg-dark-blue">
        <div class="container">
              <div class="row text-center">
                
                <div class="col-md-3 col-sm-3 col-xs-6">
                  <i class="fa fa-code"></i>
                  <h2 class="text-white"><span class="counter" data-count="43">0</span>+</h2>
                  <span class="counter-desc yellow-text">Nationalities</span>
                </div>
                <div class="col-md-3 col-sm-3 col-xs-6">
                  <i class="fa fa-coffee"></i>
                  <h2 class="text-white"><span class="counter" data-count="565">0</span>+</h2>
                  <span class="counter-desc yellow-text">Employees</span>
                </div>
                <div class="col-md-3 col-sm-3 col-xs-6">
                  <i class="fa fa-bug"></i>
                  <h2 class="text-white"><span class="counter" data-count="50">0</span>+</h2>
                  <span class="counter-desc yellow-text">Locations</span>
                </div>
                <div class="col-md-3 col-sm-3 col-xs-6">
                  <i class="fa fa-hourglass-half"></i>
                  <h2 class="text-white"><span class="counter" data-count="91874">0</span>+</h2>
                  <span class="counter-desc yellow-text">Happy Clients</span>
                </div>
              </div>
            </div>
    </section>
      
          <section class="team">
        <div class="container">
            <div class="row align-items-center">                
                <div class="col-lg-12 col-md-12 col-sm-12">
                        <div class="sec-title">
                            <span class="title">Welcome to Wealthmark</span>
                            <h2 class="heading-h2">Choose Your Team</h2>
                        </div>
                        <div class="text">Select a team most relevant to your interests and experience to view job openings</div>
               
                </div>
            </div>
            
            <div class="select-supp">
  <a href="#" class="select-supp-a">
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="select-supp-svg">
      <path transform="matrix(1 0 0 -1 3 19)" fill="url(#business-development-g_svg__paint0)" d="M0 0h3v4H0z"></path>
      <path fill="#76808F" d="M8 11h3v10H8zM13 6h3v15h-3zM18 3h3v18h-3z"></path>
      <path transform="matrix(1 0 0 -1 8 21)" fill="url(#business-development-g_svg__paint1)" d="M0 0h3v6H0z"></path>
      <path transform="matrix(1 0 0 -1 13 21)" fill="url(#business-development-g_svg__paint2)" d="M0 0h3v10H0z"></path>
      <path transform="matrix(1 0 0 -1 18 21)" fill="url(#business-development-g_svg__paint3)" d="M0 0h3v15H0z"></path>
      <path fill="#76808F" d="M3 19h18v2H3zM3 3h2v2H3zM3 7h2v2H3zM3 11h2v2H3z"></path>
      <defs>
        <linearGradient id="business-development-g_svg__paint0" x1="1.5" y1="0" x2="1.5" y2="4" gradientUnits="userSpaceOnUse">
          <stop stop-color="#F0B90B"></stop>
          <stop offset="1" stop-color="#F8D33A"></stop>
        </linearGradient>
        <linearGradient id="business-development-g_svg__paint1" x1="1.5" y1="0" x2="1.5" y2="6" gradientUnits="userSpaceOnUse">
          <stop stop-color="#F0B90B"></stop>
          <stop offset="1" stop-color="#F8D33A"></stop>
        </linearGradient>
        <linearGradient id="business-development-g_svg__paint2" x1="1.5" y1="0" x2="1.5" y2="10" gradientUnits="userSpaceOnUse">
          <stop stop-color="#F0B90B"></stop>
          <stop offset="1" stop-color="#F8D33A"></stop>
        </linearGradient>
        <linearGradient id="business-development-g_svg__paint3" x1="1.5" y1="0" x2="1.5" y2="15" gradientUnits="userSpaceOnUse">
          <stop stop-color="#F0B90B"></stop>
          <stop offset="1" stop-color="#F8D33A"></stop>
        </linearGradient>
      </defs>
    </svg>
    <div class="select-supp-a-div">
      <div class="select-supp-a-div-txt">Business Development</div>
    </div>
  </a>
  <a href="#" class="select-supp-a">
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 50 50" fill="none" class="select-supp-svg">
      <path d="M26.786 8.333c8.054 0 14.584 6.53 14.584 14.584h4.166c0-10.356-8.394-18.75-18.75-18.75v4.166z" fill="#76808F"></path>
      <path d="M35.416 14.583V37.5h-4.167V21.696l-6.755 6.756-2.947-2.947 6.756-6.755H12.499v-4.167h22.917zM4.88 42.172l8.334-8.333 2.946 2.946-8.333 8.334-2.946-2.947z" fill="#76808F"></path>
      <path d="M10.268 39.731c8.136 8.136 21.327 8.136 29.463 0L10.268 10.27c-8.136 8.136-8.136 21.327 0 29.462z" fill="url(#communications-g_svg__paint0_linear_2218_19589)"></path>
      <defs>
        <linearGradient id="communications-g_svg__paint0_linear_2218_19589" x1="21.948" y1="45.833" x2="21.948" y2="10.269" gradientUnits="userSpaceOnUse">
          <stop stop-color="#F0B90B"></stop>
          <stop offset="1" stop-color="#F8D33A"></stop>
        </linearGradient>
      </defs>
    </svg>
    <div class="select-supp-a-div">
      <div class="select-supp-a-div-txt">Communications</div>
    </div>
  </a>
  <a href="#" class="select-supp-a">
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="select-supp-svg">
      <path d="M6 10a6 6 0 1112 0v7h2v-7a8 8 0 10-16 0v7h2v-7zM12 18a2.5 2.5 0 110 5 2.5 2.5 0 010-5z" fill="#76808F"></path>
      <path d="M.5 13.5A3.5 3.5 0 004 17v-7a3.5 3.5 0 00-3.5 3.5z" fill="url(#customer-service-g_svg__paint0_linear)"></path>
      <path d="M23.5 13.5A3.5 3.5 0 0120 17v-7a3.5 3.5 0 013.5 3.5z" fill="url(#customer-service-g_svg__paint1_linear)"></path>
      <defs>
        <linearGradient id="customer-service-g_svg__paint0_linear" x1="12" y1="17" x2="12" y2="10" gradientUnits="userSpaceOnUse">
          <stop stop-color="#F0B90B"></stop>
          <stop offset="1" stop-color="#F8D33A"></stop>
        </linearGradient>
        <linearGradient id="customer-service-g_svg__paint1_linear" x1="12" y1="17" x2="12" y2="10" gradientUnits="userSpaceOnUse">
          <stop stop-color="#F0B90B"></stop>
          <stop offset="1" stop-color="#F8D33A"></stop>
        </linearGradient>
      </defs>
    </svg>
    <div class="select-supp-a-div">
      <div class="select-supp-a-div-txt">Customer Support</div>
    </div>
  </a>
  <a href="#" class="select-supp-a">
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="select-supp-svg">
      <path fill-rule="evenodd" clip-rule="evenodd" d="M22 19.879l-5.94-5.94L15 15l-1.06 1.062L19.879 22 22 19.879z" fill="#76808F"></path>
      <path fill-rule="evenodd" clip-rule="evenodd" d="M15.94 10a6 6 0 10-12 0 6 6 0 0012 0zm-6-8a8 8 0 110 16 8 8 0 010-16z" fill="url(#zoom-in-g_svg__paint0_linear)"></path>
      <path d="M9 11v3h2v-3h3V9h-3V6H9v3H6v2h3z" fill="#76808F"></path>
      <defs>
        <linearGradient id="zoom-in-g_svg__paint0_linear" x1="9.939" y1="18" x2="9.939" y2="2" gradientUnits="userSpaceOnUse">
          <stop stop-color="#F0B90B"></stop>
          <stop offset="1" stop-color="#F8D33A"></stop>
        </linearGradient>
      </defs>
    </svg>
    <div class="select-supp-a-div">
      <div class="select-supp-a-div-txt">Data &amp; Research</div>
    </div>
  </a>
  <a href="#" class="select-supp-a">
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="select-supp-svg">
      <circle r="10" transform="matrix(1 0 0 -1 12 12)" fill="url(#circled-play-g_svg__paint0_linear)"></circle>
      <path d="M17 12L9 7v10l8-5z" fill="#76808F"></path>
      <defs>
        <linearGradient id="circled-play-g_svg__paint0_linear" x1="10" y1="0" x2="10" y2="20" gradientUnits="userSpaceOnUse">
          <stop stop-color="#F0B90B"></stop>
          <stop offset="1" stop-color="#F8D33A"></stop>
        </linearGradient>
      </defs>
    </svg>
    <div class="select-supp-a-div">
      <div class="select-supp-a-div-txt">Editorial &amp; Video</div>
    </div>
  </a>
  <a href="#" class="select-supp-a">
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 50 50" fill="none" class="select-supp-svg">
      <path fill-rule="evenodd" clip-rule="evenodd" d="M45.833 8.333H4.166v33.334h41.667V8.333zm-6.25 22.917H22.916v4.167h16.667V31.25z" fill="url(#programming-g_svg__paint0_linear_2218_19591)"></path>
      <path d="M4.166 8.333h41.667V12.5H4.166V8.333zM9.048 19.107l2.946-2.946L20.833 25l-8.839 8.839-2.946-2.947L14.94 25l-5.892-5.893z" fill="#76808F"></path>
      <defs>
        <linearGradient id="programming-g_svg__paint0_linear_2218_19591" x1="24.999" y1="41.667" x2="24.999" y2="8.333" gradientUnits="userSpaceOnUse">
          <stop stop-color="#F0B90B"></stop>
          <stop offset="1" stop-color="#F8D33A"></stop>
        </linearGradient>
      </defs>
    </svg>
    <div class="select-supp-a-div">
      <div class="select-supp-a-div-txt">Engineering</div>
    </div>
  </a>
  <a href="#" class="select-supp-a">
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="select-supp-svg">
      <circle r="10" transform="matrix(1 0 0 -1 12 12)" fill="url(#payment-g_svg__paint0_linear)"></circle>
      <path d="M13.088 20v-1.782c2.468-.408 3.62-1.949 3.62-3.768 0-1.893-1.244-2.951-3.843-3.545V7.824c.89.204 1.485.612 1.93 1.113l1.69-1.522c-.817-.928-1.912-1.503-3.397-1.67V4h-2.116v1.745c-2.395.278-3.675 1.578-3.675 3.526 0 1.8 1.132 3.026 3.916 3.601v3.341c-1.04-.148-1.912-.65-2.617-1.392l-1.67 1.522c.927 1.021 2.171 1.782 4.046 1.95V20h2.116zM9.858 9.197c0-.724.408-1.225 1.355-1.41v2.747c-.947-.26-1.355-.631-1.355-1.337zm4.288 5.457c0 .706-.409 1.281-1.281 1.522v-2.932c1.058.315 1.28.872 1.28 1.41z" fill="#76808F"></path>
      <defs>
        <linearGradient id="payment-g_svg__paint0_linear" x1="10" y1="0" x2="10" y2="20" gradientUnits="userSpaceOnUse">
          <stop stop-color="#F0B90B"></stop>
          <stop offset="1" stop-color="#F8D33A"></stop>
        </linearGradient>
      </defs>
    </svg>
    <div class="select-supp-a-div">
      <div class="select-supp-a-div-txt">Finance &amp; Administration</div>
    </div>
  </a>
  <a href="#" class="select-supp-a">
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 50 50" fill="none" class="select-supp-svg">
      <path d="M11.459 12.5l-9.375 9.375h18.75L11.459 12.5zM38.541 12.5l-9.375 9.375h18.75L38.541 12.5z" fill="#76808F"></path>
      <path d="M22.917 4.167h4.167v4.166h18.75V12.5h-18.75v29.167h-4.167V12.5H4.167V8.333h18.75V4.167z" fill="url(#compliance-g_svg__paint0_linear_2218_19592)"></path>
      <path d="M11.459 31.25a9.375 9.375 0 009.375-9.375H2.084a9.375 9.375 0 009.375 9.375z" fill="url(#compliance-g_svg__paint1_linear_2218_19592)"></path>
      <path d="M38.542 31.25a9.375 9.375 0 009.375-9.375h-18.75a9.375 9.375 0 009.375 9.375z" fill="url(#compliance-g_svg__paint2_linear_2218_19592)"></path>
      <path fill="#76808F" d="M22.916 12.5h4.167V8.333h-4.167zM10.416 41.667h29.167v-6.25H10.416v6.25z"></path>
      <defs>
        <linearGradient id="compliance-g_svg__paint0_linear_2218_19592" x1="25.001" y1="41.667" x2="25.001" y2="4.167" gradientUnits="userSpaceOnUse">
          <stop stop-color="#F0B90B"></stop>
          <stop offset="1" stop-color="#F8D33A"></stop>
        </linearGradient>
        <linearGradient id="compliance-g_svg__paint1_linear_2218_19592" x1="25.001" y1="41.667" x2="25.001" y2="4.167" gradientUnits="userSpaceOnUse">
          <stop stop-color="#F0B90B"></stop>
          <stop offset="1" stop-color="#F8D33A"></stop>
        </linearGradient>
        <linearGradient id="compliance-g_svg__paint2_linear_2218_19592" x1="25.001" y1="41.667" x2="25.001" y2="4.167" gradientUnits="userSpaceOnUse">
          <stop stop-color="#F0B90B"></stop>
          <stop offset="1" stop-color="#F8D33A"></stop>
        </linearGradient>
      </defs>
    </svg>
    <div class="select-supp-a-div">
      <div class="select-supp-a-div-txt">Legal &amp; Compliance</div>
    </div>
  </a>
  <a href="#" class="select-supp-a">
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="select-supp-svg">
      <path d="M3 13h2V8H3v5z" fill="#76808F"></path>
      <path d="M17 6H5v9H17l4 4V2l-4 4z" fill="url(#announcement-g_svg__paint0_linear)"></path>
      <path d="M14 15H7v7h4v-5h3v-2z" fill="#76808F"></path>
      <defs>
        <linearGradient id="announcement-g_svg__paint0_linear" x1="13.001" y1="19" x2="13.001" y2="2" gradientUnits="userSpaceOnUse">
          <stop stop-color="#F0B90B"></stop>
          <stop offset="1" stop-color="#F8D33A"></stop>
        </linearGradient>
      </defs>
    </svg>
    <div class="select-supp-a-div">
      <div class="select-supp-a-div-txt">Marketing</div>
    </div>
  </a>
  <a href="#" class="select-supp-a">
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="select-supp-svg">
      <path fill-rule="evenodd" clip-rule="evenodd" d="M14.987 4.391l2.066 1.195 2.672-.16 1.818 3.149-1.474 2.232v2.386l1.474 2.232-1.818 3.15-2.672-.16-2.066 1.194L13.792 22h-3.636L8.96 19.609l-2.066-1.195-2.672.16-1.818-3.149 1.474-2.232v-2.386L2.404 8.575l1.818-3.15 2.672.16L8.96 4.392 10.155 2h3.637l1.195 2.391zm-2.99 2.155a5.454 5.454 0 110 10.909 5.454 5.454 0 010-10.91z" fill="url(#settings-cog-g_svg__paint0_linear)"></path>
      <path d="M9.27 12l2.727-2.727L14.725 12l-2.728 2.727L9.27 12z" fill="#76808F"></path>
      <defs>
        <linearGradient id="settings-cog-g_svg__paint0_linear" x1="11.974" y1="22" x2="11.974" y2="2" gradientUnits="userSpaceOnUse">
          <stop stop-color="#F0B90B"></stop>
          <stop offset="1" stop-color="#F8D33A"></stop>
        </linearGradient>
      </defs>
    </svg>
    <div class="select-supp-a-div">
      <div class="css-1bh5lix">Operations, Strategy &amp; Project Management</div>
    </div>
  </a>
  <a href="#" class="select-supp-a">
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 50 50" fill="none" class="select-supp-svg">
      <path fill-rule="evenodd" clip-rule="evenodd" d="M4.166 8.333h37.5v25h-37.5v-25z" fill="url(#product-design-g_svg__paint0_linear_2218_19595)"></path>
      <path fill-rule="evenodd" clip-rule="evenodd" d="M45.833 14.583L18.75 41.667h27.083V14.583zm-4.166 10.06L28.809 37.5h12.858V24.642z" fill="#76808F"></path>
      <path fill="#fff" d="M10.416 14.583h22.917v4.167H10.416z"></path>
      <path d="M33.334 14.583v6.25L10.417 43.75l-6.25-6.25 22.917-22.917h6.25z" fill="#76808F"></path>
      <defs>
        <linearGradient id="product-design-g_svg__paint0_linear_2218_19595" x1="22.916" y1="33.333" x2="22.916" y2="8.333" gradientUnits="userSpaceOnUse">
          <stop stop-color="#F0B90B"></stop>
          <stop offset="1" stop-color="#F8D33A"></stop>
        </linearGradient>
      </defs>
    </svg>
    <div class="select-supp-a-div">
      <div class="select-supp-a-div-txt">Product &amp; Design</div>
    </div>
  </a>
  <a href="#" class="select-supp-a">
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="select-supp-svg">
      <path fill-rule="evenodd" clip-rule="evenodd" d="M4 18h18V4h-2l-7 7H8l-4 4v3z" fill="url(#chart-line-g_svg__paint0_linear)"></path>
      <path d="M4 4H2v16h20v-2H4V4z" fill="#76808F"></path>
      <defs>
        <linearGradient id="chart-line-g_svg__paint0_linear" x1="13" y1="18" x2="13" y2="4" gradientUnits="userSpaceOnUse">
          <stop stop-color="#F0B90B"></stop>
          <stop offset="1" stop-color="#F8D33A"></stop>
        </linearGradient>
      </defs>
    </svg>
    <div class="select-supp-a-div">
      <div class="select-supp-a-div-txt">Quantitative Strategy</div>
    </div>
  </a>
  <a href="#" class="select-supp-a">
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="select-supp-svg">
      <path d="M4 22h16V9H4v13z" fill="url(#lock-close-g_svg__paint0_linear)"></path>
      <path d="M9 6a3 3 0 116 0v3h2V6A5 5 0 007 6v3h2V6zM13 19v-7h-2v7h2z" fill="#76808F"></path>
      <defs>
        <linearGradient id="lock-close-g_svg__paint0_linear" x1="12" y1="22" x2="12" y2="9" gradientUnits="userSpaceOnUse">
          <stop stop-color="#F0B90B"></stop>
          <stop offset="1" stop-color="#F8D33A"></stop>
        </linearGradient>
      </defs>
    </svg>
    <div class="select-supp-a-div">
      <div class="select-supp-a-div-txt">Security &amp; IT Helpdesk</div>
    </div>
  </a>
  <a href="#" class="select-supp-a">
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 50 50" fill="none" class="select-supp-svg">
      <path d="M16.667 23.958v7.292H9.376a7.292 7.292 0 117.291-7.292zM36.458 2.083C30.13 2.083 25 7.213 25 13.542h22.917c0-6.329-5.13-11.459-11.459-11.459z" fill="#76808F"></path>
      <path d="M13.772 28.356c-4.475 4.475-4.475 11.73 0 16.205l16.205-16.205c-4.475-4.475-11.73-4.475-16.205 0z" fill="#76808F"></path>
      <path d="M36.458 25C30.13 25 25 19.87 25 13.542h22.917C47.917 19.87 42.787 25 36.458 25z" fill="url(#hr-g_svg__paint0_linear_2218_19597)"></path>
      <path d="M29.978 44.56c-4.475 4.475-11.73 4.475-16.205 0l16.205-16.204c4.475 4.475 4.475 11.73 0 16.205z" fill="url(#hr-g_svg__paint1_linear_2218_19597)"></path>
      <path d="M18.75 9.375h10.417v4.167H18.75V9.375z" fill="#76808F"></path>
      <defs>
        <linearGradient id="hr-g_svg__paint0_linear_2218_19597" x1="25" y1="19.271" x2="47.917" y2="19.271" gradientUnits="userSpaceOnUse">
          <stop stop-color="#F0B90B"></stop>
          <stop offset="1" stop-color="#F8D33A"></stop>
        </linearGradient>
        <linearGradient id="hr-g_svg__paint1_linear_2218_19597" x1="23.554" y1="47.917" x2="23.554" y2="28.356" gradientUnits="userSpaceOnUse">
          <stop stop-color="#F0B90B"></stop>
          <stop offset="1" stop-color="#F8D33A"></stop>
        </linearGradient>
      </defs>
    </svg>
    <div class="select-supp-a-div">
      <div class="select-supp-a-div-txt">HR</div>
    </div>
  </a>
  <a href="#" class="select-supp-a">
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 50 50" fill="none" class="select-supp-svg">
      <path fill-rule="evenodd" clip-rule="evenodd" d="M29.167 19.792a7.292 7.292 0 1114.583 0 7.292 7.292 0 01-14.583 0z" fill="url(#users-g_svg__paint0_linear_2218_19600)"></path>
      <path d="M39.584 31.25h-6.25v10.417h12.5V37.5a6.25 6.25 0 00-6.25-6.25z" fill="#76808F"></path>
      <path fill-rule="evenodd" clip-rule="evenodd" d="M7.291 15.625A9.375 9.375 0 1116.666 25a9.375 9.375 0 01-9.375-9.375z" fill="url(#users-g_svg__paint1_linear_2218_19600)"></path>
      <path d="M29.166 37.5a8.333 8.333 0 00-8.333-8.333h-8.334A8.333 8.333 0 004.166 37.5v4.167h25V37.5z" fill="#76808F"></path>
      <defs>
        <linearGradient id="users-g_svg__paint0_linear_2218_19600" x1="36.458" y1="27.083" x2="36.458" y2="12.5" gradientUnits="userSpaceOnUse">
          <stop stop-color="#F0B90B"></stop>
          <stop offset="1" stop-color="#F8D33A"></stop>
        </linearGradient>
        <linearGradient id="users-g_svg__paint1_linear_2218_19600" x1="16.666" y1="25" x2="16.666" y2="6.25" gradientUnits="userSpaceOnUse">
          <stop stop-color="#F0B90B"></stop>
          <stop offset="1" stop-color="#F8D33A"></stop>
        </linearGradient>
      </defs>
    </svg>
    <div class="select-supp-a-div">
      <div class="select-supp-a-div-txt">Internships</div>
    </div>
  </a>
</div>
        </div>
    </section>
    
    
      <section class="bg-light-blue">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-8">
                     <div class="sec-title">
                            <span class="title">Welcome to Wealthmark</span>
                            <h2 class="heading-h2">Why Work Here</h2>
                        </div>
                        <div class="text">We are proud to offer competitive benefits that enable healthy and fulfilling careers at Wealthmark</div>
                </div>
            </div>
            <div class="select-supp">
  <div class="_div">
    <div class="why_work_block">
      <!--<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 90 90" fill="none" class="why_work_block-svg">-->
      <!--  <circle cx="45" cy="45" r="45" fill="#929AA5"></circle>-->
      <!--  <mask id="reason-1_svg__a" style="mask-type:alpha" maskUnits="userSpaceOnUse" x="0" y="0" width="90" height="90">-->
      <!--    <circle cx="45" cy="45" r="45" fill="#E6E8EA"></circle>-->
      <!--  </mask>-->
      <!--  <g mask="url(#reason-1_svg__a)">-->
      <!--    <path d="M95.56 8.648l-6.502 6.503 6.502 6.503 6.503-6.503-6.502-6.503zM13.93 48.494l-6.503 6.503L13.93 61.5l6.502-6.503-6.502-6.503z" fill="#F0B90B"></path>-->
      <!--    <path d="M73.297 23.072h-18.04l-3.972 14.03h25.147l-3.135-14.03z" fill="#fff"></path>-->
      <!--    <path d="M74.64 25.919c0-5.477-4.439-9.917-9.916-9.917-5.476 0-9.916 4.44-9.916 9.917h19.833z" fill="#fff"></path>-->
      <!--    <path d="M56.06 25.975a8.54 8.54 0 0017.08 0H56.06z" fill="#F0B90B"></path>-->
      <!--    <path d="M69.402 25.914l4.847-2.842 3.972 14.03H67.252l2.15-11.188z" fill="#fff"></path>-->
      <!--    <path fill-rule="evenodd" clip-rule="evenodd" d="M51.263 40.514l-8.934 8.933H23.967v10.5h18.362a10.5 10.5 0 007.425-3.075l8.933-8.933-7.424-7.425z" fill="#474D57"></path>-->
      <!--    <path d="M51.29 69.178v1.775c0 6.953 5.635 12.59 12.588 12.59V69.177H51.289z" fill="#484E58"></path>-->
      <!--    <path fill-rule="evenodd" clip-rule="evenodd" d="M60.951 64.328h13.866l29.84 29.84-9.281 9.281L69.38 77.453h-8.429V64.328z" fill="url(#reason-1_svg__paint0_linear_2218_19603)"></path>-->
      <!--    <path fill-rule="evenodd" clip-rule="evenodd" d="M51.012 69.393h13.125v45.054H51.012V69.393z" fill="url(#reason-1_svg__paint1_linear_2218_19603)"></path>-->
      <!--    <path fill-rule="evenodd" clip-rule="evenodd" d="M72.767 51.054h17.648c5.799 0 10.5-4.701 10.5-10.5V25.97h-10.5v14.584H72.767v10.5z" fill="#474D57"></path>-->
      <!--    <path fill-rule="evenodd" clip-rule="evenodd" d="M72.478 40.556l-4.917 4.917-4.917-4.917H51.112v28.902h28.902V40.556h-7.536z" fill="#474D57"></path>-->
      <!--  </g>-->
      <!--  <path d="M47.178 11.165l2.179 2.179-2.179 2.178L45 13.344l2.178-2.178zM9.365 33.826l1.939 1.94-1.94 1.938-1.938-1.939 1.939-1.939zM15.935 41.47l1.122 1.122-1.122 1.122-1.123-1.122 1.123-1.123z" fill="#AEB4BC"></path>-->
      <!--  <path d="M46.192 29.619c0-7.785-6.311-14.096-14.096-14.096S18 21.833 18 29.619c0 7.784 6.31 14.095 14.096 14.095 7.785 0 14.096-6.31 14.096-14.095z" fill="#F8D33A"></path>-->
      <!--  <path d="M42.742 29.618c0-5.878-4.766-10.644-10.645-10.644-5.878 0-10.644 4.766-10.644 10.644 0 5.88 4.766 10.645 10.644 10.645 5.88 0 10.645-4.766 10.645-10.645z" fill="url(#reason-1_svg__paint2_linear_2218_19603)"></path>-->
      <!--  <path d="M33.277 36.888v-1.62c2.293-.37 3.362-1.77 3.362-3.424 0-1.72-1.155-2.681-3.569-3.22v-2.8c.828.185 1.38.556 1.793 1.011l1.57-1.383c-.76-.843-1.776-1.366-3.156-1.518V22.35h-1.966v1.585c-2.224.253-3.413 1.434-3.413 3.205 0 1.636 1.051 2.749 3.638 3.272v3.036c-.966-.135-1.776-.59-2.431-1.265l-1.552 1.383c.862.928 2.017 1.619 3.758 1.77v1.553h1.966zm-3-9.817c0-.657.38-1.113 1.259-1.281v2.496c-.88-.236-1.259-.574-1.259-1.215zm3.983 4.96c0 .64-.38 1.163-1.19 1.382v-2.665c.983.287 1.19.793 1.19 1.282z" fill="#fff"></path>-->
      <!--  <defs>-->
      <!--    <linearGradient id="reason-1_svg__paint0_linear_2218_19603" x1="82.804" y1="64.328" x2="82.804" y2="103.449" gradientUnits="userSpaceOnUse">-->
      <!--      <stop offset="0.333" stop-color="#F0B90B"></stop>-->
      <!--      <stop offset="1" stop-color="#FBDA3C"></stop>-->
      <!--    </linearGradient>-->
      <!--    <linearGradient id="reason-1_svg__paint1_linear_2218_19603" x1="72.119" y1="77.375" x2="43.029" y2="106.465" gradientUnits="userSpaceOnUse">-->
      <!--      <stop offset="0.333" stop-color="#F0B90B"></stop>-->
      <!--      <stop offset="1" stop-color="#FBDA3C"></stop>-->
      <!--    </linearGradient>-->
      <!--    <linearGradient id="reason-1_svg__paint2_linear_2218_19603" x1="32.097" y1="40.263" x2="32.097" y2="18.974" gradientUnits="userSpaceOnUse">-->
      <!--      <stop stop-color="#F5BF00"></stop>-->
      <!--      <stop offset="1" stop-color="#F5BF00" stop-opacity="0"></stop>-->
      <!--    </linearGradient>-->
      <!--  </defs>-->
      <!--</svg>-->
        <img src="{{ asset('public/assets/img/competitive-salary.png') }}" class="why_work_block-svg">
    </div>
    <div class="why_work_block-list">Competitive salary</div>
    <div class="why_work_block-list">Option to be paid in crypto</div>
    <div class="why_work_block-list">Health insurance</div>
    <div class="why_work_block-list">Flexible working hours</div>
  </div>
  <div class="_div">
    <div class="why_work_block">
      <!--<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 90 90" fill="none" class="why_work_block-svg">-->
      <!--  <circle cx="45" cy="45" r="45" fill="#929AA5"></circle>-->
      <!--  <mask id="reason-2-g_svg__a" style="mask-type:alpha" maskUnits="userSpaceOnUse" x="0" y="0" width="90" height="90">-->
      <!--    <path d="M90 45c0 24.853-20.147 45-45 45S0 69.853 0 45 20.147 0 45 0s45 20.147 45 45z" fill="#E6E8EA"></path>-->
      <!--  </mask>-->
      <!--  <g mask="url(#reason-2-g_svg__a)">-->
      <!--    <path d="M41.63 69.706h69.78v38.16H41.63v-38.16z" fill="#F5F5F5"></path>-->
      <!--    <path d="M111.41 58.803H41.631v10.903h69.779V58.803z" fill="url(#reason-2-g_svg__paint0_linear_2218_19632)"></path>-->
      <!--    <path fill-rule="evenodd" clip-rule="evenodd" d="M58.219 65.867v-3.225h-3.22v3.225h3.22z" fill="#02C076"></path>-->
      <!--    <path fill-rule="evenodd" clip-rule="evenodd" d="M53.145 65.867v-3.225h-3.221v3.225h3.22z" fill="#F0B90B"></path>-->
      <!--    <path fill-rule="evenodd" clip-rule="evenodd" d="M48.072 65.867v-3.225h-3.22v3.225h3.22z" fill="#F84960"></path>-->
      <!--    <path fill-rule="evenodd" clip-rule="evenodd" d="M108.189 62.642v3.225H61.441v-3.225h46.748z" fill="#F5F5F5"></path>-->
      <!--    <path fill-rule="evenodd" clip-rule="evenodd" d="M44.852 77.513v-3.225h63.337v3.225H44.852z" fill="url(#reason-2-g_svg__paint1_linear_2218_19632)"></path>-->
      <!--    <path fill-rule="evenodd" clip-rule="evenodd" d="M44.852 90.399v-3.226h63.337V90.4H44.852z" fill="url(#reason-2-g_svg__paint2_linear_2218_19632)"></path>-->
      <!--    <path fill-rule="evenodd" clip-rule="evenodd" d="M44.852 83.956V80.73h63.337v3.225H44.852z" fill="url(#reason-2-g_svg__paint3_linear_2218_19632)"></path>-->
      <!--    <path fill-rule="evenodd" clip-rule="evenodd" d="M43.56 38.352h-5.984a6.441 6.441 0 01-4.554-1.886l-7.26-7.26 4.25-4.251 7.26 7.26c.081.08.19.125.304.125h5.985v6.012z" fill="#F0B90B"></path>-->
      <!--    <path fill-rule="evenodd" clip-rule="evenodd" d="M42.916 32.18h8.803v6.87h-8.803v-6.87z" fill="url(#reason-2-g_svg__paint4_linear_2218_19632)"></path>-->
      <!--    <path fill-rule="evenodd" clip-rule="evenodd" d="M49.788 59.66H37.601l-.051 11.244-6.012-.028.05-11.243a6.012 6.012 0 016.013-5.984h12.187v6.012z" fill="#E6AF0A"></path>-->
      <!--    <path fill-rule="evenodd" clip-rule="evenodd" d="M39.052 51.073h10.735v8.588H39.052v-8.588z" fill="#AEB4BC"></path>-->
      <!--    <path d="M37.336 70.826h-6.012l-3.006 3.006-3.006 3.006h12.024v-6.012z" fill="#F5F5F5"></path>-->
      <!--    <path fill-rule="evenodd" clip-rule="evenodd" d="M49.284 59.608h-7.193a.43.43 0 00-.43.43v10.799h-6.01l-.001-10.8a6.441 6.441 0 016.441-6.441h7.193v6.012z" fill="#F0B90B"></path>-->
      <!--    <path d="M48.797 18.521a5.582 5.582 0 107.895 7.895l-7.895-7.895z" fill="#F0B90B"></path>-->
      <!--    <path d="M48.797 18.52a5.582 5.582 0 017.894 7.895l-7.894-7.895z" fill="#fff"></path>-->
      <!--    <circle cx="60.944" cy="22.888" r="2.791" transform="rotate(-90 60.944 22.888)" fill="#fff"></circle>-->
      <!--    <path fill-rule="evenodd" clip-rule="evenodd" d="M57.518 51.073v.86a7.73 7.73 0 01-7.73 7.728h-7.085v-8.588h14.815z" fill="#AEB4BC"></path>-->
      <!--    <path d="M41.629 70.826h-6.012l-3.006 3.006-3.006 3.006H41.63v-6.012z" fill="#fff"></path>-->
      <!--    <path fill="#F0B90B" d="M26.17 18.438v6.012h-6.012v-6.012z"></path>-->
      <!--    <path fill-rule="evenodd" clip-rule="evenodd" d="M58.805 35.615v15.458h-14.17V39.05l6.87-6.87h3.865l3.435 3.435z" fill="#474D57"></path>-->
      <!--    <path fill="#F0B90B" d="M69.968 53.65v6.012h-6.012V53.65z"></path>-->
      <!--    <path fill-rule="evenodd" clip-rule="evenodd" d="M63.957 51.18v-4.91a.429.429 0 00-.126-.304l-3.288-3.288 4.251-4.251 3.288 3.288a6.441 6.441 0 011.887 4.554v4.911h-6.012z" fill="#F0B90B"></path>-->
      <!--    <path fill-rule="evenodd" clip-rule="evenodd" d="M53.865 32.179h3.086a6.87 6.87 0 014.858 2.012l3.718 3.718-4.858 4.858-3.718-3.718h-3.086v-6.87z" fill="url(#reason-2-g_svg__paint5_linear_2218_19632)"></path>-->
      <!--  </g>-->
      <!--  <path d="M22.542 40.644l2.178 2.178L22.542 45l-2.179-2.178 2.179-2.178zM36.039 11.406l1.939 1.94-1.94 1.938-1.938-1.939 1.939-1.939zM13.95 33.764l1.123 1.122-1.123 1.123-1.122-1.123 1.123-1.122z" fill="#AEB4BC"></path>-->
      <!--  <defs>-->
      <!--    <linearGradient id="reason-2-g_svg__paint0_linear_2218_19632" x1="41.631" y1="69.692" x2="110.521" y2="69.692" gradientUnits="userSpaceOnUse">-->
      <!--      <stop stop-color="#5E6673"></stop>-->
      <!--      <stop offset="1" stop-color="#76808F"></stop>-->
      <!--    </linearGradient>-->
      <!--    <linearGradient id="reason-2-g_svg__paint1_linear_2218_19632" x1="44.91" y1="77.701" x2="97.127" y2="77.69" gradientUnits="userSpaceOnUse">-->
      <!--      <stop offset="0.589" stop-color="#76808F"></stop>-->
      <!--      <stop offset="1" stop-color="#AEB4BC"></stop>-->
      <!--    </linearGradient>-->
      <!--    <linearGradient id="reason-2-g_svg__paint2_linear_2218_19632" x1="44.91" y1="90.586" x2="97.127" y2="90.575" gradientUnits="userSpaceOnUse">-->
      <!--      <stop offset="0.589" stop-color="#76808F"></stop>-->
      <!--      <stop offset="1" stop-color="#AEB4BC"></stop>-->
      <!--    </linearGradient>-->
      <!--    <linearGradient id="reason-2-g_svg__paint3_linear_2218_19632" x1="44.91" y1="84.14" x2="96.977" y2="84.14" gradientUnits="userSpaceOnUse">-->
      <!--      <stop stop-color="#76808F"></stop>-->
      <!--      <stop offset="1" stop-color="#AEB4BC"></stop>-->
      <!--    </linearGradient>-->
      <!--    <linearGradient id="reason-2-g_svg__paint4_linear_2218_19632" x1="42.916" y1="35.614" x2="57.194" y2="35.614" gradientUnits="userSpaceOnUse">-->
      <!--      <stop stop-color="#474D57"></stop>-->
      <!--      <stop offset="1" stop-color="#2B2F36"></stop>-->
      <!--    </linearGradient>-->
      <!--    <linearGradient id="reason-2-g_svg__paint5_linear_2218_19632" x1="60.736" y1="35.614" x2="66.318" y2="47.853" gradientUnits="userSpaceOnUse">-->
      <!--      <stop stop-color="#474D57"></stop>-->
      <!--      <stop offset="1" stop-color="#2B2F36"></stop>-->
      <!--    </linearGradient>-->
      <!--  </defs>-->
      <!--</svg>-->
        <img src="{{ asset('public/assets/img/remote-work.png') }}" class="why_work_block-svg">
    </div>
    <div class="why_work_block-list">Remote work for many roles</div>
    <div class="why_work_block-list">Company sponsored holidays</div>
    <div class="why_work_block-list">Team building activities</div>
    <div class="why_work_block-list">And other various perks and benefits</div>
  </div>
  <div class="_div">
    <div class="why_work_block">
      <!--<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 90 90" fill="none" class="why_work_block-svg">-->
      <!--  <circle cx="45" cy="45" r="45" fill="#929AA5"></circle>-->
      <!--  <mask id="reason-3-g_svg__a" style="mask-type:alpha" maskUnits="userSpaceOnUse" x="0" y="0" width="90" height="90">-->
      <!--    <path d="M90 45c0 24.853-20.147 45-45 45S0 69.853 0 45 20.147 0 45 0s45 20.147 45 45z" fill="#FCEA9C"></path>-->
      <!--  </mask>-->
      <!--  <g mask="url(#reason-3-g_svg__a)">-->
      <!--    <path fill-rule="evenodd" clip-rule="evenodd" d="M25.569 59.435v-9.42H15.29v10.09c0 5.325 4.328 9.608 9.625 9.608h17.782V59.435h-17.13z" fill="#474D57"></path>-->
      <!--    <path d="M50.402 59.436l5.995 5.995 5.995-5.995H72.67v60.508H42.693V59.436h7.709z" fill="url(#reason-3-g_svg__paint0_linear_2218_19670)"></path>-->
      <!--    <path fill-rule="evenodd" clip-rule="evenodd" d="M85.958 69.714H72.67V59.436h14.115c8.851 0 13.284 10.702 7.025 16.96l-8.085 8.086-7.268-7.268 7.5-7.5z" fill="url(#reason-3-g_svg__paint1_linear_2218_19670)"></path>-->
      <!--    <path d="M77.805 96.264h-5.14l.001-10.277h5.139v10.277z" fill="#F0B90B"></path>-->
      <!--    <path d="M61.926 70.464l3.779-3.779 3.78 3.78-3.78 3.778-3.78-3.779z" fill="url(#reason-3-g_svg__paint2_linear_2218_19670)"></path>-->
      <!--    <path d="M66.673 59.436H62.39l-5.995 5.995-5.995-5.995h-4.283l10.278 10.278 10.278-10.278z" fill="url(#reason-3-g_svg__paint3_linear_2218_19670)"></path>-->
      <!--    <path d="M25.568 50.015v-3.426H15.291v3.426h10.277z" fill="url(#reason-3-g_svg__paint4_linear_2218_19670)"></path>-->
      <!--    <path d="M78.463 77.216l-2.422 2.422 7.265 7.265 2.422-2.422-7.264-7.265z" fill="url(#reason-3-g_svg__paint5_linear_2218_19670)"></path>-->
      <!--    <path d="M50.23 39.102A8.993 8.993 0 1062.948 51.82L50.23 39.102z" fill="#F0B90B"></path>-->
      <!--    <path d="M53.408 27.746l20.894 20.893-1.363 1.363-20.893-20.894 1.362-1.362z" fill="#2B2F36"></path>-->
      <!--    <path d="M56.591 36.467a8.965 8.965 0 00-6.359 2.634L62.95 51.819a8.965 8.965 0 002.634-6.36v-2.816l-6.176-6.176H56.59z" fill="url(#reason-3-g_svg__paint6_linear_2218_19670)"></path>-->
      <!--    <path d="M66.585 48.185h2.725v2.725h-2.725v-2.725z" fill="#2B2F36"></path>-->
      <!--    <path d="M28.125 41.45h6.852v5.995l-3.426-3.426-3.426 3.426V41.45zM20.422 17.468h20.555V41.45H20.422V17.468z" fill="#474D57"></path>-->
      <!--    <path d="M38.408 41.45H20.422V17.468h17.986V41.45z" fill="#5E6673"></path>-->
      <!--    <path d="M40.977 39.737h-2.57V19.18h2.57v20.556z" fill="#fff"></path>-->
      <!--    <path d="M40.977 17.468h1.713V41.45h-1.713V17.468zM19.564 17.468h3.426V41.45h-3.425V17.468z" fill="#474D57"></path>-->
      <!--    <path d="M21.285 44.019h-5.139V33.741h5.14l-.001 10.278z" fill="#F0B90B"></path>-->
      <!--  </g>-->
      <!--  <path d="M39.452 49.772l2.178 2.178-2.178 2.179-2.179-2.179 2.179-2.178zM50.029 12.81l1.939 1.94-1.94 1.939-1.938-1.94 1.939-1.939zM9.017 37.773l1.122 1.122-1.122 1.123-1.122-1.123 1.122-1.122z" fill="#AEB4BC"></path>-->
      <!--  <defs>-->
      <!--    <linearGradient id="reason-3-g_svg__paint0_linear_2218_19670" x1="72.67" y1="119.944" x2="42.693" y2="119.944" gradientUnits="userSpaceOnUse">-->
      <!--      <stop stop-color="#2B2F36"></stop>-->
      <!--      <stop offset="1" stop-color="#474D57"></stop>-->
      <!--    </linearGradient>-->
      <!--    <linearGradient id="reason-3-g_svg__paint1_linear_2218_19670" x1="72.67" y1="69.584" x2="92.776" y2="96.825" gradientUnits="userSpaceOnUse">-->
      <!--      <stop stop-color="#2B2F36"></stop>-->
      <!--      <stop offset="1" stop-color="#474D57"></stop>-->
      <!--    </linearGradient>-->
      <!--    <linearGradient id="reason-3-g_svg__paint2_linear_2218_19670" x1="65.705" y1="66.685" x2="65.705" y2="74.243" gradientUnits="userSpaceOnUse">-->
      <!--      <stop stop-color="#F0B90B"></stop>-->
      <!--      <stop offset="1" stop-color="#F8D33A"></stop>-->
      <!--    </linearGradient>-->
      <!--    <linearGradient id="reason-3-g_svg__paint3_linear_2218_19670" x1="56.395" y1="59.436" x2="56.395" y2="69.714" gradientUnits="userSpaceOnUse">-->
      <!--      <stop stop-color="#F0B90B"></stop>-->
      <!--      <stop offset="1" stop-color="#F8D33A"></stop>-->
      <!--    </linearGradient>-->
      <!--    <linearGradient id="reason-3-g_svg__paint4_linear_2218_19670" x1="25.568" y1="48.302" x2="15.291" y2="48.302" gradientUnits="userSpaceOnUse">-->
      <!--      <stop stop-color="#F0B90B"></stop>-->
      <!--      <stop offset="1" stop-color="#F8D33A"></stop>-->
      <!--    </linearGradient>-->
      <!--    <linearGradient id="reason-3-g_svg__paint5_linear_2218_19670" x1="77.252" y1="78.427" x2="84.517" y2="85.692" gradientUnits="userSpaceOnUse">-->
      <!--      <stop stop-color="#F0B90B"></stop>-->
      <!--      <stop offset="1" stop-color="#F8D33A"></stop>-->
      <!--    </linearGradient>-->
      <!--    <linearGradient id="reason-3-g_svg__paint6_linear_2218_19670" x1="50.232" y1="36.467" x2="50.232" y2="51.819" gradientUnits="userSpaceOnUse">-->
      <!--      <stop stop-color="#2B2F36"></stop>-->
      <!--      <stop offset="1" stop-color="#474D57"></stop>-->
      <!--    </linearGradient>-->
      <!--  </defs>-->
      <!--</svg>-->
       <img src="{{ asset('public/assets/img/learning-development.png') }}" class="why_work_block-svg">
    </div>
    <div class="why_work_block-list">Learning and development programs</div>
    <div class="why_work_block-list">Free language classes</div>
    <div class="why_work_block-list">Relocation support</div>
    <div class="why_work_block-list">International transfers mid-career</div>
  </div>
</div>
        </div>
    </section>
    
    <section class="hiring">
        <div class="container">
              <div class="row align-items-center">
                <div class="col-md-8">
                     <div class="sec-title">
                            <span class="title">Welcome to Wealthmark</span>
                            <h2 class="heading-h2">How We Hire</h2>
                        </div>
                        <div class="text">On average 2~4 week interview process with 4 interviews.</div>
                </div>
            </div>
            <div class="row">
                <div class="select-supp">
                      <div class="hiring_block">
                        <div class="hiring_block-txt">Application Review</div>
                        <div class="hiring_block-num">0
                          <!-- -->1
                        </div>
                        <div class="hiring_block-line"></div>
                      </div>
                      <div class="hiring_block">
                        <div class="hiring_block-txt">Interviews</div>
                        <div class="hiring_block-num">0
                          <!-- -->2
                        </div>
                        <div class="hiring_block-line"></div>
                      </div>
                      <div class="hiring_block">
                        <div class="hiring_block-txt">Offer</div>
                        <div class="hiring_block-num">0
                          <!-- -->3
                        </div>
                        <div class="hiring_block-line"></div>
                      </div>
                      <div class="hiring_block">
                        <div class="hiring_block-txt">Onboarding</div>
                        <div class="hiring_block-num">0
                          <!-- -->4
                        </div>
                        <div class="hiring_block-line"></div>
                      </div>
                    </div>
            </div>
        </div>
      
    </section>
    
  @include('template.country_language')
    @include('template.web_footer') 
    
    
    <script>
        $(document).ready(function($) {
    //Check if an element was in a screen
    function isScrolledIntoView(elem){
        var docViewTop = $(window).scrollTop();
        var docViewBottom = docViewTop + $(window).height();
        var elemTop = $(elem).offset().top;
        var elemBottom = elemTop + $(elem).height();
        return ((elemBottom <= docViewBottom));
    }
    //Count up code
    function countUp() {
        $('.counter').each(function() {
          var $this = $(this), // <- Don't touch this variable. It's pure magic.
              countTo = $this.attr('data-count');
              ended = $this.attr('ended');

        if ( ended != "true" && isScrolledIntoView($this) ) {
            $({ countNum: $this.text()}).animate({
            countNum: countTo
          },
          {
            duration: 2500, //duration of counting
            easing: 'swing',
            step: function() {
              $this.text(Math.floor(this.countNum));
            },
            complete: function() {
              $this.text(this.countNum);
            }
          });
        $this.attr('ended', 'true');
        }
        });
    }
    //Start animation on page-load
    if ( isScrolledIntoView(".counter") ) {
        countUp();
    }
    //Start animation on screen
    $(document).scroll(function() {
        if ( isScrolledIntoView(".counter") ) {
            countUp();
        }
    });
});
    </script>
  
  
    </body>
</html>