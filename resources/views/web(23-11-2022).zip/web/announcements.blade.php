<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <title>Wealth Mark | {{ Request::segment(2) }}</title>
    @include('template.web_css')
    <link rel='stylesheet' href="{{('../public/assets/css/deepak_custom.css') }}">
    <link rel='stylesheet' href="{{('../public/assets/css/style_main.css') }}">
</head>

<body>
    @include('template.mobile_menu')
    @include('template.web_menu')

    <section class="announcements-search-block pb-0" id="announcements-search-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <div class="sec-title text-left">
                        <span class="title">Know About</span>
                        <h2 class="heading-h2">Announcement What are you <span class="yellow-text">looking for?</span>
                        </h2>
                    </div>
                </div>
                <div class="col-md-12 col-lg-12 col-xs-12 col-sm-12" id="search-box-announcement">
                    <div class="input-group mb-3">
                        <input type="text" class="form-control" placeholder="Type here and search announcements"
                            aria-label="Announcements" aria-describedby="basic-addon2">
                        <div class="input-group-append">
                            <span class="input-group-text" id="basic-addon2">Search</span>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>

    <section class="announcements-listing-block pt-0" id="announcements-listing-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <div class="sec-title text-left">
                        <span class="title">Know About</span>
                        <h2 class="heading-h2">All Topics</h2>
                    </div>
                </div>
            </div>
            <div class="row mb-4">
                <div class="col-md-4 col-lg-4 col-sm-6">
                    <div class="flip-box listing-topic-box">
                        <div class="flip-box-inner">
                            <div class="flip-box-front">
                                <img src="{{ asset('public/assets/img/listing-icon-1.png') }}" class="img-fluid"
                                    alt="gift Card Image">
                                <h4>New Cryptocurrency Listing </h4>
                                <p>Check out the latest coin listings and pairs on Launchpad, Launchpool, Spot, Margin,
                                    and Futures markets.<a class="text-warning">Read More </a> </p>
                            </div>
                            <div class="flip-box-back">
                                <p><span class="text-uppercase title">Wealthmark</span> is a leading player in the
                                    Crypto ecosystem; Since its inception it has risen to provide its users with an
                                    ostentatious </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-lg-4 col-sm-6">
                    <div class="flip-box listing-topic-box">
                        <div class="flip-box-inner">
                            <div class="flip-box-front">
                                <img src="{{ asset('public/assets/img/listing-icon-2.png') }}" class="img-fluid"
                                    alt="gift Card Image">
                                <h4>Latest Wealth Mark News</h4>
                                <p>Check out the latest coin listings and pairs on Launchpad, Launchpool, Spot, Margin,
                                    and Futures markets.<a class="text-warning">Read More </a> </p>
                            </div>
                            <div class="flip-box-back">
                                <p><span class="text-uppercase title">Wealthmark</span> is a leading player in the
                                    Crypto ecosystem; Since its inception it has risen to provide its users with an
                                    ostentatious </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-lg-4 col-sm-6">
                    <div class="flip-box listing-topic-box">
                        <div class="flip-box-inner">
                            <div class="flip-box-front">
                                <img src="{{ asset('public/assets/img/listing-icon-3.png') }}" class="img-fluid"
                                    alt="gift Card Image">
                                <h4>Latest Activities</h4>
                                <p>Check out the latest coin listings and pairs on Launchpad, Launchpool, Spot, Margin,
                                    and Futures markets.<a class="text-warning">Read More </a> </p>
                            </div>
                            <div class="flip-box-back">
                                <p><span class="text-uppercase title">Wealthmark</span> is a leading player in the
                                    Crypto ecosystem; Since its inception it has risen to provide its users with an
                                    ostentatious </p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-4 col-lg-4 col-sm-6">
                    <div class="flip-box listing-topic-box">
                        <div class="flip-box-inner">
                            <div class="flip-box-front">
                                <img src="{{ asset('public/assets/img/listing-icon-4.png') }}" class="img-fluid"
                                    alt="gift Card Image">
                                <h4>New Fiat Listings</h4>
                                <p>Check out the latest coin listings and pairs on Launchpad, Launchpool, Spot, Margin,
                                    and Futures markets.<a class="text-warning">Read More </a> </p>
                            </div>
                            <div class="flip-box-back">
                                <p><span class="text-uppercase title">Wealthmark</span> is a leading player in the
                                    Crypto ecosystem; Since its inception it has risen to provide its users with an
                                    ostentatious </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-lg-4 col-sm-6">
                    <div class="flip-box listing-topic-box">
                        <div class="flip-box-inner">
                            <div class="flip-box-front">
                                <img src="{{ asset('public/assets/img/listing-icon-5.png') }}" class="img-fluid"
                                    alt="gift Card Image">
                                <h4>API Updates</h4>
                                <p>Check out the latest coin listings and pairs on Launchpad, Launchpool, Spot, Margin,
                                    and Futures markets.<a class="text-warning">Read More </a> </p>
                            </div>
                            <div class="flip-box-back">
                                <p><span class="text-uppercase title">Wealthmark</span> is a leading player in the
                                    Crypto ecosystem; Since its inception it has risen to provide its users with an
                                    ostentatious </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-lg-4 col-sm-6">
                    <div class="flip-box listing-topic-box">
                        <div class="flip-box-inner">
                            <div class="flip-box-front">
                                <img src="{{ asset('public/assets/img/listing-icon-6.png') }}" class="img-fluid"
                                    alt="gift Card Image">
                                <h4>Crypto Airdrop</h4>
                                <p>Check out the latest coin listings and pairs on Launchpad, Launchpool, Spot, Margin,
                                    and Futures markets.<a class="text-warning">Read More </a> </p>
                            </div>
                            <div class="flip-box-back">
                                <p><span class="text-uppercase title">Wealthmark</span> is a leading player in the
                                    Crypto ecosystem; Since its inception it has risen to provide its users with an
                                    ostentatious </p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-4 col-lg-4 col-sm-6">
                    <div class="flip-box listing-topic-box">
                        <div class="flip-box-inner">
                            <div class="flip-box-front">
                                <img src="{{ asset('public/assets/img/listing-icon-7.png') }}" class="img-fluid"
                                    alt="gift Card Image">
                                <h4>Wallet Maintenance Updates</h4>
                                <p>Check out the latest coin listings and pairs on Launchpad, Launchpool, Spot, Margin,
                                    and Futures markets.<a class="text-warning">Read More </a> </p>
                            </div>
                            <div class="flip-box-back">
                                <p><span class="text-uppercase title">Wealthmark</span> is a leading player in the
                                    Crypto ecosystem; Since its inception it has risen to provide its users with an
                                    ostentatious </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-lg-4 col-sm-6">
                    <div class="flip-box listing-topic-box">
                        <div class="flip-box-inner">
                            <div class="flip-box-front">
                                <img src="{{ asset('public/assets/img/listing-icon-8.png') }}" class="img-fluid"
                                    alt="gift Card Image">
                                <h4>Delisting</h4>
                                <p>Check out the latest coin listings and pairs on Launchpad, Launchpool, Spot, Margin,
                                    and Futures markets.<a class="text-warning">Read More </a> </p>
                            </div>
                            <div class="flip-box-back">
                                <p><span class="text-uppercase title">Wealthmark</span> is a leading player in the
                                    Crypto ecosystem; Since its inception it has risen to provide its users with an
                                    ostentatious </p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-4 col-lg-4 col-sm-6">
                    <div class="flip-box listing-topic-box">
                        <div class="flip-box-inner">
                            <div class="flip-box-front">
                                <img src="{{ asset('public/assets/img/listing-icon-4.png') }}" class="img-fluid"
                                    alt="gift Card Image">
                                <h4>Coming Soon</h4>
                                <p>Check out the latest coin listings and pairs on Launchpad, Launchpool, Spot, Margin,
                                    and Futures markets.<a class="text-warning">Read More </a> </p>
                            </div>
                            <div class="flip-box-back">
                                <p><span class="text-uppercase title">Wealthmark</span> is a leading player in the
                                    Crypto ecosystem; Since its inception it has risen to provide its users with an
                                    ostentatious </p>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

        </div>
    </section>

    <section class="announcements-article-block pb-0" id="announcements-article-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <div class="sec-title text-left">
                        <span class="title">Know About</span>
                        <h2 class="heading-h2">Latest<span class="yellow-text">Articles</span></h2>
                    </div>
                </div>

            </div>
            <div class="row">
                <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12">
                    <div class="latest-article-box">
                        <div class="alert alert-warning" role="alert">
                            <h4 class="alert-heading">Article 1</h4>
                            <p>Updates on Tick Size for Spot Trading Pairs <strong class="alert-heading">(2022-11-08)</strong></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12">
                    <div class="latest-article-box">
                        <div class="alert alert-warning" role="alert">
                            <h4 class="alert-heading">Article 2</h4>
                            <p>Wealth Mark Loans Adds OSMO as Borrowable Asset and Collateral Asset <strong>2022-11-01</strong></p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12">
                    <div class="latest-article-box">
                        <div class="alert alert-warning" role="alert">
                            <h4 class="alert-heading">Article 3</h4>
                            <p>Get 10% Cashback on Your First Travala.com Hotel Wealth Mark Card <strong class="alert-heading">2022-11-01</strong></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12">
                    <div class="latest-article-box">
                        <div class="alert alert-warning" role="alert">
                            <h4 class="alert-heading">Article 4</h4>
                            <p>Learn About Dual Investment & Complete a Quiz to Receive Duan<strong class="alert-heading">2022-10-31<strong></p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12">
                    <div class="latest-article-box">
                        <div class="alert alert-warning" role="alert">
                            <h4 class="alert-heading">Article 5</h4>
                            <p>Introducing Hashflow (HFT) on Wealth Mark Launchpool! HFT and BUSD <strong class="alert-heading">2022-10-31</strong></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12">
                    <div class="latest-article-box">
                        <div class="alert alert-warning" role="alert">
                            <h4 class="alert-heading">Article 6</h4>
                            <p>Wealth Mark Loans Adds OSMO as Borrowable Asset and Collateral Asset <strong class="alert-heading">2022-11-01</strong></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    @include('template.country_language')
    @include('template.web_footer')
</body>

</html>