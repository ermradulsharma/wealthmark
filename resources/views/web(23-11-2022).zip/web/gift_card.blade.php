<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <title>Wealth Mark | {{ Request::segment(2) }}</title>
    @include('template.web_css')
    <link rel='stylesheet' href="{{('../public/assets/css/deepak_custom.css') }}">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script>
    $(document).ready(function() {

        $(".next-slide").click(function() {
            $("#banner-one").hide(1000);
            $(".next-slide-2").show(1000);
            $("#banner-two").show(1000);
            $(".next-slide").addClass("next-slide-2");
        });
        $(".next-slide-2").click(function() {
            $(".next-slide-2").removeClass(".next-slide-2");
            $(".next-slide-2").addClass("next-slide-3");
            $("#banner-two").hide(1000);
            $("#banner-three").show(1000);
        });

        $(".next-slide-3").click(function() {
            $(".next-slide-3").removeClass(".next-slide-3");
            $(".next-slide-3").addClass("next-slide-4");
            $("#banner-one").show(1000);
            $("#banner-two").hide(1000);
            $("#banner-three").hide(1000);
        });
    });
    </script>



</head>

<body>
    @include('template.mobile_menu')
    @include('template.web_menu')

    <!-- gift banner section  start-->
    <section class="gift-banner-section" id="gift-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">

                    <!-- Carousel -->
                    <div id="demo" class="carousel slide" data-bs-ride="carousel">

                        <!-- Indicators/dots -->
                        <div class="carousel-indicators">
                            <button type="button" data-bs-target="#demo" data-bs-slide-to="0" class="active"></button>
                            <button type="button" data-bs-target="#demo" data-bs-slide-to="1"></button>
                            <button type="button" data-bs-target="#demo" data-bs-slide-to="2"></button>
                        </div>

                        <!-- The slideshow/carousel -->
                        <div class="carousel-inner">
                            <div class="carousel-item active">
                                <div class="row">


                                    <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12 order-2 order-lg-1">
                                        <div class="blogs-inner-box-slider gift-card-tab-box">
                                            <div class="left-content-block">
                                                <h1>Transfer Crypto <br />with Wealth Mark Gift Card </h1>
                                                <span>Send and receive crypto at zero fees </span><br />
                                                <a href="#" class="btn btn-yellow shadow mt-3"> Transfer Crypto &#x2192; </a>
                                            </div>
                                            <div class="gift-tabing-section mt-5">
                                                <ul class="nav nav-pills" id="pills-tab" role="tablist">
                                                    <li class="nav-item" role="presentation">
                                                        <button class="nav-link active" id="pills-home-tab"
                                                            data-bs-toggle="pill" data-bs-target="#pills-home"
                                                            type="button" role="tab" aria-controls="pills-home"
                                                            aria-selected="true">Redeem</button>
                                                    </li>
                                                    <li class="nav-item" role="presentation">
                                                        <button class="nav-link" id="pills-profile-tab"
                                                            data-bs-toggle="pill" data-bs-target="#pills-profile"
                                                            type="button" role="tab" aria-controls="pills-profile"
                                                            aria-selected="false">Add Card</button>
                                                    </li>
                                                    <li class="nav-item" role="presentation">
                                                        <button class="nav-link" id="pills-contact-tab"
                                                            data-bs-toggle="pill" data-bs-target="#pills-contact"
                                                            type="button" role="tab" aria-controls="pills-contact"
                                                            aria-selected="false">Check Card</button>
                                                    </li>
                                                </ul>
                                                <div class="tab-content" id="pills-tabContent">
                                                    <div class="tab-pane fade show active" id="pills-home"
                                                        role="tabpanel" aria-labelledby="pills-home-tab">
                                                        <div class="input-group mb-3">
                                                            <input type="text" class="form-control"
                                                                placeholder="16 characters in digits and letters"
                                                                aria-label="Recipient's username"
                                                                aria-describedby="basic-addon2">
                                                            <a href="#" class="input-group-text"
                                                                id="basic-addon2">Redeem</a>
                                                        </div>
                                                        <p>Wealth Mark is not responsible for, and assumes no liability
                                                            to you for, any
                                                            unlawful
                                                            conduct or fraud by any third party associated with any Gift
                                                            Card. <a href="#" class="text-warning"> View more </a></p>
                                                    </div>
                                                    <div class="tab-pane fade" id="pills-profile" role="tabpanel"
                                                        aria-labelledby="pills-profile-tab">
                                                        <div class="input-group mb-3">
                                                            <input type="text" class="form-control"
                                                                placeholder="16 characters in digits and letters"
                                                                aria-label="Recipient's username"
                                                                aria-describedby="basic-addon2">
                                                            <a href="#" class="input-group-text" id="basic-addon2">Add
                                                                Card</a>
                                                        </div>
                                                        <p>Wealth Mark is not responsible for, and assumes no liability
                                                            to you for, any
                                                            unlawful
                                                            conduct or fraud by any third party associated with any Gift
                                                            Card. <a href="#" class="text-warning"> View more </a></p>
                                                    </div>
                                                    <div class="tab-pane fade" id="pills-contact" role="tabpanel"
                                                        aria-labelledby="pills-contact-tab">
                                                        <div class="input-group mb-3">
                                                            <input type="text" class="form-control"
                                                                placeholder="16 characters in digits and letters"
                                                                aria-label="Recipient's username"
                                                                aria-describedby="basic-addon2">
                                                            <a href="#" class="input-group-text" id="basic-addon2">Check
                                                                Card</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12 order-1 order-lg-2">
                                        <div class="blogs-inner-box-slider">
                                            <img src="{{ asset('public/assets/img/gift-banner3.png') }}"
                                                class="img-fluid" alt="walth mark blog">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="carousel-item">
                                <div class="row">


                                    <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12 order-2 order-lg-1">
                                        <div class="blogs-inner-box-slider gift-card-tab-box">
                                            <div class="left-content-block">
                                                <h1>Transfer Crypto <br />with Wealth Mark Gift Card </h1>
                                                <span>Send and receive crypto at zero fees </span><br />
                                                <a href="#" class="btn btn-yellow shadow mt-3"> Transfer Crypto &#x2192; </a>
                                            </div>
                                            <div class="gift-tabing-section mt-5">
                                                <ul class="nav nav-pills" id="pills-tab" role="tablist">
                                                    <li class="nav-item" role="presentation">
                                                        <button class="nav-link active" id="pills-home-tab"
                                                            data-bs-toggle="pill" data-bs-target="#pills-home"
                                                            type="button" role="tab" aria-controls="pills-home"
                                                            aria-selected="true">Redeem</button>
                                                    </li>
                                                    <li class="nav-item" role="presentation">
                                                        <button class="nav-link" id="pills-profile-tab"
                                                            data-bs-toggle="pill" data-bs-target="#pills-profile"
                                                            type="button" role="tab" aria-controls="pills-profile"
                                                            aria-selected="false">Add Card</button>
                                                    </li>
                                                    <li class="nav-item" role="presentation">
                                                        <button class="nav-link" id="pills-contact-tab"
                                                            data-bs-toggle="pill" data-bs-target="#pills-contact"
                                                            type="button" role="tab" aria-controls="pills-contact"
                                                            aria-selected="false">Check Card</button>
                                                    </li>
                                                </ul>
                                                <div class="tab-content" id="pills-tabContent">
                                                    <div class="tab-pane fade show active" id="pills-home"
                                                        role="tabpanel" aria-labelledby="pills-home-tab">
                                                        <div class="input-group mb-3">
                                                            <input type="text" class="form-control"
                                                                placeholder="16 characters in digits and letters"
                                                                aria-label="Recipient's username"
                                                                aria-describedby="basic-addon2">
                                                            <a href="#" class="input-group-text"
                                                                id="basic-addon2">Redeem</a>
                                                        </div>
                                                        <p>Wealth Mark is not responsible for, and assumes no liability
                                                            to you for, any
                                                            unlawful
                                                            conduct or fraud by any third party associated with any Gift
                                                            Card. <a href="#" class="text-warning"> View more </a></p>
                                                    </div>
                                                    <div class="tab-pane fade" id="pills-profile" role="tabpanel"
                                                        aria-labelledby="pills-profile-tab">
                                                        <div class="input-group mb-3">
                                                            <input type="text" class="form-control"
                                                                placeholder="16 characters in digits and letters"
                                                                aria-label="Recipient's username"
                                                                aria-describedby="basic-addon2">
                                                            <a href="#" class="input-group-text" id="basic-addon2">Add
                                                                Card</a>
                                                        </div>
                                                        <p>Wealth Mark is not responsible for, and assumes no liability
                                                            to you for, any
                                                            unlawful
                                                            conduct or fraud by any third party associated with any Gift
                                                            Card. <a href="#" class="text-warning"> View more </a></p>
                                                    </div>
                                                    <div class="tab-pane fade" id="pills-contact" role="tabpanel"
                                                        aria-labelledby="pills-contact-tab">
                                                        <div class="input-group mb-3">
                                                            <input type="text" class="form-control"
                                                                placeholder="16 characters in digits and letters"
                                                                aria-label="Recipient's username"
                                                                aria-describedby="basic-addon2">
                                                            <a href="#" class="input-group-text" id="basic-addon2">Check
                                                                Card</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12 order-1 order-lg-2">
                                        <div class="blogs-inner-box-slider">
                                            <img src="{{ asset('public/assets/img/gift-banner3.png') }}"
                                                class="img-fluid" alt="walth mark blog">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <div class="row">


                                    <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12 order-2 order-lg-1">
                                        <div class="blogs-inner-box-slider gift-card-tab-box">
                                            <div class="left-content-block">
                                                <h1>Transfer Crypto <br />with Wealth Mark Gift Card </h1>
                                                <span>Send and receive crypto at zero fees </span><br />
                                                <a href="#" class="btn btn-yellow shadow mt-3"> Transfer Crypto &#x2192; </a>
                                            </div>
                                            <div class="gift-tabing-section mt-5">
                                                <ul class="nav nav-pills" id="pills-tab" role="tablist">
                                                    <li class="nav-item" role="presentation">
                                                        <button class="nav-link active" id="pills-home-tab"
                                                            data-bs-toggle="pill" data-bs-target="#pills-home"
                                                            type="button" role="tab" aria-controls="pills-home"
                                                            aria-selected="true">Redeem</button>
                                                    </li>
                                                    <li class="nav-item" role="presentation">
                                                        <button class="nav-link" id="pills-profile-tab"
                                                            data-bs-toggle="pill" data-bs-target="#pills-profile"
                                                            type="button" role="tab" aria-controls="pills-profile"
                                                            aria-selected="false">Add Card</button>
                                                    </li>
                                                    <li class="nav-item" role="presentation">
                                                        <button class="nav-link" id="pills-contact-tab"
                                                            data-bs-toggle="pill" data-bs-target="#pills-contact"
                                                            type="button" role="tab" aria-controls="pills-contact"
                                                            aria-selected="false">Check Card</button>
                                                    </li>
                                                </ul>
                                                <div class="tab-content" id="pills-tabContent">
                                                    <div class="tab-pane fade show active" id="pills-home"
                                                        role="tabpanel" aria-labelledby="pills-home-tab">
                                                        <div class="input-group mb-3">
                                                            <input type="text" class="form-control"
                                                                placeholder="16 characters in digits and letters"
                                                                aria-label="Recipient's username"
                                                                aria-describedby="basic-addon2">
                                                            <a href="#" class="input-group-text"
                                                                id="basic-addon2">Redeem</a>
                                                        </div>
                                                        <p>Wealth Mark is not responsible for, and assumes no liability
                                                            to you for, any
                                                            unlawful
                                                            conduct or fraud by any third party associated with any Gift
                                                            Card. <a href="#" class="text-warning"> View more </a></p>
                                                    </div>
                                                    <div class="tab-pane fade" id="pills-profile" role="tabpanel"
                                                        aria-labelledby="pills-profile-tab">
                                                        <div class="input-group mb-3">
                                                            <input type="text" class="form-control"
                                                                placeholder="16 characters in digits and letters"
                                                                aria-label="Recipient's username"
                                                                aria-describedby="basic-addon2">
                                                            <a href="#" class="input-group-text" id="basic-addon2">Add
                                                                Card</a>
                                                        </div>
                                                        <p>Wealth Mark is not responsible for, and assumes no liability
                                                            to you for, any
                                                            unlawful
                                                            conduct or fraud by any third party associated with any Gift
                                                            Card. <a href="#" class="text-warning"> View more </a></p>
                                                    </div>
                                                    <div class="tab-pane fade" id="pills-contact" role="tabpanel"
                                                        aria-labelledby="pills-contact-tab">
                                                        <div class="input-group mb-3">
                                                            <input type="text" class="form-control"
                                                                placeholder="16 characters in digits and letters"
                                                                aria-label="Recipient's username"
                                                                aria-describedby="basic-addon2">
                                                            <a href="#" class="input-group-text" id="basic-addon2">Check
                                                                Card</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12 order-1 order-lg-2">
                                        <div class="blogs-inner-box-slider">
                                            <img src="{{ asset('public/assets/img/gift-banner3.png') }}"
                                                class="img-fluid" alt="walth mark blog">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="carousel-item">
                                <div class="row">


                                    <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12 order-2 order-lg-1">
                                        <div class="blogs-inner-box-slider gift-card-tab-box">
                                            <div class="left-content-block">
                                                <h1>Transfer Crypto <br />with Wealth Mark Gift Card </h1>
                                                <span>Send and receive crypto at zero fees </span><br />
                                                <a href="#" class="btn btn-yellow shadow mt-3"> Transfer Crypto &#x2192; </a>
                                            </div>
                                            <div class="gift-tabing-section mt-5">
                                                <ul class="nav nav-pills" id="pills-tab" role="tablist">
                                                    <li class="nav-item" role="presentation">
                                                        <button class="nav-link active" id="pills-home-tab"
                                                            data-bs-toggle="pill" data-bs-target="#pills-home"
                                                            type="button" role="tab" aria-controls="pills-home"
                                                            aria-selected="true">Redeem</button>
                                                    </li>
                                                    <li class="nav-item" role="presentation">
                                                        <button class="nav-link" id="pills-profile-tab"
                                                            data-bs-toggle="pill" data-bs-target="#pills-profile"
                                                            type="button" role="tab" aria-controls="pills-profile"
                                                            aria-selected="false">Add Card</button>
                                                    </li>
                                                    <li class="nav-item" role="presentation">
                                                        <button class="nav-link" id="pills-contact-tab"
                                                            data-bs-toggle="pill" data-bs-target="#pills-contact"
                                                            type="button" role="tab" aria-controls="pills-contact"
                                                            aria-selected="false">Check Card</button>
                                                    </li>
                                                </ul>
                                                <div class="tab-content" id="pills-tabContent">
                                                    <div class="tab-pane fade show active" id="pills-home"
                                                        role="tabpanel" aria-labelledby="pills-home-tab">
                                                        <div class="input-group mb-3">
                                                            <input type="text" class="form-control"
                                                                placeholder="16 characters in digits and letters"
                                                                aria-label="Recipient's username"
                                                                aria-describedby="basic-addon2">
                                                            <a href="#" class="input-group-text"
                                                                id="basic-addon2">Redeem</a>
                                                        </div>
                                                        <p>Wealth Mark is not responsible for, and assumes no liability
                                                            to you for, any
                                                            unlawful
                                                            conduct or fraud by any third party associated with any Gift
                                                            Card. <a href="#" class="text-warning"> View more </a></p>
                                                    </div>
                                                    <div class="tab-pane fade" id="pills-profile" role="tabpanel"
                                                        aria-labelledby="pills-profile-tab">
                                                        <div class="input-group mb-3">
                                                            <input type="text" class="form-control"
                                                                placeholder="16 characters in digits and letters"
                                                                aria-label="Recipient's username"
                                                                aria-describedby="basic-addon2">
                                                            <a href="#" class="input-group-text" id="basic-addon2">Add
                                                                Card</a>
                                                        </div>
                                                        <p>Wealth Mark is not responsible for, and assumes no liability
                                                            to you for, any
                                                            unlawful
                                                            conduct or fraud by any third party associated with any Gift
                                                            Card. <a href="#" class="text-warning"> View more </a></p>
                                                    </div>
                                                    <div class="tab-pane fade" id="pills-contact" role="tabpanel"
                                                        aria-labelledby="pills-contact-tab">
                                                        <div class="input-group mb-3">
                                                            <input type="text" class="form-control"
                                                                placeholder="16 characters in digits and letters"
                                                                aria-label="Recipient's username"
                                                                aria-describedby="basic-addon2">
                                                            <a href="#" class="input-group-text" id="basic-addon2">Check
                                                                Card</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12 order-1 order-lg-2">
                                        <div class="blogs-inner-box-slider">
                                            <img src="{{ asset('public/assets/img/gift-banner3.png') }}"
                                                class="img-fluid" alt="walth mark blog">
                                        </div>
                                    </div>
                                </div>
                            </div>


                            
                        </div>

                        <!-- Left and right controls/icons -->
                        <button class="carousel-control-prev" type="button" data-bs-target="#demo" data-bs-slide="prev">
                            <span class="carousel-control-prev-icon"></span>
                        </button>
                        <button class="carousel-control-next" type="button" data-bs-target="#demo" data-bs-slide="next">
                            <span class="carousel-control-next-icon"></span>
                        </button>
                    </div>

                </div>
            </div>

        </div>
    </section>
    <!-- gift banner section end -->


    <!-- popular cards section start -->
    <section class="popular-card-section" id="popular-card-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-md-8 col-xs-6 col-sm-6 sec-title text-left popular-head-block">
                    <span class="title">Know About</span>
                    <h2 class="heading-h2">Wealthmark Cards</h2>
                </div>
                <div class="col-lg-4 col-md-4 col-xs-6 col-sm-6 sec-title text-right view-all-block popular-head-block">
                    <h2 class="float-right view-all-btn popular-view-all">View all cards &#x2192;</h2>
                </div>
            </div>

            <div class="row popular-card-inner-row">
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <img src="{{ asset('public/assets/img/card.jpg') }}" class="img-fluid" alt="gift Card Image">
                    <h6>Popular Cards </h6>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <img src="{{ asset('public/assets/img/card.jpg') }}" class="img-fluid" alt="gift Card Image">
                    <h6>Popular Cards </h6>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <img src="{{ asset('public/assets/img/card.jpg') }}" class="img-fluid" alt="gift Card Image">
                    <h6>Popular Cards </h6>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <img src="{{ asset('public/assets/img/card.jpg') }}" class="img-fluid" alt="gift Card Image">
                    <h6>Popular Cards </h6>
                </div>
            </div>
            <div class="row popular-card-inner-row">
                <div class="col-lg-3 col-md-3  col-sm-6 col-xs-6">
                    <img src="{{ asset('public/assets/img/card.jpg') }}" class="img-fluid" alt="gift Card Image">
                    <h6>Popular Cards </h6>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <img src="{{ asset('public/assets/img/card.jpg') }}" class="img-fluid" alt="gift Card Image">
                    <h6>Popular Cards </h6>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <img src="{{ asset('public/assets/img/card.jpg') }}" class="img-fluid" alt="gift Card Image">
                    <h6>Popular Cards </h6>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <img src="{{ asset('public/assets/img/card.jpg') }}" class="img-fluid" alt="gift Card Image">
                    <h6>Popular Cards </h6>
                </div>
            </div>
        </div>
    </section>
    <!-- popular cards section end -->


    <!-- My card Section -->
    <section class="My-card-section" id="My-card-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="sec-title text-left mb-5">
                        <span class="title">Know About</span>
                        <h2 class="heading-h2">My Cards</h2>
                    </div>
                    <div class="available-gift-card" id="added-gift-card">
                        <img src="{{ asset('public/assets/img/added-card-icon.jpg') }}" class="img-fluid"
                            alt="gift Card Image">
                        <h5>No gift card available Create Gift Card</h5>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- My card Section -->


    <!-- grow-your-business section  start-->
    <section class="grow-your-business" id="business-grow">
        <div class="container">
            <div class="row">
                <div class="row banner-1" id="grow-business">
                    <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12 order-2 order-lg-1">
                        <div class="left-content">
                            <h1 class="mb-3 heading-h2">Grow your business with versatile crypto solutions</h1>
                            <span>Wealth Mark Code is a prepaid crypto voucher that enables your business to transfer
                                and
                                exchange crypto outside of Wealth Mark, supported by API. Use cases include: Gift Card
                                reselling, loyalty and game rewards, e-commerce purchases and more. </span><br />
                            <a href="#" class="btn learn-more-btn mt-4">Learn More &#x2192; </a>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12 order-1 order-lg-2 grow-business-img-block">
                        <img src="{{ asset('public/assets/img/grow-business-img.png') }}" class="img-fluid"
                            alt="gift Card Image" />
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- grow-your-business section end -->


    <!-- FAQ section  start-->
    <section class="faq-block" id="faq-section">
        <div class="container">
            <div class="row">
                <div class="sec-title text-left">
                    <span class="title">Know About</span>
                    <h2 class="heading-h2">FAQ</h2>
                </div>
            </div>
            <div class="row">
                <div class="faq-inner-block" id="faq-inner-section">
                    <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                        <div class="accordion" id="accordian-api">
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingOne">
                                    <button class="accordion-button" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                        1. What is Wealthmark Pay?
                                    </button>
                                </h2>
                                <div id="collapseOne" class="accordion-collapse collapse show"
                                    aria-labelledby="headingOne" data-bs-parent="#accordian-api">
                                    <div class="accordion-body">
                                        <strong>This is the first item's accordion body.</strong> It is shown by
                                        default, until the collapse plugin adds the appropriate classes that we use to
                                        style each element. These classes control the overall appearance, as well as the
                                        showing and hiding via CSS transitions. You can modify any of this with custom
                                        CSS or overriding our default variables. It's also worth noting that just about
                                        any HTML can go within the <code>.accordion-body</code>, though the transition
                                        does limit overflow.
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingTwo">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                        2. Can I pay with Bitcoin, Wealthmark and other cryptocurrencies supported by
                                        Wealthmark?
                                    </button>
                                </h2>
                                <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo"
                                    data-bs-parent="#accordian-api">
                                    <div class="accordion-body">
                                        <strong>You can access your Wealthmark Pay Wallet by clicking [Wallets] -
                                            [Funding] - [Pay] on your Wealthmark App.
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingThree">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapseThree" aria-expanded="false"
                                        aria-controls="collapseThree">
                                        3. How long does it take for a Wealthmark Pay transaction to be completed?
                                    </button>
                                </h2>
                                <div id="collapseThree" class="accordion-collapse collapse"
                                    aria-labelledby="headingThree" data-bs-parent="#accordian-api">
                                    <div class="accordion-body">
                                        <strong>Wealthmark Pay transactions are usually confirmed instantly.
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingfour">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapsefour" aria-expanded="false"
                                        aria-controls="collapsefour">
                                        4. Can I pay with Bitcoin, Wealthmark and other cryptocurrencies supported by
                                        Wealthmark?
                                    </button>
                                </h2>
                                <div id="collapsefour" class="accordion-collapse collapse" aria-labelledby="headingfour"
                                    data-bs-parent="#accordian-api">
                                    <div class="accordion-body">
                                        <strong>You can access your Wealthmark Pay Wallet by clicking [Wallets] -
                                            [Funding] - [Pay] on your Wealthmark App.
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingfive">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapsefive" aria-expanded="false"
                                        aria-controls="collapsefive">
                                        5. How long does it take for a Wealthmark Pay transaction to be completed?
                                    </button>
                                </h2>
                                <div id="collapsefive" class="accordion-collapse collapse" aria-labelledby="headingfive"
                                    data-bs-parent="#accordian-api">
                                    <div class="accordion-body">
                                        <strong>Wealthmark Pay transactions are usually confirmed instantly.
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- FAQ section end -->

    @include('template.country_language')
    @include('template.web_footer')
</body>

</html>