<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <title>Wealth Mark | {{ Request::segment(2) }}</title>
    @include('template.web_css')
    <link rel='stylesheet' href="{{('../public/assets/css/deepak_custom.css') }}">
</head>

<body>
    @include('template.mobile_menu')
    @include('template.web_menu')

    <section class="chat-submit-request-block" id="chat-submit-request">
        <div class="container chat-container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 colxs-12 d-flex justify-content-center align-items-center">
                    <div class="chat-submit-request row" id="chat-submit-request">
                        <div class="user-info-box col-md-8 col-lg-8 col-xs-8 col-sm-8">
                            <h4 class="text-white">Hi, Wealth Mark User </h4>
                            <p class="text-white">What can I do for you? </p>
                        </div>
                        <div class="user-profile col-md-4 col-lg-4 col-xs-4 col-xs-4">
                            <svg  viewBox="0 0 48 48" width="48" height="48"
                                preserveAspectRatio="xMidYMid meet">
                                <defs>
                                    <clipPath id="__lottie_element_2">
                                        <rect width="48" height="48" x="0" y="0"></rect>
                                    </clipPath>
                                    <linearGradient id="__lottie_element_18" spreadMethod="pad"
                                        gradientUnits="userSpaceOnUse">
                                        <stop></stop>
                                        <stop></stop>
                                        <stop></stop>
                                    </linearGradient>
                                    <clipPath id="__lottie_element_32">
                                        <path fill="#ffffff" clip-rule="nonzero"
                                            d=" M3.180999994277954,-3.184999942779541 C3.180999994277954,-3.184999942779541 -3.183000087738037,3.184999942779541 -3.183000087738037,3.184999942779541 C-3.183000087738037,3.184999942779541 -3.180999994277954,4.894000053405762 -3.180999994277954,4.894000053405762 C-3.180999994277954,4.894000053405762 5.090000152587891,5.021999835968018 5.090000152587891,5.021999835968018 C5.090000152587891,5.021999835968018 5.249000072479248,-1.9579999446868896 5.249000072479248,-1.9579999446868896 C5.249000072479248,-1.9579999446868896 3.180999994277954,-3.184999942779541 3.180999994277954,-3.184999942779541"
                                            fill-opacity="1"></path>
                                    </clipPath>
                                    <mask id="__lottie_element_35" mask-type="alpha">
                                        <g transform="matrix(2.309999942779541,0,0,2.309999942779541,24,24)" opacity="1"
                                            style="display: block;">
                                            <g opacity="1" transform="matrix(1,0,0,1,0,0)">
                                                <path fill="rgb(255,255,255)" fill-opacity="1"
                                                    d=" M0,-10 C5.5229997634887695,-10 10,-5.5229997634887695 10,0 C10,5.5229997634887695 5.5229997634887695,10 0,10 C-5.5229997634887695,10 -10,5.5229997634887695 -10,0 C-10,-5.5229997634887695 -5.5229997634887695,-10 0,-10z">
                                                </path>
                                            </g>
                                        </g>
                                    </mask>
                                    <mask id="__lottie_element_41" mask-type="alpha">
                                        <g transform="matrix(2.309999942779541,0,0,2.309999942779541,24,24)" opacity="1"
                                            style="display: block;">
                                            <g opacity="1" transform="matrix(1,0,0,1,0,0)">
                                                <path fill="rgb(255,255,255)" fill-opacity="1"
                                                    d=" M0,-10 C5.5229997634887695,-10 10,-5.5229997634887695 10,0 C10,5.5229997634887695 5.5229997634887695,10 0,10 C-5.5229997634887695,10 -10,5.5229997634887695 -10,0 C-10,-5.5229997634887695 -5.5229997634887695,-10 0,-10z">
                                                </path>
                                            </g>
                                        </g>
                                    </mask>
                                </defs>
                                <g clip-path="url(#__lottie_element_2)">
                                    <g transform="matrix(2.309999942779541,0,0,2.309999942779541,24,24)" opacity="0.1"
                                        style="display: block;">
                                        <g opacity="1" transform="matrix(1,0,0,1,0,0)">
                                            <path fill="rgb(132,142,156)" fill-opacity="1"
                                                d=" M0,-10 C5.5229997634887695,-10 10,-5.5229997634887695 10,0 C10,5.5229997634887695 5.5229997634887695,10 0,10 C-5.5229997634887695,10 -10,5.5229997634887695 -10,0 C-10,-5.5229997634887695 -5.5229997634887695,-10 0,-10z">
                                            </path>
                                        </g>
                                    </g>
                                    <g mask="url(#__lottie_element_41)" style="display: block;">
                                        <g transform="matrix(2.309999942779541,0,0,2.309999942779541,26.406248092651367,40.20695495605469)"
                                            opacity="1">
                                            <g opacity="1" transform="matrix(1,0,0,1,0,0)">
                                                <path fill="rgb(118,128,143)" fill-opacity="1"
                                                    d=" M5,-4 C5,-4 3,-4 3,-4 C3,-4 0,-1 0,-1 C0,-1 -3,-4 -3,-4 C-3,-4 -5,-4 -5,-4 C-7.209000110626221,-4 -9,-2.2090001106262207 -9,0 C-9,0 -9,4 -9,4 C-9,4 9,4 9,4 C9,4 9,0 9,0 C9,-2.2090001106262207 7.209000110626221,-4 5,-4z">
                                                </path>
                                            </g>
                                        </g>
                                    </g>
                                    <g mask="url(#__lottie_element_35)" style="display: block;">
                                        <g transform="matrix(2.309999942779541,0,0,2.309999942779541,26.406248092651367,40.20695495605469)"
                                            opacity="1">
                                            <g opacity="1" transform="matrix(1,0,0,1,0,0)">
                                                <path fill="rgb(146,154,165)" fill-opacity="1"
                                                    d=" M3,4 C3,4 3,-4 3,-4 C3,-4 0,-1 0,-1 C0,-1 -3,-4 -3,-4 C-3,-4 -3,4 -3,4 C-3,4 3,4 3,4z">
                                                </path>
                                            </g>
                                        </g>
                                    </g>
                                    <g clip-path="url(#__lottie_element_32)"
                                        transform="matrix(2.309999942779541,0,0,2.309999942779541,28.619998931884766,17.06999969482422)"
                                        opacity="1" style="display: block;">
                                        <g opacity="1" transform="matrix(1,0,0,1,0,0)">
                                            <path fill="rgb(240,185,11)" fill-opacity="1"
                                                d=" M3.181999921798706,-3.181999921798706 C1.4249999523162842,-4.939000129699707 -1.4249999523162842,-4.939000129699707 -3.181999921798706,-3.181999921798706 C-4.939000129699707,-1.4249999523162842 -4.939000129699707,1.4249999523162842 -3.181999921798706,3.181999921798706 C-1.4249999523162842,4.939000129699707 1.4249999523162842,4.939000129699707 3.181999921798706,3.181999921798706 C4.939000129699707,1.4249999523162842 4.939000129699707,-1.4249999523162842 3.181999921798706,-3.181999921798706z">
                                            </path>
                                        </g>
                                    </g>
                                    <g transform="matrix(2.309999942779541,0,0,2.309999942779541,27.096168518066406,15.54616928100586)"
                                        opacity="1" style="display: block;">
                                        <g opacity="1" transform="matrix(1,0,0,1,0,0)">
                                            <path fill="rgb(118,128,143)" fill-opacity="1"
                                                d=" M3.8410000801086426,-2.5230000019073486 C2.0840001106262207,-4.28000020980835 -0.765999972820282,-4.28000020980835 -2.5230000019073486,-2.5230000019073486 C-4.28000020980835,-0.765999972820282 -4.28000020980835,2.0840001106262207 -2.5230000019073486,3.8410000801086426 C-2.5230000019073486,3.8410000801086426 3.8410000801086426,-2.5230000019073486 3.8410000801086426,-2.5230000019073486z">
                                            </path>
                                        </g>
                                    </g>
                                    <g style="display: none;">
                                        <g>
                                            <path></path>
                                        </g>
                                    </g>
                                    <g style="display: none;">
                                        <g>
                                            <path></path>
                                        </g>
                                    </g>
                                    <g style="display: none;">
                                        <g>
                                            <path></path>
                                        </g>
                                    </g>
                                    <g style="display: none;">
                                        <g>
                                            <path fill="url(#__lottie_element_18)"></path>
                                        </g>
                                    </g>
                                    <g style="display: none;">
                                        <g>
                                            <path></path>
                                        </g>
                                    </g>
                                    <g style="display: none;">
                                        <g>
                                            <path></path>
                                        </g>
                                    </g>
                                    <g style="display: none;">
                                        <g>
                                            <path></path>
                                        </g>
                                    </g>
                                </g>
                            </svg>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12">
                    <h5>&nbsp;KYC Verification </h5>
                </div>
                <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12">
                    <h5 class="chat-proces-txt">Process</h5>
                </div>

                <hr>
            </div>

            <div class="row">
                <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12" id="verifcation-step">
                    <img src="{{ asset('public/assets/img/kyc-chat-img.png') }}" class="img-fluid"
                        alt="chat-img" />
                    <a class="btn btn-yellow-text float-left continue-txt">How to Continue <svg
                             width="16" height="16" fill="currentColor"
                            class="bi bi-arrow-right" viewBox="0 0 16 16">
                            <path fill-rule="evenodd"
                                d="M1 8a.5.5 0 0 1 .5-.5h11.793l-3.147-3.146a.5.5 0 0 1 .708-.708l4 4a.5.5 0 0 1 0 .708l-4 4a.5.5 0 0 1-.708-.708L13.293 8.5H1.5A.5.5 0 0 1 1 8z" />
                        </svg></a>
                </div>
            </div>


            <div class="row">
                <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12">
                    <h6>&nbsp;&nbsp;&nbsp;You might be looking for</h6>
                </div>
                <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12 refresh-icon-block">
                    <svg  viewBox="0 0 24 24" fill="none" class="css-dkmy95">
                        <path fill-rule="evenodd" clip-rule="evenodd"
                            d="M19.997 12.21a8.161 8.161 0 000-.42v.42zm-4.463 3.327l-2.608-2.608h7.07V20l-2.341-2.342A8.003 8.003 0 014.252 14h3.164a5.001 5.001 0 008.118 1.537zM19.747 10A8.003 8.003 0 006.343 6.343L4.001 4v7.071h7.07L8.466 8.464A5.001 5.001 0 0116.585 10h3.162zM4 12L4 11.845v.31A8.126 8.126 0 014 12z"
                            fill="currentColor"></path>
                    </svg>
                </div>
                <hr>
            </div>


            <div class="row">
                <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12">
                    <p><svg  viewBox="0 0 24 24" fill="none" class="css-lqzdyy">
                            <path
                                d="M12.24 8L8 12.24l4.24 4.24 4.24-4.24L12.24 8zm-1.41 4.24l1.41-1.41 1.41 1.41-1.41 1.41-1.41-1.41z"
                                fill="currentColor"></path>
                        </svg> How to mint BAB token</p>
                </div>
                <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12 refresh-icon-block">
                    <svg  viewBox="0 0 24 24" fill="none" class="css-kersv5">
                        <path fill-rule="evenodd" clip-rule="evenodd"
                            d="M12.288 12l-3.89 3.89 1.768 1.767L15.823 12l-1.768-1.768-3.889-3.889-1.768 1.768 3.89 3.89z"
                            fill="currentColor"></path>
                    </svg>
                </div>
                <hr>
            </div>


            <div class="row">
                <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12">
                    <p><svg  viewBox="0 0 24 24" fill="none" class="css-lqzdyy">
                            <path
                                d="M12.24 8L8 12.24l4.24 4.24 4.24-4.24L12.24 8zm-1.41 4.24l1.41-1.41 1.41 1.41-1.41 1.41-1.41-1.41z"
                                fill="currentColor"></path>
                        </svg> How to mint BAB token</p>
                </div>
                <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12 refresh-icon-block">
                    <svg  viewBox="0 0 24 24" fill="none" class="css-kersv5">
                        <path fill-rule="evenodd" clip-rule="evenodd"
                            d="M12.288 12l-3.89 3.89 1.768 1.767L15.823 12l-1.768-1.768-3.889-3.889-1.768 1.768 3.89 3.89z"
                            fill="currentColor"></path>
                    </svg>
                </div>
                <hr>
            </div>

            <div class="row">
                <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12">
                    <p><svg  viewBox="0 0 24 24" fill="none" class="css-lqzdyy">
                            <path
                                d="M12.24 8L8 12.24l4.24 4.24 4.24-4.24L12.24 8zm-1.41 4.24l1.41-1.41 1.41 1.41-1.41 1.41-1.41-1.41z"
                                fill="currentColor"></path>
                        </svg> How to mint BAB token</p>
                </div>
                <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12 refresh-icon-block">
                    <svg  viewBox="0 0 24 24" fill="none" class="css-kersv5">
                        <path fill-rule="evenodd" clip-rule="evenodd"
                            d="M12.288 12l-3.89 3.89 1.768 1.767L15.823 12l-1.768-1.768-3.889-3.889-1.768 1.768 3.89 3.89z"
                            fill="currentColor"></path>
                    </svg>
                </div>
                <hr>
            </div>


            <div class="row">
                <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12">
                    <h6>&nbsp;&nbsp;&nbsp;Self Service</h6>
                </div>
                <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12">
                    &nbsp;
                </div>
            </div>


            <div class="row">
                <div class="col-md-3 col-lg-3 col-xs-12 col-sm-6">
                    <div class="service-box">
                        <svg width="30" height="30" viewBox="0 0 65 64" fill="none">
                            <circle r="13.3333" transform="matrix(1 0 0 -1 32.4 32)" fill="#F8D33A"></circle>
                            <ellipse rx="9.12279" ry="9.12279" transform="matrix(1 0 0 -1 32.4 32.001)"
                                fill="url(#paint0_linear)"></ellipse>
                            <path d="M27.487 32l4.913 4.912L37.312 32 32.4 27.088 27.487 32z" fill="#F0B90B"></path>
                            <path fill-rule="evenodd" clip-rule="evenodd"
                                d="M11.066 32a21.258 21.258 0 006.248 15.085l-1.886 1.886-1.885 1.885A26.592 26.592 0 015.733 32c0-14.728 11.939-26.667 26.666-26.667 14.728 0 26.667 11.94 26.667 26.667 0 14.728-11.94 26.667-26.667 26.667v-5.334c11.782 0 21.333-9.55 21.333-21.333 0-11.782-9.55-21.333-21.333-21.333-11.782 0-21.333 9.55-21.333 21.333z"
                                fill="#76808F"></path>
                            <path
                                d="M32.4 5.333c14.727 0 26.666 11.94 26.666 26.667 0 14.728-11.939 26.667-26.667 26.667v-5.334c11.782 0 21.334-9.55 21.334-21.333 0-11.782-9.551-21.333-21.334-21.333V5.333z"
                                fill="#E9EAED"></path>
                            <path d="M9.732 54.667l11.334-11.334v11.334H9.732z" fill="#76808F"></path>
                            <path
                                d="M55.066 7.333l2 2 2-2-2-2-2 2zM26.4 50.667L27.732 52l1.333-1.333-1.333-1.334-1.334 1.334zM5.732 16.667h2v-2h-2v2z"
                                fill="#E6E8EA"></path>
                            <defs>
                                <linearGradient id="paint0_linear" x1="9.12279" y1="0" x2="9.12279" y2="18.2456"
                                    gradientUnits="userSpaceOnUse">
                                    <stop stop-color="#F0B90B"></stop>
                                    <stop offset="1" stop-color="#F8D33A"></stop>
                                </linearGradient>
                            </defs>
                        </svg>
                        <p>Crypto Deposit not credited </p>
                    </div>
                </div>
                <div class="col-md-3 col-lg-3 col-xs-12 col-sm-6">
                    <div class="service-box">
                        <svg width="30" height="30" viewBox="0 0 65 64" fill="none">
                            <circle r="13.3333" transform="matrix(1 0 0 -1 32.4 32)" fill="#F8D33A"></circle>
                            <ellipse rx="9.12279" ry="9.12279" transform="matrix(1 0 0 -1 32.4 32.001)"
                                fill="url(#paint0_linear)"></ellipse>
                            <path d="M27.487 32l4.913 4.912L37.312 32 32.4 27.088 27.487 32z" fill="#F0B90B"></path>
                            <path fill-rule="evenodd" clip-rule="evenodd"
                                d="M11.066 32a21.258 21.258 0 006.248 15.085l-1.886 1.886-1.885 1.885A26.592 26.592 0 015.733 32c0-14.728 11.939-26.667 26.666-26.667 14.728 0 26.667 11.94 26.667 26.667 0 14.728-11.94 26.667-26.667 26.667v-5.334c11.782 0 21.333-9.55 21.333-21.333 0-11.782-9.55-21.333-21.333-21.333-11.782 0-21.333 9.55-21.333 21.333z"
                                fill="#76808F"></path>
                            <path
                                d="M32.4 5.333c14.727 0 26.666 11.94 26.666 26.667 0 14.728-11.939 26.667-26.667 26.667v-5.334c11.782 0 21.334-9.55 21.334-21.333 0-11.782-9.551-21.333-21.334-21.333V5.333z"
                                fill="#E9EAED"></path>
                            <path d="M9.732 54.667l11.334-11.334v11.334H9.732z" fill="#76808F"></path>
                            <path
                                d="M55.066 7.333l2 2 2-2-2-2-2 2zM26.4 50.667L27.732 52l1.333-1.333-1.333-1.334-1.334 1.334zM5.732 16.667h2v-2h-2v2z"
                                fill="#E6E8EA"></path>
                            <defs>
                                <linearGradient id="paint0_linear" x1="9.12279" y1="0" x2="9.12279" y2="18.2456"
                                    gradientUnits="userSpaceOnUse">
                                    <stop stop-color="#F0B90B"></stop>
                                    <stop offset="1" stop-color="#F8D33A"></stop>
                                </linearGradient>
                            </defs>
                        </svg>
                        <p>Crypto Deposit not credited </p>
                    </div>
                </div>
                <div class="col-md-3 col-lg-3 col-xs-12 col-sm-6">
                    <div class="service-box">
                        <svg width="30" height="30" viewBox="0 0 65 64" fill="none">
                            <circle r="13.3333" transform="matrix(1 0 0 -1 32.4 32)" fill="#F8D33A"></circle>
                            <ellipse rx="9.12279" ry="9.12279" transform="matrix(1 0 0 -1 32.4 32.001)"
                                fill="url(#paint0_linear)"></ellipse>
                            <path d="M27.487 32l4.913 4.912L37.312 32 32.4 27.088 27.487 32z" fill="#F0B90B"></path>
                            <path fill-rule="evenodd" clip-rule="evenodd"
                                d="M11.066 32a21.258 21.258 0 006.248 15.085l-1.886 1.886-1.885 1.885A26.592 26.592 0 015.733 32c0-14.728 11.939-26.667 26.666-26.667 14.728 0 26.667 11.94 26.667 26.667 0 14.728-11.94 26.667-26.667 26.667v-5.334c11.782 0 21.333-9.55 21.333-21.333 0-11.782-9.55-21.333-21.333-21.333-11.782 0-21.333 9.55-21.333 21.333z"
                                fill="#76808F"></path>
                            <path
                                d="M32.4 5.333c14.727 0 26.666 11.94 26.666 26.667 0 14.728-11.939 26.667-26.667 26.667v-5.334c11.782 0 21.334-9.55 21.334-21.333 0-11.782-9.551-21.333-21.334-21.333V5.333z"
                                fill="#E9EAED"></path>
                            <path d="M9.732 54.667l11.334-11.334v11.334H9.732z" fill="#76808F"></path>
                            <path
                                d="M55.066 7.333l2 2 2-2-2-2-2 2zM26.4 50.667L27.732 52l1.333-1.333-1.333-1.334-1.334 1.334zM5.732 16.667h2v-2h-2v2z"
                                fill="#E6E8EA"></path>
                            <defs>
                                <linearGradient id="paint0_linear" x1="9.12279" y1="0" x2="9.12279" y2="18.2456"
                                    gradientUnits="userSpaceOnUse">
                                    <stop stop-color="#F0B90B"></stop>
                                    <stop offset="1" stop-color="#F8D33A"></stop>
                                </linearGradient>
                            </defs>
                        </svg>
                        <p>Crypto Deposit not credited </p>
                    </div>
                </div>
                <div class="col-md-3 col-lg-3 col-xs-12 col-sm-6">
                    <div class="service-box">
                        <svg width="30" height="30" viewBox="0 0 65 64" fill="none">
                            <circle r="13.3333" transform="matrix(1 0 0 -1 32.4 32)" fill="#F8D33A"></circle>
                            <ellipse rx="9.12279" ry="9.12279" transform="matrix(1 0 0 -1 32.4 32.001)"
                                fill="url(#paint0_linear)"></ellipse>
                            <path d="M27.487 32l4.913 4.912L37.312 32 32.4 27.088 27.487 32z" fill="#F0B90B"></path>
                            <path fill-rule="evenodd" clip-rule="evenodd"
                                d="M11.066 32a21.258 21.258 0 006.248 15.085l-1.886 1.886-1.885 1.885A26.592 26.592 0 015.733 32c0-14.728 11.939-26.667 26.666-26.667 14.728 0 26.667 11.94 26.667 26.667 0 14.728-11.94 26.667-26.667 26.667v-5.334c11.782 0 21.333-9.55 21.333-21.333 0-11.782-9.55-21.333-21.333-21.333-11.782 0-21.333 9.55-21.333 21.333z"
                                fill="#76808F"></path>
                            <path
                                d="M32.4 5.333c14.727 0 26.666 11.94 26.666 26.667 0 14.728-11.939 26.667-26.667 26.667v-5.334c11.782 0 21.334-9.55 21.334-21.333 0-11.782-9.551-21.333-21.334-21.333V5.333z"
                                fill="#E9EAED"></path>
                            <path d="M9.732 54.667l11.334-11.334v11.334H9.732z" fill="#76808F"></path>
                            <path
                                d="M55.066 7.333l2 2 2-2-2-2-2 2zM26.4 50.667L27.732 52l1.333-1.333-1.333-1.334-1.334 1.334zM5.732 16.667h2v-2h-2v2z"
                                fill="#E6E8EA"></path>
                            <defs>
                                <linearGradient id="paint0_linear" x1="9.12279" y1="0" x2="9.12279" y2="18.2456"
                                    gradientUnits="userSpaceOnUse">
                                    <stop stop-color="#F0B90B"></stop>
                                    <stop offset="1" stop-color="#F8D33A"></stop>
                                </linearGradient>
                            </defs>
                        </svg>
                        <p>Crypto Deposit not credited </p>
                    </div>
                </div>
            </div>



            <div class="row">
                <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12">
                    <h6>&nbsp;&nbsp;&nbsp;FAQ</h6>
                </div>
                <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12 refresh-icon-block">
                    <svg  viewBox="0 0 24 24" fill="none" class="css-dkmy95">
                        <path fill-rule="evenodd" clip-rule="evenodd"
                            d="M19.997 12.21a8.161 8.161 0 000-.42v.42zm-4.463 3.327l-2.608-2.608h7.07V20l-2.341-2.342A8.003 8.003 0 014.252 14h3.164a5.001 5.001 0 008.118 1.537zM19.747 10A8.003 8.003 0 006.343 6.343L4.001 4v7.071h7.07L8.466 8.464A5.001 5.001 0 0116.585 10h3.162zM4 12L4 11.845v.31A8.126 8.126 0 014 12z"
                            fill="currentColor"></path>
                    </svg>
                </div>
                <hr>
            </div>


            <div class="row">
                <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12">
                    <p><svg  viewBox="0 0 24 24" fill="none" class="css-lqzdyy">
                            <path
                                d="M12.24 8L8 12.24l4.24 4.24 4.24-4.24L12.24 8zm-1.41 4.24l1.41-1.41 1.41 1.41-1.41 1.41-1.41-1.41z"
                                fill="currentColor"></path>
                        </svg> Getting Started</p>
                </div>
                <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12 refresh-icon-block">
                    <svg  viewBox="0 0 24 24" fill="none" class="css-kersv5">
                        <path fill-rule="evenodd" clip-rule="evenodd"
                            d="M12.288 12l-3.89 3.89 1.768 1.767L15.823 12l-1.768-1.768-3.889-3.889-1.768 1.768 3.89 3.89z"
                            fill="currentColor"></path>
                    </svg>
                </div>
                <hr>
            </div>

            <div class="row">
                <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12">
                    <p><svg  viewBox="0 0 24 24" fill="none" class="css-lqzdyy">
                            <path
                                d="M12.24 8L8 12.24l4.24 4.24 4.24-4.24L12.24 8zm-1.41 4.24l1.41-1.41 1.41 1.41-1.41 1.41-1.41-1.41z"
                                fill="currentColor"></path>
                        </svg> Account Functions</p>
                </div>
                <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12 refresh-icon-block">
                    <svg  viewBox="0 0 24 24" fill="none" class="css-kersv5">
                        <path fill-rule="evenodd" clip-rule="evenodd"
                            d="M12.288 12l-3.89 3.89 1.768 1.767L15.823 12l-1.768-1.768-3.889-3.889-1.768 1.768 3.89 3.89z"
                            fill="currentColor"></path>
                    </svg>
                </div>
                <hr>
            </div>

            <div class="row">
                <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12">
                    <p><svg  viewBox="0 0 24 24" fill="none" class="css-lqzdyy">
                            <path
                                d="M12.24 8L8 12.24l4.24 4.24 4.24-4.24L12.24 8zm-1.41 4.24l1.41-1.41 1.41 1.41-1.41 1.41-1.41-1.41z"
                                fill="currentColor"></path>
                        </svg> Crypto Deposit / Withdrawal</p>
                </div>
                <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12 refresh-icon-block">
                    <svg  viewBox="0 0 24 24" fill="none" class="css-kersv5">
                        <path fill-rule="evenodd" clip-rule="evenodd"
                            d="M12.288 12l-3.89 3.89 1.768 1.767L15.823 12l-1.768-1.768-3.889-3.889-1.768 1.768 3.89 3.89z"
                            fill="currentColor"></path>
                    </svg>
                </div>
                <hr>
            </div>

            <div class="row">
                <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12">
                    <p><svg  viewBox="0 0 24 24" fill="none" class="css-lqzdyy">
                            <path
                                d="M12.24 8L8 12.24l4.24 4.24 4.24-4.24L12.24 8zm-1.41 4.24l1.41-1.41 1.41 1.41-1.41 1.41-1.41-1.41z"
                                fill="currentColor"></path>
                        </svg> Buy Crypto (Fiat/P2P)</p>
                </div>
                <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12 refresh-icon-block">
                    <svg  viewBox="0 0 24 24" fill="none" class="css-kersv5">
                        <path fill-rule="evenodd" clip-rule="evenodd"
                            d="M12.288 12l-3.89 3.89 1.768 1.767L15.823 12l-1.768-1.768-3.889-3.889-1.768 1.768 3.89 3.89z"
                            fill="currentColor"></path>
                    </svg>
                </div>
                <hr>
            </div>

            <div class="row">
                <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12">
                    <p><svg  viewBox="0 0 24 24" fill="none" class="css-lqzdyy">
                            <path
                                d="M12.24 8L8 12.24l4.24 4.24 4.24-4.24L12.24 8zm-1.41 4.24l1.41-1.41 1.41 1.41-1.41 1.41-1.41-1.41z"
                                fill="currentColor"></path>
                        </svg>Spot & Margin Trading</p>
                </div>
                <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12 refresh-icon-block">
                    <svg  viewBox="0 0 24 24" fill="none" class="css-kersv5">
                        <path fill-rule="evenodd" clip-rule="evenodd"
                            d="M12.288 12l-3.89 3.89 1.768 1.767L15.823 12l-1.768-1.768-3.889-3.889-1.768 1.768 3.89 3.89z"
                            fill="currentColor"></path>
                    </svg>
                </div>
                <hr>
            </div>

            <div class="row">
                <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12">
                    <p><svg  viewBox="0 0 24 24" fill="none" class="css-lqzdyy">
                            <path
                                d="M12.24 8L8 12.24l4.24 4.24 4.24-4.24L12.24 8zm-1.41 4.24l1.41-1.41 1.41 1.41-1.41 1.41-1.41-1.41z"
                                fill="currentColor"></path>
                        </svg>Website Activities / Promotion</p>
                </div>
                <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12 refresh-icon-block">
                    <svg  viewBox="0 0 24 24" fill="none" class="css-kersv5">
                        <path fill-rule="evenodd" clip-rule="evenodd"
                            d="M12.288 12l-3.89 3.89 1.768 1.767L15.823 12l-1.768-1.768-3.889-3.889-1.768 1.768 3.89 3.89z"
                            fill="currentColor"></path>
                    </svg>
                </div>
                <hr>
            </div>

            <div class="row">
                <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12">
                    <p><svg  viewBox="0 0 24 24" fill="none" class="css-lqzdyy">
                            <path
                                d="M12.24 8L8 12.24l4.24 4.24 4.24-4.24L12.24 8zm-1.41 4.24l1.41-1.41 1.41 1.41-1.41 1.41-1.41-1.41z"
                                fill="currentColor"></path>
                        </svg>News/Announcements</p>
                </div>
                <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12 refresh-icon-block">
                    <svg  viewBox="0 0 24 24" fill="none" class="css-kersv5">
                        <path fill-rule="evenodd" clip-rule="evenodd"
                            d="M12.288 12l-3.89 3.89 1.768 1.767L15.823 12l-1.768-1.768-3.889-3.889-1.768 1.768 3.89 3.89z"
                            fill="currentColor"></path>
                    </svg>
                </div>
                <hr>
            </div>

            <div class="row" id="btn-footer-row">
                <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                <a  id="chat-now" class="btn btn-blue shadow float-end">
                        <svg  width="16" height="16" fill="currentColor"
                            class="bi bi-headphones" viewBox="0 0 16 16">
                            <path
                                d="M8 3a5 5 0 0 0-5 5v1h1a1 1 0 0 1 1 1v3a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V8a6 6 0 1 1 12 0v5a1 1 0 0 1-1 1h-1a1 1 0 0 1-1-1v-3a1 1 0 0 1 1-1h1V8a5 5 0 0 0-5-5z" />
                        </svg> Chat Now </a>

                    <a id="get-support" class="btn btn-blue shadow"><svg  width="16"
                            height="16" fill="currentColor" class="bi bi-chat" viewBox="0 0 16 16">
                            <path
                                d="M2.678 11.894a1 1 0 0 1 .287.801 10.97 10.97 0 0 1-.398 2c1.395-.323 2.247-.697 2.634-.893a1 1 0 0 1 .71-.074A8.06 8.06 0 0 0 8 14c3.996 0 7-2.807 7-6 0-3.192-3.004-6-7-6S1 4.808 1 8c0 1.468.617 2.83 1.678 3.894zm-.493 3.905a21.682 21.682 0 0 1-.713.129c-.2.032-.352-.176-.273-.362a9.68 9.68 0 0 0 .244-.637l.003-.01c.248-.72.45-1.548.524-2.319C.743 11.37 0 9.76 0 8c0-3.866 3.582-7 8-7s8 3.134 8 7-3.582 7-8 7a9.06 9.06 0 0 1-2.347-.306c-.52.263-1.639.742-3.468 1.105z" />
                        </svg> Get Support </a>

                </div>
            </div>
        </div>
    </section>

    <section class="user-chat-ui" id="user-chat-ui-section">
        <div class="container py-5">
            <div class="row d-flex justify-content-center">
                <div class="col-md-8 col-lg-6 col-xl-4">
                    <div class="card" id="chat1" style="border-radius: 15px;">
                        <div class="card-header d-flex justify-content-between align-items-center p-3 bg-primary text-white border-bottom-0"
                            style="border-top-left-radius: 15px; border-top-right-radius: 15px;">
                            <i class="fas fa-angle-left"></i>
                            <p class="mb-0 fw-bold text-white">Wealth Mark Live chat</p>
                            <i class="fas fa-times"></i>
                        </div>
                        <div class="card-body">

                            <div class="d-flex flex-row justify-content-start mb-4">
                            <img src="{{ asset('public/assets/img/ava2-bg.webp') }}" class="img-fluid user-icon-chat" alt="chat-img" />
                                <div class="p-3 ms-3 user-chat-txt">
                                    <p class="small mb-0">Hello and thank you for visiting MDBootstrap. Please click the
                                        video
                                        below.</p>
                                </div>
                            </div>

                            <div class="d-flex flex-row justify-content-end mb-4">
                                <div class="p-3 me-3 border" style="border-radius: 15px; background-color: #fbfbfb;">
                                    <p class="small mb-0">Thank you, I really like your product.</p>
                                </div>
                                <img src="{{ asset('public/assets/img/ava1-bg.webp') }}" class="img-fluid user-icon-chat" alt="chat-img" />
                            </div>

                            <div class="d-flex flex-row justify-content-start mb-4">
                            <img src="{{ asset('public/assets/img/ava1-bg.webp') }}" class="img-fluid user-icon-chat" alt="chat-img" />
                                <div class="ms-3" style="border-radius: 15px;">
                                    <div class="bg-image">
                                        <img src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-chat/screenshot1.webp"
                                            style="border-radius: 15px;" alt="video">
                                        <a href="#!">
                                            <div class="mask"></div>
                                        </a>
                                    </div>
                                </div>
                            </div>

                            <div class="d-flex flex-row justify-content-start mb-4">
                            <img src="{{ asset('public/assets/img/ava2-bg.webp') }}" class="img-fluid user-icon-chat" alt="chat-img" />
                                <div class="p-3 ms-3"
                                    style="border-radius: 15px; background-color: rgba(57, 192, 237,.2);">
                                    <p class="small mb-0">...</p>
                                </div>
                            </div>

                            <div class="form-outline">
                                <textarea class="form-control" id="textAreaExample" rows="4"></textarea>
                                <label class="form-label" for="textAreaExample">Type your message</label>
                            </div>

                        </div>
                    </div>

                </div>
            </div>

        </div>
    </section>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script>
    $(document).ready(function() {
        $("#chat-now").click(function() {
            $("#chat-submit-request").hide();
            $("#user-chat-ui-section").show();
        });
        $("#get-support").click(function() {
            $("#chat-submit-request").show();
            $("#user-chat-ui-section").hide();
        });
    });
    </script>
    @include('template.country_language')
    @include('template.web_footer')
</body>

</html>