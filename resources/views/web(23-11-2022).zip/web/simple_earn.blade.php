  <!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
   <head>
      <meta charset="utf-8">
      <meta content="width=device-width, initial-scale=1.0" name="viewport">
      <title>Wealth Mark | Create Entity Account</title>
  @include('template.web_css')
      
  
 <style>
     #header{
         background:white;
         
     }
     








 </style>
  
  
   </head>
   
 <body class="bg-white">
     
     @include('template.mobile_menu')
        @include('template.web_menu')
    
    <section  class="breadcrumbs shadow-sm simple-earn-top pt-5 pb-5">
          <div class="container">
              <div class="row justify-content-center">
                 <div class="col-lg-5 offset-lg-1 d-flex flex-column justify-content-center pt-lg-0 order-2 order-lg-1" data-aos="fade-up" data-aos-delay="200">
                 <h3 class="top-heading mb-0 text-left">Simple Earn</h3>
                 <p class="top-p text-left">The simple way to Deposit & Earn</p>
               
                 </div>
                 <div class="col-lg-5 offset-lg-1 order-1 order-lg-2 hero-img mt-3 mb-5" data-aos="zoom-in" data-aos-delay="200">
                   <div class="asset-overview login-box-main">
                          <div class="login-box-bg">
                            <div class="login-box">
                              <img src="https://www.wealthmark.io/public/assets/img/account.png" class="login-box-img">
                              <div class="login-box-txt">Log in to view holding details</div>
                            <a href="{{ url( app()->getLocale(), 'login') }}"  <button type="button" class="btn btn-yellow">Log In</button></a>
                            </div>
                          </div>
                        </div>
                  
                 </div>
              </div>
            </div>
      </section>
    
    
    <section class="Staking simple-earn-tbl bg-white">
        <div class="container">
              <div class="staking-top mb-5">
      <div class="search-div">
        <input  placeholder="Choose/Search Coin" style="color:inherit;flex:1 1 auto">
        <svg viewBox="0 0 24 24" fill="none" class="svg-search">
          <path d="M3 10.982c0 3.845 3.137 6.982 6.982 6.982 1.518 0 3.036-.506 4.149-1.416L18.583 21 20 19.583l-4.452-4.452c.81-1.113 1.416-2.631 1.416-4.149 0-1.922-.81-3.643-2.023-4.958C13.726 4.81 11.905 4 9.982 4 6.137 4 3 7.137 3 10.982zM13.423 7.44a4.819 4.819 0 011.416 3.441c0 1.315-.506 2.53-1.416 3.44a4.819 4.819 0 01-3.44 1.417 4.819 4.819 0 01-3.441-1.417c-1.012-.81-1.518-2.023-1.518-3.339 0-1.315.506-2.53 1.416-3.44.911-1.012 2.227-1.518 3.542-1.518 1.316 0 2.53.506 3.44 1.416z" fill="currentColor"></path>
        </svg>
      </div>
      <label class="lbl-fillter-optn">
        <div class="lbl-fillter-check-div">
          <input type="checkbox"  name="remember"  value="2">
         
          
        </div>
        <div class="lbl-fillter-text">Display available only</div>
      </label>
      <label class="lbl-fillter-optn">
        <div class="lbl-fillter-check-div">
          <input type="checkbox"  name="remember" value="1">
        
        </div>
        <div class="lbl-fillter-text">Match My Assets</div>
      </label>
    </div>
            <div class="row">
                <div class="col-md-12">
                 
                    <div class="sm-top-div">
                    <h3 class="h3 mb-0">Protected Products</h3>
                    <div class="sm-small-text">Get stable earnings by depositing assets</div>
                  </div>
                    <div class="simple-earn-pc">
                    <div class="simple-earn-pc-inner">
                      <div class="simple-earn-header-1">
                        <div  class="simple-earn-coin-nm-head">Coin</div>
                      </div>
                      <div class="simple-earn-header-2">
                        <div class="sm-tbl-row-mob-top">
                          <div  class="simple-earn-coin-nm-head">APR</div>
                          <svg  viewBox="0 0 20 20" fill="none" class="svg-fillter-icon">
                            <path d="M7.29167 8.75023V7.37401L10 4.45642L12.7083 7.37401V8.75023H7.29167Z" fill="#929AA5"></path>
                            <path d="M12.7083 11.25V12.6262L10 15.5438L7.29167 12.6262V11.25H12.7083Z" fill="#929AA5"></path>
                          </svg>
                        </div>
                      </div>
                      <div class="simple-earn-header-3">
                        <div  class="simple-earn-coin-nm-head">Duration(Days)</div>
                      </div>
                      <div class="simple-earn-header-4">
                        <div class="">
                        
                          <div  class="simple-earn-header-5">Auto-Subscribe</div>
                        </div>
                      </div>
                      <div class="simple-earn-header-5"></div>
                    </div>
                    <div class="table-body simple-earn-row">
                      <div class="simple-earn-1">
                       
                        <div  class="simple-earn-coin-nm">EGLD</div>
                       
                      </div>
                      <div class="simple-earn-2">
                        
                          <div  class="simple-earn-profit-txt">16.9%</div>
                       
                       
                      </div>
                      <div class="simple-earn-3">
                        <div class="simple-earn-duration">
                          <div class="simple-earn-flexible">
                            <div  class="simple-earn-text">Flexible</div>
                           
                          </div>
                          <div class="simple-earn-day">
                            <div  class="simple-earn-text">30</div>
                           
                          </div>
                          <div class="simple-earn-day">
                            <div  class="simple-earn-text">60</div>
                           
                          </div>
                          <div class="simple-earn-day">
                            <div  class="simple-earn-text">90</div>
                           
                          </div>
                          <div class="simple-earn-active">
                            <div  class="simple-earn-text">120</div>
                            <div class="sm-tbl-row-mob-svg-check">
                              <svg  viewBox="0 0 24 24" fill="none" class="sm-tbl-row-mob-check">
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M7.035 16.812l-.001.002 2.121 2.121.002-.002 2.121-2.12 9.19-9.192-2.12-2.121-9.191 9.19-3.536-3.534-2.121 2.12 3.535 3.536z" fill="currentColor"></path>
                              </svg>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="simple-earn-blnk-div"></div>
                      <div class="simple-earn-btn-div">
                       
                          <button type="button" class="btn-yellow border-0 shadow-none">
                            <div  class="">Subscribe</div>
                          </button>
                       
                      </div>
                    </div>
                    <div class="table-body simple-earn-row">
                      <div class="simple-earn-1">
                      
                        <div  class="simple-earn-coin-nm">RAY</div>
                       
                      </div>
                      <div class="simple-earn-2">
                       
                          <div  class="simple-earn-profit-txt">4.5%</div>
                       
                       
                      </div>
                      <div class="simple-earn-3">
                        <div class="simple-earn-duration">
                          <div class="simple-earn--flex-active">
                            <div  class="simple-earn-text">Flexible</div>
                            <div class="sm-tbl-row-mob-svg-check">
                              <svg  viewBox="0 0 24 24" fill="none" class="sm-tbl-row-mob-check">
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M7.035 16.812l-.001.002 2.121 2.121.002-.002 2.121-2.12 9.19-9.192-2.12-2.121-9.191 9.19-3.536-3.534-2.121 2.12 3.535 3.536z" fill="currentColor"></path>
                              </svg>
                            </div>
                          </div>
                          <div class="simple-earn-day">
                            <div  class="simple-earn-text">30</div>
                         
                          </div>
                          <div class="simple-earn-day">
                            <div  class="simple-earn-text">60</div>
                           
                          </div>
                          <div class="simple-earn-day">
                            <div  class="simple-earn-text">90</div>
                           
                          </div>
                        </div>
                      </div>
                      <div class="simple-earn-blnk-div">
                      
                      </div>
                      <div class="simple-earn-btn-div">
                        
                          <button type="button" class="btn-yellow border-0 shadow-none">
                            <div  class="">Subscribe</div>
                          </button>
                       
                      </div>
                    </div>
                    <div class="table-body simple-earn-row">
                      <div class="simple-earn-1">
                     
                        <div  class="simple-earn-coin-nm">KLAY</div>
                       
                      </div>
                      <div class="simple-earn-2">
                       
                          <div  class="simple-earn-profit-txt">5%</div>
                        
                       
                      </div>
                      <div class="simple-earn-3">
                        <div class="simple-earn-duration">
                          <div class="simple-earn--flex-active">
                            <div  class="simple-earn-text">Flexible</div>
                            <div class="sm-tbl-row-mob-svg-check">
                              <svg  viewBox="0 0 24 24" fill="none" class="sm-tbl-row-mob-check">
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M7.035 16.812l-.001.002 2.121 2.121.002-.002 2.121-2.12 9.19-9.192-2.12-2.121-9.191 9.19-3.536-3.534-2.121 2.12 3.535 3.536z" fill="currentColor"></path>
                              </svg>
                            </div>
                          </div>
                          <div class="simple-earn-day">
                            <div  class="simple-earn-text">30</div>
                            
                          </div>
                          <div class="simple-earn-day">
                            <div  class="simple-earn-text">60</div>
                          
                          </div>
                          <div class="simple-earn-day">
                            <div  class="simple-earn-text">90</div>
                           
                          </div>
                        </div>
                      </div>
                      <div class="simple-earn-blnk-div">
                      
                      </div>
                      <div class="simple-earn-btn-div">
                       
                          <button type="button" class="btn-yellow border-0 shadow-none">
                            <div  class="">Subscribe</div>
                          </button>
                        
                      </div>
                    </div>
                    <div class="table-body simple-earn-row">
                      <div class="simple-earn-1">
                        
                        <div  class="simple-earn-coin-nm">ANKR</div>
                       
                      </div>
                      <div class="simple-earn-2">
                       
                          <div  class="simple-earn-profit-txt">8%</div>
                       
                       
                      </div>
                      <div class="simple-earn-3">
                        <div class="simple-earn-duration">
                          <div class="simple-earn--flex-active">
                            <div  class="simple-earn-text">Flexible</div>
                            <div class="sm-tbl-row-mob-svg-check">
                              <svg  viewBox="0 0 24 24" fill="none" class="sm-tbl-row-mob-check">
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M7.035 16.812l-.001.002 2.121 2.121.002-.002 2.121-2.12 9.19-9.192-2.12-2.121-9.191 9.19-3.536-3.534-2.121 2.12 3.535 3.536z" fill="currentColor"></path>
                              </svg>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="simple-earn-blnk-div">
                        <input type="checkbox" hidden="hidden" id="username">
                <label class="switch" for="username"></label>
                      </div>
                      <div class="simple-earn-btn-div">
                        
                          <button type="button" class="btn-yellow border-0 shadow-none">
                            <div  class="">Subscribe</div>
                          </button>
                        
                      </div>
                    </div>
                    <div class="table-body simple-earn-row">
                      <div class="simple-earn-1">
                      
                        <div  class="simple-earn-coin-nm">COMP</div>
                       
                      </div>
                      <div class="simple-earn-2">
                       
                          <div  class="simple-earn-profit-txt">5%</div>
                        
                       
                      </div>
                      <div class="simple-earn-3">
                        <div class="simple-earn-duration">
                          <div class="simple-earn--flex-active">
                            <div  class="simple-earn-text">Flexible</div>
                            <div class="sm-tbl-row-mob-svg-check">
                              <svg  viewBox="0 0 24 24" fill="none" class="sm-tbl-row-mob-check">
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M7.035 16.812l-.001.002 2.121 2.121.002-.002 2.121-2.12 9.19-9.192-2.12-2.121-9.191 9.19-3.536-3.534-2.121 2.12 3.535 3.536z" fill="currentColor"></path>
                              </svg>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="simple-earn-blnk-div">
                        <input type="checkbox" hidden="hidden" id="username">
                <label class="switch" for="username"></label>
                      </div>
                      <div class="simple-earn-btn-div">
                        
                          <button type="button" class="btn-yellow border-0 shadow-none">
                            <div  class="">Subscribe</div>
                          </button>
                       
                      </div>
                    </div>
                    <div class="table-body simple-earn-row">
                      <div class="simple-earn-1">
                     
                        <div  class="simple-earn-coin-nm">OSMO</div>
                       
                      </div>
                      <div class="simple-earn-2">
                       
                          <div  class="simple-earn-profit-txt">10%</div>
                       
                       
                      </div>
                      <div class="simple-earn-3">
                        <div class="simple-earn-duration">
                          <div class="simple-earn--flex-active">
                            <div  class="simple-earn-text">Flexible</div>
                            <div class="sm-tbl-row-mob-svg-check">
                              <svg  viewBox="0 0 24 24" fill="none" class="sm-tbl-row-mob-check">
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M7.035 16.812l-.001.002 2.121 2.121.002-.002 2.121-2.12 9.19-9.192-2.12-2.121-9.191 9.19-3.536-3.534-2.121 2.12 3.535 3.536z" fill="currentColor"></path>
                              </svg>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="simple-earn-blnk-div">
                       <input type="checkbox" hidden="hidden" id="username">
                <label class="switch" for="username"></label>
                      </div>
                      <div class="simple-earn-btn-div">
                       
                          <button type="button" class="btn-yellow border-0 shadow-none">
                            <div  class="">Subscribe</div>
                          </button>
                        </div>
                     
                    </div>
                    <div class="table-body simple-earn-row">
                      <div class="simple-earn-1">
                      
                        <div  class="simple-earn-coin-nm">DOGE</div>
                       
                      </div>
                      <div class="simple-earn-2">
                        
                          <div  class="simple-earn-profit-txt">10%</div>
                       
                       
                      </div>
                      <div class="simple-earn-3">
                        <div class="simple-earn-duration">
                          <div class="simple-earn--flex-active">
                            <div  class="simple-earn-text">Flexible</div>
                            <div class="sm-tbl-row-mob-svg-check">
                              <svg  viewBox="0 0 24 24" fill="none" class="sm-tbl-row-mob-check">
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M7.035 16.812l-.001.002 2.121 2.121.002-.002 2.121-2.12 9.19-9.192-2.12-2.121-9.191 9.19-3.536-3.534-2.121 2.12 3.535 3.536z" fill="currentColor"></path>
                              </svg>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="simple-earn-blnk-div">
                       <input type="checkbox" hidden="hidden" id="username">
                <label class="switch" for="username"></label>
                      </div>
                      <div class="simple-earn-btn-div">
                       
                          <button type="button" class="btn-yellow border-0 shadow-none">
                            <div  class="">Subscribe</div>
                          </button>
                        </div>
                    
                    </div>
                    <div class="table-body simple-earn-row">
                      <div class="simple-earn-1">
                      
                        <div  class="simple-earn-coin-nm">ENS</div>
                       
                      </div>
                      <div class="simple-earn-2">
                       
                          <div  class="simple-earn-profit-txt">4.25%</div>
                       
                       
                      </div>
                      <div class="simple-earn-3">
                        <div class="simple-earn-duration">
                          <div class="simple-earn--flex-active">
                            <div  class="simple-earn-text">Flexible</div>
                            <div class="sm-tbl-row-mob-svg-check">
                              <svg  viewBox="0 0 24 24" fill="none" class="sm-tbl-row-mob-check">
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M7.035 16.812l-.001.002 2.121 2.121.002-.002 2.121-2.12 9.19-9.192-2.12-2.121-9.191 9.19-3.536-3.534-2.121 2.12 3.535 3.536z" fill="currentColor"></path>
                              </svg>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="simple-earn-blnk-div">
                       <input type="checkbox" hidden="hidden" id="username">
                <label class="switch" for="username"></label>
                      </div>
                      <div class="simple-earn-btn-div">
                        
                          <button type="button" class="btn-yellow border-0 shadow-none">
                            <div  class="">Subscribe</div>
                          </button>
                      
                      </div>
                    </div>
                    <div class="table-body simple-earn-row">
                      <div class="simple-earn-1">
                       
                        <div  class="simple-earn-coin-nm">IMX</div>
                       
                      </div>
                      <div class="simple-earn-2">
                       
                          <div  class="simple-earn-profit-txt">3.25%</div>
                        
                       
                      </div>
                      <div class="simple-earn-3">
                        <div class="simple-earn-duration">
                          <div class="simple-earn--flex-active">
                            <div  class="simple-earn-text">Flexible</div>
                            <div class="sm-tbl-row-mob-svg-check">
                              <svg  viewBox="0 0 24 24" fill="none" class="sm-tbl-row-mob-check">
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M7.035 16.812l-.001.002 2.121 2.121.002-.002 2.121-2.12 9.19-9.192-2.12-2.121-9.191 9.19-3.536-3.534-2.121 2.12 3.535 3.536z" fill="currentColor"></path>
                              </svg>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="simple-earn-blnk-div">
                       <input type="checkbox" hidden="hidden" id="username">
                <label class="switch" for="username"></label>
                      </div>
                      <div class="simple-earn-btn-div">
                      
                          <button type="button" class="btn-yellow border-0 shadow-none">
                            <div  class="">Subscribe</div>
                          </button>
                      
                      </div>
                    </div>
                    <div class="table-body simple-earn-row">
                      <div class="simple-earn-1">
                      
                        <div  class="simple-earn-coin-nm">BNB</div>
                      </div>
                      <div class="simple-earn-2">
                      
                          <div  class="simple-earn-profit-txt">6.2%</div>
                      
                       
                      </div>
                      <div class="simple-earn-3">
                        <div class="simple-earn-duration">
                          <div class="simple-earn-day">
                            <div  class="simple-earn-text">30</div>
                           
                          </div>
                          <div class="simple-earn-day">
                            <div  class="simple-earn-text">60</div>
                           
                          </div>
                          <div class="simple-earn-day">
                            <div  class="simple-earn-text">90</div>
                           
                          </div>
                          <div class="simple-earn-active">
                            <div  class="simple-earn-text">120</div>
                            <div class="sm-tbl-row-mob-svg-check">
                              <svg  viewBox="0 0 24 24" fill="none" class="sm-tbl-row-mob-check">
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M7.035 16.812l-.001.002 2.121 2.121.002-.002 2.121-2.12 9.19-9.192-2.12-2.121-9.191 9.19-3.536-3.534-2.121 2.12 3.535 3.536z" fill="currentColor"></path>
                              </svg>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="simple-earn-blnk-div"></div>
                      <div class="simple-earn-btn-div">
                       
                          <button type="button" class="btn-yellow border-0 shadow-none">
                            <div  class="">Subscribe</div>
                          </button>
                      
                      </div>
                    </div>
                  </div>
                    <div class="simple-earn-mob">
                  <div class="table-body sm-tbl-row-mob">
                   
                    <div class="sm-tbl-row-mob-top">
                      <div class="sm-tbl-row-mob-top">
                        <div class="sm-tbl-row-mob-img">
                          <img class="sm-tbl-row-mob-img--" src="images/20200827/3333bad6-7dc4-4687-93cf-9f57442af7ae.png">
                        </div>
                        <div class="sm-tbl-row-mob-img-txt">EGLD</div>
                      </div>
                      
                        <div class="simple-earn-profit-txt">16.9%</div>
                     
                     
                    </div>
                    <div class="sm-tbl-row-mob-second">
                      <div class="simple-earn-left-sec">
                        <div class="sm-tbl-row-mob-dur">Duration(Days)</div>
                        <div class="simple-earn-duration">
                          <div class="simple-earn-flexible">
                            <div class="simple-earn-text">Flexible</div>
                          
                          </div>
                          <div class="simple-earn-day">
                            <div class="simple-earn-text">30</div>
                            
                          </div>
                          <div class="simple-earn-day">
                            <div class="simple-earn-text">60</div>
                            
                          </div>
                          <div class="simple-earn-day">
                            <div class="simple-earn-text">90</div>
                            
                          </div>
                          <div class="simple-earn-active">
                            <div class="simple-earn-text">120</div>
                            <div class="sm-tbl-row-mob-svg-check">
                              <svg  viewBox="0 0 24 24" fill="none" class="sm-tbl-row-mob-check">
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M7.035 16.812l-.001.002 2.121 2.121.002-.002 2.121-2.12 9.19-9.192-2.12-2.121-9.191 9.19-3.536-3.534-2.121 2.12 3.535 3.536z" fill="currentColor"></path>
                              </svg>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="simple-earn-right-sec">
                        <div class="sm-tbl-row-mob-auto">
                          <div class="sm-tbl-row-mob-auto-div">
                           
                            <div class="simple-earn-header-5">Auto-Subscribe</div>
                          </div>
                         <input type="checkbox" hidden="hidden" id="username">
                <label class="switch" for="username"></label>
                        </div>
                       
                          <button type="button" class="btn-yellow border-0 shadow-none">
                            <div class="">Subscribe</div>
                          </button>
                        
                      </div>
                    </div>
                  </div>
                  <div class="table-body sm-tbl-row-mob">
                   
                    <div class="sm-tbl-row-mob-top">
                      <div class="sm-tbl-row-mob-top">
                        <div class="sm-tbl-row-mob-img">
                          <img class="sm-tbl-row-mob-img--" src="image/admin_mgs_image_upload/20220126/2264ffb3-a6e5-45b3-a267-db6ad2e1208c.png">
                        </div>
                        <div class="sm-tbl-row-mob-img-txt">RAY</div>
                      </div>
                      
                        <div class="simple-earn-profit-txt">4.5%</div>
                     
                     
                    </div>
                    <div class="sm-tbl-row-mob-second">
                      <div class="simple-earn-left-sec">
                        <div class="sm-tbl-row-mob-dur">Duration(Days)</div>
                        <div class="simple-earn-duration">
                          <div class="simple-earn--flex-active">
                            <div class="simple-earn-text">Flexible</div>
                            <div class="sm-tbl-row-mob-svg-check">
                              <svg  viewBox="0 0 24 24" fill="none" class="sm-tbl-row-mob-check">
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M7.035 16.812l-.001.002 2.121 2.121.002-.002 2.121-2.12 9.19-9.192-2.12-2.121-9.191 9.19-3.536-3.534-2.121 2.12 3.535 3.536z" fill="currentColor"></path>
                              </svg>
                            </div>
                          </div>
                          <div class="simple-earn-day">
                            <div class="simple-earn-text">30</div>
                           
                          </div>
                          <div class="simple-earn-day">
                            <div class="simple-earn-text">60</div>
                            
                          </div>
                          <div class="simple-earn-day">
                            <div class="simple-earn-text">90</div>
                            
                          </div>
                        </div>
                      </div>
                      <div class="sm-tbl-row-mob-auto-div-0">
                        <div class="sm-tbl-row-mob-auto-div-1">
                          <div class="sm-tbl-row-mob-auto-div">
                           
                            <div class="simple-earn-header-5">Auto-Subscribe</div>
                          </div>
                         <input type="checkbox" hidden="hidden" id="username">
                <label class="switch" for="username"></label>
                        </div>
                       
                          <button type="button" class="btn-yellow border-0 shadow-none">
                            <div class="">Subscribe</div>
                          </button>
                       
                      </div>
                    </div>
                  </div>
                  <div class="table-body sm-tbl-row-mob">
                   
                    <div class="sm-tbl-row-mob-top">
                      <div class="sm-tbl-row-mob-top">
                        <div class="sm-tbl-row-mob-img">
                          <img class="sm-tbl-row-mob-img--" src="image/admin_mgs_image_upload/20220121/346e0854-dbd3-4241-922b-d9818451a3f7.png">
                        </div>
                        <div class="sm-tbl-row-mob-img-txt">KLAY</div>
                      </div>
                     
                        <div class="simple-earn-profit-txt">5%</div>
                    
                     
                    </div>
                    <div class="sm-tbl-row-mob-second">
                      <div class="simple-earn-left-sec">
                        <div class="sm-tbl-row-mob-dur">Duration(Days)</div>
                        <div class="simple-earn-duration">
                          <div class="simple-earn--flex-active">
                            <div class="simple-earn-text">Flexible</div>
                            <div class="sm-tbl-row-mob-svg-check">
                              <svg  viewBox="0 0 24 24" fill="none" class="sm-tbl-row-mob-check">
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M7.035 16.812l-.001.002 2.121 2.121.002-.002 2.121-2.12 9.19-9.192-2.12-2.121-9.191 9.19-3.536-3.534-2.121 2.12 3.535 3.536z" fill="currentColor"></path>
                              </svg>
                            </div>
                          </div>
                          <div class="simple-earn-day">
                            <div class="simple-earn-text">30</div>
                          
                          </div>
                          <div class="simple-earn-day">
                            <div class="simple-earn-text">60</div>
                           
                          </div>
                          <div class="simple-earn-day">
                            <div class="simple-earn-text">90</div>
                            
                          </div>
                        </div>
                      </div>
                      <div class="sm-tbl-row-mob-auto-div-0">
                        <div class="sm-tbl-row-mob-auto-div-1">
                          <div class="sm-tbl-row-mob-auto-div">
                          
                            <div class="simple-earn-header-5">Auto-Subscribe</div>
                          </div>
                        <input type="checkbox" hidden="hidden" id="username">
                <label class="switch" for="username"></label>
                        </div>
                      
                          <button type="button" class="btn-yellow border-0 shadow-none">
                            <div class="">Subscribe</div>
                          </button>
                       
                      </div>
                    </div>
                  </div>
                  <div class="table-body sm-tbl-row-mob">
                   
                    <div class="sm-tbl-row-mob-top">
                      <div class="sm-tbl-row-mob-top">
                        <div class="sm-tbl-row-mob-img">
                          <img class="sm-tbl-row-mob-img--" src="image/admin_mgs_image_upload/20220329/e97839bc-289c-4ea5-9fba-c75a92c3e781.png">
                        </div>
                        <div class="sm-tbl-row-mob-img-txt">ANKR</div>
                      </div>
                     
                        <div class="simple-earn-profit-txt">8%</div>
                      
                     
                    </div>
                    <div class="sm-tbl-row-mob-second">
                      <div class="simple-earn-left-sec">
                        <div class="sm-tbl-row-mob-dur">Duration(Days)</div>
                        <div class="simple-earn-duration">
                          <div class="simple-earn--flex-active">
                            <div class="simple-earn-text">Flexible</div>
                            <div class="sm-tbl-row-mob-svg-check">
                              <svg  viewBox="0 0 24 24" fill="none" class="sm-tbl-row-mob-check">
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M7.035 16.812l-.001.002 2.121 2.121.002-.002 2.121-2.12 9.19-9.192-2.12-2.121-9.191 9.19-3.536-3.534-2.121 2.12 3.535 3.536z" fill="currentColor"></path>
                              </svg>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="sm-tbl-row-mob-auto-div-0">
                        <div class="sm-tbl-row-mob-auto-div-1">
                          <div class="sm-tbl-row-mob-auto-div">
                          
                            <div class="simple-earn-header-5">Auto-Subscribe</div>
                          </div>
                         <input type="checkbox" hidden="hidden" id="username">
                <label class="switch" for="username"></label>
                        </div>
                       
                          <button type="button" class="btn-yellow border-0 shadow-none">
                            <div class="">Subscribe</div>
                          </button>
                      
                      </div>
                    </div>
                  </div>
                  <div class="table-body sm-tbl-row-mob">
                   
                    <div class="sm-tbl-row-mob-top">
                      <div class="sm-tbl-row-mob-top">
                        <div class="sm-tbl-row-mob-img">
                          <img class="sm-tbl-row-mob-img--" src="image/admin_mgs_image_upload/20201110/bbe7fb63-5b85-4f5a-9c7f-450a8cec116b.png">
                        </div>
                        <div class="sm-tbl-row-mob-img-txt">COMP</div>
                      </div>
                     
                        <div class="simple-earn-profit-txt">5%</div>
                     
                     
                    </div>
                    <div class="sm-tbl-row-mob-second">
                      <div class="simple-earn-left-sec">
                        <div class="sm-tbl-row-mob-dur">Duration(Days)</div>
                        <div class="simple-earn-duration">
                          <div class="simple-earn--flex-active">
                            <div class="simple-earn-text">Flexible</div>
                            <div class="sm-tbl-row-mob-svg-check">
                              <svg  viewBox="0 0 24 24" fill="none" class="sm-tbl-row-mob-check">
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M7.035 16.812l-.001.002 2.121 2.121.002-.002 2.121-2.12 9.19-9.192-2.12-2.121-9.191 9.19-3.536-3.534-2.121 2.12 3.535 3.536z" fill="currentColor"></path>
                              </svg>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="sm-tbl-row-mob-auto-div-0">
                        <div class="sm-tbl-row-mob-auto-div-1">
                          <div class="sm-tbl-row-mob-auto-div">
                           
                            <div class="simple-earn-header-5">Auto-Subscribe</div>
                          </div>
                         <input type="checkbox" hidden="hidden" id="username">
                <label class="switch" for="username"></label>
                        </div>
                        
                          <button type="button" class="btn-yellow border-0 shadow-none">
                            <div class="">Subscribe</div>
                          </button>
                       
                      </div>
                    </div>
                  </div>
                  <div class="table-body sm-tbl-row-mob">
                   
                    <div class="sm-tbl-row-mob-top">
                      <div class="sm-tbl-row-mob-top">
                        <div class="sm-tbl-row-mob-img">
                          <img class="sm-tbl-row-mob-img--" src="image/admin_mgs_image_upload/20221026/4b10ad25-ae7c-476c-bd78-bb61e1bf8f02.png">
                        </div>
                        <div class="sm-tbl-row-mob-img-txt">OSMO</div>
                      </div>
                     
                        <div class="simple-earn-profit-txt">10%</div>
                     
                     
                    </div>
                    <div class="sm-tbl-row-mob-second">
                      <div class="simple-earn-left-sec">
                        <div class="sm-tbl-row-mob-dur">Duration(Days)</div>
                        <div class="simple-earn-duration">
                          <div class="simple-earn--flex-active">
                            <div class="simple-earn-text">Flexible</div>
                            <div class="sm-tbl-row-mob-svg-check">
                              <svg  viewBox="0 0 24 24" fill="none" class="sm-tbl-row-mob-check">
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M7.035 16.812l-.001.002 2.121 2.121.002-.002 2.121-2.12 9.19-9.192-2.12-2.121-9.191 9.19-3.536-3.534-2.121 2.12 3.535 3.536z" fill="currentColor"></path>
                              </svg>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="sm-tbl-row-mob-auto-div-0">
                        <div class="sm-tbl-row-mob-auto-div-1">
                          <div class="sm-tbl-row-mob-auto-div">
                            
                            <div class="simple-earn-header-5">Auto-Subscribe</div>
                          </div>
                         <input type="checkbox" hidden="hidden" id="username">
                <label class="switch" for="username"></label>
                        </div>
                       
                          <button type="button" class="btn-yellow border-0 shadow-none">
                            <div class="">Subscribe</div>
                          </button>
                       
                      </div>
                    </div>
                  </div>
                  <div class="table-body sm-tbl-row-mob">
                   
                    <div class="sm-tbl-row-mob-top">
                      <div class="sm-tbl-row-mob-top">
                        <div class="sm-tbl-row-mob-img">
                          <img class="sm-tbl-row-mob-img--" src="image/admin_mgs_image_upload/20201110/22ef2baf-b210-4882-afd9-1317bb7a3603.png">
                        </div>
                        <div class="sm-tbl-row-mob-img-txt">DOGE</div>
                      </div>
                      
                        <div class="simple-earn-profit-txt">10%</div>
                     
                     
                    </div>
                    <div class="sm-tbl-row-mob-second">
                      <div class="simple-earn-left-sec">
                        <div class="sm-tbl-row-mob-dur">Duration(Days)</div>
                        <div class="simple-earn-duration">
                          <div class="simple-earn--flex-active">
                            <div class="simple-earn-text">Flexible</div>
                            <div class="sm-tbl-row-mob-svg-check">
                              <svg  viewBox="0 0 24 24" fill="none" class="sm-tbl-row-mob-check">
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M7.035 16.812l-.001.002 2.121 2.121.002-.002 2.121-2.12 9.19-9.192-2.12-2.121-9.191 9.19-3.536-3.534-2.121 2.12 3.535 3.536z" fill="currentColor"></path>
                              </svg>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="sm-tbl-row-mob-auto-div-0">
                        <div class="sm-tbl-row-mob-auto-div-1">
                          <div class="sm-tbl-row-mob-auto-div">
                            
                            <div class="simple-earn-header-5">Auto-Subscribe</div>
                          </div>
                         <input type="checkbox" hidden="hidden" id="username">
                <label class="switch" for="username"></label>
                        </div>
                      
                          <button type="button" class="btn-yellow border-0 shadow-none">
                            <div class="">Subscribe</div>
                          </button>
                       
                      </div>
                    </div>
                  </div>
                  <div class="table-body sm-tbl-row-mob">
                   
                    <div class="sm-tbl-row-mob-top">
                      <div class="sm-tbl-row-mob-top">
                        <div class="sm-tbl-row-mob-img">
                          <img class="sm-tbl-row-mob-img--" src="image/admin_mgs_image_upload/20211110/41e21941-ce24-460f-a6bc-ef9beb66e711.png">
                        </div>
                        <div class="sm-tbl-row-mob-img-txt">ENS</div>
                      </div>
                      
                        <div class="simple-earn-profit-txt">4.25%</div>
                      
                     
                    </div>
                    <div class="sm-tbl-row-mob-second">
                      <div class="simple-earn-left-sec">
                        <div class="sm-tbl-row-mob-dur">Duration(Days)</div>
                        <div class="simple-earn-duration">
                          <div class="simple-earn--flex-active">
                            <div class="simple-earn-text">Flexible</div>
                            <div class="sm-tbl-row-mob-svg-check">
                              <svg  viewBox="0 0 24 24" fill="none" class="sm-tbl-row-mob-check">
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M7.035 16.812l-.001.002 2.121 2.121.002-.002 2.121-2.12 9.19-9.192-2.12-2.121-9.191 9.19-3.536-3.534-2.121 2.12 3.535 3.536z" fill="currentColor"></path>
                              </svg>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="sm-tbl-row-mob-auto-div-0">
                        <div class="sm-tbl-row-mob-auto-div-1">
                          <div class="sm-tbl-row-mob-auto-div">
                            
                            <div class="simple-earn-header-5">Auto-Subscribe</div>
                          </div>
                         <input type="checkbox" hidden="hidden" id="username">
                <label class="switch" for="username"></label>
                        </div>
                       
                          <button type="button" class="btn-yellow border-0 shadow-none">
                            <div class="">Subscribe</div>
                          </button>
                        
                      </div>
                    </div>
                  </div>
                  <div class="table-body sm-tbl-row-mob">
                   
                    <div class="sm-tbl-row-mob-top">
                      <div class="sm-tbl-row-mob-top">
                        <div class="sm-tbl-row-mob-img">
                          <img class="sm-tbl-row-mob-img--" src="image/admin_mgs_image_upload/20220110/d0f0a678-a008-47c7-a422-e90e5f855bad.png">
                        </div>
                        <div class="sm-tbl-row-mob-img-txt">IMX</div>
                      </div>
                     
                        <div class="simple-earn-profit-txt">3.25%</div>
                      
                     
                    </div>
                    <div class="sm-tbl-row-mob-second">
                      <div class="simple-earn-left-sec">
                        <div class="sm-tbl-row-mob-dur">Duration(Days)</div>
                        <div class="simple-earn-duration">
                          <div class="simple-earn--flex-active">
                            <div class="simple-earn-text">Flexible</div>
                            <div class="sm-tbl-row-mob-svg-check">
                              <svg  viewBox="0 0 24 24" fill="none" class="sm-tbl-row-mob-check">
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M7.035 16.812l-.001.002 2.121 2.121.002-.002 2.121-2.12 9.19-9.192-2.12-2.121-9.191 9.19-3.536-3.534-2.121 2.12 3.535 3.536z" fill="currentColor"></path>
                              </svg>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="sm-tbl-row-mob-auto-div-0">
                        <div class="sm-tbl-row-mob-auto-div-1">
                          <div class="sm-tbl-row-mob-auto-div">
                           
                            <div class="simple-earn-header-5">Auto-Subscribe</div>
                          </div>
                         <input type="checkbox" hidden="hidden" id="username">
                <label class="switch" for="username"></label>
                        </div>
                       
                          <button type="button" class="btn-yellow border-0 shadow-none">
                            <div class="">Subscribe</div>
                          </button>
                       
                      </div>
                    </div>
                  </div>
               
                </div>

                </div>
            </div>
        </div>
    </section>
    
    

    
    
    
    <section class="simple-earn bg-light-blue">
     <div class="container">
         <div class="sec-title text-left mb-4">
                           <h2 class="heading-h2">Learn More</h2>
                            </div>
       <div class="row">
         <div class="col-md-3 col-sm-6">
           <div class="learn-more-sm">
             <h3 class="sm-title">Flexible Products</h3>
             <div class="sm-service-content">
               <p class="sm-description">Deposit and redeem on a flexible manner. </p>
             </div>
             <div class="service-icon">
               <span>
                  <img src="{{ asset('public/assets/img/wm-savings.svg') }}" alt="Wealthmark" >
               </span>
             </div>
           </div>
         </div>
         <div class="col-md-3 col-sm-6">
           <div class="learn-more-sm blue">
             <h3 class="sm-title">Locked Products</h3>
             <div class="sm-service-content">
               <p class="sm-description">Lock assets for a fixed period of time in return for higher rewards. </p>
             </div>
             <div class="service-icon">
               <span>
                  <img src="{{ asset('public/assets/img/wm-staking.svg') }}" alt="Wealthmark" >
               </span>
             </div>
           </div>
         </div>
         <div class="col-md-3 col-sm-6">
           <div class="learn-more-sm blue">
             <h3 class="sm-title">Tiered APR</h3>
             <div class="sm-service-content">
               <p class="sm-description">Different levels of APR according to the deposit amount in the Flexible Products.</p>
             </div>
             <div class="service-icon">
               <span>
                  <img src="{{ asset('public/assets/img/wm-profit.svg') }}" alt="Wealthmark" >
               </span>
             </div>
           </div>
         </div>
         <div class="col-md-3 col-sm-6">
           <div class="learn-more-sm blue">
             <h3 class="sm-title">Auto-Subscribe</h3>
             <div class="sm-service-content">
               <p class="sm-description">Hassle-free automatic subscription for Flexible or Locked. </p>
             </div>
             <div class="service-icon">
               <span>
                  <img src="{{ asset('public/assets/img/wm-auto.svg') }}" alt="Wealthmark" >
               </span>
             </div>
           </div>
         </div>
       </div>
     </div>
   </section>
    



<section class="wm-pay-accordian-section">
    <div class="container">
        <div class="outlet-main-div">
                 <div class="wm-outlet-div">
                           
                            <div class="sec-title text-center mb-2">
                           <h2 class="heading-h2">FAQs</h2>
                            </div>
                           
                        </div>
                         <div class="wm-outlet-div text-right justify-content-end">
                           
                            <a href="#" class="learn-more btn-6">
                           <span>Learn More </span>
                           <span><i class="bi bi-chevron-right"></i></span>
                        </a>
                           
                        </div>
                        </div>
    </div>
            <div class="container">
          <div class="accordion" id="accordionExample">
          <div class="card">
            <div class="card-head" id="headingOne">
              <h2 class="mb-0 collapsed" data-toggle="collapse" data-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
           How does Simple Earn work?
              </h2>
            </div>
        
            <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
              <div class="card-body">
              <div class="text"> Simple Earn allows users to earn daily rewards by depositing assets, either for flexible-term or locked-terms.</div>
              </div>
            </div>
          </div>
          <div class="card">
            <div class="card-head" id="headingTwo">
              <h2 class="mb-0 collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
        When will I start earning?
              </h2>
            </div>
            <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
              <div class="card-body">
               <div class="text">The first distribution of Rewards to your Spot wallet will be on the third day after you Subscribe, between 0:00 UTC to 08:00 UTC.</div>
              
              </div>
            </div>
          </div>
          <div class="card">
            <div class="card-head" id="headingThree">
              <h2 class="mb-0 collapsed" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
           How are the daily rewards calculated?
              </h2>
            </div>
            <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
              <div class="card-body">
                <div class="text">Rewards=your deposited assets*APR/365<br>
        *APR is subject to change, and may change on a daily basis.</div>
              </div>
            </div>
          </div>
          
          
          <div class="card">
            <div class="card-head" id="headingFour">
              <h2 class="mb-0 collapsed" data-toggle="collapse" data-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
          What happens if I redeem my Locked Products early?
              </h2>
            </div>
            <div id="collapseFour" class="collapse" aria-labelledby="headingFour" data-parent="#accordionExample">
              <div class="card-body">
          <div class="text">You can redeem your assets anytime. But if you do this before the locked period ends, you’ll lose all rewards you have accrued. Any rewards recorded in your Spot wallet will be deducted from the asset you deposited, when you withdraw them.</div>     
              </div>
            </div>
          </div>
          
          <div class="card">
            <div class="card-head" id="headingfive">
              <h2 class="mb-0 collapsed" data-toggle="collapse" data-target="#collapsefive" aria-expanded="false" aria-controls="collapsefive">
         What is the difference between Fast Redemption and Standard Redemption for flexible-term products?
              </h2>
            </div>
            <div id="collapsefive" class="collapse" aria-labelledby="headingfive" data-parent="#accordionExample">
              <div class="card-body">
          <div class="text">If you elect to redeem using Fast Redemption:</div>  
          <div class="text">Rewards will not be accrued or distributed to your Spot wallet for the day that you elect to redeem; and your saved assets will be returned to your Spot wallet immediately;</div>  
          <div class="text">If you elect to redeem using Standard Redemption:</div>  
          <div class="text">Rewards will be accrued and distributed to your Spot wallet for the day that you elect to redeem; and your saved assets will be returned to your Spot wallet within 24 hours of your request.</div>  
              </div>
            </div>
          </div>
  
  
</div>
</div>
</section>



  @include('template.country_language')
    @include('template.web_footer') 
    
     <!--<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>-->
 <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/js/bootstrap.min.js"></script> 
 

  
    </body>
</html>