  <!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
   <head>
      <meta charset="utf-8">
      <meta content="width=device-width, initial-scale=1.0" name="viewport">
      <title>Wealth Mark | Create Entity Account</title>
  @include('template.web_css')
      
  
 <style>
     #header{
         background:white;
         
     }
     
     
     .login-box .btn-yellow:hover{
         border:1px solid #fdc116;
     }
.custom-modal-search-div:hover{
    border-color: #F0B90B;
}

.custom-modal-search-input::placeholder {
  color: #cbc9c9;
  font-size:15px;
  
}

.di-coin-list-sts-apr {
    box-sizing: border-box;
    margin: 0;
    min-width: 0;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-flex-direction: column;
    -ms-flex-direction: column;
    flex-direction: column;
}
.di-coin-list-div {
    box-sizing: border-box;
    margin: 0px 0px 16px;
    min-width: 0px;
    width: 100%;
    display: none;
}
.di-coin-list-active {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    cursor: pointer;
    padding: 16px;
    border: 1.5px solid rgb(240, 185, 11);
    background-color: rgb(255, 255, 255);
    flex-direction: column;
    border-radius: 10px 6px 10px 10px;
    position: relative;
    margin:5px;
}
.di-coin-list-img-tick {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    max-width: 100%;
    position: absolute;
    top: 0px;
    right: 0px;
    width: 24px;
    height: 24px;
}
.di-coin-list-title-div {
    box-sizing: border-box;
    margin: 0px 0px 18px;
    min-width: 0px;
    display: flex;
}
.di-coin-list-img-content {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    color: rgb(30, 35, 41);
    -webkit-box-align: center;
    align-items: center;
    display: inline-flex;
}
.di-coin-list-name-coin {
    box-sizing: border-box;
    margin: 0px 0px 0px 10px;
    min-width: 0px;
    display: flex;
    line-height: 24px;
    font-weight: 500;
}
.di-coin-list-img-coin {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    max-width: 100%;
    z-index: 0;
    background-color: rgb(255, 255, 255);
    border-radius: 50%;
    box-shadow: rgb(24 26 32 / 10%) 0px 0px 1px, rgb(71 77 87 / 8%) 0px 7px 14px, rgb(24 26 32 / 8%) 0px 3px 6px;
    width: 24px;
    height: 24px;
}
.di-coin-list-img-hot {
    box-sizing: border-box;
    margin: 0px 0px 0px 10px;
    min-width: 0px;
    max-width: 100%;
    height: auto;
}
.di-coin-list-sts {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    -webkit-box-pack: justify;
    justify-content: space-between;
    color: rgb(112, 122, 138);
    font-size: 12px;
    line-height: 16px;
}
.di-coin-list-sts-apr {
    box-sizing: border-box;
    margin: 0;
    min-width: 0;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-flex-direction: column;
    -ms-flex-direction: column;
    flex-direction: column;
}
.di-coin-list-sts-apr-sb {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    color: rgb(3, 166, 109);
    font-size: 14px;
    line-height: 20px;
}
.di-coin-list-sts-apr {
    box-sizing: border-box;
    margin: 0;
    min-width: 0;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-flex-direction: column;
    -ms-flex-direction: column;
    flex-direction: column;
}
.di-coin-list {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    cursor: pointer;
    padding: 16px;
    border: 1.5px solid rgb(234, 236, 239);
    background-color: rgb(245, 245, 245);
    flex-direction: column;
    border-radius: 10px 6px 10px 10px;
    position: relative;
    margin:5px;
}
.di-get-start-rgt {
    box-sizing: border-box;
    margin: 0;
    min-width: 0;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    grid-template-columns: 234px 1fr;
    grid-template-rows: max-content max-content;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    -ms-flex-pack: center;
    justify-content: center;
    -webkit-flex-direction: column;
    -ms-flex-direction: column;
    flex-direction: column;
}.di-get-start-img {
    box-sizing: border-box;
    margin: 0;
    min-width: 0;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    background: linear-gradient(149.3deg,#EAECEF 4.64%,#CACED3 98.81%);
    display: none;
    width: 234px;
    height: 288px;
    -webkit-align-items: center;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    -ms-flex-pack: center;
    justify-content: center;
}
.di-get-start-img- {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    max-width: 100%;
    width: 234px;
    height: 288px;
}
.di-get-start-rgt-lft {
    box-sizing: border-box;
    margin: 0;
    min-width: 0;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    box-shadow: 0px 0px 1px rgb(24 26 32 / 10%), 0px 7px 14px rgb(71 77 87 / 8%), 0px 3px 6px rgb(24 26 32 / 8%);
    background-color: #FFFFFF;
    border-radius: 10px;
    position: relative;
    -webkit-flex-direction: column;
    -ms-flex-direction: column;
    flex-direction: column;
    height: auto;
    padding-left: 16px;
    padding-right: 16px;
    padding-bottom: 24px;
}
.di-get-start-rgt-lft-1 {
    box-sizing: border-box;
    margin: 0;
    min-width: 0;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    color: #1E2329;
    font-size: 16px;
    line-height: 24px;
    font-weight: 500;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    -ms-flex-pack: center;
    justify-content: center;
    -webkit-align-items: center;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    margin-top: 24px;
    margin-bottom: 12px;
}
.di-get-start-rgt-lft-1-inner {
    box-sizing: border-box;
    margin: 0px 8px;
    min-width: 0px;
    color: rgb(30, 35, 41);
    -webkit-box-align: center;
    align-items: center;
    display: inline-flex;
}
.di-coin-list-name-coin {
    box-sizing: border-box;
    margin: 0px 0px 0px 10px;
    min-width: 0px;
    display: flex;
    line-height: 24px;
    font-weight: 500;
}


.buy_BTC_div {
    box-sizing: border-box;
    margin: 0;
    min-width: 0;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-flex-direction: column;
    -ms-flex-direction: column;
    flex-direction: column;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    -ms-flex-pack: center;
    justify-content: center;
    -webkit-align-items: center;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
}
.buy_BTC_div-inner {
    box-sizing: border-box;
    margin: 0;
    min-width: 0;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    -ms-flex-pack: center;
    justify-content: center;
    -webkit-align-items: center;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    margin-bottom: 8px;
}

.line-img {
    box-sizing: border-box;
    margin: 0;
    min-width: 0;
    max-width: 20px;
    height: auto;
    margin-right: 8px;
    height: 19px;
}
.edit-svg {
    box-sizing: border-box;
    margin: 0;
    min-width: 0;
    color: #484d56;
    width: 24px;
    height: 24px;
    font-size: 24px;
    fill: #1E2329;
    fill: #484d56;
    width: 1em;
    height: 1em;
    font-size: 24px;
}
.lover-risk {
    box-sizing: border-box;
    margin: 0px 0px 8px;
    min-width: 0px;
    display: flex;
    color: rgb(216, 159, 0);
    font-size: 12px;
    line-height: 18px;
    font-weight: 500;
    background-color: rgba(240, 185, 11, 0.1);
    padding: 1px 5px;
    flex: 0 0 auto;
    width: max-content;
}
.gt-status {
    box-sizing: border-box;
    margin: 0;
    min-width: 0;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    -ms-flex-pack: center;
    justify-content: center;
    -webkit-align-items: center;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    margin-bottom: 10px;
}
.gt-status-crrnt-price {
    box-sizing: border-box;
    margin: 0;
    min-width: 0;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    color: #1E2329;
    font-size: 16px;
    line-height: 24px;
    font-weight: 500;
}
.gt-crrnt-earn-title {
    box-sizing: border-box;
    margin: 0;
    min-width: 0;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    color: #02C076;
    font-size: 16px;
    line-height: 24px;
    font-weight: 500;
}
.gt-status-crrnt-div {
    box-sizing: border-box;
    margin: 0;
    min-width: 0;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    -ms-flex-pack: center;
    justify-content: center;
    -webkit-align-items: center;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
}
.gt-status-crrnt-price {
    box-sizing: border-box;
    margin: 0;
    min-width: 0;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    color: #1E2329;
    font-size: 16px;
    line-height: 24px;
    font-weight: 500;
}
.di-get-start {
    box-sizing: border-box;
    margin: 0;
    min-width: 0;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-flex-direction: column;
    -ms-flex-direction: column;
    flex-direction: column;
    grid-template-columns: 360px 1fr;
    grid-template-rows: auto;
    -webkit-box-pack: start;
    -webkit-justify-content: flex-start;
    -ms-flex-pack: start;
    justify-content: flex-start;
}
.di-get-start-login-div {
    box-sizing: border-box;
    margin: 0;
    min-width: 0;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    grid-column: 1 / 3;
    margin-top: 24px;
    -webkit-box-pack: end;
    -webkit-justify-content: flex-end;
    -ms-flex-pack: end;
    justify-content: flex-end;
    -webkit-align-items: center;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    font-size: 14px;
    line-height: 20px;
    font-weight: 500;
}
.di-get-start-rgt-lft-swt-tbn-div {
    box-sizing: border-box;
    margin: 0;
    min-width: 0;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    -ms-flex-pack: center;
    justify-content: center;
    margin-bottom: 20px;
}
.di-get-start-rgt-lft-swt-tbn-div .btn-yellow {
    box-sizing: border-box;
    margin: 0;
    min-width: 0;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    padding: 8px 24px;
    border-radius: 480px;
    color: #1E2329;
    cursor: default;
  
    margin-right: 5px;
    font-size: 14px;
   line-height: 24px;
    font-weight: 500;
}
.di-get-start-rgt-lft-swt-tbn {
    box-sizing: border-box;
    margin: 0;
    min-width: 0;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    padding: 8px 24px;
    border-radius: 480px;
    color: #1E2329;
    cursor: pointer;
    background-color: #F5F5F5;
    margin-left: 5px;
    font-size: 14px;
    line-height: 20px;
    font-weight: 500;
}

.coin-list-popup {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    width: 100%;
    display: grid;
    grid-template-columns: repeat(3, minmax(max-content, auto));
    grid-template-rows: 24px repeat(20, max-content);
    gap: 0px;
    flex: 1 1 auto;
    overflow-y: auto;
    height: auto;
    position: relative;
}
.coin-list-popup-title {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    -webkit-box-pack: start;
    justify-content: flex-start;
    color: rgb(112, 122, 138);
    padding: 4px;
    font-size: 12px;
    line-height: 12px;
    position: sticky;
    top: 0px;
    background-color: rgb(255, 255, 255);
}


.coin-list-popup-row {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: contents;
    cursor: pointer;
}
.coin-list-popup-inner-div {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    -webkit-box-pack: start;
    justify-content: flex-start;
    -webkit-box-align: center;
    align-items: center;
    padding: 16px 4px;
    white-space: nowrap;
    color: rgb(30, 35, 41);
    font-size: 16px;
    line-height: 24px;
    border-bottom: 1px solid rgb(234, 236, 239);
}
.coin-list-popup-apr-div {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    -webkit-box-align: center;
    align-items: center;
    padding: 16px 4px;
    white-space: nowrap;
    color: rgb(30, 35, 41);
    font-size: 16px;
    line-height: 24px;
    border-bottom: 1px solid rgb(234, 236, 239);
    -webkit-box-pack: end;
    justify-content: flex-end;
}
.coin-list-popup-apr-up-sts {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    font-size: 16px;
    line-height: 24px;
    font-weight: 500;
    color: rgb(2, 192, 118);
}
.coin-list-popup-apr-down-sts{
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    font-size: 16px;
    line-height: 24px;
    font-weight: 500;
    color: #f91100;
}
.di-get-start-left {
    box-sizing: border-box;
    margin: 0;
    min-width: 0;
    margin-right: unset;
}
.li-prog-tst-mob {
    box-sizing: border-box;
    margin: 0;
    min-width: 0;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-pack: start;
    -webkit-justify-content: flex-start;
    -ms-flex-pack: start;
    justify-content: flex-start;
    -webkit-align-items: center;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    margin-left: 8px;
    line-height: 24px;
    font-weight: 500;
}

.step-prog {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: none;
    flex-direction: column;
    align-items: flex-start;
    height: 288px;
}
.li-prog-div-main[data-status="process"] {
    color: #1E2329;
}
.li-prog-div-main {
    box-sizing: border-box;
    margin: 0;
    min-width: 0;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    position: static;
    color: #707A8A;
    padding: 8px;
    -webkit-box-flex: 0;
    -webkit-flex-grow: 0;
    -ms-flex-positive: 0;
    flex-grow: 0;
    -webkit-align-items: center;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    text-align: center;
    overflow: hidden;
}
.li-prog-div {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    flex-direction: row;
}

.li-prog-tst {
    box-sizing: border-box;
    margin: 0px 0px 0px 8px;
    min-width: 0px;
    display: flex;
    -webkit-box-pack: center;
    justify-content: center;
    -webkit-box-align: center;
    align-items: center;
}
.li-prog-div-main[data-status="process"] [data-class="step_marker_row"], .li-prog-div-main[data-status="process"] [data-class="step_marker_column"] {
    background-color: #FCD535;
}
.li-prog-div-main [data-class="step_marker_row"] {
    position: relative;
    width: 24px;
    height: 24px;
    line-height: 24px;
    text-align: center;
    border-radius: 100%;
    margin-top: 20px;
    background-color: #EAECEF;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
}
.li-prog-div-main [data-class="step_marker_column"] {
    position: relative;
    width: 24px;
    height: 24px;
    line-height: 24px;
    text-align: center;
    border-radius: 100%;
    background-color: #EAECEF;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
}
.li-prog-div-main[data-status="process"] [data-class="step_marker_number"] {
    color: #181A20;
}
.step_marker_span {
    box-sizing: border-box;
    margin: 0;
    min-width: 0;
    font-size: 16px;
}
.step_marker_number {
    box-sizing: border-box;
    margin: 0;
    min-width: 0;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    color: #181A20;
    font-size: 14px;
    line-height: 22px;
    font-weight: 500;
    -webkit-align-items: center;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    -ms-flex-pack: center;
    justify-content: center;
}
.li-prog-div-main [data-class="step_marker_column"]::after {
    content: '';
    position: absolute;
    height: 9999px;
    top: 28px;
    width: 4px;
    background-color: inherit;
    left: 10px;
    margin-top: 8px;
}
.li-prog-line {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    width: 4px;
    left: 18px;
    flex: 1 1 0%;
    position: relative;
    background-color: rgb(234, 236, 239);
}
.li-prog-line::after {
    content: "";
    position: absolute;
    top: 0px;
    left: 0px;
    right: 0px;
    width: 4px;
    background-color: inherit;
}
.Di_Current_coin_Price_status {
    box-sizing: border-box;
    margin: 0;
    min-width: 0;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    color: #03A66D;
    font-size: 20px;
    line-height: 28px;
    font-weight: 500;
    margin-left: 8px;
}

#return_cal_main_div{
        display:none !important;
    }
@media screen and (min-width: 767px)
{
  
    #return_cal_main_div{
        display:block !important;
    }
    .Di_Current_coin_Price_status {
    font-size: 24px;
    line-height: 32px;
    font-weight: 600;
}
   
    .coin-list-popup-apr-div {
    padding: 8px 16px;
}
    .coin-list-popup-inner-div {
    padding: 8px 16px;
}


    .coin-list-popup-title {
    padding: 12px 16px;
    line-height: 16px;
}


    .coin-list-popup {
    grid-template-rows: 40px repeat(20, max-content);}
    .di-get-start-rgt-lft-swt-tbn {
    font-size: 16px;
    line-height: 24px;
  
}
    .di-get-start-rgt-lft-swt-tbn-div {
    margin-bottom: 16px;
}

    .di-get-start-login-div {
    margin-top: 16px;
    -webkit-box-pack: end;
    -webkit-justify-content: flex-end;
    -ms-flex-pack: end;
    justify-content: flex-end;
}
    
.di-get-start-rgt-lft-1 {
    font-size: 20px;
    line-height: 28px;
    margin-top: 30px;
    margin-bottom: 16px;
}

    
    .di-get-start-rgt-lft {
    height: 288px;
    padding-left: 20px;
    padding-right: 20px;
    padding-bottom: unset;
    box-shadow: unset;
    background-color: #FAFAFA;
    border-radius: unset;
}
.di-get-start-img {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    
}


  .di-coin-list-div {
       display: flex;
       justify-content: start;
        flex-wrap: wrap;
}  
.di-get-start-rgt {
    display: grid;
    grid-template-columns: 234px 1fr;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    -ms-flex-pack: center;
    justify-content: center;
}
.di-get-start {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-flex-direction: column;
    -ms-flex-direction: column;
    flex-direction: column;
}
.di-get-start-left {
    margin-right: unset;
}
.li-prog-tst-mob {
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
}
}
@media screen and (min-width: 1279px){
    .li-prog-tst-mob {
    display: none;
}
.step-prog{
    display:flex !important;
}
.step-prog-mobile{
    display:none !important;
}
    .di-get-start-left {
    margin-right: 24px;
}
    .di-get-start-rgt-lft-1 {
    margin-top: 30px;
}
.di-get-start-rgt {
    grid-template-columns: 234px 1fr;
    -webkit-box-pack: start;
    -webkit-justify-content: start;
    -ms-flex-pack: start;
    justify-content: start;
}
   .di-get-start {
    display: grid;
    -webkit-flex-direction: unset;
    -ms-flex-direction: unset;
    flex-direction: unset;
} 
}

.open.hide{
    display:none !important;
}
.open.show{
    display:block !important;
}
.gt-earn-apr {
    box-sizing: border-box;
    margin: 0;
    min-width: 0;
    max-width: 100%;
    height: auto;
    margin-right: 8px;
    height: 19px;
    margin-left: 8px;
}

.step-prog-mobile {
    box-sizing: border-box;
    margin: 0;
    min-width: 0;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-align-items: flex-end;
    -webkit-box-align: flex-end;
    -ms-flex-align: flex-end;
    align-items: flex-end;
    height: 40px;
    
}
.li-prog-line-mob {
    box-sizing: border-box;
    margin: 0;
    min-width: 0;
    bottom: 20px;
    height: 0px;
    -webkit-align-self: flex-end;
    -ms-flex-item-align: end;
    align-self: flex-end;
    -webkit-flex: 1;
    -ms-flex: 1;
    flex: 1;
    position: relative;
    background-color: #EAECEF;
}
.li-prog-line-mob::after {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 4px;
    background-color: inherit;
}

.Di_Current_coin_Price_div {
    box-sizing: border-box;
    margin: 0;
    min-width: 0;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    color: #474D57;
    font-size: 14px;
    line-height: 20px;
    -webkit-align-items: center;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    font-weight: 400;
}

.Choose_settlement_optn-div {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
  
    cursor: pointer;
    white-space: nowrap;
    flex: 0 0 auto;
    -webkit-box-align: center;
    align-items: center;
   
}
.Choose_settlement_optn-img {
    box-sizing: border-box;
    margin: 0px 8px 0px 0px;
    min-width: 0px;
    display: flex;
    align-items: flex-end;
    flex: 0 0 auto;
}
.di-coin-list-img-content {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    color: rgb(30, 35, 41);
    -webkit-box-align: center;
    align-items: center;
    display: inline-flex;
}
.Choose_settlement_optn-img-main {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    max-width: 100%;
    z-index: 0;
    background-color: rgb(255, 255, 255);
    border-radius: 50%;
    width: 24px;
    height: 24px;
}
.Choose_settlement_optn-img2-main {
    box-sizing: border-box;
    margin: 0px 0px 0px -8px;
    min-width: 0px;
    color: rgb(30, 35, 41);
    -webkit-box-align: center;
    align-items: center;
    display: inline-flex;
}
.Choose_settlement_optn-img2-main2 {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    max-width: 100%;
    z-index: 0;
    background-color: rgb(255, 255, 255);
    border-radius: 50%;
    width: 16px;
    height: 16px;
}
.Choose_settlement_optn-title {
    box-sizing: border-box;
    margin: 0px 8px 0px 0px;
    min-width: 0px;
    color: rgb(30, 35, 41);
    font-weight: 500;
    display: none;
}
.Choose_settlement_optn-up {
    box-sizing: border-box;
    margin: 0px 8px 0px 0px;
    min-width: 0px;
    background-color: rgb(30, 35, 41);
    -webkit-mask: url("https://www.wealthmark.io/public/assets/img/dual-investment/wm-up_arrow.svg") center center no-repeat;
    width: 22px;
    height: 22px;
    display: none;
}
.Choose_settlement_optn-down {
    box-sizing: border-box;
    margin: 0px 8px 0px 0px;
    min-width: 0px;
    background-color: rgb(112, 122, 138);
    -webkit-mask: url("https://www.wealthmark.io/public/assets/img/dual-investment/wm-down_arrow.svg") center center no-repeat;
    width: 22px;
    height: 22px;
    display: none;
}
.Choose_settlement_optn-title-2 {
    box-sizing: border-box;
    margin: 0px 8px 0px 0px;
    min-width: 0px;
    display: flex;
    color: rgb(112, 122, 138);
}
.date-wise-filter {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    width: 100%;
    white-space: nowrap;
    display: flex;
    flex-direction: row;
    overflow-x: scroll;
}
.date-wise-filter-div {
    box-sizing: border-box;
    margin: 0px;
    cursor: pointer;
    min-width: auto;
}
.date-wise-filter--txt {
    box-sizing: border-box;
    margin: 0px 16px 0px 0px;
    min-width: 0px;
    padding: 8px 16px;
    font-weight: 500;
    font-size: 14px;
    line-height: 20px;
    user-select: none;
    color: rgb(112, 122, 138);
    border-radius: 4px;
}
.tab-content .tab-pane .date-wise-filter .date-wise-filter-div .date-wise-filter--txt.active {
    border: 1px solid rgb(240, 185, 11);
    border-radius: 4px;
    background-color: rgb(255, 255, 255);
    color: rgb(30, 35, 41);
}
@media screen and (min-width: 767px)
{
    .date-wise-filter--txt {
    padding-left: 24px;
    padding-right: 24px;
    font-size: 16px;
    line-height: 24px;
    margin-right: 24px;
}
    .Choose_settlement_optn-down {
    display: flex;
}
    .Choose_settlement_optn-up {
    display: flex;
}
.Choose_settlement_optn-title {
    display: flex;
}}
.coin-list-popup-price-div {
    box-sizing: border-box;
    margin: 0;
    min-width: 0;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-align-items: center;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    width:100%;
    justify-content:space-between;
}




.step-prog-num-div {
    box-sizing: border-box;
    margin: 0;
    min-width: 0;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-flex-direction: column;
    -ms-flex-direction: column;
    flex-direction: column;
    -webkit-align-items: center;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
}
.coin-list-popup-price-div {
    box-sizing: border-box;
    margin: 0;
    min-width: 0;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-align-items: center;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
}

.return_cal{
    display:flex;
    align-items:center;
    justify-content:space-between;
    flex-direction:column;
}
@media screen and (min-width: 1279px){
       
    .return_cal{
         flex-direction:row !important;
    }
}

.date-wise-filter-list-inner {
    box-sizing: border-box;
    margin: 0px 0px 24px;
    min-width: 0px;
    border: 1px solid rgb(234, 236, 239);
    box-shadow: rgb(24 26 32 / 10%) 0px 0px 1px, rgb(71 77 87 / 8%) 0px 7px 14px, rgb(24 26 32 / 8%) 0px 3px 6px;
    border-radius: 4px;
    padding: 16px;
    display: grid;
    grid-template-columns: auto;
    grid-template-rows: repeat(2, auto);
    justify-content: stretch;
    -webkit-box-align: center;
    align-items: center;
}
.filter-list-inner-left {
    box-sizing: border-box;
    margin: 0px 0px 16px;
    min-width: 0px;
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    column-gap: unset;
}
.filter-list-trgt-div {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    flex-direction: column;
    font-size: 12px;
    line-height: 20px;
}

.filter-list-trgt-sts {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    font-size: 16px;
    font-weight: 500;
    line-height: 24px;
    padding-top: 2px;
    color: inherit;
}
.filter-list-trgt-crrnt-sts-div {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    font-weight: 500;
    align-items: flex-start;
    flex-direction: column;
}
.filter-list-trgt-per-div {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    -webkit-box-align: center;
    align-items: center;
}
.filter-list-trgt-per {
    box-sizing: border-box;
    margin: 0px 2px 0px 0px;
    min-width: 0px;
    display: flex;
    font-size: 12px;
    line-height: 16px;
    font-weight: 400;
    color: rgb(112, 122, 138);
}
.filter-list-trgt-per-icon {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    color: rgb(146, 154, 165);
    fill: rgb(146, 154, 165);
    font-size: 12px;
}
.filter-list-apr-div {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    flex-direction: column;
    font-size: 12px;
    line-height: 20px;
    justify-self: center;
}
.filter-list-trgt-sts {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    font-size: 16px;
    font-weight: 500;
    line-height: 24px;
    padding-top: 2px;
    color: inherit;
}
.filter-list-apr-sts {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    color: rgb(3, 166, 109);
    font-weight: 500;
    -webkit-box-align: center;
    align-items: center;
}
.filter-list-date-div {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    flex-direction: column;
    font-size: 12px;
    line-height: 20px;
    justify-self: end;
}
.filter-list-date-div-title {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    border-bottom: 1px dashed rgb(112, 122, 138);
}
.filter-list-trgt-sts {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    font-size: 16px;
    font-weight: 500;
    line-height: 24px;
    padding-top: 2px;
    color: inherit;
}
.filter-list-inner-right {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    column-gap: 16px;
}

.di_cal_btn {
    margin: 0px;
    appearance: none;
    user-select: none;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    display: inline-flex;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: center;
    justify-content: center;
    box-sizing: border-box;
    font-size: 14px;
    font-family: inherit;
    font-weight: 500;
    text-align: center;
    text-decoration: none;
    outline: none;
    padding: 6px 12px;
    line-height: 20px;
    word-break: keep-all;
    border-radius: 4px;
    min-height: 24px;
    border: none;
    background: rgb(234, 236, 239);
    min-width: 102px;
    cursor: pointer;
    color: rgb(30, 32, 38);
}
@media screen and (min-width: 767px)
{
    .filter-list-inner-right{
        grid-template-columns:repeat(1, 1fr)
    }
     .di_cal_btn{
        display:none;
    } .filter-list-date-div {
    margin-right: 16px;
}
    .filter-list-trgt-per-div {
    margin-left: 10px;
}
    .filter-list-trgt-crrnt-sts-div {
    -webkit-box-align: center;
    align-items: center;
    flex-direction: row;
}
    .filter-list-inner-left {
    grid-template-columns: repeat(3, 1fr);
    column-gap: 48px;
    margin-bottom: unset;
}
.date-wise-filter-list-inner {
    box-shadow: rgb(0 0 0 / 5%) 0px 1px 6px;
    grid-template-columns: repeat(2, auto);
    grid-template-rows: auto;
    -webkit-box-pack: justify;
    justify-content: space-between;
}
    
}


/*-----------------------------div -2 --------------*/
.Return_Calculator_div {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    flex-direction: column;
    -webkit-box-pack: justify;
    justify-content: space-between;
    align-items: flex-start;
}
.chart_Calculator_div {
    box-sizing: border-box;
    margin: 0px 30px 0px 0px;
    min-width: 0px;
    display: flex;
    align-self: center;
}
.chart_Calculator_div-main-inner {
    box-sizing: border-box;
    margin: 24px 0px;
    min-width: 0px;
    display: flex;
    height: 209px;
    width: 320px;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: start;
    justify-content: flex-start;
    flex-wrap: nowrap;
    border-radius: 10px;
    background-color: rgb(250, 250, 250);
}
.chart_Calculator_div-inner {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    -webkit-box-align: center;
    align-items: center;
    flex-direction: column;
    -webkit-box-pack: justify;
    justify-content: space-between;
    padding: 11px 7px;
    width: 74px;
    background-color: rgb(250, 250, 250);
    height: 100%;
}
.rc-coin-selected-price {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    font-weight: 400;
    font-size: 12px;
    line-height: 16px;
    color: rgb(112, 122, 138);
    text-align: right;
}
. {
    box-sizing: border-box;
    margin: 0;
    min-width: 0;
}
.rc-coin-selected-price {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    font-weight: 400;
    font-size: 12px;
    line-height: 16px;
    color: rgb(112, 122, 138);
    text-align: right;
}
.rc-coin-selected-price-1 {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    font-weight: 400;
    font-size: 12px;
    line-height: 16px;
    color: rgb(30, 35, 41);
    text-align: right;
}
.chart_Calculator_right {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    width: 246px;
    position: relative;
    height: 100%;
    background-color: rgb(245, 245, 245);
    border-radius: 0px 10px 10px 0px;
    -webkit-box-align: center;
    align-items: center;
}
.chart_Calculator_dashed-line {
    margin: 0px;
    min-width: 0px;
    width: 100%;
    border-bottom: 1px dashed rgb(183, 189, 198);
    box-sizing: border-box;
    height: 1px;
    position: absolute;
    top: 104px;
    left: 0px;
}

.cal_div_return {
    box-sizing: border-box;
    margin: 0px 0px 0px 20px;
    min-width: 0px;
    display: flex;
    align-self: center;
}
.cal_div_return-inner {
    box-sizing: border-box;
    margin-top: 0px;
    margin-right: 0px;
    margin-bottom: 0px;
    min-width: 0px;
    display: flex;
    width: 100%;
    padding: 16px;
    background-color: rgb(250, 250, 250);
    flex-direction: column;
    flex: unset;
    margin-left: unset;
    position: relative;
    border-radius: 4px;
    height: unset;
    word-break: break-word;
    overflow: auto;
}
.cal_div_return-title {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    font-weight: 500;
    font-size: 14px;
    line-height: 20px;
    color: rgb(30, 35, 41);
}
.cal_div_return-1-row {
    box-sizing: border-box;
    margin: 24px 0px 0px;
    min-width: 0px;
    display: flex;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: justify;
    justify-content: space-between;
    flex-wrap: wrap;
}
.cal_div_return_left {
    box-sizing: border-box;
    margin: 0;
    min-width: 0;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-align-items: center;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
}
.rc_blank_record {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    font-weight: 400;
    font-size: 14px;
    line-height: 20px;
    color: rgb(30, 35, 41);
}
.cal_div_return_right {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    flex-wrap: wrap;
}
.rc_blank_record {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    font-weight: 400;
    font-size: 14px;
    line-height: 20px;
    color: rgb(30, 35, 41);
}
.rc_crnt_rcrd {
    box-sizing: border-box;
    margin: 0px 0px 0px 4px;
    min-width: 0px;
    color: rgb(30, 35, 41);
    -webkit-box-align: center;
    align-items: center;
    display: inline-flex;
}
.rc_coin-img {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    max-width: 100%;
    z-index: 0;
    background-color: rgb(255, 255, 255);
    border-radius: 50%;
    box-shadow: rgb(24 26 32 / 10%) 0px 0px 1px, rgb(71 77 87 / 8%) 0px 7px 14px, rgb(24 26 32 / 8%) 0px 3px 6px;
    width: 16px;
    height: 16px;
}
.rc_title {
    box-sizing: border-box;
    margin: 0px 0px 0px 6px;
    min-width: 0px;
}

.rc_Interests_div {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    -webkit-box-align: center;
    align-items: center;
    line-height: 20px;
    font-size: 14px;
    font-weight: 400;
    color: rgb(30, 35, 41);
}
.css-1vsfwfm {
    box-sizing: border-box;
    margin: 0px 5px 0px 0px;
    min-width: 0px;
    color: rgb(2, 192, 118);
}
.cal_div_return_left_info {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: inline-block;
    position: relative;
    -webkit-box-align: center;
    align-items: center;
}
.cal_div_return_left_info_icn {
    box-sizing: border-box;
    margin: 0px 0px 0px 6px;
    min-width: 0px;
    font-size: 18px;
    fill: rgb(132, 142, 156);
    color: rgb(132, 142, 156);
    position: relative;
    top: 1px;
    width: 1em;
    height: 1em;
}
.cal_div_return-border-line {
    box-sizing: border-box;
    margin: 8px 0px;
    min-width: 0px;
    height: 1px;
    background-color: rgb(234, 236, 239);
    width: 100%;
}
.cal_div_return-3-row {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: justify;
    justify-content: space-between;
    flex-wrap: wrap;
}
.css-4cffwv {
    box-sizing: border-box;
    margin: 0;
    min-width: 0;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
}
.rc_blank_record {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    font-weight: 400;
    font-size: 14px;
    line-height: 20px;
    color: rgb(30, 35, 41);
}
.cal_div_return-3-arrow {
    box-sizing: border-box;
    margin: 0;
    min-width: 0;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-flex-direction: column;
    -ms-flex-direction: column;
    flex-direction: column;
    -webkit-align-items: center;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
}
.rc_arrow {
    box-sizing: border-box;
    margin: 16px 0px;
    min-width: 0px;
    color: currentcolor;
    font-size: 20px;
    fill: currentcolor;
    width: 1em;
    height: 1em;
}
.css-16u3n6c {
    box-sizing: border-box;
    margin: 0px 0px 8px;
    min-width: 0px;
    font-weight: 400;
    font-size: 14px;
    line-height: 20px;
    color: rgb(30, 35, 41);
}
.cal_div_return-3-row {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: justify;
    justify-content: space-between;
    flex-wrap: wrap;
}
.cal_div_return-2-row {
    box-sizing: border-box;
    margin: 8px 0px 0px;
    min-width: 0px;
    display: flex;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: justify;
    justify-content: space-between;
    flex-wrap: wrap;
}
.sell_Calculator_div {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    align-self: flex-start;
}
.css-1065ayc {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    width: 100%;
    padding-top: unset;
}
.css-1mvajns {
    box-sizing: border-box;
    margin-right: 0px;
    margin-bottom: 0px;
    margin-left: 0px;
    min-width: 0px;
    font-weight: 500;
    font-size: 14px;
    line-height: 20px;
    color: rgb(30, 35, 41);
    margin-top: unset;
}
.sell_div_inner {
    box-sizing: border-box;
    margin: 8px 0px 0px;
    min-width: 0px;
    display: flex;
    width: 100%;
    flex-flow: column wrap;
    -webkit-box-pack: unset;
    justify-content: unset;
}
.sell_div_inner-row1 {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: justify;
    justify-content: space-between;
    width: 100%;
}
.sell_div_inner-row-title {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    font-weight: 400;
    font-size: 14px;
    line-height: 20px;
    color: rgb(30, 35, 41);
    width: 135px;
}
.css-1rzqh0 {
    box-sizing: border-box;
    margin: 0px;
    display: inline-flex;
    position: relative;
    -webkit-box-align: center;
    align-items: center;
    line-height: 1.6;
    height: 40px;
    background-color: rgb(245, 245, 245);
    border-radius: 4px;
    border-width: 1px;
    border-style: solid;
    border-color: transparent;
    min-width: unset;
    width: unset;
    flex: 0.9 1 0%;
}
.css-1rzqh0.bn-input-status-disabled > input {
    color: rgb(183, 189, 198);
}

.css-1rzqh0 input {
    cursor: not-allowed;
}

.css-1rzqh0 input {
    color: rgb(30, 35, 41);
    font-size: 14px;
    border-radius: 4px;
    padding-left: 12px;
    padding-right: 12px;
}

.css-16fg16t {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    width: 100%;
    height: 100%;
    padding: 0px;
    outline: none;
    border: none;
    background-color: inherit;
    opacity: 1;
}
.css-19rak99 {
    box-sizing: border-box;
    margin: 0px 20px 0px 0px;
    min-width: 0px;
    display: flex;
    -webkit-box-align: center;
    align-items: center;
}
.sell_div_inner-row-right-img {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    color: rgb(30, 35, 41);
    -webkit-box-align: center;
    align-items: center;
    display: inline-flex;
}
.css-i3htau {
    box-sizing: border-box;
    margin-top: 0px;
    margin-right: 0px;
    margin-bottom: 0px;
    min-width: 0px;
    font-weight: 500;
    font-size: 14px;
    line-height: 20px;
    margin-left: 4px !important;
}
.sell_div_inner-row3 {
    box-sizing: border-box;
    margin: 20px 0px 0px;
    min-width: 0px;
    display: flex;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: justify;
    justify-content: space-between;
    width: 100%;
}
.sell_div_inner-row3-btns-div {
    box-sizing: border-box;
    margin: 0px;
    display: flex;
    background-color: rgb(245, 245, 245);
    border-radius: 4px;
    height: 32px;
    min-width: unset;
    width: unset;
    padding: 0px;
    -webkit-box-align: center;
    align-items: center;
    flex: 0.9 1 0%;
    cursor: pointer;
}
.sell_div_inner-row3-btns {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: center;
    justify-content: center;
    padding-left: 4px;
    padding-right: 4px;
    flex: 1 1 auto;
    border-radius: 4px;
    height: 100%;
    color: rgb(30, 35, 41);
}
.chart_Calculator_crnt-price-txt {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    font-weight: 400;
    font-size: 12px;
    line-height: 16px;
}
.sell_div_inner-row3-btns.acitve {
    background-color: rgb(252, 213, 53);
    color: rgb(30, 35, 41);
    font-weight: 500;
}
.sell_div_inner-row2 {
    box-sizing: border-box;
    margin: 20px 0px 0px;
    min-width: 0px;
    display: flex;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: justify;
    justify-content: space-between;
    width: 100%;
}
.sell_div_inner-row-right {
    box-sizing: border-box;
    margin: 0px;
    display: flex;
    background-color: rgb(245, 245, 245);
    border-radius: 4px;
    height: 40px;
    min-width: unset;
    width: unset;
    padding: 8px 12px;
    -webkit-box-align: center;
    align-items: center;
    flex: 0.9 1 0%;
}
.sell_div_inner-row-target-coin {
    box-sizing: border-box;
    margin: 0px 0px 0px 4px;
    min-width: 0px;
    font-weight: 500;
    font-size: 14px;
    line-height: 20px;
    color: rgb(30, 35, 41);
}
.sell_div_inner-row-target-price {
    box-sizing: border-box;
    margin: 0px 0px 0px 4px;
    min-width: 0px;
    font-weight: 500;
    font-size: 16px;
    line-height: 24px;
    color: rgb(30, 35, 41);
}.css-5uedr7 {
    box-sizing: border-box;
    margin: 0px;
    display: inline-flex;
    position: relative;
    -webkit-box-align: center;
    align-items: center;
    line-height: 1.6;
    height: 40px;
    background-color: rgb(245, 245, 245);
    border-radius: 4px;
    border-width: 1px;
    border-style: solid;
    border-color: transparent;
    min-width: unset;
    width: unset;
    flex: 0.9 1 0%;
}
.css-5uedr7 input {
    cursor: text;
}

.css-5uedr7 input {
    color: rgb(30, 35, 41);
    font-size: 14px;
    border-radius: 4px;
    padding-left: 12px;
    padding-right: 12px;
}
.css-5uedr7 .wm-input-suffix {
    flex-shrink: 0;
    margin-left: 4px;
    margin-right: 4px;
    font-size: 14px;
}
.chart_Calculator_right_top {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    height: 101px;
    width: 74px;
    position: absolute;
    border-radius: 0px 10px 0px 0px;
    background-color: rgb(250, 250, 250);
    top: 0px;
    right: 0px;
    flex-direction: column;
    -webkit-box-pack: center;
    justify-content: center;
    padding-right: 8px;
    opacity: 1;
    text-align: right;
}
.chart_Calculator_list_dot {
    box-sizing: border-box;
    margin: 0px 4px 0px 0px;
    min-width: 0px;
    width: 5px;
    height: 5px;
    background-color: rgb(248, 211, 58);
    transform: rotate(45deg);
}
.chart_Calculator_title_right {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    font-weight: 400;
    font-size: 12px;
    line-height: 16px;
    color: rgb(24, 26, 32);
}
.chart_Calculator_title_-- {
    box-sizing: border-box;
    margin: 4px 0px 0px;
    min-width: 0px;
    font-weight: 400;
    font-size: 12px;
    line-height: 16px;
    color: rgb(2, 192, 118);
    text-align: right;
    word-break: break-word;
}
.chart_Calculator_img_div-coin {
    box-sizing: border-box;
    margin: 4px 0px 0px;
    min-width: 0px;
    color: rgb(30, 35, 41);
    -webkit-box-align: center;
    align-items: center;
    display: inline-flex;
}
.chart_Calculator_img_name {
    box-sizing: border-box;
    margin-top: 0px;
    margin-right: 0px;
    margin-bottom: 0px;
    min-width: 0px;
    font-size: 12px;
    line-height: 16px;
    margin-left: 4px !important;
}
.chart_Calculator_right_bottom {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    height: 101px;
    width: 74px;
    position: absolute;
    border-radius: 0px 0px 10px;
    background-color: rgb(250, 250, 250);
    bottom: 0px;
    right: 0px;
    flex-direction: column;
    -webkit-box-pack: center;
    justify-content: center;
    padding-right: 8px;
    opacity: 0.5;
    text-align: right;
}
.chart_Calculator_date {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    position: absolute;
    bottom: 0px;
    right: 82px;
    line-height: 16px;
    font-size: 10px;
    color: rgb(30, 35, 41);
}
.chart_Calculator_dot-1 {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    position: absolute;
    width: 8px;
    height: 8px;
    border: 1.5px solid rgb(248, 211, 58);
    background: rgb(255, 255, 255);
    border-radius: 50%;
    left: 139px;
    top: 75px;
}.chart_Calculator_dot-2 {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    position: absolute;
    width: 8px;
    height: 8px;
    border: 1.5px solid rgb(248, 211, 58);
    background: rgb(255, 255, 255);
    border-radius: 50%;
    left: 32px;
    top: 122px;
}.css-12wjg1g {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    flex-direction: row;
    -webkit-box-pack: center;
    justify-content: center;
    -webkit-box-align: center;
    align-items: center;
    padding: 4px;
    box-shadow: rgb(24 26 32 / 10%) 0px 0px 1px, rgb(71 77 87 / 8%) 0px 7px 14px, rgb(24 26 32 / 8%) 0px 3px 6px;
    border-radius: 4px;
    width: auto;
    position: absolute;
    background-color: rgb(255, 255, 255);
    z-index: 1;
    transform: translate(-50%, -130%);
    white-space: nowrap;
    left: 139px;
    top: 75px;
}.chart_Calculator_crrnt_div {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    flex-direction: row;
    -webkit-box-pack: center;
    justify-content: center;
    -webkit-box-align: center;
    align-items: center;
    padding: 4px;
    box-shadow: rgb(24 26 32 / 10%) 0px 0px 1px, rgb(71 77 87 / 8%) 0px 7px 14px, rgb(24 26 32 / 8%) 0px 3px 6px;
    border-radius: 4px;
    width: auto;
    position: absolute;
    background-color: rgb(255, 255, 255);
    z-index: 1;
    transform: translate(-50%, 50%);
    white-space: nowrap;
    left: 32px;
    top: 122px;
}
.return_div_2222{
    display:none;
}
@media screen and (min-width: 767px){
    .return_div_2222{
    display:block;
}
    .chart_Calculator_div{
        margin:0px;
    }
    .css-12wjg1g {
    left: 139px;
    top: 75px;
}
    .chart_Calculator_date {
    right: 82px;
    font-size: 12px;
}
    .css-5uedr7 {
    min-width: 212px;
    width: unset;
    flex: 0.9 1 0%;
}
    .css-1mvajns {
    margin-top: 32px;
}
.Return_Calculator_div {
    flex-direction: column;
}
.chart_Calculator_div-main-inner {
    width: 320px;
    border-radius: unset;
    margin-top: unset;
    margin-bottom: unset;
}
.chart_Calculator_div-inner {
    width: 74px;
}.chart_Calculator_right {
    width: 246px;
    border-radius: unset;
}
  
  .cal_div_return-inner {
    width: 100%;
    /*padding: 8px 35px;*/
    /*flex: 1 1 0%;*/
    /*margin-left: 14px;*/
    /*height: 299px;*/
}  
    .css-1065ayc {
    padding-top: unset;
     width: 100%;
}
.sell_div_inner {
    margin-top: 24px;
    width: 100%;
    flex-direction: row;
    -webkit-box-pack: justify;
    justify-content: space-between;
}
.sell_div_inner-row1 {
    width: 49%;
}.css-1rzqh0 {
    min-width: 212px;
    width: unset;
    flex: 0.9 1 0%;
}.sell_div_inner-row3 {
    width: 49%;
}.sell_div_inner-row3-btns-div {
    min-width: 212px;
    width: unset;
    flex: 0.9 1 0%;
}
.sell_div_inner-row2 {
    margin-top: unset;
    width: 49%;
}
.sell_div_inner-row-right {
    min-width: 212px;
    width: unset;
    flex: 0.9 1 0%;
}
.chart_Calculator_dot-1 {
    left: 139px;
    top: 75px;
}.chart_Calculator_dot-2 {
    left: 32px;
    top: 122px;
}
.chart_Calculator_crrnt_div {
    left: 32px;
    top: 122px;
}
#apend_div{
        display: flex;
    padding: 10px;
    width: 100%;
    justify-content: space-between;
    margin-top: 25px;
    margin-bottom: 30px;
    }
    #apend_div #apend_div_child-2.cal_div_return{
        width: 390px;
    padding: 8px 0px;
    flex: 1 1 0%;
    margin-left: 14px;
    height: 239px;
    }
}
    
@media screen and (min-width: 1279px){
    #apend_div{
        display:none;
    }
    .css-12wjg1g {
    left: 218px;
    top: 62px;
}
.chart_Calculator_crrnt_div {
    left: 60px;
    top: 132px;
}
    .chart_Calculator_dot-2 {
    left: 60px;
    top: 132px;
}
    .chart_Calculator_dot-1 {
    left: 218px;
    top: 62px;
}
    .css-5uedr7 {
    min-width: unset;
    width: 212px;
    flex: unset;
}
    .sell_div_inner-row-right {
    min-width: unset;
    width: 212px;
    flex: unset;
}
    .sell_div_inner-row2 {
    margin-top: 20px;
    width: 100%;
}
    .sell_div_inner-row3-btns-div {
    min-width: unset;
    width: 212px;
    flex: unset;
}
    .sell_div_inner-row3 {
    width: 100%;
}
    .css-1rzqh0 {
    min-width: unset;
    width: 212px;
    flex: unset;
}
    .sell_div_inner-row1 {
    width: 100%;
}
    .sell_div_inner {
    width: 357px;
    flex-direction: column;
    -webkit-box-pack: unset;
    justify-content: unset;
}
    .css-1mvajns {
    margin-top: unset;
}
    .css-1065ayc {
        padding:0px 15px;
    padding-top: 16px;
    width: 100%;
}
    .cal_div_return-inner {
    width: 352px;
    padding: 16px;
    flex: unset;
    margin-left: unset;
    height: 316px;
}
    .chart_Calculator_crrnt_div {
    left: 60px;
    top: 132px;
}
    .chart_Calculator_right {
    width: 354px;
    border-radius: 0px 10px 10px 0px;
}
.Return_Calculator_div {
    flex-direction: row;
}
.chart_Calculator_div-main-inner {
    width: 432px;
    border-radius: 10px;
}
.chart_Calculator_div-inner {
    width: 78px;
}
.chart_Calculator_date {
    right: 87px;
}
}

.css-1rzqh0.bn-input-status-disabled {
    background-color: rgb(234, 236, 239);
    opacity: 0.7;
}
.return_cal_deading_div{
    display:flex;
    justify-content:space-between;
    flex-direction:row;
    align-items: end;
}
@media screen and (max-width: 768px){
#more_coin_div.hide{
    display:block !important;
}
    .hide-max-768{
        display:none !important;
    }
    
    .return_cal_deading_div{
        flex-direction:column;
    }
}

#calculate_coin #apend_div_child-1, #calculate_coin #apend_div_child-2 , #calculate_coin #apend_div_child-3{
    display:block !important;
}

 </style>
  
  
   </head>
   
 <body class="bg-white">
     
     @include('template.mobile_menu')
        @include('template.web_menu')
    
            <section class="auto-invesment">
     <div class="container">
         <div class="row align-items-center justify-content-center" >
             <div class="col-md-8 col-sm-12 col-xs-12">
                <div class="sec-title text-left mb-3">
                            <span class="title">Welcome to Wealthmark</span>
                            <h2 class="heading-h2 text-white mt-0">Dual Investment</h2>
                            <div class="text text-left text-white mt-0">Monetize your market view and get access to potentially high rewards</div>
                        </div>
                     <div class="auto-invesment-top-row">
                          
                          <div class="detail">
                              <i class="bi bi-check2 auto-invesment-check"></i>
                              Buy Low or Sell High</div>
                          
                          <div class="detail">
                              <i class="bi bi-check2 auto-invesment-check"></i>
                              Wide Selection</div>
                        
                          <div class="detail">
                               <i class="bi bi-check2 auto-invesment-check"></i>
                               No Trading Fees</div>
                         
                          <div class="detail">
                               <i class="bi bi-check2 auto-invesment-check"></i>
                               High Rewards</div>
                    </div>   
                 
             </div>
              <div class="col-md-4 col-sm-5 col-xs-12">
                 <div class="asset-overview login-box-main">
                          <div class="login-box-bg">
                            <div class="login-box">
                              <img src="{{ asset('public/assets/img/account.png') }}" class="login-box-img">
                              <div class="login-box-txt">Log in to view holding details</div>
                              <button type="button" class="btn btn-yellow">Log In</button>
                            </div>
                          </div>
                        </div>
                  </div>
             
         </div>
         </div>
         </section>
    
            <div class="bg-white pt-2 pb-2">
        <div class="container">
            <div class="dual-inv-top-row">
  <div class="dual-inv-top-row-inner">
    <div class="dual-inv-top-row-inner-left">
      <div class="avbl-coin-text">Available Coins</div>
      <div class="dual-inv-avbl-coin">
        <img class="dual-inv-avbl-coin-img" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}">
      </div>
      <div class="dual-inv-avbl-coin">
        <img class="dual-inv-avbl-coin-img" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}">
      </div>
      <div class="dual-inv-avbl-coin">
        <img class="dual-inv-avbl-coin-img" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}">
      </div>
      <div class="dual-inv-avbl-coin">
        <img class="dual-inv-avbl-coin-img" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}">
      </div>
      <div class="dual-inv-avbl-coin">
        <img class="dual-inv-avbl-coin-img" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}">
      </div>
      <div class="dual-inv-avbl-coin">
        <img class="dual-inv-avbl-coin-img" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}">
      </div>
      <div class="dual-inv-avbl-coin">
        <img class="dual-inv-avbl-coin-img" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}">
      </div>
      <span class="dual-inv-avbl-coin-more">+7</span>
    </div>
    <div class="dual-inv-top-row-inner-right">
      <button type="button" class=" dual-tutorial-btn">
        
        
            <div class="dual-svg-video-div">
              <svg  viewBox="0 0 24 24" fill="none" class="dual-svg-video">
                <path d="M12 3.35c-4.8 0-8.8 3.9-8.8 8.8 0 4.8 3.9 8.8 8.8 8.8s8.8-3.9 8.8-8.8c0-4.8-4-8.8-8.8-8.8zm0 15.6c-3.7 0-6.8-3-6.8-6.8 0-3.7 3-6.8 6.8-6.8s6.8 3 6.8 6.8c0 3.7-3.1 6.8-6.8 6.8z" fill="currentColor"></path>
                <path d="M16.5 12.15l-6.8-3.9v7.8l6.8-3.9z" fill="currentColor"></path>
              </svg>Tutorial
           
          
        </div>
      </button>
      <button type="button" class=" dual-learn-btn">
        <a href="#" target="_blank" class="dual-learn-text">Learn More</a>
      </button>
      <div class="dual-faq-btn">FAQ</div>
    </div>
  </div>
</div>
        </div>
    </div>
    
    
            <section class="bg-light-blue">
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-sm-6 col-xs-12">
                     <h3 class="title">
                Step 1: Choose an asset
            </h3>
                </div>
                <div class="col-md-4 col-sm-6 col-xs-12 text-right ">
                   <div class="switch-box d-flex align-items-center justify-content-end">
                   <span>Beginner Mode</span>
                            <label class="switch">
                              <input type="checkbox" class="switch_input" checked/>
                             <div></div>
                            </label>
                </div>

                </div>
            </div>
            <div class="row">
                <div class="col-md-4 col-sm-6 col-xs-12 pt-4 mb-4">
                     <div class="custom-modal-search-div m-0">
                <svg viewBox="0 0 24 24" fill="none" class="custom-modal-search-icn">
                  <path fill-rule="evenodd" clip-rule="evenodd" d="M11 6a5 5 0 110 10 5 5 0 010-10zm0-3a8 8 0 017.021 11.838l3.07 3.07-1.59 1.591-1.591 1.591-3.07-3.07A8 8 0 1111 3z" fill="currentColor"></path>
                </svg>
                <input type="text" id="coinModalInput" placeholder="Search Coin" class="custom-modal-search-input" value="">
      </div>
                </div>
            </div>
           <div class="row">
               <div class="col-md-12 open show" id="coin_opt_desk">
               <div class="di-coin-list-div">
                  <div class="di-coin-list-active">
                    <img src="{{ asset('public/assets/img/wm-card_tick.svg') }}" class="di-coin-list-img-tick">
                    <div class="di-coin-list-title-div">
                      <div class="di-coin-list-img-content">
                        <img class="di-coin-list-img-coin" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}">
                        <div class="di-coin-list-name-coin">BTC</div>
                      </div>
                      <img src="{{ asset('public/assets/img/wm-hot.svg') }}" class="di-coin-list-img-hot">
                    </div>
                    <div class="di-coin-list-sts">
                      <div class="di-coin-list-sts-apr">
                        <div class="d-flex">APR</div>
                        <div class="di-coin-list-sts-apr-sb">4.00%~84.48%</div>
                      </div>
                      <div class="di-coin-list-sts-apr">
                        <div class="d-flex">Current Price</div>
                        <div class="di-coin-list-sts-crrnt">16,583</div>
                      </div>
                    </div>
                  </div>
                  <div class="di-coin-list">
                  <img src="{{ asset('public/assets/img/wm-not_selected_tick.svg') }}" class="di-coin-list-img-tick">
                    <div class="di-coin-list-title-div">
                      <div class="di-coin-list-img-content">
                        <img class="di-coin-list-img-coin" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}">
                        <div class="di-coin-list-name-coin">BTC</div>
                      </div>
                      <img src="{{ asset('public/assets/img/wm-hot.svg') }}" class="di-coin-list-img-hot">
                    </div>
                    <div class="di-coin-list-sts">
                      <div class="di-coin-list-sts-apr">
                        <div class="d-flex">APR</div>
                        <div class="di-coin-list-sts-apr-sb">4.00%~84.48%</div>
                      </div>
                      <div class="di-coin-list-sts-apr">
                        <div class="d-flex">Current Price</div>
                        <div class="di-coin-list-sts-crrnt">16,583</div>
                      </div>
                    </div>
                  </div>
                   <div class="di-coin-list">
                  <img src="{{ asset('public/assets/img/wm-not_selected_tick.svg') }}" class="di-coin-list-img-tick">
                    <div class="di-coin-list-title-div">
                      <div class="di-coin-list-img-content">
                        <img class="di-coin-list-img-coin" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}">
                        <div class="di-coin-list-name-coin">BTC</div>
                      </div>
                      <img src="{{ asset('public/assets/img/wm-hot.svg') }}" class="di-coin-list-img-hot">
                    </div>
                    <div class="di-coin-list-sts">
                      <div class="di-coin-list-sts-apr">
                        <div class="d-flex">APR</div>
                        <div class="di-coin-list-sts-apr-sb">4.00%~84.48%</div>
                      </div>
                      <div class="di-coin-list-sts-apr">
                        <div class="d-flex">Current Price</div>
                        <div class="di-coin-list-sts-crrnt">16,583</div>
                      </div>
                    </div>
                  </div>
                  <div class="di-coin-list">
                  <img src="{{ asset('public/assets/img/wm-not_selected_tick.svg') }}" class="di-coin-list-img-tick">
                    <div class="di-coin-list-title-div">
                      <div class="di-coin-list-img-content">
                        <img class="di-coin-list-img-coin" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}">
                        <div class="di-coin-list-name-coin">BTC</div>
                      </div>
                      <img src="{{ asset('public/assets/img/wm-hot.svg') }}" class="di-coin-list-img-hot">
                    </div>
                    <div class="di-coin-list-sts">
                      <div class="di-coin-list-sts-apr">
                        <div class="d-flex">APR</div>
                        <div class="di-coin-list-sts-apr-sb">4.00%~84.48%</div>
                      </div>
                      <div class="di-coin-list-sts-apr">
                        <div class="d-flex">Current Price</div>
                        <div class="di-coin-list-sts-crrnt">16,583</div>
                      </div>
                    </div>
                  </div>
                  <div class="di-coin-list">
                  <img src="{{ asset('public/assets/img/wm-not_selected_tick.svg') }}" class="di-coin-list-img-tick">
                    <div class="di-coin-list-title-div">
                      <div class="di-coin-list-img-content">
                        <img class="di-coin-list-img-coin" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}">
                        <div class="di-coin-list-name-coin">BTC</div>
                      </div>
                      <img src="{{ asset('public/assets/img/wm-hot.svg') }}" class="di-coin-list-img-hot">
                    </div>
                    <div class="di-coin-list-sts">
                      <div class="di-coin-list-sts-apr">
                        <div class="d-flex">APR</div>
                        <div class="di-coin-list-sts-apr-sb">4.00%~84.48%</div>
                      </div>
                      <div class="di-coin-list-sts-apr">
                        <div class="d-flex">Current Price</div>
                        <div class="di-coin-list-sts-crrnt">16,583</div>
                      </div>
                    </div>
                  </div>
                  <div class="di-coin-list">
                  <img src="{{ asset('public/assets/img/wm-not_selected_tick.svg') }}" class="di-coin-list-img-tick">
                    <div class="di-coin-list-title-div">
                      <div class="di-coin-list-img-content">
                        <img class="di-coin-list-img-coin" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}">
                        <div class="di-coin-list-name-coin">BTC</div>
                      </div>
                      <img src="{{ asset('public/assets/img/wm-hot.svg') }}" class="di-coin-list-img-hot">
                    </div>
                    <div class="di-coin-list-sts">
                      <div class="di-coin-list-sts-apr">
                        <div class="d-flex">APR</div>
                        <div class="di-coin-list-sts-apr-sb">4.00%~84.48%</div>
                      </div>
                      <div class="di-coin-list-sts-apr">
                        <div class="d-flex">Current Price</div>
                        <div class="di-coin-list-sts-crrnt">16,583</div>
                      </div>
                    </div>
                  </div>
                  
                </div>
             </div>
             <div class="col-md-12 p-4 border mb-4 bg-white open hide" id="more_coin_div">
                
                    <div class="row">
                        <div class="col-md-6 col-sm-12 col-xs-12 ">
                            <div class="table-responsive" style="">
                      <table class="wm-table">
                       
                        <thead style="">
                          <tr>
                            <th class="stickyTop"></th>
                            <th class="stickyTop" style="text-align:start">
                              <div class="broker-tb-first-th">
                                <div class="wm-tbl-column-div">
                                  <p class="wm-tbl-column-title ">#</p>
                                  <span class=" space-width"></span>
                                </div>
                              </div>
                            </th>
                            <th class="stickyTop" style="text-align:start">
                              <div class="broker-tb-first-th">
                                <div class="wm-tbl-column-div">
                                  <p class="wm-tbl-column-title">Name</p>
                                  <span class=" space-width"></span>
                                </div>
                              </div>
                            </th>
                            <th class="stickyTop" style="text-align:end">
                              <div class="bGlLSM">
                                <div class="wm-tbl-column-div">
                                  <span class=" space-width"></span>
                                  <p class="wm-tbl-column-title">Price</p>
                                </div>
                              </div>
                            </th>
                           
                            <th class="stickyTop" style="text-align:end">
                              <div>
                                <div class="bGlLSM">
                                  <div class="wm-tbl-column-div">
                                    <span class=" space-width"></span>
                                    <p class="wm-tbl-column-title">24h %</p>
                                  </div>
                                </div>
                              </div>
                            </th>
                           
                           
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            <td>
                              <span>
                                <span class="wm-tbl-str-div">
                                  <span class="icon-Star" style="color: #a6b0c3 ;"></span>
                                </span>
                              </span>
                            </td>
                            <td style="text-align: start;">
                              <p color="text2" class="wm-tbl-broker-vol-sub">1</p>
                            </td>
                            <td style="text-align: start;" class="">
                              <div class="d-flex align-items-center">
                                <a href="#" class="wm-link">
                                  <div class="broker-tbl-coin-div-main">
                                    <img class="coin-logo" src="{{ asset('public/assets/img/87496d50-2408-43e1-ad4c-78b47b448a6a.png') }} " loading="lazy" alt="BTC logo">
                                    <div class="name-area ">
                                      <p class="broker-tbl-coin-title">Bitcoin</p>
                                      <div class="coin-item-symbol-div">
                                        <div class="coin-nm-mob">1</div>
                                        <p color="text3" class="coin-nm-color coin-item-symbol">BTC</p>
                                      </div>
                                    </div>
                                  </div>
                                </a>
                              </div>
                            </td>
                            <td style="text-align: end;">
                              <div class="">
                                <a href="#" class="wm-link">
                                  <span>$16,833.51</span>
                                </a>
                              </div>
                            </td>
                           
                            <td style="text-align: end;">
                              <span class="broker-tbl-price-up">
                                <span class="icon-Caret-up"></span>0.27% </span>
                            </td>
                           
                           
                          </tr>
                         
                          <tr>
                            <td>
                              <span>
                                <span class="wm-tbl-str-div">
                                  <span class="icon-Star" style="color: #a6b0c3 ;"></span>
                                </span>
                              </span>
                            </td>
                            <td style="text-align: start;">
                              <p color="text2" class="wm-tbl-broker-vol-sub">2</p>
                            </td>
                            <td style="text-align: start;" class="">
                              <div class="d-flex align-items-center">
                                <a href="#" class="wm-link">
                                  <div class="broker-tbl-coin-div-main">
                                    <img class="coin-logo" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}" alt="BNB logo">
                                    <div class="name-area ">
                                      <p class="broker-tbl-coin-title">BNB</p>
                                      <div class="coin-item-symbol-div">
                                        <div class="coin-nm-mob">4</div>
                                        <p color="text3" class="coin-nm-color coin-item-symbol">BNB</p>
                                      </div>
                                    </div>
                                  </div>
                                </a>
                              </div>
                            </td>
                            <td style="text-align: end;">
                              <div class="rise">
                                <a href="#" class="wm-link">
                                  <span>$279.42</span>
                                </a>
                              </div>
                            </td>
                           
                            <td style="text-align: end;">
                              <span class="broker-tbl-price-down">
                                <span class="icon-Caret-down"></span>0.39% </span>
                            </td>
                           
                          </tr>
                          <tr>
                            <td>
                              <span>
                                <span class="wm-tbl-str-div">
                                  <span class="icon-Star" style="color: #a6b0c3 ;"></span>
                                </span>
                              </span>
                            </td>
                            <td style="text-align: start;">
                              <p color="text2" class="wm-tbl-broker-vol-sub">3</p>
                            </td>
                            <td style="text-align: start;" class="">
                              <div class="d-flex align-items-center">
                                <a href="#" class="wm-link">
                                  <div class="broker-tbl-coin-div-main">
                                    <img class="coin-logo" src="{{ asset('public/assets/img/87496d50-2408-43e1-ad4c-78b47b448a6a.png') }} " loading="lazy" alt="BTC logo">
                                    <div class="name-area ">
                                      <p class="broker-tbl-coin-title">Bitcoin</p>
                                      <div class="coin-item-symbol-div">
                                        <div class="coin-nm-mob">1</div>
                                        <p color="text3" class="coin-nm-color coin-item-symbol">BTC</p>
                                      </div>
                                    </div>
                                  </div>
                                </a>
                              </div>
                            </td>
                            <td style="text-align: end;">
                              <div class="">
                                <a href="#" class="wm-link">
                                  <span>$16,833.51</span>
                                </a>
                              </div>
                            </td>
                           
                            <td style="text-align: end;">
                              <span class="broker-tbl-price-up">
                                <span class="icon-Caret-up"></span>0.27% </span>
                            </td>
                           
                          </tr>
                         
                          <tr>
                            <td>
                              <span>
                                <span class="wm-tbl-str-div">
                                  <span class="icon-Star" style="color: #a6b0c3 ;"></span>
                                </span>
                              </span>
                            </td>
                            <td style="text-align: start;">
                              <p color="text2" class="wm-tbl-broker-vol-sub">4</p>
                            </td>
                            <td style="text-align: start;" class="">
                              <div class="d-flex align-items-center">
                                <a href="#" class="wm-link">
                                  <div class="broker-tbl-coin-div-main">
                                    <img class="coin-logo" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}" alt="BNB logo">
                                    <div class="name-area ">
                                      <p class="broker-tbl-coin-title">BNB</p>
                                      <div class="coin-item-symbol-div">
                                        <div class="coin-nm-mob">4</div>
                                        <p color="text3" class="coin-nm-color coin-item-symbol">BNB</p>
                                      </div>
                                    </div>
                                  </div>
                                </a>
                              </div>
                            </td>
                            <td style="text-align: end;">
                              <div class="rise">
                                <a href="#" class="wm-link">
                                  <span>$279.42</span>
                                </a>
                              </div>
                            </td>
                            
                            
                            
                            <td style="text-align: end;">
                              <span class="broker-tbl-price-down">
                                <span class="icon-Caret-down"></span>0.39% </span>
                            </td>
                           
                          </tr>
                          <tr>
                            <td>
                              <span>
                                <span class="wm-tbl-str-div">
                                  <span class="icon-Star" style="color: #a6b0c3 ;"></span>
                                </span>
                              </span>
                            </td>
                            <td style="text-align: start;">
                              <p color="text2" class="wm-tbl-broker-vol-sub">5</p>
                            </td>
                            <td style="text-align: start;" class="">
                              <div class="d-flex align-items-center">
                                <a href="#" class="wm-link">
                                  <div class="broker-tbl-coin-div-main">
                                    <img class="coin-logo" src="{{ asset('public/assets/img/87496d50-2408-43e1-ad4c-78b47b448a6a.png') }} " loading="lazy" alt="BTC logo">
                                    <div class="name-area ">
                                      <p class="broker-tbl-coin-title">Bitcoin</p>
                                      <div class="coin-item-symbol-div">
                                        <div class="coin-nm-mob">1</div>
                                        <p color="text3" class="coin-nm-color coin-item-symbol">BTC</p>
                                      </div>
                                    </div>
                                  </div>
                                </a>
                              </div>
                            </td>
                            <td style="text-align: end;">
                              <div class="">
                                <a href="#" class="wm-link">
                                  <span>$16,833.51</span>
                                </a>
                              </div>
                            </td>
                           
                            <td style="text-align: end;">
                              <span class="broker-tbl-price-up">
                                <span class="icon-Caret-up"></span>0.27% </span>
                            </td>
                           
                          </tr>
                         
                          <tr>
                            <td>
                              <span>
                                <span class="wm-tbl-str-div">
                                  <span class="icon-Star" style="color: #a6b0c3 ;"></span>
                                </span>
                              </span>
                            </td>
                            <td style="text-align: start;">
                              <p color="text2" class="wm-tbl-broker-vol-sub">6</p>
                            </td>
                            <td style="text-align: start;" class="">
                              <div class="d-flex align-items-center">
                                <a href="#" class="wm-link">
                                  <div class="broker-tbl-coin-div-main">
                                    <img class="coin-logo" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}" alt="BNB logo">
                                    <div class="name-area ">
                                      <p class="broker-tbl-coin-title">BNB</p>
                                      <div class="coin-item-symbol-div">
                                        <div class="coin-nm-mob">4</div>
                                        <p color="text3" class="coin-nm-color coin-item-symbol">BNB</p>
                                      </div>
                                    </div>
                                  </div>
                                </a>
                              </div>
                            </td>
                            <td style="text-align: end;">
                              <div class="rise">
                                <a href="#" class="wm-link">
                                  <span>$279.42</span>
                                </a>
                              </div>
                            </td>
                           
                           
                           
                            <td style="text-align: end;">
                              <span class="broker-tbl-price-down">
                                <span class="icon-Caret-down"></span>0.39% </span>
                            </td>
                          
                           
                          </tr>
                          <tr>
                            <td>
                              <span>
                                <span class="wm-tbl-str-div">
                                  <span class="icon-Star" style="color: #a6b0c3 ;"></span>
                                </span>
                              </span>
                            </td>
                            <td style="text-align: start;">
                              <p color="text2" class="wm-tbl-broker-vol-sub">7</p>
                            </td>
                            <td style="text-align: start;" class="">
                              <div class="d-flex align-items-center">
                                <a href="#" class="wm-link">
                                  <div class="broker-tbl-coin-div-main">
                                    <img class="coin-logo" src="{{ asset('public/assets/img/87496d50-2408-43e1-ad4c-78b47b448a6a.png') }} " loading="lazy" alt="BTC logo">
                                    <div class="name-area ">
                                      <p class="broker-tbl-coin-title">Bitcoin</p>
                                      <div class="coin-item-symbol-div">
                                        <div class="coin-nm-mob">1</div>
                                        <p color="text3" class="coin-nm-color coin-item-symbol">BTC</p>
                                      </div>
                                    </div>
                                  </div>
                                </a>
                              </div>
                            </td>
                            <td style="text-align: end;">
                              <div class="">
                                <a href="#" class="wm-link">
                                  <span>$16,833.51</span>
                                </a>
                              </div>
                            </td>
                          
                            <td style="text-align: end;">
                              <span class="broker-tbl-price-up">
                                <span class="icon-Caret-up"></span>0.27% </span>
                            </td>
                           
                          </tr>
                         
                          <tr>
                            <td>
                              <span>
                                <span class="wm-tbl-str-div">
                                  <span class="icon-Star" style="color: #a6b0c3 ;"></span>
                                </span>
                              </span>
                            </td>
                            <td style="text-align: start;">
                              <p color="text2" class="wm-tbl-broker-vol-sub">8</p>
                            </td>
                            <td style="text-align: start;" class="">
                              <div class="d-flex align-items-center">
                                <a href="#" class="wm-link">
                                  <div class="broker-tbl-coin-div-main">
                                    <img class="coin-logo" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}" alt="BNB logo">
                                    <div class="name-area ">
                                      <p class="broker-tbl-coin-title">BNB</p>
                                      <div class="coin-item-symbol-div">
                                        <div class="coin-nm-mob">4</div>
                                        <p color="text3" class="coin-nm-color coin-item-symbol">BNB</p>
                                      </div>
                                    </div>
                                  </div>
                                </a>
                              </div>
                            </td>
                            <td style="text-align: end;">
                              <div class="rise">
                                <a href="#" class="wm-link">
                                  <span>$279.42</span>
                                </a>
                              </div>
                            </td>
                           
                           
                            <td style="text-align: end;">
                              <span class="broker-tbl-price-down">
                                <span class="icon-Caret-down"></span>0.39% </span>
                            </td>
                           
                          </tr>
                          
                        
                        </tbody>
                      </table>
                    </div>
                        </div>
                           <div class="col-md-6 col-sm-12 col-xs-12 d-md-block d-sm-none">
                            <div class="table-responsive" style="">
                      <table class="wm-table">
                       
                        <thead style="">
                          <tr>
                            <th class="stickyTop"></th>
                            <th class="stickyTop" style="text-align:start">
                              <div class="broker-tb-first-th">
                                <div class="wm-tbl-column-div">
                                  <p class="wm-tbl-column-title ">#</p>
                                  <span class=" space-width"></span>
                                </div>
                              </div>
                            </th>
                            <th class="stickyTop" style="text-align:start">
                              <div class="broker-tb-first-th">
                                <div class="wm-tbl-column-div">
                                  <p class="wm-tbl-column-title">Name</p>
                                  <span class=" space-width"></span>
                                </div>
                              </div>
                            </th>
                            <th class="stickyTop" style="text-align:end">
                              <div class="bGlLSM">
                                <div class="wm-tbl-column-div">
                                  <span class=" space-width"></span>
                                  <p class="wm-tbl-column-title">Price</p>
                                </div>
                              </div>
                            </th>
                           
                            <th class="stickyTop" style="text-align:end">
                              <div>
                                <div class="bGlLSM">
                                  <div class="wm-tbl-column-div">
                                    <span class=" space-width"></span>
                                    <p class="wm-tbl-column-title">24h %</p>
                                  </div>
                                </div>
                              </div>
                            </th>
                           
                           
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            <td>
                              <span>
                                <span class="wm-tbl-str-div">
                                  <span class="icon-Star" style="color: #a6b0c3 ;"></span>
                                </span>
                              </span>
                            </td>
                            <td style="text-align: start;">
                              <p color="text2" class="wm-tbl-broker-vol-sub">1</p>
                            </td>
                            <td style="text-align: start;" class="">
                              <div class="d-flex align-items-center">
                                <a href="#" class="wm-link">
                                  <div class="broker-tbl-coin-div-main">
                                    <img class="coin-logo" src="{{ asset('public/assets/img/87496d50-2408-43e1-ad4c-78b47b448a6a.png') }} " loading="lazy" alt="BTC logo">
                                    <div class="name-area ">
                                      <p class="broker-tbl-coin-title">Bitcoin</p>
                                      <div class="coin-item-symbol-div">
                                        <div class="coin-nm-mob">1</div>
                                        <p color="text3" class="coin-nm-color coin-item-symbol">BTC</p>
                                      </div>
                                    </div>
                                  </div>
                                </a>
                              </div>
                            </td>
                            <td style="text-align: end;">
                              <div class="">
                                <a href="#" class="wm-link">
                                  <span>$16,833.51</span>
                                </a>
                              </div>
                            </td>
                           
                            <td style="text-align: end;">
                              <span class="broker-tbl-price-up">
                                <span class="icon-Caret-up"></span>0.27% </span>
                            </td>
                           
                           
                          </tr>
                         
                          <tr>
                            <td>
                              <span>
                                <span class="wm-tbl-str-div">
                                  <span class="icon-Star" style="color: #a6b0c3 ;"></span>
                                </span>
                              </span>
                            </td>
                            <td style="text-align: start;">
                              <p color="text2" class="wm-tbl-broker-vol-sub">2</p>
                            </td>
                            <td style="text-align: start;" class="">
                              <div class="d-flex align-items-center">
                                <a href="#" class="wm-link">
                                  <div class="broker-tbl-coin-div-main">
                                    <img class="coin-logo" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}" alt="BNB logo">
                                    <div class="name-area ">
                                      <p class="broker-tbl-coin-title">BNB</p>
                                      <div class="coin-item-symbol-div">
                                        <div class="coin-nm-mob">4</div>
                                        <p color="text3" class="coin-nm-color coin-item-symbol">BNB</p>
                                      </div>
                                    </div>
                                  </div>
                                </a>
                              </div>
                            </td>
                            <td style="text-align: end;">
                              <div class="rise">
                                <a href="#" class="wm-link">
                                  <span>$279.42</span>
                                </a>
                              </div>
                            </td>
                           
                            <td style="text-align: end;">
                              <span class="broker-tbl-price-down">
                                <span class="icon-Caret-down"></span>0.39% </span>
                            </td>
                           
                          </tr>
                          <tr>
                            <td>
                              <span>
                                <span class="wm-tbl-str-div">
                                  <span class="icon-Star" style="color: #a6b0c3 ;"></span>
                                </span>
                              </span>
                            </td>
                            <td style="text-align: start;">
                              <p color="text2" class="wm-tbl-broker-vol-sub">3</p>
                            </td>
                            <td style="text-align: start;" class="">
                              <div class="d-flex align-items-center">
                                <a href="#" class="wm-link">
                                  <div class="broker-tbl-coin-div-main">
                                    <img class="coin-logo" src="{{ asset('public/assets/img/87496d50-2408-43e1-ad4c-78b47b448a6a.png') }} " loading="lazy" alt="BTC logo">
                                    <div class="name-area ">
                                      <p class="broker-tbl-coin-title">Bitcoin</p>
                                      <div class="coin-item-symbol-div">
                                        <div class="coin-nm-mob">1</div>
                                        <p color="text3" class="coin-nm-color coin-item-symbol">BTC</p>
                                      </div>
                                    </div>
                                  </div>
                                </a>
                              </div>
                            </td>
                            <td style="text-align: end;">
                              <div class="">
                                <a href="#" class="wm-link">
                                  <span>$16,833.51</span>
                                </a>
                              </div>
                            </td>
                           
                            <td style="text-align: end;">
                              <span class="broker-tbl-price-up">
                                <span class="icon-Caret-up"></span>0.27% </span>
                            </td>
                           
                          </tr>
                         
                          <tr>
                            <td>
                              <span>
                                <span class="wm-tbl-str-div">
                                  <span class="icon-Star" style="color: #a6b0c3 ;"></span>
                                </span>
                              </span>
                            </td>
                            <td style="text-align: start;">
                              <p color="text2" class="wm-tbl-broker-vol-sub">4</p>
                            </td>
                            <td style="text-align: start;" class="">
                              <div class="d-flex align-items-center">
                                <a href="#" class="wm-link">
                                  <div class="broker-tbl-coin-div-main">
                                    <img class="coin-logo" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}" alt="BNB logo">
                                    <div class="name-area ">
                                      <p class="broker-tbl-coin-title">BNB</p>
                                      <div class="coin-item-symbol-div">
                                        <div class="coin-nm-mob">4</div>
                                        <p color="text3" class="coin-nm-color coin-item-symbol">BNB</p>
                                      </div>
                                    </div>
                                  </div>
                                </a>
                              </div>
                            </td>
                            <td style="text-align: end;">
                              <div class="rise">
                                <a href="#" class="wm-link">
                                  <span>$279.42</span>
                                </a>
                              </div>
                            </td>
                            
                            
                            
                            <td style="text-align: end;">
                              <span class="broker-tbl-price-down">
                                <span class="icon-Caret-down"></span>0.39% </span>
                            </td>
                           
                          </tr>
                          <tr>
                            <td>
                              <span>
                                <span class="wm-tbl-str-div">
                                  <span class="icon-Star" style="color: #a6b0c3 ;"></span>
                                </span>
                              </span>
                            </td>
                            <td style="text-align: start;">
                              <p color="text2" class="wm-tbl-broker-vol-sub">5</p>
                            </td>
                            <td style="text-align: start;" class="">
                              <div class="d-flex align-items-center">
                                <a href="#" class="wm-link">
                                  <div class="broker-tbl-coin-div-main">
                                    <img class="coin-logo" src="{{ asset('public/assets/img/87496d50-2408-43e1-ad4c-78b47b448a6a.png') }} " loading="lazy" alt="BTC logo">
                                    <div class="name-area ">
                                      <p class="broker-tbl-coin-title">Bitcoin</p>
                                      <div class="coin-item-symbol-div">
                                        <div class="coin-nm-mob">1</div>
                                        <p color="text3" class="coin-nm-color coin-item-symbol">BTC</p>
                                      </div>
                                    </div>
                                  </div>
                                </a>
                              </div>
                            </td>
                            <td style="text-align: end;">
                              <div class="">
                                <a href="#" class="wm-link">
                                  <span>$16,833.51</span>
                                </a>
                              </div>
                            </td>
                           
                            <td style="text-align: end;">
                              <span class="broker-tbl-price-up">
                                <span class="icon-Caret-up"></span>0.27% </span>
                            </td>
                           
                          </tr>
                         
                          <tr>
                            <td>
                              <span>
                                <span class="wm-tbl-str-div">
                                  <span class="icon-Star" style="color: #a6b0c3 ;"></span>
                                </span>
                              </span>
                            </td>
                            <td style="text-align: start;">
                              <p color="text2" class="wm-tbl-broker-vol-sub">6</p>
                            </td>
                            <td style="text-align: start;" class="">
                              <div class="d-flex align-items-center">
                                <a href="#" class="wm-link">
                                  <div class="broker-tbl-coin-div-main">
                                    <img class="coin-logo" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}" alt="BNB logo">
                                    <div class="name-area ">
                                      <p class="broker-tbl-coin-title">BNB</p>
                                      <div class="coin-item-symbol-div">
                                        <div class="coin-nm-mob">4</div>
                                        <p color="text3" class="coin-nm-color coin-item-symbol">BNB</p>
                                      </div>
                                    </div>
                                  </div>
                                </a>
                              </div>
                            </td>
                            <td style="text-align: end;">
                              <div class="rise">
                                <a href="#" class="wm-link">
                                  <span>$279.42</span>
                                </a>
                              </div>
                            </td>
                           
                           
                           
                            <td style="text-align: end;">
                              <span class="broker-tbl-price-down">
                                <span class="icon-Caret-down"></span>0.39% </span>
                            </td>
                          
                           
                          </tr>
                          <tr>
                            <td>
                              <span>
                                <span class="wm-tbl-str-div">
                                  <span class="icon-Star" style="color: #a6b0c3 ;"></span>
                                </span>
                              </span>
                            </td>
                            <td style="text-align: start;">
                              <p color="text2" class="wm-tbl-broker-vol-sub">7</p>
                            </td>
                            <td style="text-align: start;" class="">
                              <div class="d-flex align-items-center">
                                <a href="#" class="wm-link">
                                  <div class="broker-tbl-coin-div-main">
                                    <img class="coin-logo" src="{{ asset('public/assets/img/87496d50-2408-43e1-ad4c-78b47b448a6a.png') }} " loading="lazy" alt="BTC logo">
                                    <div class="name-area ">
                                      <p class="broker-tbl-coin-title">Bitcoin</p>
                                      <div class="coin-item-symbol-div">
                                        <div class="coin-nm-mob">1</div>
                                        <p color="text3" class="coin-nm-color coin-item-symbol">BTC</p>
                                      </div>
                                    </div>
                                  </div>
                                </a>
                              </div>
                            </td>
                            <td style="text-align: end;">
                              <div class="">
                                <a href="#" class="wm-link">
                                  <span>$16,833.51</span>
                                </a>
                              </div>
                            </td>
                          
                            <td style="text-align: end;">
                              <span class="broker-tbl-price-up">
                                <span class="icon-Caret-up"></span>0.27% </span>
                            </td>
                           
                          </tr>
                         
                          <tr>
                            <td>
                              <span>
                                <span class="wm-tbl-str-div">
                                  <span class="icon-Star" style="color: #a6b0c3 ;"></span>
                                </span>
                              </span>
                            </td>
                            <td style="text-align: start;">
                              <p color="text2" class="wm-tbl-broker-vol-sub">8</p>
                            </td>
                            <td style="text-align: start;" class="">
                              <div class="d-flex align-items-center">
                                <a href="#" class="wm-link">
                                  <div class="broker-tbl-coin-div-main">
                                    <img class="coin-logo" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}" alt="BNB logo">
                                    <div class="name-area ">
                                      <p class="broker-tbl-coin-title">BNB</p>
                                      <div class="coin-item-symbol-div">
                                        <div class="coin-nm-mob">4</div>
                                        <p color="text3" class="coin-nm-color coin-item-symbol">BNB</p>
                                      </div>
                                    </div>
                                  </div>
                                </a>
                              </div>
                            </td>
                            <td style="text-align: end;">
                              <div class="rise">
                                <a href="#" class="wm-link">
                                  <span>$279.42</span>
                                </a>
                              </div>
                            </td>
                           
                           
                            <td style="text-align: end;">
                              <span class="broker-tbl-price-down">
                                <span class="icon-Caret-down"></span>0.39% </span>
                            </td>
                           
                          </tr>
                          
                        
                        </tbody>
                      </table>
                    </div>
                        </div>
                    </div>
                        
        <div class="pagination-div mt-3">
                   <button type="button" class="mirror pagination-back" aria-label="Previous page" disabled="">
                     <svg viewBox="0 0 24 24" fill="none" class="custom-modal-close-icon">
                       <path fill-rule="evenodd" clip-rule="evenodd" d="M11.934 12l3.89 3.89-1.769 1.767L8.398 12l1.768-1.768 3.89-3.889 1.767 1.768-3.889 3.89z" fill="currentColor"></path>
                     </svg>
                   </button>
                   <button type="button" aria-label="Page number 1" class="pagination-active" disabled="">1</button>
                   <button type="button" aria-label="Page number 2" class="pagination-all">2</button>
                   <button type="button" aria-label="Page number 3" class="pagination-all">3</button>
                   <button type="button" aria-label="Page number 4" class="pagination-all">4</button>
                   <button type="button" aria-label="Page number 5" class="pagination-all">5</button>
                   <button type="button" class="mirror pagination-next" aria-label="Next page">
                     <svg viewBox="0 0 24 24" fill="none" class="custom-modal-close-icon">
                       <path fill-rule="evenodd" clip-rule="evenodd" d="M12.288 12l-3.89 3.89 1.768 1.767L15.823 12l-1.768-1.768-3.889-3.889-1.768 1.768 3.89 3.89z" fill="currentColor"></path>
                     </svg>
                   </button>
                 </div>
            </div>
            <div class="text">* APR is refreshed in real time. We will use the latest APR at the time you complete the subscription successfully.</div>
            
            <div class="border-top border-bottom pt-2 pb-2 mt-2 mb-2 yellow-text text-center hide-max-768">
              <span class="open show" id="Show_more_btn"> <b> Show more </b></span> <span class="open hide" id="Show_less_btn"> <b> Show Less </b></span>
            </div>
           </div>
        </div>
        
    </section>
    
            <section id="Beginner_Mode_on">
      <div class="container" >
          <div class="row">
              <div class="">
  <h3 class="title mt-2 mb-4">Step 2: Get Started</h3>
  <div class="di-get-start">
   
   <div class="di-get-start-left">
  <div class="li-prog-tst-mob">Decide to Sell High or Buy Low</div>
 
     
      <div id="step-prog" class="step-prog">
        <div class="bn-steps-step li-prog-div-main" data-status="process">
          <div class="li-prog-div">
            <div class="step_marker_column " data-class="step_marker_column">
              <span data-class="step_marker_number" class="step_marker_span">
                <div class="step_marker_number">1</div>
              </span>
            </div>
            <div class="li-prog-tst">Decide to Sell High or Buy Low</div>
            
          </div>
        </div>
        <div data-status-line="wait" class="cn-mob li-prog-line"></div>
        <div class="bn-steps-step li-prog-div-main" data-status="wait">
          <div class="li-prog-div">
            <div class="step_marker_column " data-class="step_marker_column">
              <span data-class="step_marker_number" class="step_marker_span">
                <div class="step_marker_number">2</div>
              </span>
            </div>
            <div class="li-prog-tst">Enter Subscription Amount</div>
            
          </div>
        </div>
        <div data-status-line="wait" class="cn-mob li-prog-line"></div>
        <div class="bn-steps-step li-prog-div-main" data-status="wait">
          <div class="li-prog-div">
            <div class="step_marker_column " data-class="step_marker_column">
              <span data-class="step_marker_number" class="step_marker_span">
                <div class="step_marker_number">3</div>
              </span>
            </div>
            <div class="li-prog-tst">Check Winning Scenarios</div>
            
          </div>
        </div>
        <div data-status-line="wait" class="cn-mob li-prog-line"></div>
        <div class="bn-steps-step li-prog-div-main" data-status="wait">
          <div class="li-prog-div">
            <div class="step_marker_column " data-class="step_marker_column">
              <span data-class="step_marker_number" class="step_marker_span">
                <div class="step_marker_number">4</div>
              </span>
            </div>
            <div class="li-prog-tst">Confirm and Subscribe</div>
            
          </div>
        </div>
      </div>
      <div class="step-prog-mobile">
  <div class="bn-steps-step li-prog-div-main" data-status="process">
    <div class="step-prog-num-div">
      
      <div class="step_marker_row " data-class="step_marker_row">
        <span data-class="step_marker_number" class="step_marker_span">
          <div class="step_marker_number">1</div>
        </span>
      </div>
    </div>
  </div>
  <div data-status-line="wait" class="li-prog-line-mob"></div>
  <div class="bn-steps-step li-prog-div-main" data-status="wait">
    <div class="step-prog-num-div">
      
      <div class="step_marker_row " data-class="step_marker_row">
        <span data-class="step_marker_number" class="step_marker_span">
          <div class="step_marker_number">2</div>
        </span>
      </div>
    </div>
  </div>
  <div data-status-line="wait" class="li-prog-line-mob"></div>
  <div class="bn-steps-step li-prog-div-main" data-status="wait">
    <div class="step-prog-num-div">
      
      <div class="step_marker_row " data-class="step_marker_row">
        <span data-class="step_marker_number" class="step_marker_span">
          <div class="step_marker_number">3</div>
        </span>
      </div>
    </div>
  </div>
  <div data-status-line="wait" class="li-prog-line-mob"></div>
  <div class="bn-steps-step li-prog-div-main" data-status="wait">
    <div class="step-prog-num-div">
      
      <div class="step_marker_row " data-class="step_marker_row">
        <span data-class="step_marker_number" class="step_marker_span">
          <div class="step_marker_number">4</div>
        </span>
      </div>
    </div>
  </div>
</div>
    
</div>
   
   
    <div class="di-get-start-rgt">
      <div class="di-get-start-img">
        <img src="{{ asset('public/assets/img/dual-investment/sell-wmc.png') }}" class="di-get-start-img-">
      </div>
      <div class="di-get-start-rgt-lft">
        <div class="di-get-start-rgt-lft-1">Find 
        <div class="di-get-start-rgt-lft-1-inner">
            <img class="di-coin-list-img-coin" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}">
            <div class="di-coin-list-name-coin">BTC</div>
          </div>
          Products </div>
        <div class="di-get-start-rgt-lft-swt-tbn-div">
          <div class="btn-yellow" id="open_sell_btc">Sell BTC at</div>
          <div class="di-get-start-rgt-lft-swt-tbn" id="open_buy_btc">Buy BTC at</div>
        </div>
         <div class="open show pt-2" id="Sell_BTC">
        <div class="buy_BTC_div">
          <div class="buy_BTC_div-inner">
            <h3 class="title">$18,000</h3>
            <img src="{{ asset('public/assets/img/wm-vertical_line.svg') }}" class="line-img">
            <div class="d-flex open_settlement_modal">
              <svg viewBox="0 0 24 24" fill="none" cursor="pointer" class="edit-svg">
                <path fill-rule="evenodd" clip-rule="evenodd" d="M15.314 4.781l3.889 3.89-1.768 1.767-3.889-3.889 1.768-1.768zm-3.182 3.182l3.89 3.89-5.129 5.127H15v3H7.893l-.004.004H4v-3.889l8.132-8.132zM17 16.98h3v3h-3v-3z" fill="currentColor"></path>
              </svg>
            </div>
          </div>
          <div class="lover-risk">Lowest Risk</div>
          <div class="gt-status">on <div class="gt-status-crrnt-price">&nbsp;&nbsp;2022/11/18</div>
            <img src="{{ asset('public/assets/img/wm-vertical_line.svg') }}" class="gt-earn-apr">earn APR
           :
           
            <div class="gt-crrnt-earn-title">&nbsp;15.18%</div>
          </div>
          <div class="gt-status-crrnt-div">Current Price
           :
           
            <div class="gt-status-crrnt-price">&nbsp;16,631</div>
          </div>
        </div>
        </div>
         <div class="open hide pt-2" id="buy_BTC">
        <div class="buy_BTC_div" >
        <div class="buy_BTC_div-inner">
                <h3 class="title m-0 p-0 me-3">$13,000</h3>with 
                <div class="ms-2 me-2">
                  
                   <div class="dropdown show">
                          <a class="btn bg-light-theme d-flex align-items-center dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                             <div class="di-get-start-rgt-lft-1-inner">
            <img class="di-coin-list-img-coin" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}">
            <div class="di-coin-list-name-coin">BTC</div>
          </div>
                          </a>
                    
                          <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                            <a class="dropdown-item" href="#">Action</a>
                            <a class="dropdown-item" href="#">Another action</a>
                            <a class="dropdown-item" href="#">Something else here</a>
                          </div>
                    </div>
                        
                 
                </div>
                <img src="{{ asset('public/assets/img/wm-vertical_line.svg') }}" class="line-img">
                <div class="d-flex open_settlement_modal">
                  <svg viewBox="0 0 24 24" fill="none" cursor="pointer" class="edit-svg">
                    <path fill-rule="evenodd" clip-rule="evenodd" d="M15.314 4.781l3.889 3.89-1.768 1.767-3.889-3.889 1.768-1.768zm-3.182 3.182l3.89 3.89-5.129 5.127H15v3H7.893l-.004.004H4v-3.889l8.132-8.132zM17 16.98h3v3h-3v-3z" fill="currentColor"></path>
                  </svg>
                </div>
              </div>
              <div class="lover-risk">Lowest Risk</div>
              <div class="gt-status">on <div class="gt-status-crrnt-price">&nbsp;&nbsp;2022/11/22</div>
                <img src="{{ asset('public/assets/img/wm-vertical_line.svg') }}" class="gt-earn-apr">earn APR
               :
               
                <div class="gt-crrnt-earn-title">&nbsp;4.72%</div>
              </div>
              <div class="gt-status-crrnt-div">Current Price
               :
               
                <div class="gt-status-crrnt-price">&nbsp;16,529</div>
              </div>
            </div>
           </div> 
      </div>
      <div class="di-get-start-login-div">
        <button type="button" class="btn btn-yellow w-auto">Log In</button>
      </div>
    </div>
  </div>
</div>
          </div>
      </div>
  </section>
  
  
        <section class="bg-white" id="biginner_mode_of" style="display:none">
      <div class="container">
          <div class="d-flex align-items-center justify-content-between pb-4 mb-4">
              <div class="div">
                  
                        <h3 class="title m-0 p-0"> Step 2: Choose a settlement</h3>
                
              </div>
             
                  <div class="Di_Current_coin_Price_div">Current BTC Price<div class="Di_Current_coin_Price_status">16,770</div></div>
                 
          </div>
          <div class="row">
              
              
              <div class="dashboard-tabpills">
                <div class="mb-4">
                    <div class="dashboard-card-body">
                        <ul class="nav nav-pills my-1 border-bottom" id="pills-tab" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active" id="pills-spot-tab" data-bs-toggle="pill" data-bs-target="#pills-spot" type="button" role="tab" aria-controls="pills-spot" aria-selected="false">
                                <div  class="Choose_settlement_optn-div">
                                      <div class="Choose_settlement_optn-img">
                                        <div class="di-coin-list-img-content">
                                          <img class="Choose_settlement_optn-img-main" src="{{ asset('public/assets/img/87496d50-2408-43e1-ad4c-78b47b448a6a.png') }}">
                                        </div>
                                        <div class="Choose_settlement_optn-img2-main">
                                          <img class="Choose_settlement_optn-img2-main2" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}">
                                        </div>
                                      </div>
                                      <div class="Choose_settlement_optn-title">Sell High</div>
                                      <div class="Choose_settlement_optn-up"></div>
                                      <div class="Choose_settlement_optn-title-2">Deposit BTC</div>
                            </div>
                            </button>
                        </li>
                       
                        <li class="nav-item" role="presentation">
                            <button class="nav-link " id="pills-margin-tab" data-bs-toggle="pill" data-bs-target="#pills-margin" type="button" role="tab" aria-controls="pills-margin" aria-selected="true">
                                <div  class="Choose_settlement_optn-div">
                                      <div class="Choose_settlement_optn-img">
                                        <div class="di-coin-list-img-content">
                                          <img class="Choose_settlement_optn-img-main" src="{{ asset('public/assets/img/87496d50-2408-43e1-ad4c-78b47b448a6a.png') }}">
                                        </div>
                                        <div class="Choose_settlement_optn-img2-main">
                                          <img class="Choose_settlement_optn-img2-main2" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}">
                                        </div>
                                      </div>
                                      <div class="Choose_settlement_optn-title">Buy Low</div>
                                      <div class="Choose_settlement_optn-down"></div>
                                      <div class="Choose_settlement_optn-title-2">Deposit Usdt</div>
                            </div>
                            </button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="pills-futures-tab" data-bs-toggle="pill" data-bs-target="#pills-futures" type="button" role="tab" aria-controls="pills-futures" aria-selected="false">
                                <div  class="Choose_settlement_optn-div">
                                      <div class="Choose_settlement_optn-img">
                                        <div class="di-coin-list-img-content">
                                          <img class="Choose_settlement_optn-img-main" src="{{ asset('public/assets/img/87496d50-2408-43e1-ad4c-78b47b448a6a.png') }}">
                                        </div>
                                        <div class="Choose_settlement_optn-img2-main">
                                          <img class="Choose_settlement_optn-img2-main2" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}">
                                        </div>
                                      </div>
                                      <div class="Choose_settlement_optn-title">Buy Low</div>
                                     <div class="Choose_settlement_optn-down"></div>
                                      <div class="Choose_settlement_optn-title-2">Deposit BUSD</div>
                            </div>
                            </button>
                        </li>
                     
                        </ul>
    
                        <div class="tab-content" id="pills-tabContent">
                            <div class="tab-pane fade active show" id="pills-spot" role="tabpanel" aria-labelledby="pills-spot-tab">
                                <div class="date-wise-filter scrollbar-style p-3 pb-3">
                                    <div class="date-wise-filter-div">
                                        <div class="active date-wise-filter--txt">All Settlement Dates</div>
                                    </div>
                                    <div class="date-wise-filter-div">
                                        <div class=" date-wise-filter--txt">2022-11-22</div>
                                    </div>
                                     <div class="date-wise-filter-div">
                                        <div class=" date-wise-filter--txt">2022-11-22</div>
                                    </div>
                                     <div class="date-wise-filter-div">
                                        <div class=" date-wise-filter--txt">2022-11-22</div>
                                    </div>
                                     <div class="date-wise-filter-div">
                                        <div class=" date-wise-filter--txt">2022-11-22</div>
                                    </div>
                                     <div class="date-wise-filter-div">
                                        <div class=" date-wise-filter--txt">2022-11-22</div>
                                    </div>
                                     <div class="date-wise-filter-div">
                                        <div class=" date-wise-filter--txt">2022-11-22</div>
                                    </div>
                                     <div class="date-wise-filter-div">
                                        <div class=" date-wise-filter--txt">2022-11-22</div>
                                    </div>
                                </div>
                                
                                
                                             <div class="mt-4">
                                     
                                     <div class="date-wise-filter-list">
                                         <div class="date-wise-filter-list-inner">
                                              <div class="filter-list-inner-left">
                                                <div class="filter-list-trgt-div">
                                                  <div class="d-flex">Target Price</div>
                                                  <div class="filter-list-trgt-sts">
                                                    <div class="filter-list-trgt-crrnt-sts-div">
                                                      <div class="d-flex">$17,000</div>
                                                      <div class="filter-list-trgt-per-div">
                                                        <div class="filter-list-trgt-per">1.54%</div>
                                                      <i class="bi bi-caret-up-fill filter-list-trgt-per-icon"></i>
                                                      </div>
                                                    </div>
                                                  </div>
                                                </div>
                                                <div class="filter-list-apr-div">
                                                  <div class="d-flex">APR</div>
                                                  <div class="filter-list-trgt-sts">
                                                    <div class="filter-list-apr-sts">74.41%</div>
                                                  </div>
                                                </div>
                                                <div class="filter-list-date-div">
                                                  <div class="d-flex">
                                                    <div class="filter-list-date-div-title">Settlement Date</div>
                                                  </div>
                                                  <div class="filter-list-trgt-sts">2022-11-22</div>
                                                </div>
                                              </div>
                                              <div class="filter-list-inner-right">
                                                <button type="button" class="btn-yellow border-0">Subscribe</button>
                                                <button type="button" class="di_cal_btn">Calculate</button>
                                              </div>
                                            </div>
                                     </div>
                                     <div class="date-wise-filter-list">
                                         <div class="date-wise-filter-list-inner">
                                              <div class="filter-list-inner-left">
                                                <div class="filter-list-trgt-div">
                                                  <div class="d-flex">Target Price</div>
                                                  <div class="filter-list-trgt-sts">
                                                    <div class="filter-list-trgt-crrnt-sts-div">
                                                      <div class="d-flex">$17,000</div>
                                                      <div class="filter-list-trgt-per-div">
                                                        <div class="filter-list-trgt-per">1.54%</div>
                                                        <i class="bi bi-caret-up-fill filter-list-trgt-per-icon"></i>
                                                      </div>
                                                    </div>
                                                  </div>
                                                </div>
                                                <div class="filter-list-apr-div">
                                                  <div class="d-flex">APR</div>
                                                  <div class="filter-list-trgt-sts">
                                                    <div class="filter-list-apr-sts">74.41%</div>
                                                  </div>
                                                </div>
                                                <div class="filter-list-date-div">
                                                  <div class="d-flex">
                                                    <div class="filter-list-date-div-title">Settlement Date</div>
                                                  </div>
                                                  <div class="filter-list-trgt-sts">2022-11-22</div>
                                                </div>
                                              </div>
                                              <div class="filter-list-inner-right">
                                                <button type="button" class="btn-yellow border-0">Subscribe</button>
                                                <button type="button" class="di_cal_btn">Calculate</button>
                                              </div>
                                            </div>
                                     </div>
                                     <div class="date-wise-filter-list">
                                         <div class="date-wise-filter-list-inner">
                                              <div class="filter-list-inner-left">
                                                <div class="filter-list-trgt-div">
                                                  <div class="d-flex">Target Price</div>
                                                  <div class="filter-list-trgt-sts">
                                                    <div class="filter-list-trgt-crrnt-sts-div">
                                                      <div class="d-flex">$17,000</div>
                                                      <div class="filter-list-trgt-per-div">
                                                        <div class="filter-list-trgt-per">1.54%</div>
                                                        <i class="bi bi-caret-up-fill filter-list-trgt-per-icon"></i>
                                                      </div>
                                                    </div>
                                                  </div>
                                                </div>
                                                <div class="filter-list-apr-div">
                                                  <div class="d-flex">APR</div>
                                                  <div class="filter-list-trgt-sts">
                                                    <div class="filter-list-apr-sts">74.41%</div>
                                                  </div>
                                                </div>
                                                <div class="filter-list-date-div">
                                                  <div class="d-flex">
                                                    <div class="filter-list-date-div-title">Settlement Date</div>
                                                  </div>
                                                  <div class="filter-list-trgt-sts">2022-11-22</div>
                                                </div>
                                              </div>
                                              <div class="filter-list-inner-right">
                                                <button type="button" class="btn-yellow border-0">Subscribe</button>
                                                <button type="button" class="di_cal_btn">Calculate</button>
                                              </div>
                                            </div>
                                     </div>
                                     <div class="date-wise-filter-list">
                                         <div class="date-wise-filter-list-inner">
                                              <div class="filter-list-inner-left">
                                                <div class="filter-list-trgt-div">
                                                  <div class="d-flex">Target Price</div>
                                                  <div class="filter-list-trgt-sts">
                                                    <div class="filter-list-trgt-crrnt-sts-div">
                                                      <div class="d-flex">$17,000</div>
                                                      <div class="filter-list-trgt-per-div">
                                                        <div class="filter-list-trgt-per">1.54%</div>
                                                       <i class="bi bi-caret-up-fill filter-list-trgt-per-icon"></i>
                                                      </div>
                                                    </div>
                                                  </div>
                                                </div>
                                                <div class="filter-list-apr-div">
                                                  <div class="d-flex">APR</div>
                                                  <div class="filter-list-trgt-sts">
                                                    <div class="filter-list-apr-sts">74.41%</div>
                                                  </div>
                                                </div>
                                                <div class="filter-list-date-div">
                                                  <div class="d-flex">
                                                    <div class="filter-list-date-div-title">Settlement Date</div>
                                                  </div>
                                                  <div class="filter-list-trgt-sts">2022-11-22</div>
                                                </div>
                                              </div>
                                              <div class="filter-list-inner-right">
                                                <button type="button" class="btn-yellow border-0">Subscribe</button>
                                                <button type="button" class="di_cal_btn">Calculate</button>
                                              </div>
                                            </div>
                                     </div>
                                     <div class="date-wise-filter-list">
                                         <div class="date-wise-filter-list-inner">
                                              <div class="filter-list-inner-left">
                                                <div class="filter-list-trgt-div">
                                                  <div class="d-flex">Target Price</div>
                                                  <div class="filter-list-trgt-sts">
                                                    <div class="filter-list-trgt-crrnt-sts-div">
                                                      <div class="d-flex">$17,000</div>
                                                      <div class="filter-list-trgt-per-div">
                                                        <div class="filter-list-trgt-per">1.54%</div>
                                                    <i class="bi bi-caret-up-fill filter-list-trgt-per-icon"></i>
                                                      </div>
                                                    </div>
                                                  </div>
                                                </div>
                                                <div class="filter-list-apr-div">
                                                  <div class="d-flex">APR</div>
                                                  <div class="filter-list-trgt-sts">
                                                    <div class="filter-list-apr-sts">74.41%</div>
                                                  </div>
                                                </div>
                                                <div class="filter-list-date-div">
                                                  <div class="d-flex">
                                                    <div class="filter-list-date-div-title">Settlement Date</div>
                                                  </div>
                                                  <div class="filter-list-trgt-sts">2022-11-22</div>
                                                </div>
                                              </div>
                                              <div class="filter-list-inner-right">
                                                <button type="button" class="btn-yellow border-0">Subscribe</button>
                                                <button type="button" class="di_cal_btn">Calculate</button>
                                              </div>
                                            </div>
                                     </div>
                                     <div class="date-wise-filter-list">
                                         <div class="date-wise-filter-list-inner">
                                              <div class="filter-list-inner-left">
                                                <div class="filter-list-trgt-div">
                                                  <div class="d-flex">Target Price</div>
                                                  <div class="filter-list-trgt-sts">
                                                    <div class="filter-list-trgt-crrnt-sts-div">
                                                      <div class="d-flex">$17,000</div>
                                                      <div class="filter-list-trgt-per-div">
                                                        <div class="filter-list-trgt-per">1.54%</div>
                                                      <i class="bi bi-caret-up-fill filter-list-trgt-per-icon"></i>
                                                      </div>
                                                    </div>
                                                  </div>
                                                </div>
                                                <div class="filter-list-apr-div">
                                                  <div class="d-flex">APR</div>
                                                  <div class="filter-list-trgt-sts">
                                                    <div class="filter-list-apr-sts">74.41%</div>
                                                  </div>
                                                </div>
                                                <div class="filter-list-date-div">
                                                  <div class="d-flex">
                                                    <div class="filter-list-date-div-title">Settlement Date</div>
                                                  </div>
                                                  <div class="filter-list-trgt-sts">2022-11-22</div>
                                                </div>
                                              </div>
                                              <div class="filter-list-inner-right">
                                                <button type="button" class="btn-yellow border-0">Subscribe</button>
                                                <button type="button" class="di_cal_btn">Calculate</button>
                                              </div>
                                            </div>
                                     </div>
                                     <div class="date-wise-filter-list">
                                         <div class="date-wise-filter-list-inner">
                                              <div class="filter-list-inner-left">
                                                <div class="filter-list-trgt-div">
                                                  <div class="d-flex">Target Price</div>
                                                  <div class="filter-list-trgt-sts">
                                                    <div class="filter-list-trgt-crrnt-sts-div">
                                                      <div class="d-flex">$17,000</div>
                                                      <div class="filter-list-trgt-per-div">
                                                        <div class="filter-list-trgt-per">1.54%</div>
                                                      <i class="bi bi-caret-up-fill filter-list-trgt-per-icon"></i>
                                                      </div>
                                                    </div>
                                                  </div>
                                                </div>
                                                <div class="filter-list-apr-div">
                                                  <div class="d-flex">APR</div>
                                                  <div class="filter-list-trgt-sts">
                                                    <div class="filter-list-apr-sts">74.41%</div>
                                                  </div>
                                                </div>
                                                <div class="filter-list-date-div">
                                                  <div class="d-flex">
                                                    <div class="filter-list-date-div-title">Settlement Date</div>
                                                  </div>
                                                  <div class="filter-list-trgt-sts">2022-11-22</div>
                                                </div>
                                              </div>
                                              <div class="filter-list-inner-right">
                                                <button type="button" class="btn-yellow border-0">Subscribe</button>
                                                <button type="button" class="di_cal_btn">Calculate</button>
                                              </div>
                                            </div>
                                     </div>
                                     <div class="date-wise-filter-list">
                                         <div class="date-wise-filter-list-inner">
                                              <div class="filter-list-inner-left">
                                                <div class="filter-list-trgt-div">
                                                  <div class="d-flex">Target Price</div>
                                                  <div class="filter-list-trgt-sts">
                                                    <div class="filter-list-trgt-crrnt-sts-div">
                                                      <div class="d-flex">$17,000</div>
                                                      <div class="filter-list-trgt-per-div">
                                                        <div class="filter-list-trgt-per">1.54%</div>
                                                      <i class="bi bi-caret-up-fill filter-list-trgt-per-icon"></i>
                                                      </div>
                                                    </div>
                                                  </div>
                                                </div>
                                                <div class="filter-list-apr-div">
                                                  <div class="d-flex">APR</div>
                                                  <div class="filter-list-trgt-sts">
                                                    <div class="filter-list-apr-sts">74.41%</div>
                                                  </div>
                                                </div>
                                                <div class="filter-list-date-div">
                                                  <div class="d-flex">
                                                    <div class="filter-list-date-div-title">Settlement Date</div>
                                                  </div>
                                                  <div class="filter-list-trgt-sts">2022-11-22</div>
                                                </div>
                                              </div>
                                              <div class="filter-list-inner-right">
                                                <button type="button" class="btn-yellow border-0">Subscribe</button>
                                                <button type="button" class="di_cal_btn">Calculate</button>
                                              </div>
                                            </div>
                                     </div>
                                     
                                     
                                     
                              
                                <div class="pagination-div mt-3">
                                   <button type="button" class="mirror pagination-back" aria-label="Previous page" disabled="">
                                     <svg viewBox="0 0 24 24" fill="none" class="custom-modal-close-icon">
                                       <path fill-rule="evenodd" clip-rule="evenodd" d="M11.934 12l3.89 3.89-1.769 1.767L8.398 12l1.768-1.768 3.89-3.889 1.767 1.768-3.889 3.89z" fill="currentColor"></path>
                                     </svg>
                                   </button>
                                   <button type="button" aria-label="Page number 1" class="pagination-active" disabled="">1</button>
                                   <button type="button" aria-label="Page number 2" class="pagination-all">2</button>
                                   <button type="button" aria-label="Page number 3" class="pagination-all">3</button>
                                   <button type="button" aria-label="Page number 4" class="pagination-all">4</button>
                                   <button type="button" aria-label="Page number 5" class="pagination-all">5</button>
                                   <button type="button" class="mirror pagination-next" aria-label="Next page">
                                     <svg viewBox="0 0 24 24" fill="none" class="custom-modal-close-icon">
                                       <path fill-rule="evenodd" clip-rule="evenodd" d="M12.288 12l-3.89 3.89 1.768 1.767L15.823 12l-1.768-1.768-3.889-3.889-1.768 1.768 3.89 3.89z" fill="currentColor"></path>
                                     </svg>
                                   </button>
                                 </div>
                              </div>
                            </div>
                            
                            <div class="tab-pane fade" id="pills-p2p" role="tabpanel" aria-labelledby="pills-p2p-tab">
                            
                            </div>
                            <div class="tab-pane fade " id="pills-margin" role="tabpanel" aria-labelledby="pills-margin-tab">
                            
                            </div>
                        </div>
                    </div>
                </div>
            </div>
             
          </div>
          
        <div class="return_div_2222">
            <div class="d-flex mb-4">
                <img src="{{ asset('public/assets/img/dual-investment/calculator.png') }}" class="me-2 di-coin-list-img-coin rounded-0" >
                <div class="return_cal_deading_div">
                    <h3 class="title m-0 p-0 me-2"> Return Calculator</h3>
                    <p class="text m-0 p-0">Select a product above to start the calculation.</p>
                </div>
            </div>
            
            <div class="Return_Calculator_div">
                <div class="chart_Calculator_div order-1" id="apend_div_child-1" >
    <div class="chart_Calculator_div-main-inner">
      <div class="chart_Calculator_div-inner">
        <div  class="rc-coin-selected-price">ETH Price</div>
        <div class="">
          <div  class="rc-coin-selected-price">Target Price</div>
          <div  class="rc-coin-selected-price-1">$1,300</div>
        </div>
       
      </div>
      <div class="chart_Calculator_right">
        <div class="chart_Calculator_dashed-line"></div>
        <div class="chart_Calculator_crrnt_div">
          <div class="">
            <div  class="chart_Calculator_crnt-price-txt">Current Price</div>
            <div  class="chart_Calculator_crnt-price-txt">$1,207</div>
          </div>
          <div class="css-1cl4vgz"></div>
        </div>
        <div class="css-12wjg1g">
          <div  class="chart_Calculator_crnt-price-txt">Price ≥ $1,300</div>
         
        </div>
        <div class="chart_Calculator_dot-2"></div>
        <div class="chart_Calculator_dot-1"></div>
        <img src="#" class="chart_Calculator_chart-img">
        <div class="chart_Calculator_right_top">
          <div class="cal_div_return_left">
            <div class="chart_Calculator_list_dot"></div>
            <div  class="chart_Calculator_title_right">Receive</div>
          </div>
          <div  class="chart_Calculator_title_--">--</div>
          <div class="chart_Calculator_img_div-coin">
            <img class="rc_coin-img" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}">
            <div  class="chart_Calculator_img_name">BUSD</div>
          </div>
        </div>
        <div class="chart_Calculator_right_bottom">
          <div class="cal_div_return_left">
            <div class="chart_Calculator_list_dot"></div>
            <div  class="chart_Calculator_title_right">Receive</div>
          </div>
          <div  class="chart_Calculator_title_--">--</div>
          <div class="chart_Calculator_img_div-coin">
            <img class="rc_coin-img" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}">
            <div  class="chart_Calculator_img_name">ETH</div>
          </div>
        </div>
        <div  class="chart_Calculator_date">2022-11-25</div>
      </div>
    </div>
  </div>
                <div class="sell_Calculator_div order-2" id="apend_div_child-3" >
    <div class="css-1065ayc">
      <div  class="css-1mvajns">Sell ETH</div>
      <div class="sell_div_inner">
        <div class="sell_div_inner-row1">
          <div  class="sell_div_inner-row-title">Subscription Amount</div>
          <div class=" css-5uedr7">
            <input type="input" placeholder="Enter Amount" class="css-16fg16t" value="">
            <div class="wm-input-suffix ">
              <div class="css-19rak99">
                <div class="sell_div_inner-row-right-img">
                  <img class="rc_coin-img" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}">
                </div>
                <div  class="css-i3htau">ETH</div>
              </div>
            </div>
          </div>
        </div>
        <div class="sell_div_inner-row2">
          <div  class="sell_div_inner-row-title">Target Price</div>
          <div class="sell_div_inner-row-right">
            <div class="sell_div_inner-row-right-img">
              <img class="rc_coin-img" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}">
            </div>
            <div  class="sell_div_inner-row-target-coin">ETH = $</div>
            <div  class="sell_div_inner-row-target-price">1,300</div>
          </div>
        </div>
        <div class="sell_div_inner-row3">
          <div  class="sell_div_inner-row-title">Settlement Date</div>
          <div class="sell_div_inner-row-right">
            <div  class="sell_div_inner-row-date">2022-11-25</div>
          </div>
        </div>
        <div class="sell_div_inner-row3">
          <div  class="sell_div_inner-row-title">Outcome</div>
          <div class="sell_div_inner-row3-btns-div">
            <div class="acitve sell_div_inner-row3-btns">
              <div  class="chart_Calculator_crnt-price-txt">At or above $1,300</div>
            </div>
            <div class=" sell_div_inner-row3-btns">
              <div  class="chart_Calculator_crnt-price-txt">Below $1,300</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
                <div class="cal_div_return order-3" id="apend_div_child-2">
    <div class="cal_div_return-inner">
      <div  class="cal_div_return-title">Return Calculator</div>
      <div class="cal_div_return-1-row">
        <div class="cal_div_return_left">
          <div  class="rc_blank_record">Subscription Amount</div>
        </div>
        <div class="cal_div_return_right">
          <div  class="rc_blank_record">--</div>
          <div class="rc_crnt_rcrd">
            <img class="rc_coin-img" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}">
            <div  class="rc_title">ETH</div>
          </div>
        </div>
      </div>
      <div class="cal_div_return-2-row">
        <div class="cal_div_return_left">
          <div class="rc_Interests_div">Interests ( <div  class="g-light-green me-2">22.36%</div> APR) </div>
          <div class="cal_div_return_left_info">
           
            <svg  viewBox="0 0 24 24" fill="none" class="cal_div_return_left_info_icn">
              <path fill-rule="evenodd" clip-rule="evenodd" d="M12 21a9 9 0 100-18 9 9 0 000 18zM10.75 8.5V6h2.5v2.5h-2.5zm0 9.5v-7h2.5v7h-2.5z" fill="currentColor"></path>
            </svg>
          </div>
        </div>
        <div class="cal_div_return_right">
          <div  class="rc_blank_record">--</div>
          <div class="rc_crnt_rcrd">
            <img class="rc_coin-img" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}">
            <div  class="rc_title">ETH</div>
          </div>
        </div>
      </div>
      <div class="cal_div_return-border-line"></div>
      <div class="cal_div_return-3-row">
        <div class="d-flex align-items-center justify-content-between">
          <div  class="rc_blank_record">Total</div>
        </div>
        <div class="cal_div_return_right">
          <div  class="rc_blank_record">--</div>
          <div class="rc_crnt_rcrd">
            <img class="rc_coin-img" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}">
            <div  class="rc_title">ETH</div>
          </div>
        </div>
      </div>
      <div class="cal_div_return-3-arrow">
        <svg  viewBox="0 0 24 24" fill="none" class="rc_arrow">
          <path fill-rule="evenodd" clip-rule="evenodd" d="M12 20.999l7.071-7.071-1.768-1.768-4.054 4.055V2.998h-2.5v13.216L6.696 12.16l-1.768 1.768 7.07 7.071H12z" fill="currentColor"></path>
        </svg>
      </div>
      <div  class="css-16u3n6c">You will receive</div>
      <div class="cal_div_return-3-row">
        <div class="cal_div_return_left">
          <div  class="rc_blank_record">Settlement Amount</div>
          <svg  viewBox="0 0 24 24" fill="none" class="cal_div_return_left_info_icn">
              <path fill-rule="evenodd" clip-rule="evenodd" d="M12 21a9 9 0 100-18 9 9 0 000 18zM10.75 8.5V6h2.5v2.5h-2.5zm0 9.5v-7h2.5v7h-2.5z" fill="currentColor"></path>
            </svg>
          
        </div>
        <div class="cal_div_return_right">
          <div  class="rc_blank_record">--</div>
          <div class="rc_crnt_rcrd">
            <img class="rc_coin-img" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}">
            <div  class="rc_title">BUSD</div>
          </div>
        </div>
      </div>
    </div>
  </div>
            
            <div id="apend_div" class="order-3">
                
            </div>
  
            </div>
        </div>
     
      </div>
  </section>
  

<section class="wm-pay-accordian-section bg-light-blue">
    <div class="container">
        <div class="outlet-main-div">
                 <div class="wm-outlet-div">
                           
                            <div class="sec-title text-center mb-2">
                           <h2 class="heading-h2">FAQs</h2>
                            </div>
                           
                        </div>
                         <div class="wm-outlet-div text-right justify-content-end">
                           
                            <a href="#" class="learn-more btn-6">
                           <span>Learn More </span>
                           <span><i class="bi bi-chevron-right"></i></span>
                        </a>
                           
                        </div>
                        </div>
    </div>
            <div class="container">
          <div class="accordion" id="accordionExample">
          <div class="card">
            <div class="card-head" id="headingOne">
              <h2 class="mb-0 collapsed" data-toggle="collapse" data-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
        1. What is Dual Investment?
              </h2>
            </div>
        
            <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
              <div class="card-body">
              <div class="text"> Dual Investment gives you an opportunity to buy or sell cryptocurrency at your desired price and date in the future, while earning high interest yield no matter which direction the market goes.</div>
              </div>
            </div>
          </div>
          <div class="card">
            <div class="card-head" id="headingTwo">
              <h2 class="mb-0 collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
       2. What are the benefits of using Dual Investment?
              </h2>
            </div>
            <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
              <div class="card-body">
               <div class="text"> • Buy Low or Sell High: You can buy crypto at a lower price or sell crypto at a higher price;</div>
               <div class="text"> • High Interest Yield: You’ll earn a high passive income no matter which direction the market goes;</div>
               <div class="text"> • Wide Selection: You can choose from a wide variety of assets and set the target date and price to your liking;</div>
               <div class="text"> • No Trading Fees: Zero trading fees when the target is reached and the “Buy Low” or “Sell High” product is filled.</div>
              
              </div>
            </div>
          </div>
          <div class="card">
            <div class="card-head" id="headingThree">
              <h2 class="mb-0 collapsed" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
           3. When should I use Dual Investment?
              </h2>
            </div>
            <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
              <div class="card-body">
                <div class="text">Whether you’re an advanced trader or simply a HODLer that wants to earn some extra yield, there are many different reasons why you may decide to use Dual Investment. Some of the most common scenarios include:</div>
              <div class="text">• Take profit: Sell your crypto holding at a Target Price to realize some of your investment gains while benefiting from additional interest yield; </div>
                 <div class="text">• Buy the dips: Buy crypto at a Target Price when the market is down, and enjoy additional interest yield; </div>
                 <div class="text">• Grow more crypto: You have crypto and want to earn additional returns while holding onto them; </div>
                 <div class="text">• Grow more stablecoin: You have stablecoins and want to earn additional returns while holding onto them. </div>
              </div>
            </div>
          </div>
          
          
          <div class="card">
            <div class="card-head" id="headingFour">
              <h2 class="mb-0 collapsed" data-toggle="collapse" data-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
        4. How do “Buy Low” and “Sell High” products work?
              </h2>
            </div>
            <div id="collapseFour" class="collapse" aria-labelledby="headingFour" data-parent="#accordionExample">
              <div class="card-body">
          <div class="text">There are two types of Dual Investment products: “Buy Low” and “Sell High”.</div>     
             
               <div class="text">
                   Buy Low products gives you a chance to buy your desired crypto (such as BTC) at a lower price in the future with stablecoins (BUSD or USDT).<br>
- Target Reached: On the Settlement Date, if the Market Price is at or below the Target Price, the target currency (BTC) will be bought<br>
- Target Not Reached: On the Settlement Date, if the Market Price is above the Target Price, then you will keep your stablecoins<br>
In both scenarios, you will first earn interest in stablecoins. Once the Target Price is reached, your subscription amount and interest income will be used to buy BTC.
               </div> 
             <div class="text">
                 Sell High products gives you a chance to sell your existing crypto (such as BNB) at a higher price in the future (for BUSD).<br>
- Target Reached: On the Settlement Date, the Market Price is at or above the Target Price, your BNB will be sold for BUSD<br>
- Target Not Reached: On the Settlement Date, the Market Price is below the Target Price, then you will keep your BNB<br>
In both scenarios, you will first earn interest in your existing currency (BNB). Once the Target Price is reached, your subscription amount and interest income will be sold for BUSD.
             </div>
              </div>
            </div>
          </div>
          
          <div class="card">
            <div class="card-head" id="headingfive">
              <h2 class="mb-0 collapsed" data-toggle="collapse" data-target="#collapsefive" aria-expanded="false" aria-controls="collapsefive">
       5. What is the Beginner Mode in Dual Investment?
              </h2>
            </div>
            <div id="collapsefive" class="collapse" aria-labelledby="headingfive" data-parent="#accordionExample">
              <div class="card-body">
          <div class="text">Beginner Mode is designed for new Dual Investment users. It provides a step-by-step guide to help you through the Dual Investment subscription process.</div>  
          <div class="text">You can turn on or off the Beginner Mode with the toggle button.</div>  
              </div>
            </div>
          </div>
  
  
</div>
</div>
</section>

<!---------- --------------------------- -modal ----------------------------->

<div class="hide">
    <div class="wm-custom-modal-diolog">
        <div class="wm-custom-modal-body">
           <div class="wm-custom-modal-header">
                    <span>Select a settlement </span>
                    <svg viewBox="0 0 24 24" fill="none" class="wm-custom-modal-close" id="wm-custom-modal-close">
                      <path d="M6.697 4.575L4.575 6.697 9.88 12l-5.304 5.303 2.122 2.122L12 14.12l5.303 5.304 2.122-2.122L14.12 12l5.304-5.303-2.122-2.122L12 9.88 6.697 4.575z" fill="currentColor"></path>
                    </svg>
            </div>
            <div id="Select_settlement">
            <div class="wm-custom-modal-max-height mb-3">
               
                   <div class="dual3-modal-scroller coin-list-popup">
  <div class="coin-list-popup-title">Target Price</div>
  <div class="coin-list-popup-title">Settlement Date</div>
  <div class="coin-list-popup-title justify-content-end">APR</div>
  <div class="coin-list-popup-row">
    <div class="coin-list-popup-inner-div">
      <div class="coin-list-popup-price-div">
         <input type="radio"  name="radio" value="48499" style="">
          
          <div class="">$17,000</div>
      </div>
    </div>
    <div class="coin-list-popup-inner-div">
            2022-11-22
    </div>
    <div class="coin-list-popup-apr-div">
      <div class="coin-list-popup-apr-up-sts">66.55%</div>
    </div>
  </div>
  <div class="coin-list-popup-row">
    <div class="coin-list-popup-inner-div">
      <div class="coin-list-popup-price-div">
         <input type="radio"  name="radio" value="48499" style="">
          
          <div class="">$17,000</div>
      </div>
    </div>
    <div class="coin-list-popup-inner-div">
            2022-11-22
    </div>
    <div class="coin-list-popup-apr-div">
      <div class="coin-list-popup-apr-up-sts">66.55%</div>
    </div>
  </div>
  <div class="coin-list-popup-row">
    <div class="coin-list-popup-inner-div">
      <div class="coin-list-popup-price-div">
         <input type="radio"  name="radio" value="48499" style="">
          
          <div class="">$17,000</div>
      </div>
    </div>
    <div class="coin-list-popup-inner-div">
            2022-11-22
    </div>
    <div class="coin-list-popup-apr-div">
       <div class="coin-list-popup-apr-down-sts">66.55%</div>
    </div>
  </div>
  <div class="coin-list-popup-row">
    <div class="coin-list-popup-inner-div">
      <div class="coin-list-popup-price-div">
         <input type="radio"  name="radio" value="48499" style="">
          
          <div class="">$17,000</div>
      </div>
    </div>
    <div class="coin-list-popup-inner-div">
            2022-11-22
    </div>
    <div class="coin-list-popup-apr-div">
      <div class="coin-list-popup-apr-up-sts">66.55%</div>
    </div>
  </div>
  <div class="coin-list-popup-row">
    <div class="coin-list-popup-inner-div">
      <div class="coin-list-popup-price-div">
         <input type="radio"  name="radio" value="48499" style="">
          
          <div class="">$17,000</div>
      </div>
    </div>
    <div class="coin-list-popup-inner-div">
            2022-11-22
    </div>
    <div class="coin-list-popup-apr-div">
      <div class="coin-list-popup-apr-up-sts">66.55%</div>
    </div>
  </div>
  <div class="coin-list-popup-row">
    <div class="coin-list-popup-inner-div">
      <div class="coin-list-popup-price-div">
         <input type="radio"  name="radio" value="48499" style="">
          
          <div class="">$17,000</div>
      </div>
    </div>
    <div class="coin-list-popup-inner-div">
            2022-11-22
    </div>
    <div class="coin-list-popup-apr-div">
      <div class="coin-list-popup-apr-up-sts">66.55%</div>
    </div>
  </div>
  <div class="coin-list-popup-row">
    <div class="coin-list-popup-inner-div">
      <div class="coin-list-popup-price-div">
         <input type="radio"  name="radio" value="48499" style="">
          
          <div class="">$17,000</div>
      </div>
    </div>
    <div class="coin-list-popup-inner-div">
            2022-11-22
    </div>
    <div class="coin-list-popup-apr-div">
      <div class="coin-list-popup-apr-up-sts">66.55%</div>
    </div>
  </div>
  <div class="coin-list-popup-row">
    <div class="coin-list-popup-inner-div">
      <div class="coin-list-popup-price-div">
         <input type="radio"  name="radio" value="48499" style="">
          
          <div class="">$17,000</div>
      </div>
    </div>
    <div class="coin-list-popup-inner-div">
            2022-11-22
    </div>
    <div class="coin-list-popup-apr-div">
      <div class="coin-list-popup-apr-up-sts">66.55%</div>
    </div>
  </div>
  <div class="coin-list-popup-row">
    <div class="coin-list-popup-inner-div">
      <div class="coin-list-popup-price-div">
         <input type="radio"  name="radio" value="48499" style="">
          
          <div class="">$17,000</div>
      </div>
    </div>
    <div class="coin-list-popup-inner-div">
            2022-11-22
    </div>
    <div class="coin-list-popup-apr-div">
      <div class="coin-list-popup-apr-up-sts">66.55%</div>
    </div>
  </div>
  <div class="coin-list-popup-row">
    <div class="coin-list-popup-inner-div">
      <div class="coin-list-popup-price-div">
         <input type="radio"  name="radio" value="48499" style="">
          
          <div class="">$17,000</div>
      </div>
    </div>
    <div class="coin-list-popup-inner-div">
            2022-11-22
    </div>
    <div class="coin-list-popup-apr-div">
      <div class="coin-list-popup-apr-up-sts">66.55%</div>
    </div>
  </div>
  
 
</div>
 </div>
          <div class="p-2 pb-4">
    <button type="button" class="btn btn-yellow w-100">Confirm</button>
</div>      
            </div>
        </div>
    </div>
</div>


<div id="calculate_coin" class="hide">
    <div class="wm-custom-modal-diolog">
        <div class="wm-custom-modal-body">
           <div class="wm-custom-modal-header">
                    <span>Select a settlement </span>
                    <svg viewBox="0 0 24 24" fill="none" class="wm-custom-modal-close" id="wm-custom-modal-close">
                      <path d="M6.697 4.575L4.575 6.697 9.88 12l-5.304 5.303 2.122 2.122L12 14.12l5.303 5.304 2.122-2.122L14.12 12l5.304-5.303-2.122-2.122L12 9.88 6.697 4.575z" fill="currentColor"></path>
                    </svg>
            </div>
             <div class="wm-custom-modal-max-height mb-3">
                <div id="show_calculate_coin_modal">
                    
                </div>
                 </div>
        </div>
     </div>
</div>





  @include('template.country_language')
    @include('template.web_footer') 
 
 <script src="{{ asset('public/assets/css/accordian_bootstrap.min.js') }}"></script> 
 
 
 
   <script>
           $('.switch input').on('change', function(){
  var dad = $(this).parent();
  if($(this).is(':checked'))
    dad.addClass('switch-checked');
  else
    dad.removeClass('switch-checked');
});
$(document).ready(function(){
        $('.switch_input').change(function(){
            if($('.switch_input:checked').is(":checked")){
                $('#Beginner_Mode_on').show();
                $('#biginner_mode_of').hide();
            }else{
                $('#Beginner_Mode_on').hide();
                $('#biginner_mode_of').show();
            }
        });
    });
    

$(".di-coin-list-div").on("click", ".di-coin-list", function () {
    $(this).addClass("di-coin-list-active").removeClass("di-coin-list");
    $(this).children(".di-coin-list-img-tick").attr("src","{{ asset('public/assets/img/wm-card_tick.svg') }}");
    $(this).siblings(".di-coin-list-active").removeClass("di-coin-list-active").addClass("di-coin-list");
    $(this).siblings(".di-coin-list").children(".di-coin-list-img-tick").attr("src","{{ asset('public/assets/img/wm-not_selected_tick.svg') }}")
});


 
         $(".open_settlement_modal").click(function() {
            $(".hide").addClass("custom-modal-bck-bg").removeClass("hide");
         });
         
         $(".wm-custom-modal-close").click(function() {
            $(".custom-modal-bck-bg").addClass("hide").removeClass("custom-modal-bck-bg");
      
        });

 //   ------------------------
        $(".di-get-start-rgt-lft-swt-tbn-div").on("click", ".di-get-start-rgt-lft-swt-tbn", function () {
            $(this).addClass("btn-yellow").removeClass("di-get-start-rgt-lft-swt-tbn");
            $(this).siblings(".btn-yellow").removeClass("btn-yellow").addClass("di-get-start-rgt-lft-swt-tbn");
  
        });


    //   ------------------------
        $("#open_sell_btc").click(function() {
             $("#Sell_BTC").addClass("show").removeClass("hide");
             $("#buy_BTC").addClass("hide").removeClass("show");
         });
        $("#open_buy_btc").click(function() {
                $("#Sell_BTC").addClass("hide").removeClass("show");
                $("#buy_BTC").addClass("show").removeClass("hide");
         });

 //   -----------show more coin top-------------

         $("#Show_more_btn").click(function() {
             $("#coin_opt_desk").addClass("hide").removeClass("show");
             $("#more_coin_div").addClass("show").removeClass("hide");
             $("#Show_more_btn").addClass("hide").removeClass("show");
             $("#Show_less_btn").addClass("show").removeClass("hide");
         });
         $("#Show_less_btn").click(function() {
             $("#coin_opt_desk").addClass("show").removeClass("hide");
             $("#more_coin_div").addClass("hide").removeClass("show");
             $("#Show_more_btn").addClass("show").removeClass("hide");
             $("#Show_less_btn").addClass("hide").removeClass("show");
         });

// ----------------------------------------
        $(".date-wise-filter").on("click", ".date-wise-filter-div", function () {
            $(this).children(".date-wise-filter--txt").addClass("active");
            $(this).siblings(".date-wise-filter-div").children(".date-wise-filter--txt").removeClass("active");
  
        });
// ----------------------------

$(function(){
  var desktopForm = $('#apend_div').html();
  $(window).on('load resize', function(){
    if ($(window).width() <= 1279) {
        $( "#apend_div_child-1" ).appendTo( "#apend_div" );
        $( "#apend_div_child-2" ).appendTo( "#apend_div" );
    } 
    else {
      $( "#apend_div_child-1" ).appendTo( ".Return_Calculator_div" );
      $( "#apend_div_child-2" ).appendTo( ".Return_Calculator_div" );
      
    }
  });
});





   </script>
  
    </body>
</html>























