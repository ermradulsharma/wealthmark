<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <title>Wealth Mark | {{ Request::segment(2) }}</title>
    @include('template.web_css')
    <link rel='stylesheet' href="{{('../public/assets/css/deepak_custom.css') }}">
</head>
<body>
    @include('template.mobile_menu')
    @include('template.web_menu')
  
    <section>
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 colxs-12 d-flex justify-content-center align-items-center">
                <img src="{{ asset('public/assets/img/maintence-image.png') }}" class="img-fluid" alt="Website is under maintence">
                </div>
            </div>
        </div>
    </section>
    

    @include('template.country_language')
    @include('template.web_footer')
</body>

</html>