  <!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
   <head>
      <meta charset="utf-8">
      <meta content="width=device-width, initial-scale=1.0" name="viewport">
      <title>Wealth Mark | Create Entity Account</title>
  @include('template.web_css')
      
  
 <style>

.latest_news.top_news .card{
    flex-direction: row;
}
.latest_news.top_news .card .card-left .card-img::before{
    background:red;
    height:auto;
    width:auto;
}
.latest_news.top_news .card .card-left{
    max-width:350px;
    min-height: auto;
    height: auto;
    max-height: max-content;
}
.latest_news.top_news .card .card-left img{
   width:100%;
   height:100%
}

.css-1t0lvrh {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    background: url("https://rvs-article-preview-component.netlify.app/images/drawers.jpg") center center / cover no-repeat;
    height: 208px;
    align-items: flex-end;
    margin-bottom:10px;
}
.css-1dchf1x {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    height: 48px;
    background-color: rgba(0, 0, 0, 0.75);
    width: 100%;
    padding-left: 16px;
    padding-right: 16px;
    -webkit-box-align: center;
    align-items: center;
}
.css-19t8bim {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    overflow: hidden;
    text-overflow: ellipsis;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    color: rgb(255, 255, 255);
    font-weight: 400;
    font-size: 14px;
    line-height: 18px;
}
.ticker {
  margin: 0;
  padding: 10px;
  width:calc(100% - 250px);
  text-align: left;
  border: #ccc 1px solid;
  position: relative;
  overflow: hidden;
  background-color:#ffffff;
  flex:1 1 0%;
}

.ticker ul {
  width: 100%;
  position: relative;
  margin: auto;
}

.ticker ul li {
  width: 100%;
  display: none;
}

/* DEMO */

.news-tickerpanel{
    height: 50px;
    display: flex;
    overflow: hidden;
    box-sizing: border-box;
}
.news-tickerpanel .Flash_news{
   padding: 10px;
    font-size: 20px;
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    padding-left: 10px;
    padding-right: 10px;
    color: white;
    background-color: #fdc116;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: center;
    justify-content: center;
}







.works-category ul{
     margin: 0;
    padding: 0;
    clear: both;
    display: flex;
    flex-wrap: nowrap;
    overflow-x: scroll;
 
}
.works-category ul li{
  list-style-type: none;
  display: inline-block;
  margin: 0;
  padding: 0 10px;
border-right: 1px solid #EAECEF;
}
.works-category ul li a{
    box-sizing: border-box;
    margin: 0;
    min-width: 0;
    cursor: pointer;
    font-size: 18px;
    padding-left: 16px;
    padding-right: 16px;
    -webkit-flex-shrink: 0;
    -ms-flex-negative: 0;
    flex-shrink: 0;
    color: #263674;
    text-transform: uppercase;
}
.works-category ul li a:hover{
    color: #566784 
}
.works-category ul li a.selected{
  color: #fdc116;
    border-bottom: 1px solid #f0b90b
}

.filter-hide{
  display: none;
}

.latest_news.top_news .card:hover{
    box-shadow:0 .5rem 1rem rgba(0,0,0,.15)!important;
}
.works-category .scrollbar-style::-webkit-scrollbar{
	    display:none;
	    	height:2px !important;
	}
 @media screen and (max-width: 767px) {
     .latest_news.top_news .card{
            flex-direction: column;
     }
     .latest_news.top_news .card .card-left{
         max-width:100%;
     }
     .works-category .scrollbar-style::-webkit-scrollbar{
         display:block !important;
     }
 }

.pagination-list .pagination {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 16px;
        flex-wrap: wrap;
      }
    .pagination-list   .pages {
        display: flex;
        flex-direction: row;
        gap: 20px;
      }
    .pagination-list   .page {
        height: 40px;
        width: 40px;
        border-radius: 50%;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 10px;
        font-size: 20px;
        color: #263674;
      }
   .pagination-list    .page:hover {
        background-color: #fdc116;
        color: #fff;
      }

    .pagination-list .active {
        background-color: #fdc116;
        color: #fff;
      }

     .pagination-list  .btn {
        background-color: #fff;
        border: 1px solid rgb(240 185 11);
        height: 40px;
        width: 40px;
        border-radius: 50%;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
      }
   .pagination-list    .btn:hover  .btn--icon {
       stroke: #fff;
      }
      .pagination-list .btn:hover  {
        background-color:#fdc116;
      }
      
    .pagination-list   .btn--icon {
        height: 24px;
        width: 24px;
        stroke: #fdc116;
      }
    .pagination-list   .btn--icon:hover {
        stroke: #fff;
      }
  
  
  
  
  
  .css-133dcxi {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
}
.css-4cffwv {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
}
.css-vseaxs {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: none;
    -webkit-box-pack: center;
    justify-content: center;
    -webkit-box-align: center;
    align-items: center;
    width: 0px;
    height: 64px;
    background-color: rgb(38 54 116);
    color: #fdc116;
    font-size: 12px;
}
.css-15318gj {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    flex: 1 1 0%;
    border-width: 1px 1px 0px;
    border-top-style: solid;
    border-right-style: solid;
    border-left-style: solid;
    border-top-color:#263674;
    border-right-color: #263674;
    border-left-color:#263674;
    border-image: initial;
    border-bottom-style: initial;
    border-bottom-color: initial;
}
.css-p2r73z {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    font-size: 12px;
    background-color: rgb(38 54 116);
    color: #fff;
    height: 40px;
    -webkit-box-align: center;
    align-items: center;
    padding-left: 16px;
    padding-right: 16px;
}.css-1rscs2a {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    padding: 12px;
}
.remove {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    overflow: hidden;
    text-overflow: ellipsis;
    display: -webkit-box;
    -webkit-line-clamp: 1;
    -webkit-box-orient: vertical;
    font-weight: 500;
    font-size: 14px;
    line-height: 16px;
    color: rgb(234, 236, 239);
}
.css-2aehni {
    box-sizing: border-box;
    margin: 0px 0px 4px;
    min-width: 0px;
}
.remove {
    box-sizing: border-box;
    margin: 8px 0px 0px;
    min-width: 0px;
    color: rgb(183, 189, 198);
    font-size: 12px;
    line-height: 20px;
    overflow-wrap: break-word;
}
.css-28zjp5 {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    width: 100%;
}
.css-1ofvshw {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    max-width: 100%;
    height: auto;
    border: 1px solid rgb(234, 236, 239);
    border-radius: 10.7755px;
    cursor: pointer;
}
.css-q2wk8b {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    justify-content: space-between;
        margin-top: 20px;
}
.css-17wixki {
    box-sizing: border-box;
    margin: 0;
    min-width: 0;
    color: #F0B90B;
    padding: 0;
}
.css-1glwhqu {
    box-sizing: border-box;
    min-width: 0px;
    display: flex;
    height: 26px;
    border: 1px solid #263674;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: justify;
    justify-content: space-between;
    border-radius: 4px;
    cursor: pointer;
    padding-right: 0px;
    background-color: #263674;
}
.css-3kf5r8 {
    box-sizing: border-box;
    margin: 0px 0px 0px 8px;
    min-width: 0px;
    color: #fdc116;
    font-size: 12px;
    fill: #fdc116;
    width: 1em;
    height: 1em;
}
.css-1neiniz {
    box-sizing: border-box;
    margin: 0px 2px 0px 4px;
    min-width: 0px;
    font-size: 12px;
    color: #fff;
    font-weight: 500;
}
.css-6iihbs {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    font-size: 12px;
    color: rgb(246, 70, 93);
}
.css-1fegw0o {
    box-sizing: border-box;
    margin: 0px 4px 0px 8px;
    min-width: 0px;
    color: #fdc116;
    font-size: 20px;
    fill: #fdc116;
    width: 1em;
    height: 1em;
    display: block;
}


.css-ilvzcf {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    -webkit-box-align: center;
    align-items: center;
    display: none;
}

.css-b8sf2g {
    box-sizing: border-box;
    margin: 0px 12px 0px 0px;
    min-width: 0px;
    display: flex;
    border: 1px solid rgb(38 54 116);
    border-radius: 2px;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: center;
    justify-content: center;
    background: rgb(38 54 116);
    cursor: pointer;
    height: 32px;
    padding-left: 10px;
    padding-right: 10px;
    color:white;
}

.css-1xhlgts {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    color: #fdc116;
    fill: #fdc116;
    width: 1em;
    height: 1em;
    font-size: 16px;
}
.css-b8sf2g:hover {
    border: 1px solid #ffc107;
    background: #ffc107;
}

.css-b8sf2g:hover .css-1xhlgts{
    color: #000;
    fill: #000;
}
.css-vurnku {
    box-sizing: border-box;
    margin: 0;
    min-width: 0;
}
.css-1f9551p {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: inline-block;
    position: relative;
}
.css-kci4wn {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    border: 1px solid rgb(38 54 116);
    border-radius: 2px;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: center;
    justify-content: center;
    background: rgb(38 54 116);
    cursor: pointer;
    height: 32px;
    padding-left: 10px;
    padding-right: 10px;
}

.css-n27cny {
    box-sizing: border-box;
    margin: 8px 0px 0px;
    min-width: 0px;
    display: flex;
    color: rgb(94, 102, 115);
    font-size: 14px;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: end;
    justify-content: flex-end;
}
.css-19aq2ty {
    box-sizing: border-box;
    margin: 0px 0px 2px;
    min-width: 0px;
    color: rgb(132, 142, 156);
    fill: rgb(132, 142, 156);
    width: 1em;
    height: 1em;
    font-size: 20px;
}
.css-15w27ik {
    box-sizing: border-box;
    margin: 0px 12px 0px 4px;
    min-width: 0px;
}
.css-vurnku {
    box-sizing: border-box;
    margin: 0;
    min-width: 0;
}
.css-1f9551p {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: inline-block;
    position: relative;
}
.css-1f9551p {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: inline-block;
    position: relative;
}
.css-mvf8df {
    box-sizing: border-box;
    margin: 16px 0px;
    min-width: 0px;
    display: flex;
    -webkit-box-align: center;
    align-items: center;
}
.css-14nuxxl {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    font-size: 20px;
    color: #ffc107;
    font-weight: 700;
}
.css-1x2yl34 {
    box-sizing: border-box;
    margin: 0px 0px 0px 8px;
    min-width: 0px;
    display: flex;
    flex-direction: column;
    -webkit-box-pack: center;
    justify-content: center;
    position: relative;
    top: 0.2rem;
    border-left: 2px solid rgb(234 236 239);
        padding-left: 10px;
}
.css-6pa7g3 {
    box-sizing: border-box;
    margin: 0px 0px 0.2rem;
    min-width: 0px;
    font-size: 12px;
    color: #263674;
}
.css-1699ptd {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    font-size: 12px;
    color: #263674;
}
@media screen and (min-width: 767px)
{
    .css-6pa7g3 {
    font-size: 18px;
}
.css-1699ptd {
    font-size: 18px;
}
    .css-1x2yl34 {
    top: 0.25rem;
}
    .css-n27cny {
    display: none;
}

    .css-ilvzcf {
    display: flex;
}
    .css-1bat3r0 {
    display: flex;
    flex-direction: row;
}

    .css-6iihbs {
    font-size: 14px;
}
    .css-1neiniz {
    font-size: 14px;
    margin-left: 4px;
    margin-right: 4px;
}
    .css-3kf5r8 {
    width: 16px;
    height: 16px;
    font-size: 16px;
}
    .css-1glwhqu {
    height: 32px;
}
    .remove {
    font-size: 14px;
    line-height: 24px;
}
    .remove {
    font-size: 24px;
    line-height: 28px;
}
.css-28zjp5 {
    width: 442px;
}
.css-vseaxs {
    display: flex;
    width: 80px;
}
    .css-p2r73z {
    display: none;
}.css-1rscs2a {
    padding: 24px;
}
.css-2aehni {
    margin-bottom: 16px;
}
.css-1ofvshw {
    border-radius: 8px;
}
.css-mvf8df {
    margin-top: 24px;
    margin-bottom: 24px;
}
.css-14nuxxl {
    font-size: 54px;
}
}

@media screen and (min-width: 1023px)
{
    .css-6pa7g3 {
    font-size: 16px;
}
.css-1699ptd {
    font-size: 16px;
}
    .css-mvf8df {
    margin-top: 40px;
    margin-bottom: 32px;
}
    
    .css-ilvzcf {
    display: flex;
}

    .css-1ofvshw {
    border-radius: 8px;
}
    .css-28zjp5 {
    width: 532px;
}
    .css-2aehni {
    margin-bottom: 20px;
}
.css-1rscs2a {
    padding: 40px;
}
.css-vseaxs {
    width: 115px;
}
}

.news ul.tabs li.tab-link{
    FONT-SIZE:calc(20px + 6 * ((100vw - 320px) / 680));
    padding:5px 10px;
    margin:0px
     margin-bottom:5px;;
      color:#9e9e9e;
    border-bottom:2px solid #9e9e9e;
}
.news ul.tabs li.current{
    BACKGROUND:NONE;
    box-shadow:0px 0px 5px transparent !important ;
      padding:5px 10px;
    margin:0px;
    margin-bottom:5px;
    color:#ffc107;
    border-bottom:2px solid #ffc107;
    border-radius:0px;
}

@media screen and (max-width: 450px)
{
    .news-tickerpanel .Flash_news{
        padding-left:5px;
        padding-right:5px;
        font-size:14px !important;
    }
   .news-tickerpanel .ticker ul li{
       overflow:hidden;
       white-space: nowrap !important; 
   }
}



.css-15318gj:hover{
    box-shadow: 0 .5rem 1rem rgba(0,0,0,.15)!important;
}
 </style>
  
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>  
 <script>
        $(function(){
          $.simpleTicker($("#ticker-roll"),{'effectType':'roll'});
        });
</script>


   </head>
   
 <body class="bg-white">
     
     @include('template.mobile_menu')
        @include('template.web_menu')
       
   <div class="bg-dark-blue p-2 reward-section">
       <div class="container">
           <div class="row aligh-items-center justify-content-center">
               <div class="col-md-6">
                <a href="{{ url( app()->getLocale(), 'register') }}" class="reward-link">
                     <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="reward-gift-svg">
                          <path d="M13.5 6.379V3h-3v3.379l-2.94-2.94-2.12 2.122L7.878 8H4v3h6.75V8h2.5v3H20V8h-3.879l2.44-2.44-2.122-2.12L13.5 6.378zM4 13.5V20h6.75v-6.5H4zM13.25 20H20v-6.5h-6.75V20z" fill="currentColor"></path>
                    </svg>
                    <div class="reward-text">Register now and get verified - Enjoy Welcome Rewards up to $100!</div>
                    <div class="reward-div-arrow">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="reward-arrow-svg">
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M21 11.999l-7.071-7.071-1.768 1.768 4.055 4.054H2.999v2.5h13.216l-4.054 4.053 1.768 1.768L21 12v-.001z" fill="currentColor"></path>
                        </svg>
                    </div>
                </a>
               </div>
           </div>
       </div>
   </div> 
    <section class="pb-0 pt-2 news">
        <div class="container">
            <div class="row">
                <div class="col-md-12 mt-2 otc-doc-div scrollbar-style">
                    <ul class="tabs">
                        <li class="tab-link current" data-tab="Flash_news-top"> Flash news  </li>
                        <li class="tab-link" data-tab="Top_news_top">Top news </li>
                    </ul>
                   
                </div>
            </div>
        </div>
    </section>
    <div id="Flash_news-top" class="table-content current bg-light-blue p-0">
       <div class="">
           <div class="container">
               <div class="row">
                   <div class="col-md-12">
                       <div class="css-mvf8df">
                            <div class="css-14nuxxl">Today</div>
                            <div class="css-1x2yl34">
                                <div class="css-6pa7g3">2022-10-13</div>
                                <div class="css-1699ptd">Thursday</div>
                            </div>
                        </div>
                       
                       <div class="css-133dcxi">
  <div class="css-4cffwv">
    <div class="css-vseaxs">53 mins ago</div>
    <div class="css-15318gj">
      <div class="css-p2r73z">
        <div class="css-vurnku">53 mins ago</div>
      </div>
      <div class="css-1rscs2a">
        <div class="css-vurnku">
          <a href="#">
            <h3>WM Chain Burns Over $570M Worth of WM in 21st Burn Event</h3>
            <div class="css-2aehni">
              <div class="text" style="overflow-wrap: break-word; display: block;">According to the Wealthmark Announcement, WM Chain burned about $570M worth of WM in its 21st ever burn on 13/10/2022. The event was also the last quarterly burn of 2022. The burn includes the Auto-Burn feature, Pioneer Burn Program, and a portion of gas fees burned in every transaction. A total of 2,065,152.42 WM was burned, which is about 1.28% of the current circulation of WM.&nbsp;What You Need to Know About the WM BurnSince the launch of WM and Wealthmark in 2017, we're committed to removing 100 million WM, or half of the total supply, from circulation, through a bur 
            
                </span>
              </div>
            </div>
          </a>
        </div>
        <div class="css-28zjp5">
          <img src="https://rvs-article-preview-component.netlify.app/images/drawers.jpg" class="css-1ofvshw">
        </div>
        <div class="css-q2wk8b">
          <a  href="#" class="css-17wixki">
            <div class="css-1glwhqu">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="css-3kf5r8">
                <path fill-rule="evenodd" clip-rule="evenodd" d="M15 3.5a5.502 5.502 0 00-5.302 4.032 7.502 7.502 0 016.77 6.77A5.502 5.502 0 0015 3.5zM14.5 15a5.5 5.5 0 10-11 0 5.5 5.5 0 0011 0zm-8 0L9 17.5l2.5-2.5L9 12.5 6.5 15zM9 4H4v5l5-5zm11 16h-5l5-5v5z" fill="currentColor"></path>
              </svg>
              <div class="css-1neiniz">WM</div>
              <div class="css-6iihbs">-2.84%</div>
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="css-1fegw0o">
                <path fill-rule="evenodd" clip-rule="evenodd" d="M12.288 12l-3.89 3.89 1.768 1.767L15.823 12l-1.768-1.768-3.889-3.889-1.768 1.768 3.89 3.89z" fill="currentColor"></path>
              </svg>
            </div>
          </a>
          <div class="css-ilvzcf">
            <div class="css-b8sf2g">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="css-1xhlgts">
                <path fill-rule="evenodd" clip-rule="evenodd" d="M8 9.723l3.444-3.391V3.01h.888a3.106 3.106 0 013.106 3.105v1.673H21v6.425a4.778 4.778 0 01-4.778 4.778H8V9.723zm-2-.038H3v9.306h3V9.685z" fill="currentColor"></path>
              </svg>
              <div class="css-16iss1g">225</div>
            </div>
            <div class="css-vurnku">
              <div class="css-1f9551p">
                <div class="bn-tooltip-box css-1yof1af" style="position: absolute; left: -61px; top: -116px; transition: opacity 120ms ease-in-out 0s, transform 120ms ease-in-out 0s; opacity: 0; transform: translate3d(0px, -6px, 0px); visibility: hidden;" data-popper-reference-hidden="true" data-popper-escaped="false" data-popper-placement="top">
                  <div class="css-12dqhzl">
                    <div class="css-1cz7k16">
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="css-16vuvx8">
                        <path d="M8.287 20.5c7.545 0 11.675-6.535 11.675-12.198 0-.181 0-.362-.01-.555A8.518 8.518 0 0022 5.527a8.283 8.283 0 01-2.363.68 4.323 4.323 0 001.81-2.379c-.791.499-1.67.85-2.612 1.042a3.967 3.967 0 00-2.992-1.37c-2.266 0-4.109 1.925-4.109 4.292 0 .34.044.657.109.974-3.404-.17-6.428-1.89-8.455-4.485a4.44 4.44 0 00-.553 2.164c0 1.483.726 2.797 1.82 3.567a3.982 3.982 0 01-1.853-.532v.057c0 2.072 1.42 3.816 3.285 4.201a3.806 3.806 0 01-1.084.148c-.26 0-.52-.023-.77-.08.52 1.71 2.038 2.945 3.837 2.98a7.995 7.995 0 01-5.094 1.834c-.326 0-.662-.011-.976-.057A11.183 11.183 0 008.287 20.5z" fill="currentColor"></path>
                      </svg>
                    </div>
                    <div class="css-1cz7k16">
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="css-16vuvx8">
                        <path d="M22 12.07c0 5.013-3.659 9.178-8.437 9.94v-7.03h2.336l.437-2.91h-2.763v-1.89c0-.794.384-1.578 1.622-1.578h1.269V6.133s-1.152-.193-2.24-.193c-2.283 0-3.787 1.395-3.787 3.908v2.222H7.9v2.91h2.538v7.03A10.07 10.07 0 012 12.07C2 6.509 6.48 2 12.005 2 17.531 2 22 6.509 22 12.07z" fill="currentColor"></path>
                      </svg>
                    </div>
                    <div class="css-1cz7k16">
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="css-16vuvx8">
                        <path d="M12 2C6.478 2 2 6.478 2 11.99 2 17.511 6.478 22 12 22s10-4.488 10-10.01C22 6.477 17.522 2 12 2zm4.925 6.28c-.064.927-1.78 7.857-1.78 7.857s-.107.405-.48.415a.644.644 0 01-.49-.192c-.395-.33-1.29-.97-2.132-1.556a.949.949 0 01-.107.096c-.192.17-.48.416-.789.714-.117.107-.245.224-.373.352l-.01.01a2.21 2.21 0 01-.193.171c-.415.341-.458.053-.458-.096l.224-2.441v-.021l.01-.022c.011-.032.033-.043.033-.043s4.36-3.88 4.477-4.296c.01-.021-.021-.043-.074-.021-.288.096-5.31 3.273-5.864 3.625-.032.02-.128.01-.128.01l-2.441-.8s-.288-.117-.192-.383c.021-.054.053-.107.17-.181.544-.384 10-3.785 10-3.785s.267-.085.427-.032c.074.032.117.064.16.17.01.043.021.128.021.224 0 .054-.01.118-.01.224z" fill="currentColor"></path>
                      </svg>
                    </div>
                    <div class="css-1cz7k16">
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="css-16vuvx8">
                        <path d="M9.714 11.994c.575 0 1.044.469 1.044 1.044 0 .576-.469 1.045-1.044 1.045a1.046 1.046 0 01-1.045-1.045c0-.575.47-1.044 1.045-1.044zM12.005 16.022c.682 0 1.64-.16 2.088-.608a.28.28 0 01.384-.01.27.27 0 010 .383c-.714.714-2.067.768-2.472.768-.405 0-1.759-.054-2.472-.757a.27.27 0 010-.384.27.27 0 01.383 0c.448.448 1.407.608 2.089.608zM13.252 13.05c0-.576.468-1.045 1.044-1.045a1.06 1.06 0 011.044 1.044c0 .576-.469 1.044-1.044 1.044a1.046 1.046 0 01-1.044-1.044z" fill="currentColor"></path>
                        <path fill-rule="evenodd" clip-rule="evenodd" d="M12.005 2.01c-5.52 0-9.995 4.475-9.995 9.995S6.485 22 12.005 22A9.989 9.989 0 0022 12.005c-.01-5.52-4.475-9.995-9.995-9.995zm5.797 11.327c.021.139.032.288.032.437 0 2.248-2.611 4.06-5.829 4.06-3.218 0-5.829-1.812-5.829-4.06 0-.15.01-.298.032-.437a1.447 1.447 0 01-.863-1.332 1.462 1.462 0 012.472-1.055c1.013-.735 2.408-1.193 3.964-1.236 0-.021.735-3.485.735-3.485 0-.063.043-.127.096-.16a.263.263 0 01.203-.042l2.419.522c.17-.34.522-.586.927-.586a1.04 1.04 0 011.044 1.044 1.04 1.04 0 01-1.044 1.045 1.033 1.033 0 01-1.034-.991l-2.174-.47-.66 3.123c1.534.053 2.909.522 3.9 1.236a1.453 1.453 0 012.472 1.044 1.48 1.48 0 01-.863 1.343z" fill="currentColor"></path>
                      </svg>
                    </div>
                    <div class="css-1cz7k16">
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="css-16vuvx8">
                        <path d="M12 3C7.03752 3 3.00006 7.03748 3.00006 12C3.00006 13.5496 3.40036 15.0733 4.15949 16.4178L3.01454 20.503C2.97697 20.6373 3.01336 20.7813 3.11041 20.881C3.18514 20.9581 3.28688 21 3.39136 21C3.42267 21 3.45436 20.9961 3.48527 20.9887L7.74891 19.9325C9.05078 20.6314 10.517 21 12 21C16.9625 21 21 16.9625 21 12C21 7.03748 16.9625 3 12 3ZM16.5274 15.1758C16.3349 15.7088 15.4114 16.1952 14.9677 16.2605C14.5693 16.3188 14.0653 16.3439 13.512 16.1701C13.1767 16.0645 12.7462 15.9244 12.1949 15.6892C9.87721 14.7008 8.36365 12.3964 8.24782 12.2442C8.13239 12.092 7.30439 11.0073 7.30439 9.88461C7.30439 8.76196 7.90113 8.20983 8.11322 7.9813C8.3253 7.75278 8.57534 7.69565 8.72952 7.69565C8.88369 7.69565 9.03747 7.69761 9.17247 7.70387C9.31452 7.71091 9.50508 7.65026 9.69251 8.09557C9.88504 8.55261 10.3472 9.67526 10.4043 9.78991C10.4622 9.90417 10.5006 10.0376 10.4239 10.1898C10.3472 10.342 10.3088 10.4371 10.193 10.5706C10.0772 10.704 9.95038 10.868 9.8463 10.9705C9.73047 11.0843 9.61034 11.2076 9.74495 11.4361C9.87956 11.6647 10.3433 12.4117 11.0304 13.0166C11.9128 13.7937 12.6574 14.0348 12.8883 14.149C13.1192 14.2633 13.2542 14.2441 13.3888 14.0919C13.5234 13.9393 13.9663 13.4255 14.1201 13.1974C14.2739 12.9693 14.4281 13.0068 14.6402 13.0831C14.8522 13.159 15.9882 13.7108 16.2191 13.825C16.4499 13.9393 16.6041 13.9964 16.662 14.0915C16.7199 14.1862 16.7199 14.6433 16.5274 15.1758Z" fill="currentColor"></path>
                      </svg>
                    </div>
                    <div class="css-1cz7k16">
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="css-16vuvx8">
                        <path d="M6.379 8.5l-1.94 1.94a6.45 6.45 0 109.122 9.12l1.939-1.939-2.121-2.121-1.94 1.94a3.45 3.45 0 01-4.878-4.88L8.5 10.622 6.379 8.5zM12.56 6.56a3.45 3.45 0 014.88 4.88l-1.94 1.939 2.121 2.121 1.94-1.94a6.45 6.45 0 10-9.122-9.12L8.5 6.378 10.621 8.5l1.94-1.94z" fill="currentColor"></path>
                        <path fill-rule="evenodd" clip-rule="evenodd" d="M9.81 16.31l-2.12-2.12 6.5-6.5 2.12 2.12-6.5 6.5z" fill="currentColor"></path>
                      </svg>
                    </div>
                  </div>
                  <div class="bn-tooltip-arrow css-1u9esp9" data-popper-arrow="true" style="position: absolute; left: 77px;"></div>
                  <i class="gap-fill"></i>
                </div>
                <div class="css-vurnku">
                  <div class="css-kci4wn">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="css-1xhlgts">
                      <path fill-rule="evenodd" clip-rule="evenodd" d="M16.5 10a3.5 3.5 0 10-3.476-3.09L8.62 9.216a3.5 3.5 0 100 5.568l4.403 2.306a3.5 3.5 0 101.16-2.214L9.94 12.652a3.52 3.52 0 000-1.304l4.245-2.224A3.487 3.487 0 0016.5 10z" fill="currentColor"></path>
                    </svg>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="css-n27cny">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="css-19aq2ty">
            <path fill-rule="evenodd" clip-rule="evenodd" d="M8 9.723l3.444-3.391V3.01h.888a3.106 3.106 0 013.106 3.105v1.673H21v6.425a4.778 4.778 0 01-4.778 4.778H8V9.723zm-2-.038H3v9.306h3V9.685z" fill="currentColor"></path>
          </svg>
          <div class="css-15w27ik">225</div>
          <div class="css-vurnku">
            <div class="css-1f9551p">
              <div class="bn-tooltip-box css-1yof1af" data-popper-reference-hidden="true" data-popper-escaped="true" data-popper-placement="right" style="position: absolute; left: 8px; top: 0px; transition: opacity 120ms ease-in-out 0s, transform 120ms ease-in-out 0s; opacity: 0; transform: translate3d(6px, 0px, 0px); visibility: hidden;">
                <div class="css-12dqhzl">
                  <div class="css-1cz7k16">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="css-16vuvx8">
                      <path d="M8.287 20.5c7.545 0 11.675-6.535 11.675-12.198 0-.181 0-.362-.01-.555A8.518 8.518 0 0022 5.527a8.283 8.283 0 01-2.363.68 4.323 4.323 0 001.81-2.379c-.791.499-1.67.85-2.612 1.042a3.967 3.967 0 00-2.992-1.37c-2.266 0-4.109 1.925-4.109 4.292 0 .34.044.657.109.974-3.404-.17-6.428-1.89-8.455-4.485a4.44 4.44 0 00-.553 2.164c0 1.483.726 2.797 1.82 3.567a3.982 3.982 0 01-1.853-.532v.057c0 2.072 1.42 3.816 3.285 4.201a3.806 3.806 0 01-1.084.148c-.26 0-.52-.023-.77-.08.52 1.71 2.038 2.945 3.837 2.98a7.995 7.995 0 01-5.094 1.834c-.326 0-.662-.011-.976-.057A11.183 11.183 0 008.287 20.5z" fill="currentColor"></path>
                    </svg>
                  </div>
                  <div class="css-1cz7k16">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="css-16vuvx8">
                      <path d="M22 12.07c0 5.013-3.659 9.178-8.437 9.94v-7.03h2.336l.437-2.91h-2.763v-1.89c0-.794.384-1.578 1.622-1.578h1.269V6.133s-1.152-.193-2.24-.193c-2.283 0-3.787 1.395-3.787 3.908v2.222H7.9v2.91h2.538v7.03A10.07 10.07 0 012 12.07C2 6.509 6.48 2 12.005 2 17.531 2 22 6.509 22 12.07z" fill="currentColor"></path>
                    </svg>
                  </div>
                  <div class="css-1cz7k16">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="css-16vuvx8">
                      <path d="M12 2C6.478 2 2 6.478 2 11.99 2 17.511 6.478 22 12 22s10-4.488 10-10.01C22 6.477 17.522 2 12 2zm4.925 6.28c-.064.927-1.78 7.857-1.78 7.857s-.107.405-.48.415a.644.644 0 01-.49-.192c-.395-.33-1.29-.97-2.132-1.556a.949.949 0 01-.107.096c-.192.17-.48.416-.789.714-.117.107-.245.224-.373.352l-.01.01a2.21 2.21 0 01-.193.171c-.415.341-.458.053-.458-.096l.224-2.441v-.021l.01-.022c.011-.032.033-.043.033-.043s4.36-3.88 4.477-4.296c.01-.021-.021-.043-.074-.021-.288.096-5.31 3.273-5.864 3.625-.032.02-.128.01-.128.01l-2.441-.8s-.288-.117-.192-.383c.021-.054.053-.107.17-.181.544-.384 10-3.785 10-3.785s.267-.085.427-.032c.074.032.117.064.16.17.01.043.021.128.021.224 0 .054-.01.118-.01.224z" fill="currentColor"></path>
                    </svg>
                  </div>
                  <div class="css-1cz7k16">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="css-16vuvx8">
                      <path d="M9.714 11.994c.575 0 1.044.469 1.044 1.044 0 .576-.469 1.045-1.044 1.045a1.046 1.046 0 01-1.045-1.045c0-.575.47-1.044 1.045-1.044zM12.005 16.022c.682 0 1.64-.16 2.088-.608a.28.28 0 01.384-.01.27.27 0 010 .383c-.714.714-2.067.768-2.472.768-.405 0-1.759-.054-2.472-.757a.27.27 0 010-.384.27.27 0 01.383 0c.448.448 1.407.608 2.089.608zM13.252 13.05c0-.576.468-1.045 1.044-1.045a1.06 1.06 0 011.044 1.044c0 .576-.469 1.044-1.044 1.044a1.046 1.046 0 01-1.044-1.044z" fill="currentColor"></path>
                      <path fill-rule="evenodd" clip-rule="evenodd" d="M12.005 2.01c-5.52 0-9.995 4.475-9.995 9.995S6.485 22 12.005 22A9.989 9.989 0 0022 12.005c-.01-5.52-4.475-9.995-9.995-9.995zm5.797 11.327c.021.139.032.288.032.437 0 2.248-2.611 4.06-5.829 4.06-3.218 0-5.829-1.812-5.829-4.06 0-.15.01-.298.032-.437a1.447 1.447 0 01-.863-1.332 1.462 1.462 0 012.472-1.055c1.013-.735 2.408-1.193 3.964-1.236 0-.021.735-3.485.735-3.485 0-.063.043-.127.096-.16a.263.263 0 01.203-.042l2.419.522c.17-.34.522-.586.927-.586a1.04 1.04 0 011.044 1.044 1.04 1.04 0 01-1.044 1.045 1.033 1.033 0 01-1.034-.991l-2.174-.47-.66 3.123c1.534.053 2.909.522 3.9 1.236a1.453 1.453 0 012.472 1.044 1.48 1.48 0 01-.863 1.343z" fill="currentColor"></path>
                    </svg>
                  </div>
                  <div class="css-1cz7k16">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="css-16vuvx8">
                      <path d="M12 3C7.03752 3 3.00006 7.03748 3.00006 12C3.00006 13.5496 3.40036 15.0733 4.15949 16.4178L3.01454 20.503C2.97697 20.6373 3.01336 20.7813 3.11041 20.881C3.18514 20.9581 3.28688 21 3.39136 21C3.42267 21 3.45436 20.9961 3.48527 20.9887L7.74891 19.9325C9.05078 20.6314 10.517 21 12 21C16.9625 21 21 16.9625 21 12C21 7.03748 16.9625 3 12 3ZM16.5274 15.1758C16.3349 15.7088 15.4114 16.1952 14.9677 16.2605C14.5693 16.3188 14.0653 16.3439 13.512 16.1701C13.1767 16.0645 12.7462 15.9244 12.1949 15.6892C9.87721 14.7008 8.36365 12.3964 8.24782 12.2442C8.13239 12.092 7.30439 11.0073 7.30439 9.88461C7.30439 8.76196 7.90113 8.20983 8.11322 7.9813C8.3253 7.75278 8.57534 7.69565 8.72952 7.69565C8.88369 7.69565 9.03747 7.69761 9.17247 7.70387C9.31452 7.71091 9.50508 7.65026 9.69251 8.09557C9.88504 8.55261 10.3472 9.67526 10.4043 9.78991C10.4622 9.90417 10.5006 10.0376 10.4239 10.1898C10.3472 10.342 10.3088 10.4371 10.193 10.5706C10.0772 10.704 9.95038 10.868 9.8463 10.9705C9.73047 11.0843 9.61034 11.2076 9.74495 11.4361C9.87956 11.6647 10.3433 12.4117 11.0304 13.0166C11.9128 13.7937 12.6574 14.0348 12.8883 14.149C13.1192 14.2633 13.2542 14.2441 13.3888 14.0919C13.5234 13.9393 13.9663 13.4255 14.1201 13.1974C14.2739 12.9693 14.4281 13.0068 14.6402 13.0831C14.8522 13.159 15.9882 13.7108 16.2191 13.825C16.4499 13.9393 16.6041 13.9964 16.662 14.0915C16.7199 14.1862 16.7199 14.6433 16.5274 15.1758Z" fill="currentColor"></path>
                    </svg>
                  </div>
                  <div class="css-1cz7k16">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="css-16vuvx8">
                      <path d="M6.379 8.5l-1.94 1.94a6.45 6.45 0 109.122 9.12l1.939-1.939-2.121-2.121-1.94 1.94a3.45 3.45 0 01-4.878-4.88L8.5 10.622 6.379 8.5zM12.56 6.56a3.45 3.45 0 014.88 4.88l-1.94 1.939 2.121 2.121 1.94-1.94a6.45 6.45 0 10-9.122-9.12L8.5 6.378 10.621 8.5l1.94-1.94z" fill="currentColor"></path>
                      <path fill-rule="evenodd" clip-rule="evenodd" d="M9.81 16.31l-2.12-2.12 6.5-6.5 2.12 2.12-6.5 6.5z" fill="currentColor"></path>
                    </svg>
                  </div>
                </div>
                <div class="bn-tooltip-arrow css-1u9esp9" data-popper-arrow="true" style="position: absolute; top: 0px;"></div>
                <i class="gap-fill"></i>
              </div>
              <div class="css-vurnku">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="css-11a3kr1">
                  <path fill-rule="evenodd" clip-rule="evenodd" d="M16.5 10a3.5 3.5 0 10-3.476-3.09L8.62 9.216a3.5 3.5 0 100 5.568l4.403 2.306a3.5 3.5 0 101.16-2.214L9.94 12.652a3.52 3.52 0 000-1.304l4.245-2.224A3.487 3.487 0 0016.5 10z" fill="currentColor"></path>
                </svg>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
                        <div class="css-133dcxi">
  <div class="css-4cffwv">
    <div class="css-vseaxs">53 mins ago</div>
    <div class="css-15318gj">
      <div class="css-p2r73z">
        <div class="css-vurnku">53 mins ago</div>
      </div>
      <div class="css-1rscs2a">
        <div class="css-vurnku">
          <a href="#">
            <h3>WM Chain Burns Over $570M Worth of WM in 21st Burn Event</h3>
            <div class="css-2aehni">
              <div class="text" style="overflow-wrap: break-word; display: block;">According to the Wealthmark Announcement, WM Chain burned about $570M worth of WM in its 21st ever burn on 13/10/2022. The event was also the last quarterly burn of 2022. The burn includes the Auto-Burn feature, Pioneer Burn Program, and a portion of gas fees burned in every transaction. A total of 2,065,152.42 WM was burned, which is about 1.28% of the current circulation of WM.&nbsp;What You Need to Know About the WM BurnSince the launch of WM and Wealthmark in 2017, we're committed to removing 100 million WM, or half of the total supply, from circulation, through a bur 
            
                </span>
              </div>
            </div>
          </a>
        </div>
      
        <div class="css-q2wk8b">
          <a  href="#" class="css-17wixki">
            <div class="css-1glwhqu">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="css-3kf5r8">
                <path fill-rule="evenodd" clip-rule="evenodd" d="M15 3.5a5.502 5.502 0 00-5.302 4.032 7.502 7.502 0 016.77 6.77A5.502 5.502 0 0015 3.5zM14.5 15a5.5 5.5 0 10-11 0 5.5 5.5 0 0011 0zm-8 0L9 17.5l2.5-2.5L9 12.5 6.5 15zM9 4H4v5l5-5zm11 16h-5l5-5v5z" fill="currentColor"></path>
              </svg>
              <div class="css-1neiniz">WM</div>
              <div class="css-6iihbs">-2.84%</div>
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="css-1fegw0o">
                <path fill-rule="evenodd" clip-rule="evenodd" d="M12.288 12l-3.89 3.89 1.768 1.767L15.823 12l-1.768-1.768-3.889-3.889-1.768 1.768 3.89 3.89z" fill="currentColor"></path>
              </svg>
            </div>
          </a>
          <div class="css-ilvzcf">
            <div class="css-b8sf2g">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="css-1xhlgts">
                <path fill-rule="evenodd" clip-rule="evenodd" d="M8 9.723l3.444-3.391V3.01h.888a3.106 3.106 0 013.106 3.105v1.673H21v6.425a4.778 4.778 0 01-4.778 4.778H8V9.723zm-2-.038H3v9.306h3V9.685z" fill="currentColor"></path>
              </svg>
              <div class="css-16iss1g">225</div>
            </div>
            <div class="css-vurnku">
              <div class="css-1f9551p">
                <div class="bn-tooltip-box css-1yof1af" style="position: absolute; left: -61px; top: -116px; transition: opacity 120ms ease-in-out 0s, transform 120ms ease-in-out 0s; opacity: 0; transform: translate3d(0px, -6px, 0px); visibility: hidden;" data-popper-reference-hidden="true" data-popper-escaped="false" data-popper-placement="top">
                  <div class="css-12dqhzl">
                    <div class="css-1cz7k16">
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="css-16vuvx8">
                        <path d="M8.287 20.5c7.545 0 11.675-6.535 11.675-12.198 0-.181 0-.362-.01-.555A8.518 8.518 0 0022 5.527a8.283 8.283 0 01-2.363.68 4.323 4.323 0 001.81-2.379c-.791.499-1.67.85-2.612 1.042a3.967 3.967 0 00-2.992-1.37c-2.266 0-4.109 1.925-4.109 4.292 0 .34.044.657.109.974-3.404-.17-6.428-1.89-8.455-4.485a4.44 4.44 0 00-.553 2.164c0 1.483.726 2.797 1.82 3.567a3.982 3.982 0 01-1.853-.532v.057c0 2.072 1.42 3.816 3.285 4.201a3.806 3.806 0 01-1.084.148c-.26 0-.52-.023-.77-.08.52 1.71 2.038 2.945 3.837 2.98a7.995 7.995 0 01-5.094 1.834c-.326 0-.662-.011-.976-.057A11.183 11.183 0 008.287 20.5z" fill="currentColor"></path>
                      </svg>
                    </div>
                    <div class="css-1cz7k16">
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="css-16vuvx8">
                        <path d="M22 12.07c0 5.013-3.659 9.178-8.437 9.94v-7.03h2.336l.437-2.91h-2.763v-1.89c0-.794.384-1.578 1.622-1.578h1.269V6.133s-1.152-.193-2.24-.193c-2.283 0-3.787 1.395-3.787 3.908v2.222H7.9v2.91h2.538v7.03A10.07 10.07 0 012 12.07C2 6.509 6.48 2 12.005 2 17.531 2 22 6.509 22 12.07z" fill="currentColor"></path>
                      </svg>
                    </div>
                    <div class="css-1cz7k16">
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="css-16vuvx8">
                        <path d="M12 2C6.478 2 2 6.478 2 11.99 2 17.511 6.478 22 12 22s10-4.488 10-10.01C22 6.477 17.522 2 12 2zm4.925 6.28c-.064.927-1.78 7.857-1.78 7.857s-.107.405-.48.415a.644.644 0 01-.49-.192c-.395-.33-1.29-.97-2.132-1.556a.949.949 0 01-.107.096c-.192.17-.48.416-.789.714-.117.107-.245.224-.373.352l-.01.01a2.21 2.21 0 01-.193.171c-.415.341-.458.053-.458-.096l.224-2.441v-.021l.01-.022c.011-.032.033-.043.033-.043s4.36-3.88 4.477-4.296c.01-.021-.021-.043-.074-.021-.288.096-5.31 3.273-5.864 3.625-.032.02-.128.01-.128.01l-2.441-.8s-.288-.117-.192-.383c.021-.054.053-.107.17-.181.544-.384 10-3.785 10-3.785s.267-.085.427-.032c.074.032.117.064.16.17.01.043.021.128.021.224 0 .054-.01.118-.01.224z" fill="currentColor"></path>
                      </svg>
                    </div>
                    <div class="css-1cz7k16">
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="css-16vuvx8">
                        <path d="M9.714 11.994c.575 0 1.044.469 1.044 1.044 0 .576-.469 1.045-1.044 1.045a1.046 1.046 0 01-1.045-1.045c0-.575.47-1.044 1.045-1.044zM12.005 16.022c.682 0 1.64-.16 2.088-.608a.28.28 0 01.384-.01.27.27 0 010 .383c-.714.714-2.067.768-2.472.768-.405 0-1.759-.054-2.472-.757a.27.27 0 010-.384.27.27 0 01.383 0c.448.448 1.407.608 2.089.608zM13.252 13.05c0-.576.468-1.045 1.044-1.045a1.06 1.06 0 011.044 1.044c0 .576-.469 1.044-1.044 1.044a1.046 1.046 0 01-1.044-1.044z" fill="currentColor"></path>
                        <path fill-rule="evenodd" clip-rule="evenodd" d="M12.005 2.01c-5.52 0-9.995 4.475-9.995 9.995S6.485 22 12.005 22A9.989 9.989 0 0022 12.005c-.01-5.52-4.475-9.995-9.995-9.995zm5.797 11.327c.021.139.032.288.032.437 0 2.248-2.611 4.06-5.829 4.06-3.218 0-5.829-1.812-5.829-4.06 0-.15.01-.298.032-.437a1.447 1.447 0 01-.863-1.332 1.462 1.462 0 012.472-1.055c1.013-.735 2.408-1.193 3.964-1.236 0-.021.735-3.485.735-3.485 0-.063.043-.127.096-.16a.263.263 0 01.203-.042l2.419.522c.17-.34.522-.586.927-.586a1.04 1.04 0 011.044 1.044 1.04 1.04 0 01-1.044 1.045 1.033 1.033 0 01-1.034-.991l-2.174-.47-.66 3.123c1.534.053 2.909.522 3.9 1.236a1.453 1.453 0 012.472 1.044 1.48 1.48 0 01-.863 1.343z" fill="currentColor"></path>
                      </svg>
                    </div>
                    <div class="css-1cz7k16">
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="css-16vuvx8">
                        <path d="M12 3C7.03752 3 3.00006 7.03748 3.00006 12C3.00006 13.5496 3.40036 15.0733 4.15949 16.4178L3.01454 20.503C2.97697 20.6373 3.01336 20.7813 3.11041 20.881C3.18514 20.9581 3.28688 21 3.39136 21C3.42267 21 3.45436 20.9961 3.48527 20.9887L7.74891 19.9325C9.05078 20.6314 10.517 21 12 21C16.9625 21 21 16.9625 21 12C21 7.03748 16.9625 3 12 3ZM16.5274 15.1758C16.3349 15.7088 15.4114 16.1952 14.9677 16.2605C14.5693 16.3188 14.0653 16.3439 13.512 16.1701C13.1767 16.0645 12.7462 15.9244 12.1949 15.6892C9.87721 14.7008 8.36365 12.3964 8.24782 12.2442C8.13239 12.092 7.30439 11.0073 7.30439 9.88461C7.30439 8.76196 7.90113 8.20983 8.11322 7.9813C8.3253 7.75278 8.57534 7.69565 8.72952 7.69565C8.88369 7.69565 9.03747 7.69761 9.17247 7.70387C9.31452 7.71091 9.50508 7.65026 9.69251 8.09557C9.88504 8.55261 10.3472 9.67526 10.4043 9.78991C10.4622 9.90417 10.5006 10.0376 10.4239 10.1898C10.3472 10.342 10.3088 10.4371 10.193 10.5706C10.0772 10.704 9.95038 10.868 9.8463 10.9705C9.73047 11.0843 9.61034 11.2076 9.74495 11.4361C9.87956 11.6647 10.3433 12.4117 11.0304 13.0166C11.9128 13.7937 12.6574 14.0348 12.8883 14.149C13.1192 14.2633 13.2542 14.2441 13.3888 14.0919C13.5234 13.9393 13.9663 13.4255 14.1201 13.1974C14.2739 12.9693 14.4281 13.0068 14.6402 13.0831C14.8522 13.159 15.9882 13.7108 16.2191 13.825C16.4499 13.9393 16.6041 13.9964 16.662 14.0915C16.7199 14.1862 16.7199 14.6433 16.5274 15.1758Z" fill="currentColor"></path>
                      </svg>
                    </div>
                    <div class="css-1cz7k16">
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="css-16vuvx8">
                        <path d="M6.379 8.5l-1.94 1.94a6.45 6.45 0 109.122 9.12l1.939-1.939-2.121-2.121-1.94 1.94a3.45 3.45 0 01-4.878-4.88L8.5 10.622 6.379 8.5zM12.56 6.56a3.45 3.45 0 014.88 4.88l-1.94 1.939 2.121 2.121 1.94-1.94a6.45 6.45 0 10-9.122-9.12L8.5 6.378 10.621 8.5l1.94-1.94z" fill="currentColor"></path>
                        <path fill-rule="evenodd" clip-rule="evenodd" d="M9.81 16.31l-2.12-2.12 6.5-6.5 2.12 2.12-6.5 6.5z" fill="currentColor"></path>
                      </svg>
                    </div>
                  </div>
                  <div class="bn-tooltip-arrow css-1u9esp9" data-popper-arrow="true" style="position: absolute; left: 77px;"></div>
                  <i class="gap-fill"></i>
                </div>
                <div class="css-vurnku">
                  <div class="css-kci4wn">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="css-1xhlgts">
                      <path fill-rule="evenodd" clip-rule="evenodd" d="M16.5 10a3.5 3.5 0 10-3.476-3.09L8.62 9.216a3.5 3.5 0 100 5.568l4.403 2.306a3.5 3.5 0 101.16-2.214L9.94 12.652a3.52 3.52 0 000-1.304l4.245-2.224A3.487 3.487 0 0016.5 10z" fill="currentColor"></path>
                    </svg>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="css-n27cny">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="css-19aq2ty">
            <path fill-rule="evenodd" clip-rule="evenodd" d="M8 9.723l3.444-3.391V3.01h.888a3.106 3.106 0 013.106 3.105v1.673H21v6.425a4.778 4.778 0 01-4.778 4.778H8V9.723zm-2-.038H3v9.306h3V9.685z" fill="currentColor"></path>
          </svg>
          <div class="css-15w27ik">225</div>
          <div class="css-vurnku">
            <div class="css-1f9551p">
              <div class="bn-tooltip-box css-1yof1af" data-popper-reference-hidden="true" data-popper-escaped="true" data-popper-placement="right" style="position: absolute; left: 8px; top: 0px; transition: opacity 120ms ease-in-out 0s, transform 120ms ease-in-out 0s; opacity: 0; transform: translate3d(6px, 0px, 0px); visibility: hidden;">
                <div class="css-12dqhzl">
                  <div class="css-1cz7k16">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="css-16vuvx8">
                      <path d="M8.287 20.5c7.545 0 11.675-6.535 11.675-12.198 0-.181 0-.362-.01-.555A8.518 8.518 0 0022 5.527a8.283 8.283 0 01-2.363.68 4.323 4.323 0 001.81-2.379c-.791.499-1.67.85-2.612 1.042a3.967 3.967 0 00-2.992-1.37c-2.266 0-4.109 1.925-4.109 4.292 0 .34.044.657.109.974-3.404-.17-6.428-1.89-8.455-4.485a4.44 4.44 0 00-.553 2.164c0 1.483.726 2.797 1.82 3.567a3.982 3.982 0 01-1.853-.532v.057c0 2.072 1.42 3.816 3.285 4.201a3.806 3.806 0 01-1.084.148c-.26 0-.52-.023-.77-.08.52 1.71 2.038 2.945 3.837 2.98a7.995 7.995 0 01-5.094 1.834c-.326 0-.662-.011-.976-.057A11.183 11.183 0 008.287 20.5z" fill="currentColor"></path>
                    </svg>
                  </div>
                  <div class="css-1cz7k16">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="css-16vuvx8">
                      <path d="M22 12.07c0 5.013-3.659 9.178-8.437 9.94v-7.03h2.336l.437-2.91h-2.763v-1.89c0-.794.384-1.578 1.622-1.578h1.269V6.133s-1.152-.193-2.24-.193c-2.283 0-3.787 1.395-3.787 3.908v2.222H7.9v2.91h2.538v7.03A10.07 10.07 0 012 12.07C2 6.509 6.48 2 12.005 2 17.531 2 22 6.509 22 12.07z" fill="currentColor"></path>
                    </svg>
                  </div>
                  <div class="css-1cz7k16">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="css-16vuvx8">
                      <path d="M12 2C6.478 2 2 6.478 2 11.99 2 17.511 6.478 22 12 22s10-4.488 10-10.01C22 6.477 17.522 2 12 2zm4.925 6.28c-.064.927-1.78 7.857-1.78 7.857s-.107.405-.48.415a.644.644 0 01-.49-.192c-.395-.33-1.29-.97-2.132-1.556a.949.949 0 01-.107.096c-.192.17-.48.416-.789.714-.117.107-.245.224-.373.352l-.01.01a2.21 2.21 0 01-.193.171c-.415.341-.458.053-.458-.096l.224-2.441v-.021l.01-.022c.011-.032.033-.043.033-.043s4.36-3.88 4.477-4.296c.01-.021-.021-.043-.074-.021-.288.096-5.31 3.273-5.864 3.625-.032.02-.128.01-.128.01l-2.441-.8s-.288-.117-.192-.383c.021-.054.053-.107.17-.181.544-.384 10-3.785 10-3.785s.267-.085.427-.032c.074.032.117.064.16.17.01.043.021.128.021.224 0 .054-.01.118-.01.224z" fill="currentColor"></path>
                    </svg>
                  </div>
                  <div class="css-1cz7k16">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="css-16vuvx8">
                      <path d="M9.714 11.994c.575 0 1.044.469 1.044 1.044 0 .576-.469 1.045-1.044 1.045a1.046 1.046 0 01-1.045-1.045c0-.575.47-1.044 1.045-1.044zM12.005 16.022c.682 0 1.64-.16 2.088-.608a.28.28 0 01.384-.01.27.27 0 010 .383c-.714.714-2.067.768-2.472.768-.405 0-1.759-.054-2.472-.757a.27.27 0 010-.384.27.27 0 01.383 0c.448.448 1.407.608 2.089.608zM13.252 13.05c0-.576.468-1.045 1.044-1.045a1.06 1.06 0 011.044 1.044c0 .576-.469 1.044-1.044 1.044a1.046 1.046 0 01-1.044-1.044z" fill="currentColor"></path>
                      <path fill-rule="evenodd" clip-rule="evenodd" d="M12.005 2.01c-5.52 0-9.995 4.475-9.995 9.995S6.485 22 12.005 22A9.989 9.989 0 0022 12.005c-.01-5.52-4.475-9.995-9.995-9.995zm5.797 11.327c.021.139.032.288.032.437 0 2.248-2.611 4.06-5.829 4.06-3.218 0-5.829-1.812-5.829-4.06 0-.15.01-.298.032-.437a1.447 1.447 0 01-.863-1.332 1.462 1.462 0 012.472-1.055c1.013-.735 2.408-1.193 3.964-1.236 0-.021.735-3.485.735-3.485 0-.063.043-.127.096-.16a.263.263 0 01.203-.042l2.419.522c.17-.34.522-.586.927-.586a1.04 1.04 0 011.044 1.044 1.04 1.04 0 01-1.044 1.045 1.033 1.033 0 01-1.034-.991l-2.174-.47-.66 3.123c1.534.053 2.909.522 3.9 1.236a1.453 1.453 0 012.472 1.044 1.48 1.48 0 01-.863 1.343z" fill="currentColor"></path>
                    </svg>
                  </div>
                  <div class="css-1cz7k16">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="css-16vuvx8">
                      <path d="M12 3C7.03752 3 3.00006 7.03748 3.00006 12C3.00006 13.5496 3.40036 15.0733 4.15949 16.4178L3.01454 20.503C2.97697 20.6373 3.01336 20.7813 3.11041 20.881C3.18514 20.9581 3.28688 21 3.39136 21C3.42267 21 3.45436 20.9961 3.48527 20.9887L7.74891 19.9325C9.05078 20.6314 10.517 21 12 21C16.9625 21 21 16.9625 21 12C21 7.03748 16.9625 3 12 3ZM16.5274 15.1758C16.3349 15.7088 15.4114 16.1952 14.9677 16.2605C14.5693 16.3188 14.0653 16.3439 13.512 16.1701C13.1767 16.0645 12.7462 15.9244 12.1949 15.6892C9.87721 14.7008 8.36365 12.3964 8.24782 12.2442C8.13239 12.092 7.30439 11.0073 7.30439 9.88461C7.30439 8.76196 7.90113 8.20983 8.11322 7.9813C8.3253 7.75278 8.57534 7.69565 8.72952 7.69565C8.88369 7.69565 9.03747 7.69761 9.17247 7.70387C9.31452 7.71091 9.50508 7.65026 9.69251 8.09557C9.88504 8.55261 10.3472 9.67526 10.4043 9.78991C10.4622 9.90417 10.5006 10.0376 10.4239 10.1898C10.3472 10.342 10.3088 10.4371 10.193 10.5706C10.0772 10.704 9.95038 10.868 9.8463 10.9705C9.73047 11.0843 9.61034 11.2076 9.74495 11.4361C9.87956 11.6647 10.3433 12.4117 11.0304 13.0166C11.9128 13.7937 12.6574 14.0348 12.8883 14.149C13.1192 14.2633 13.2542 14.2441 13.3888 14.0919C13.5234 13.9393 13.9663 13.4255 14.1201 13.1974C14.2739 12.9693 14.4281 13.0068 14.6402 13.0831C14.8522 13.159 15.9882 13.7108 16.2191 13.825C16.4499 13.9393 16.6041 13.9964 16.662 14.0915C16.7199 14.1862 16.7199 14.6433 16.5274 15.1758Z" fill="currentColor"></path>
                    </svg>
                  </div>
                  <div class="css-1cz7k16">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="css-16vuvx8">
                      <path d="M6.379 8.5l-1.94 1.94a6.45 6.45 0 109.122 9.12l1.939-1.939-2.121-2.121-1.94 1.94a3.45 3.45 0 01-4.878-4.88L8.5 10.622 6.379 8.5zM12.56 6.56a3.45 3.45 0 014.88 4.88l-1.94 1.939 2.121 2.121 1.94-1.94a6.45 6.45 0 10-9.122-9.12L8.5 6.378 10.621 8.5l1.94-1.94z" fill="currentColor"></path>
                      <path fill-rule="evenodd" clip-rule="evenodd" d="M9.81 16.31l-2.12-2.12 6.5-6.5 2.12 2.12-6.5 6.5z" fill="currentColor"></path>
                    </svg>
                  </div>
                </div>
                <div class="bn-tooltip-arrow css-1u9esp9" data-popper-arrow="true" style="position: absolute; top: 0px;"></div>
                <i class="gap-fill"></i>
              </div>
              <div class="css-vurnku">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="css-11a3kr1">
                  <path fill-rule="evenodd" clip-rule="evenodd" d="M16.5 10a3.5 3.5 0 10-3.476-3.09L8.62 9.216a3.5 3.5 0 100 5.568l4.403 2.306a3.5 3.5 0 101.16-2.214L9.94 12.652a3.52 3.52 0 000-1.304l4.245-2.224A3.487 3.487 0 0016.5 10z" fill="currentColor"></path>
                </svg>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
                   </div>
               </div>
           </div>
       </div>
    </div>
    
    <!--=============================second tab =================================-->
    
    <div id="Top_news_top" class="table-content p-0">
        <section class="p-4 bg-light-blue">
        <div class="container">
              <div class="row">
              <div class="col-md-12">
                  <div class="sec-title">
                            <span class="title">Welcome to Wealthmark Latest News </span>
                            <h2 class="heading-h2">Highlights</h2>
                        </div>
              </div>
          </div>
            <div class="row">
              <div class="col-md-4 col-sm-4">
                <a href="#">
                    <div class="css-1t0lvrh">
                        <div class="css-1dchf1x">
                              <div class="css-19t8bim">Trademark Applications for NFTs Filed Soar High</div>
                        </div>
                    </div>
                </a>
              </div>
              <div class="col-md-4 col-sm-4">
                <a href="#">
                    <div class="css-1t0lvrh">
                        <div class="css-1dchf1x">
                              <div class="css-19t8bim">Trademark Applications for NFTs Filed Soar High</div>
                        </div>
                    </div>
                </a>
              </div>
              <div class="col-md-4 col-sm-4">
                <a href="#">
                    <div class="css-1t0lvrh">
                        <div class="css-1dchf1x">
                              <div class="css-19t8bim">Trademark Applications for NFTs Filed Soar High</div>
                        </div>
                    </div>
                </a>
              </div>
            </div>
        </div>
    </section>
        <div class="mb-3 p-3 bg-dark-blue">
        <div class="container">
            <div class="row">
              <div class="col-md-12 news-tickerpanel p-0">
               
          <div class="Flash_news" >
              Flash news
          </div>   
<div id="ticker-roll" class="ticker">
<ul>
<li>Working at Wealthmark</li>
<li>Working with regulators</li>
<li>Putting our users first</li>
<li>Customer Support in 40 languages</li>
<li>Transactions per second</li>
</ul>
</div><!--/#ticker -->

              </div>
             
            </div>
        </div>
    </div>
        <section class="latest_news top_news">
      <div class="container">
    
            <div class="row works-category">
                  <ul class="scrollbar-style">
                    <li><a href="#" class="selected" data-filter="*" id="filter-a">All</a></li>
        <li><a href="#" data-filter="Business" id="filter-a">Business</a></li>
        <li><a href="#" data-filter="Markets" id="filter-a"> Markets</a></li>
        <li><a href="#" data-filter="Technology" id="filter-a">Technology</a></li>
        <li><a href="#" data-filter="Policy" id="filter-a">Policy&nbsp;&&nbsp;Regulation</a></li>
                  </ul>
            </div>
            <div class="row mt-5">
             <div class="col-md-12 work-one" data-filter="vectors">
            <a href="#"> 
                <div class="card">
                    <div class="card-left">
                     
                             <img src="https://rvs-article-preview-component.netlify.app/images/drawers.jpg" class="img-responsIve">
                         
                    </div>
                    <div class="card-right">
                            <div class="">
                           <h3 class="">Bitcoin and Beyond: The Future of Cryptocurrency Investing</h3>
                            <div class="text">Since 2009, when Bitcoin was quietly launched by its creator, the technology spurred thousands of digital money projects, creating a vibrant and lucrative landscape for investors.Investors now come in all sorts of flavors. What once was a small group of geeky believers is now a diverse crowd of people, from cypherpunks to big mainstream companies and large investment funds.With cryptocurrencies gaining traction as an investment asset, investors a</div>
                            </div>
                            <div class="card-right-body">
                                <div class="card-rb-1">
                                    <img src="https://rvs-article-preview-component.netlify.app/images/avatar-michelle.jpg" alt="">
                                </div>
                                <div class="card-rb-2">
                                    <div class="card-rb-2-title fw-7">Michelle Appleton</div>
                                    <div class="card-rb-2-text fw-5">28 Jun 2020</div>
                                </div>
                                <div class="card-rb-3">
                                    <div class="card-rb-3-inner"></div>
                                    <div class="card-rb-3-inner-before">
                                        <div class="before-1">SHARE</div>
                                        <div class="before-2"><img src="https://rvs-article-preview-component.netlify.app/images/icon-facebook.svg" alt=""></div>
                                        <div class="before-3"><img src="https://rvs-article-preview-component.netlify.app/images/icon-twitter.svg" alt=""></div>
                                        <div class="before-4"><img src="https://rvs-article-preview-component.netlify.app/images/icon-pinterest.svg" alt=""></div>
                                    </div>
                                </div>
                            </div>
                    </div>
                </div>
            </a>
        </div>
             <div class="col-md-12 work-one" data-filter="Business">
            <a href="#"> 
                <div class="card">
                    <div class="card-left">
                     
                             <img src="https://rvs-article-preview-component.netlify.app/images/drawers.jpg" class="img-responsIve">
                         
                    </div>
                    <div class="card-right">
                            <div class="">
                           <h3 class="">Bitcoin and Beyond: The Future of Cryptocurrency Investing</h3>
                            <div class="text">Since 2009, when Bitcoin was quietly launched by its creator, the technology spurred thousands of digital money projects, creating a vibrant and lucrative landscape for investors.Investors now come in all sorts of flavors. What once was a small group of geeky believers is now a diverse crowd of people, from cypherpunks to big mainstream companies and large investment funds.With cryptocurrencies gaining traction as an investment asset, investors a</div>
                            </div>
                            <div class="card-right-body">
                                <div class="card-rb-1">
                                    <img src="https://rvs-article-preview-component.netlify.app/images/avatar-michelle.jpg" alt="">
                                </div>
                                <div class="card-rb-2">
                                    <div class="card-rb-2-title fw-7">Michelle Appleton</div>
                                    <div class="card-rb-2-text fw-5">28 Jun 2020</div>
                                </div>
                                <div class="card-rb-3">
                                    <div class="card-rb-3-inner"></div>
                                    <div class="card-rb-3-inner-before">
                                        <div class="before-1">SHARE</div>
                                        <div class="before-2"><img src="https://rvs-article-preview-component.netlify.app/images/icon-facebook.svg" alt=""></div>
                                        <div class="before-3"><img src="https://rvs-article-preview-component.netlify.app/images/icon-twitter.svg" alt=""></div>
                                        <div class="before-4"><img src="https://rvs-article-preview-component.netlify.app/images/icon-pinterest.svg" alt=""></div>
                                    </div>
                                </div>
                            </div>
                    </div>
                </div>
            </a>
        </div>
             <div class="col-md-12 work-one" data-filter="vectors">
            <a href="#"> 
                <div class="card">
                    <div class="card-left">
                     
                             <img src="https://rvs-article-preview-component.netlify.app/images/drawers.jpg" class="img-responsIve">
                         
                    </div>
                    <div class="card-right">
                            <div class="">
                           <h3 class="">Bitcoin and Beyond: The Future of Cryptocurrency Investing</h3>
                            <div class="text">Since 2009, when Bitcoin was quietly launched by its creator, the technology spurred thousands of digital money projects, creating a vibrant and lucrative landscape for investors.Investors now come in all sorts of flavors. What once was a small group of geeky believers is now a diverse crowd of people, from cypherpunks to big mainstream companies and large investment funds.With cryptocurrencies gaining traction as an investment asset, investors a</div>
                            </div>
                            <div class="card-right-body">
                                <div class="card-rb-1">
                                    <img src="https://rvs-article-preview-component.netlify.app/images/avatar-michelle.jpg" alt="">
                                </div>
                                <div class="card-rb-2">
                                    <div class="card-rb-2-title fw-7">Michelle Appleton</div>
                                    <div class="card-rb-2-text fw-5">28 Jun 2020</div>
                                </div>
                                <div class="card-rb-3">
                                    <div class="card-rb-3-inner"></div>
                                    <div class="card-rb-3-inner-before">
                                        <div class="before-1">SHARE</div>
                                        <div class="before-2"><img src="https://rvs-article-preview-component.netlify.app/images/icon-facebook.svg" alt=""></div>
                                        <div class="before-3"><img src="https://rvs-article-preview-component.netlify.app/images/icon-twitter.svg" alt=""></div>
                                        <div class="before-4"><img src="https://rvs-article-preview-component.netlify.app/images/icon-pinterest.svg" alt=""></div>
                                    </div>
                                </div>
                            </div>
                    </div>
                </div>
            </a>
        </div>
             <div class="col-md-12 work-one" data-filter="Business">
            <a href="#"> 
                <div class="card">
                    <div class="card-left">
                     
                             <img src="https://rvs-article-preview-component.netlify.app/images/drawers.jpg" class="img-responsIve">
                         
                    </div>
                    <div class="card-right">
                            <div class="">
                           <h3 class="">Bitcoin and Beyond: The Future of Cryptocurrency Investing</h3>
                            <div class="text">Since 2009, when Bitcoin was quietly launched by its creator, the technology spurred thousands of digital money projects, creating a vibrant and lucrative landscape for investors.Investors now come in all sorts of flavors. What once was a small group of geeky believers is now a diverse crowd of people, from cypherpunks to big mainstream companies and large investment funds.With cryptocurrencies gaining traction as an investment asset, investors a</div>
                            </div>
                            <div class="card-right-body">
                                <div class="card-rb-1">
                                    <img src="https://rvs-article-preview-component.netlify.app/images/avatar-michelle.jpg" alt="">
                                </div>
                                <div class="card-rb-2">
                                    <div class="card-rb-2-title fw-7">Michelle Appleton</div>
                                    <div class="card-rb-2-text fw-5">28 Jun 2020</div>
                                </div>
                                <div class="card-rb-3">
                                    <div class="card-rb-3-inner"></div>
                                    <div class="card-rb-3-inner-before">
                                        <div class="before-1">SHARE</div>
                                        <div class="before-2"><img src="https://rvs-article-preview-component.netlify.app/images/icon-facebook.svg" alt=""></div>
                                        <div class="before-3"><img src="https://rvs-article-preview-component.netlify.app/images/icon-twitter.svg" alt=""></div>
                                        <div class="before-4"><img src="https://rvs-article-preview-component.netlify.app/images/icon-pinterest.svg" alt=""></div>
                                    </div>
                                </div>
                            </div>
                    </div>
                </div>
            </a>
        </div>
             <div class="col-md-12 work-one" data-filter="Markets">
            <a href="#"> 
                <div class="card">
                    <div class="card-left">
                     
                             <img src="https://rvs-article-preview-component.netlify.app/images/drawers.jpg" class="img-responsIve">
                         
                    </div>
                    <div class="card-right">
                            <div class="">
                           <h3 class="">Bitcoin and Beyond: The Future of Cryptocurrency Investing</h3>
                            <div class="text">Since 2009, when Bitcoin was quietly launched by its creator, the technology spurred thousands of digital money projects, creating a vibrant and lucrative landscape for investors.Investors now come in all sorts of flavors. What once was a small group of geeky believers is now a diverse crowd of people, from cypherpunks to big mainstream companies and large investment funds.With cryptocurrencies gaining traction as an investment asset, investors a</div>
                            </div>
                            <div class="card-right-body">
                                <div class="card-rb-1">
                                    <img src="https://rvs-article-preview-component.netlify.app/images/avatar-michelle.jpg" alt="">
                                </div>
                                <div class="card-rb-2">
                                    <div class="card-rb-2-title fw-7">Michelle Appleton</div>
                                    <div class="card-rb-2-text fw-5">28 Jun 2020</div>
                                </div>
                                <div class="card-rb-3">
                                    <div class="card-rb-3-inner"></div>
                                    <div class="card-rb-3-inner-before">
                                        <div class="before-1">SHARE</div>
                                        <div class="before-2"><img src="https://rvs-article-preview-component.netlify.app/images/icon-facebook.svg" alt=""></div>
                                        <div class="before-3"><img src="https://rvs-article-preview-component.netlify.app/images/icon-twitter.svg" alt=""></div>
                                        <div class="before-4"><img src="https://rvs-article-preview-component.netlify.app/images/icon-pinterest.svg" alt=""></div>
                                    </div>
                                </div>
                            </div>
                    </div>
                </div>
            </a>
        </div>
             <div class="col-md-12 work-one" data-filter="Technology">
            <a href="#"> 
                <div class="card">
                    <div class="card-left">
                     
                             <img src="https://rvs-article-preview-component.netlify.app/images/drawers.jpg" class="img-responsIve">
                         
                    </div>
                    <div class="card-right">
                            <div class="">
                           <h3 class="">Bitcoin and Beyond: The Future of Cryptocurrency Investing</h3>
                            <div class="text">Since 2009, when Bitcoin was quietly launched by its creator, the technology spurred thousands of digital money projects, creating a vibrant and lucrative landscape for investors.Investors now come in all sorts of flavors. What once was a small group of geeky believers is now a diverse crowd of people, from cypherpunks to big mainstream companies and large investment funds.With cryptocurrencies gaining traction as an investment asset, investors a</div>
                            </div>
                            <div class="card-right-body">
                                <div class="card-rb-1">
                                    <img src="https://rvs-article-preview-component.netlify.app/images/avatar-michelle.jpg" alt="">
                                </div>
                                <div class="card-rb-2">
                                    <div class="card-rb-2-title fw-7">Michelle Appleton</div>
                                    <div class="card-rb-2-text fw-5">28 Jun 2020</div>
                                </div>
                                <div class="card-rb-3">
                                    <div class="card-rb-3-inner"></div>
                                    <div class="card-rb-3-inner-before">
                                        <div class="before-1">SHARE</div>
                                        <div class="before-2"><img src="https://rvs-article-preview-component.netlify.app/images/icon-facebook.svg" alt=""></div>
                                        <div class="before-3"><img src="https://rvs-article-preview-component.netlify.app/images/icon-twitter.svg" alt=""></div>
                                        <div class="before-4"><img src="https://rvs-article-preview-component.netlify.app/images/icon-pinterest.svg" alt=""></div>
                                    </div>
                                </div>
                            </div>
                    </div>
                </div>
            </a>
        </div>
             <div class="col-md-12 work-one" data-filter="Policy">
            <a href="#"> 
                <div class="card">
                    <div class="card-left">
                     
                             <img src="https://rvs-article-preview-component.netlify.app/images/drawers.jpg" class="img-responsIve">
                         
                    </div>
                    <div class="card-right">
                            <div class="">
                           <h3 class="">Bitcoin and Beyond: The Future of Cryptocurrency Investing</h3>
                            <div class="text">Since 2009, when Bitcoin was quietly launched by its creator, the technology spurred thousands of digital money projects, creating a vibrant and lucrative landscape for investors.Investors now come in all sorts of flavors. What once was a small group of geeky believers is now a diverse crowd of people, from cypherpunks to big mainstream companies and large investment funds.With cryptocurrencies gaining traction as an investment asset, investors a</div>
                            </div>
                            <div class="card-right-body">
                                <div class="card-rb-1">
                                    <img src="https://rvs-article-preview-component.netlify.app/images/avatar-michelle.jpg" alt="">
                                </div>
                                <div class="card-rb-2">
                                    <div class="card-rb-2-title fw-7">Michelle Appleton</div>
                                    <div class="card-rb-2-text fw-5">28 Jun 2020</div>
                                </div>
                                <div class="card-rb-3">
                                    <div class="card-rb-3-inner"></div>
                                    <div class="card-rb-3-inner-before">
                                        <div class="before-1">SHARE</div>
                                        <div class="before-2"><img src="https://rvs-article-preview-component.netlify.app/images/icon-facebook.svg" alt=""></div>
                                        <div class="before-3"><img src="https://rvs-article-preview-component.netlify.app/images/icon-twitter.svg" alt=""></div>
                                        <div class="before-4"><img src="https://rvs-article-preview-component.netlify.app/images/icon-pinterest.svg" alt=""></div>
                                    </div>
                                </div>
                            </div>
                    </div>
                </div>
            </a>
        </div>
             <div class="col-md-12 work-one" data-filter="Policy">
            <a href="#"> 
                <div class="card">
                    <div class="card-left">
                     
                             <img src="https://rvs-article-preview-component.netlify.app/images/drawers.jpg" class="img-responsIve">
                         
                    </div>
                    <div class="card-right">
                            <div class="">
                           <h3 class="">Bitcoin and Beyond: The Future of Cryptocurrency Investing</h3>
                            <div class="text">Since 2009, when Bitcoin was quietly launched by its creator, the technology spurred thousands of digital money projects, creating a vibrant and lucrative landscape for investors.Investors now come in all sorts of flavors. What once was a small group of geeky believers is now a diverse crowd of people, from cypherpunks to big mainstream companies and large investment funds.With cryptocurrencies gaining traction as an investment asset, investors a</div>
                            </div>
                            <div class="card-right-body">
                                <div class="card-rb-1">
                                    <img src="https://rvs-article-preview-component.netlify.app/images/avatar-michelle.jpg" alt="">
                                </div>
                                <div class="card-rb-2">
                                    <div class="card-rb-2-title fw-7">Michelle Appleton</div>
                                    <div class="card-rb-2-text fw-5">28 Jun 2020</div>
                                </div>
                                <div class="card-rb-3">
                                    <div class="card-rb-3-inner"></div>
                                    <div class="card-rb-3-inner-before">
                                        <div class="before-1">SHARE</div>
                                        <div class="before-2"><img src="https://rvs-article-preview-component.netlify.app/images/icon-facebook.svg" alt=""></div>
                                        <div class="before-3"><img src="https://rvs-article-preview-component.netlify.app/images/icon-twitter.svg" alt=""></div>
                                        <div class="before-4"><img src="https://rvs-article-preview-component.netlify.app/images/icon-pinterest.svg" alt=""></div>
                                    </div>
                                </div>
                            </div>
                    </div>
                </div>
            </a>
        </div>
        
        
                     
            
        </div>
        <div class="row mt-5 pagination-list">
            <div class="col-md-12">
                <div class="pagination">
      <button class="btn">
        <svg
          xmlns="http://www.w3.org/2000/svg"
          class="btn--icon"
          fill="none"
          viewBox="0 0 24 24"
          stroke="currentColor"
          stroke-width="2"
        >
          <path
            stroke-linecap="round"
            stroke-linejoin="round"
            d="M15 19l-7-7 7-7"
          />
        </svg>
      </button>
      <div class="pages">
        <a class="page">1</a>
        <a class="page">2</a>
        <a class="page active">3</a>
        <a class="page">4</a>
        <a class="page">5</a>
        <a class="page">6</a>
        <a class="page">...</a>
        <a class="page">23</a>
      </div>
      <button class="btn">
        <svg
          xmlns="http://www.w3.org/2000/svg"
          class="btn--icon"
          fill="none"
          viewBox="0 0 24 24"
          stroke="currentColor"
          stroke-width="2"
        >
          <path
            stroke-linecap="round"
            stroke-linejoin="round"
            d="M9 5l7 7-7 7"
          />
        </svg>
      </button>
    </div>
            </div>
        </div>
        </div>
 </section> 
    </div>
    
      
  @include('template.country_language')
    @include('template.web_footer') 
    
   <script>
       
(function($) {
  $.simpleTicker =function(element, options) {
    var defaults = {
      speed : 1000,
      delay : 3000,
      easing : 'swing',
      effectType : 'slide'
    }

    var param = {
      'ul' : '',
      'li' : '',
      'initList' : '',
      'ulWidth'  : '',
      'liHeight' : '',
      'tickerHook' : 'tickerHook',
      'effect' : {}
    }

    var plugin = this;
        plugin.settings = {}

    var $element = $(element),
        element = element;

    plugin.init = function() {
      plugin.settings = $.extend({}, defaults, options);
      param.ul = element.children('ul');
      param.li = element.find('li');
      param.initList = element.find('li:first');
      param.ulWidth  = param.ul.width();
      param.liHeight = param.li.height();

    //   element.css({height:(param.liHeight)});
      param.li.css({top:'0',left:'0',position:'absolute'});

      //dispatch
      switch (plugin.settings.effectType) {
       
        case 'roll':
          plugin.effect.roll();
          break;
      
      }
      plugin.effect.exec();
    }

    plugin.effect = {};

    plugin.effect.exec = function() {
      param.initList.css(param.effect.init.css)
                    .animate(param.effect.init.animate,plugin.settings.speed,plugin.settings.easing)
                    .addClass(param.tickerHook);
      if (element.find(param.li).length > 1) {
        setInterval(function(){
          element.find('.' + param.tickerHook)
                 .animate(param.effect.start.animate,plugin.settings.speed,plugin.settings.easing)
                 .next()
                 .css(param.effect.next.css)
                 .animate(param.effect.next.animate,plugin.settings.speed,plugin.settings.easing)
                 .addClass(param.tickerHook)
                 .end()
                 .appendTo(param.ul)
                 .css(param.effect.end.css)
                 .removeClass(param.tickerHook);
        },plugin.settings.delay);
      }
    }

    

    plugin.effect.roll = function() {
      param.effect = {
        'init' : {
          'css' : {top:'3em',display:'block',opacity:'0'},
          'animate' : {top:'0',opacity:'1',zIndex:'98'}
        },
        'start' : {
          'animate' : {top:'-3em',opacity:'0'}
        },
        'next' : {
          'css' : {top:'3em',display:'block',opacity:'0',zIndex:'99'},
          'animate' : {top:'0',opacity:'1'}
        },
        'end' : {
          'css' : {zIndex:'98'}
        }
      }
    }
  


    plugin.init();
  }

  $.fn.simpleTicker = function(options) {
    return this.each(function() {
      if (undefined == $(this).data('simpleTicker')) {
        var plugin = new $.simpleTiecker(this, options);
        $(this).data('simpleTicker', plugin);
      }
    });
  }
})(jQuery);
   </script>
  
<script>
    $(document).ready(function(){
     $('a#filter-a').click(function(){
       //hide all works by default 
       $(".work-one").addClass('filter-hide');
       //show slected works based on the menu clicked
       $(".work-one[data-filter='"+$(this).attr('data-filter')+"']").removeClass("filter-hide");
       //remove selected class to the link      
       $('a#filter-a').removeClass('selected');
       //add selected class to the active link
       $(this).addClass('selected');
       return false;
      });
      //show all works for "all" menu
     $('a[data-filter="*"]').click(function(event) {    
        $(".work-one").removeClass('filter-hide');
        return false;
     });
});
</script>
<script>
       //   =========================	tab pills js=========================

	    $(document).ready(function(){
	
	        $('ul.tabs li').click(function(){
		        var tab_id = $(this).attr('data-tab');
		        $('ul.tabs li').removeClass('current');
		        $('.table-content').removeClass('current');

		        $(this).addClass('current');
		        $("#"+tab_id).addClass('current');
	       })

        })
        
         $('.tabs').on('click', function(){
      $('.tabs').removeClass('active');
      $(this).addClass('active');
    });
   //   =========================	tab pills js=========================
</script>
    </body>
</html>