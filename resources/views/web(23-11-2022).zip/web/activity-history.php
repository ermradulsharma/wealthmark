<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <title>Wealth Mark | {{ Request::segment(2) }}</title>
    @include('template.web_css')
    <link rel='stylesheet' href="{{('../public/assets/css/deepak_custom.css') }}">
    <link rel="stylesheet" href="https:cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>
    @include('template.mobile_menu')
    @include('template.web_menu')
    <div class=" row seperator-img">
        <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
            <img loading="lazy" src="{{ asset('public/assets/img/banner-bottom-bg.png') }}"
                class="img-fluid dex-seperator-img">
        </div>
    </div>
    </section>
    @include('template.country_language')
    @include('template.web_footer')
</body>

</html>