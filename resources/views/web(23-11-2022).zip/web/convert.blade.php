  <!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
   <head>
      <meta charset="utf-8">
      <meta content="width=device-width, initial-scale=1.0" name="viewport">
      <title>Wealth Mark | Create Entity Account</title>
  @include('template.web_css')
      
  
 <style>
     #header{
         background:white;
         
     }

.convert_tbn {
    margin-bottom:20px;
   
    
}
.convert_tbn .nav-tabs .nav-link.active{
    border:1px solid transparent !important;
     background-color: rgb(245, 245, 245) !important;
    color: rgb(30, 35, 41);
}
.convert_tbn .nav-tabs .nav-link{
    padding:.5rem 1rem !important;
}
.convert_tbn .nav-tabs{
        border:1px solid transparent !important;
}
.convert_setting {
    box-sizing: border-box;
    margin: 0;
    min-width: 0;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-align-items: center;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
}
 .setting-icon {
    cursor: pointer;
}
.convert_tbn{
   display: flex;
    justify-content: space-between;
    align-items: center;
}
.convert_setting_inner {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
}
.svg-setting {
    box-sizing: border-box;
    margin: 0px 0px 0px 8px;
    min-width: 0px;
    color: rgb(146, 154, 165);
    font-size: 24px;
    fill: rgb(146, 154, 165);
    width: 1em;
    height: 1em;
}

.css-1u2pn8e {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    position: fixed;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: center;
    justify-content: center;
    z-index: 1200;
    flex-direction: unset;
    inset: 0px;
    background-color: rgba(0, 0, 0, 0.5);
}
.css-a4v9py {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    position: relative;
    box-shadow: rgb(20 21 26 / 16%) 0px 8px 16px, rgb(71 77 87 / 16%) 0px 16px 32px, rgb(20 21 26 / 10%) 0px 0px 1px;
    border-radius: 6px;
    background-color: rgb(255, 255, 255);
    animation: 0.3s ease-in-out 0s 1 normal none running animation-1wqz9z0;
    padding: 24px 24px 0px;
}
.css-6ccfl4 {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    flex-direction: row;
    -webkit-box-pack: justify;
    justify-content: space-between;
    -webkit-box-align: center;
    align-items: center;
    font-size: 20px;
    line-height: 28px;
    color: rgb(30, 35, 41);
}
.css-8mokm4 {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    font-weight: 500;
}
.svg-cross {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    color: rgb(146, 154, 165);
    font-size: 24px;
    fill: rgb(146, 154, 165);
    width: 1em;
    height: 1em;
}
.css-a4v9py .dialogContainer {
    box-sizing: border-box;
    width: 295px;
    padding-bottom: 8px;
}
.css-186t46b {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    padding-top: 28px;
    padding-bottom: 28px;
}
.css-a4v9py .setting-col {
    flex-direction: row;
    -webkit-box-pack: justify;
    justify-content: space-between;
    width: 100%;
    margin-top: 20px;
    line-height: 32px;
    font-weight: 500;
}


.css-17nzfcu {
    min-width: 90px;
}
.css-17nzfcu {
    margin: 0px;
    appearance: none;
    user-select: none;
    cursor: pointer;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    display: inline-flex;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: center;
    justify-content: center;
    box-sizing: border-box;
    font-size: inherit;
    font-family: inherit;
    font-weight: 500;
    text-align: center;
    text-decoration: none;
    outline: none;
    word-break: keep-all;
    color: rgb(30, 35, 41);
    border-radius: 4px;
    min-height: 24px;
    border: none;
    min-width: 90px;
    background-color: rgb(245, 245, 245);
    height: 32px;
    line-height: 32px;
}
.css-1c82c04 {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    font-weight: 500;
    font-size: 14px;
    line-height: 20px;
}




 .convert_tbn .nav-tabs .nav-link:hover{
        border:1px solid transparent !important;
    
}
@media screen and (min-width: 767px)
{
.css-a4v9py .dialogContainer {
    width: 327px;
}
    .css-a4v9py .setting-col {
    margin-top: 0px;
}
.convert_tbn {
    margin-bottom:40px;
   
    
}
}

.css-1jbmnp7 {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    flex-direction: row;
    -webkit-box-pack: justify;
    justify-content: space-between;
    width: 100%;
    min-height: 80px;
    margin-bottom: 24px;
    padding: 24px 0px 24px 24px;
}
 .main {
    color: rgb(30, 35, 41);
    font-weight: 600;
    line-height: 32px;
    font-size: 24px;
}
.css-1i0bxso {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    flex-direction: row;
    -webkit-box-pack: end;
    justify-content: flex-end;
}
 .order {
    display: none;
    line-height: 20px;
    font-size: 14px;
    cursor: pointer;
    border-radius: 4px;
    -webkit-box-align: center;
    align-items: center;
    background-color: rgb(234, 236, 239);
    padding: 6px 10px;
}


 .order .t {
    display: none;
    margin-right: 6.5px;
}

.css-1c82c04 {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    font-weight: 500;
    font-size: 14px;
    line-height: 20px;
}
.css-hfx4ru {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    color: rgb(30, 35, 41);
    font-size: 20px;
    fill: rgb(30, 35, 41);
    width: 1em;
    height: 1em;
}
 .order2 {
    display: flex;
    -webkit-box-align: center;
    align-items: center;
}
.css-101k8f4 {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    color: rgb(132, 142, 156);
}
 .label {
    
}
.css-7y16gy {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    -webkit-box-pack: end;
    justify-content: flex-end;
    line-height: 24px;
    font-size: 14px;
    color: rgb(71, 77, 87);
    user-select: none;
    font-weight: 500;
    margin-bottom: 24px;
}
.css-nqimpp {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    color: rgb(71, 77, 87);
}
.css-1tw3esi {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    height: 100%;
    cursor: pointer;
    color: rgb(71, 77, 87);
    padding: 2px 8px;
    background-color: rgb(245, 245, 245);
    -webkit-box-align: center;
    align-items: center;
    border-radius: 50px;
}
.css-q28zzn {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    color: rgb(71, 77, 87);
    font-size: 14px;
    fill: rgb(71, 77, 87);
    width: 1em;
    height: 1em;
}
.css-dr2o7u {
    box-sizing: border-box;
    margin: 0px 0px 0px 7px;
    min-width: 0px;
    font-size: 14px;
    line-height: 20px;
    font-weight: 400;
}
.css-1tw3esi:hover {
    opacity: 0.8;
}

.css-19hhts3 {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    padding: 16px;
    background-color: rgb(245, 245, 245);
    border-radius: 4px;
    width: 100%;
    cursor: pointer;
    border: 1px solid transparent;
}
.css-8ini9j {
    box-sizing: border-box;
    margin: 0px 0px 16px;
    min-width: 0px;
    display: flex;
    flex-direction: row;
    -webkit-box-pack: justify;
    justify-content: space-between;
}
.css-l4zhg1 {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    color: rgb(112, 122, 138);
    font-size: 12px;
    font-weight: 500;
}
.css-bczmgg {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    font-weight: 400;
    font-size: 12px;
    line-height: 16px;
    white-space: nowrap;
    cursor: pointer;
    color: rgb(112, 122, 138);
}
.css-1jbmnp7 {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    flex-direction: row;
    -webkit-box-pack: justify;
    justify-content: space-between;
}
.css-1wzfplb {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    position: relative;
    width: 100%;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: justify;
    justify-content: space-between;
}
.css-diw8xz {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    transform: translateY(0px);
}
.css-1wzfplb input {
    border-style: hidden;
    outline: none;
    width: 16ch;
    background-color: rgb(245, 245, 245);
    font-size: 24px;
    color: rgb(30, 35, 41);
}
.css-1lix6sn {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    position: absolute;
    flex-wrap: wrap;
    left: 2px;
    pointer-events: none;
}
.css-12prbrb {
    box-sizing: border-box;
    margin: 0px 8px 0px 0px;
    min-width: 0px;
    font-size: 24px;
    color: transparent;
    pointer-events: none;
}
.css-8ckvgb {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    font-size: 12px;
    line-height: 20px;
    color: rgb(183, 189, 198);
    align-self: end;
    pointer-events: none;
    transform: translateY(0px);
}
.css-163x3ya {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    padding: 8px;
    border-radius: 50px;
    height: 36px;
    background-color: rgb(255, 255, 255);
    -webkit-box-pack: justify;
    justify-content: space-between;
    cursor: pointer;
}
.css-h7ddr {
    box-sizing: border-box;
    margin: 0px 12px 0px 0px;
    min-width: 0px;
    display: flex;
    -webkit-box-align: center;
    align-items: center;
}
.css-1t83k2d {
    box-sizing: border-box;
    margin: 0px;
    max-width: 100%;
    border-radius: 50%;
    height: 24px;
    width: 24px;
    min-width: 24px;
}
.css-ybr09d {
    box-sizing: border-box;
    margin: 0px 0px 0px 8px;
    min-width: 0px;
    font-weight: 500;
    font-size: 16px;
    line-height: 24px;
    color: rgb(30, 35, 41);
}
.css-ix9wfv {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    transform: rotateZ(90deg) translate3d(-5px, -12px, 0px);
}
.css-1gagpxi {
    box-sizing: border-box;
    margin: 0px 0px 0px 12px;
    min-width: 0px;
    color: rgb(146, 154, 165);
    font-size: 32px;
    fill: rgb(146, 154, 165);
    width: 1em;
    height: 1em;
}
.css-4cffwv {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
}
 .revert {
    -webkit-box-pack: center;
    justify-content: center;
    margin-top: 24px;
    margin-bottom: 24px;
}

 .revert.able .icon {
    cursor: pointer;
}
 .revert .icon {
    color: rgb(112, 122, 138);
    height: 40px;
    width: 40px;
    -webkit-box-pack: center;
    justify-content: center;
    -webkit-box-align: center;
    align-items: center;
    background-color: rgb(245, 245, 245);
    border-radius: 50%;
}

.css-1iztezc {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    color: currentcolor;
    font-size: 24px;
    fill: currentcolor;
    width: 1em;
    height: 1em;
}
 .price-box {
    color: rgb(30, 35, 41);
}
.css-vurnku {
    box-sizing: border-box;
    margin: 0;
    min-width: 0;
}
 .price-box .symbol-row {
    line-height: 28px;
    margin-bottom: 12px;
}

.css-1aosppj {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    display: flex;
    -webkit-box-align: center;
    align-items: center;
}
.css-l950g5 {
    box-sizing: border-box;
    margin: 0px;
    max-width: 100%;
    border-radius: 50%;
    height: 32px;
    width: 32px;
    min-width: 32px;
}
 .price-box .symbol-name {
    font-size: 20px;
    font-weight: 500;
    margin-left: 8px;
    margin-right: 8px;
}
.css-1gkwei4 {
    box-sizing: border-box;
    margin: 0px;
    min-width: 0px;
    font-weight: 500;
    color: rgb(112, 122, 138);
    line-height: 26px;
    padding-top: 6px;
    font-size: 12px;
}
 .price-box .price-content {
    flex-flow: row wrap;
    -webkit-box-pack: justify;
    justify-content: space-between;
}
 .price-box .price-info {
    -webkit-box-align: baseline;
    align-items: baseline;
    font-size: 24px;
    line-height: 32px;
    font-weight: 500;
    flex-wrap: nowrap;
}
 .price-box .price-info .number {
    font-size: 24px;
    line-height: 24px;
    font-weight: 600;
}
 .price-box .price-info .change {
    margin-left: 8px;
    font-size: 16px;
    line-height: 24px;
}
 .price-box .price-info .change.dec {
    color: rgb(207, 48, 74);
}
 .price-box .price-info .period {
    font-size: 16px;
    line-height: 24px;
    margin-left: 8px;
    color: rgb(112, 122, 138);
}
 .period-select {
    margin-top: 16px;
    margin-bottom: 16px;
    -webkit-box-pack: center;
    justify-content: center;
    font-size: 14px;
    line-height: 22px;
    align-self: flex-end;
    height: 22px;
}
 .period-select .period-item {
    color: rgb(112, 122, 138);
    cursor: pointer;
    margin-left: 22px;
}
 .period-select .period-item:first-child {
    margin-left: 0px;
}
 .period-select .period-item.on {
    color: rgb(201, 148, 0);
    font-weight: 500;
}
@media screen and (min-width: 767px)
{
     .period-select {
    margin-top: 16px;
    margin-bottom: 0px;
    -webkit-box-pack: start;
    justify-content: flex-start;
    font-size: 14px;
    line-height: 20px;
    height: 20px;
}
     .price-box .price-info .period {
    font-size: 16px;
    line-height: 24px;
}
     .price-box .price-info .change {
    font-size: 16px;
    line-height: 24px;
}
     .price-box .price-info .number {
    font-size: 16px;
    line-height: 24px;
}
     .price-box .price-info {
    font-size: 24px;
    line-height: 32px;
}
     .price-box .price-content {
    flex-direction: column;
}

    .css-1gkwei4 {
    font-size: 16px;
}
     .price-box .symbol-name {
    font-size: 20px;
    font-weight: 500;
}
     .price-box .symbol-row {
    line-height: 28px;
    margin-bottom: 14px;
}
    .css-163x3ya {
    height: 40px;
}
 .order {
    display: flex;
    margin-right: 24px;
    padding-left: 12px;
    padding-right: 12px;
}
 .order .t {
    display: inline;
}
 .order2 {
    display: none;
}
}
 </style>
  
  
   </head>
   
 <body class="bg-white">
     
     @include('template.mobile_menu')
        @include('template.web_menu')
    
    
    
    <div class="convert-top-outer">
  <section class="header convert-top-div">
  
      <div class="container">
           <h1 class="main">Wealthmark Convert</h1>
            <div class="sub">
      <div class="sub-item">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="#fdc116" class="svg-convert-top">
          <path fill-rule="evenodd" clip-rule="evenodd" d="M20 12a8 8 0 10-16 0 8 8 0 0016 0zM12 2c5.523 0 10 4.477 10 10s-4.477 10-10 10S2 17.523 2 12 6.477 2 12 2z" fill="#fdc116"></path>
          <path fill-rule="evenodd" clip-rule="evenodd" d="M7.293 15.293l8-8 1.414 1.414-8 8-1.414-1.414z" fill="#fdc116"></path>
          <path d="M7.293 8.707l1.414 1.414 1.414-1.414-1.414-1.414-1.414 1.414zM16.707 15.293l-1.414-1.414-1.414 1.414 1.414 1.414 1.414-1.414z" fill="#fdc116"></path>
        </svg>
        <div   class="text">Zero fee</div>
      </div>
      <div class="sub-item">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="#fdc116" class="svg-convert-top">
          <path d="M13 13V7h-2v6h2zM13 17v-2h-2v2h2z" fill="#fdc116"></path>
          <path fill-rule="evenodd" clip-rule="evenodd" d="M16.591 4.045l-1.68-2.911-2.912 1.68-2.912-1.68-1.68 2.911H4.043v3.363l-2.911 1.68L2.813 12l-1.68 2.911 2.91 1.681v3.362h3.363l1.681 2.912L12 21.185l2.911 1.68 1.681-2.91h3.362v-3.362l2.912-1.682L21.184 12l1.68-2.912-2.911-1.681V4.045H16.59zm-8.03 2l1.258-2.18L12 5.126l2.18-1.26 1.258 2.18h2.516v2.517l2.18 1.258L18.875 12l1.258 2.18-2.18 1.258v2.516h-2.516l-1.259 2.18-2.18-1.259-2.179 1.259-1.258-2.18H6.044v-2.517l-2.18-1.258L5.125 12 3.863 9.82l2.18-1.258V6.045H8.56z" fill="#fdc116"></path>
        </svg>
        <div   class="text">Guaranteed price</div>
      </div>
      <div class="sub-item">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="#fdc116" class="svg-convert-top">
          <path d="M9 13.5l1.5 1.5L9 16.5 7.5 15 9 13.5z" fill="#fdc116"></path>
          <path fill-rule="evenodd" clip-rule="evenodd" d="M8.062 8.062A7.001 7.001 0 0122 9c0 3.548-2.64 6.48-6.062 6.938A7.001 7.001 0 012 15c0-3.548 2.64-6.48 6.062-6.938zM15 4a5 5 0 01.917 9.916 7.005 7.005 0 00-5.833-5.833A5.002 5.002 0 0115 4zm-6 6a5 5 0 110 10 5 5 0 010-10z" fill="#fdc116"></path>
        </svg>
        <div   class="text">Any pairs</div>
      </div>
    </div>
      </div>
      
   
   
  </section>
  
   
  <div class="content wm-convert-2 wm-convert">
  
       <div class="  css-1jbmnp7">
  <h1 data-bn-type="text" class="main css-vurnku">wealthmark Convert</h1>
  <div class="css-1i0bxso">
    <div class="order css-4cffwv">
      <div data-bn-type="text" class="t css-1c82c04">Conversion History</div>
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="css-hfx4ru">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M21 11.999l-7.071-7.071-1.768 1.768 4.055 4.054H2.999v2.5h13.216l-4.054 4.053 1.768 1.768L21 12v-.001z" fill="currentColor"></path>
      </svg>
    </div>
  </div>
  <div class="order2 css-101k8f4">
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="css-hfx4ru">
      <path fill-rule="evenodd" clip-rule="evenodd" d="M21 11.999l-7.071-7.071-1.768 1.768 4.055 4.054H2.999v2.5h13.216l-4.054 4.053 1.768 1.768L21 12v-.001z" fill="currentColor"></path>
    </svg>
  </div>
</div>
   <div class="container">
   
       <div class="row align-items-center justify-content-center">
            <div class="col-md-6 col-sm-8 col-xs-12">
            <div class="convert_tbn">
                	<nav>
			<div class="nav nav-tabs" id="nav-tab" role="tablist">
				<button class="nav-link  active" id="nav-home-tab" data-bs-toggle="tab" data-bs-target="#nav-home" type="button" role="tab" aria-controls="nav-home" aria-selected="true">Market</button>
				<button class="nav-link" id="nav-profile-tab" data-bs-toggle="tab" data-bs-target="#nav-profile" type="button" role="tab" aria-controls="nav-profile" aria-selected="false">Limit</button>
			</div>
		</nav>
		
		    <div class="convert_setting">
  <div class="setting-icon convert_setting_inner" id="Convert-setting-btn">
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="svg-setting">
      <path fill-rule="evenodd" clip-rule="evenodd" d="M13.8 3h-3.6v2.027c-.66.17-1.285.431-1.858.77L6.91 4.363 4.363 6.91l1.434 1.433a7.157 7.157 0 00-.77 1.858H3v3.6h2.027c.17.66.431 1.285.77 1.858L4.363 17.09l2.546 2.546 1.433-1.434c.573.339 1.197.6 1.858.77V21h3.6v-2.027a7.157 7.157 0 001.858-.77l1.433 1.434 2.546-2.546-1.434-1.434a7.16 7.16 0 00.77-1.857H21v-3.6h-2.027a7.158 7.158 0 00-.77-1.858l1.434-1.433-2.546-2.546-1.434 1.434a7.156 7.156 0 00-1.857-.77V3zm-4.5 9a2.7 2.7 0 115.4 0 2.7 2.7 0 01-5.4 0z" fill="currentColor"></path>
    </svg>
  </div>

		</div>
            </div>
            </div>
       </div>
       	<div class="tab-content" id="nav-tabContent">
			<div class="tab-pane fade active show" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
			
				<div class="row align-items-center justify-content-center">
           <div class="col-md-6 col-sm-8 col-xs-12">
           	<div class="label css-7y16gy">
  <div class="css-nqimpp">
    <div class="css-1tw3esi">
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="css-q28zzn">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M4 8.5A4.5 4.5 0 018.5 4H20v16H8.5A4.5 4.5 0 014 15.5v-7zM8.5 7H17v3H8.5a1.5 1.5 0 110-3zm4.5 6h4v4h-4v-4z" fill="currentColor"></path>
      </svg>
      <span data-bn-type="text" class="css-dr2o7u">Spot wallet</span>
    </div>
  </div>
</div>
           <div class="mb-3">
  
  <div class="css-19hhts3">
    <div class="css-8ini9j">
      <div data-bn-type="text" class="css-l4zhg1">From</div>
      <div data-bn-type="text" class="css-bczmgg">Balance : -- Wm</div>
    </div>
    <div class="css-1jbmnp7">
      <div class="css-1wzfplb">
        <div class="css-diw8xz">
          <input type="number" placeholder="0.00" value="">
        </div>
        <div class="css-1lix6sn">
          <div data-bn-type="text" class="css-12prbrb">0.00</div>
          <div data-bn-type="text" class="css-8ckvgb">0.0037-14000</div>
        </div>
      </div>
      <div class="css-163x3ya">
        <div class="css-h7ddr">
          <img src="https://bin.Wmstatic.com/image/admin_mgs_image_upload/20220218/94863af2-c980-42cf-a139-7b9f462a36c2.png" class="css-1t83k2d">
          <div data-bn-type="text" class="css-ybr09d">Wm</div>
        </div>
        <div class="css-ix9wfv">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="css-1gagpxi">
            <path fill-rule="evenodd" clip-rule="evenodd" d="M12.288 12l-3.89 3.89 1.768 1.767L15.823 12l-1.768-1.768-3.889-3.889-1.768 1.768 3.89 3.89z" fill="currentColor"></path>
          </svg>
        </div>
      </div>
    </div>
  </div>
</div>
           
           <div class="revert able css-4cffwv">
  <div class="icon css-4cffwv">
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="css-1iztezc">
      <path d="M7.5 3h3v18.5l-7-7h4V3zM16.5 21h-3V2.5l7 7h-4V21z" fill="currentColor"></path>
    </svg>
  </div>
</div>
  <div class="second-row css-vurnku">
  
  <div class="css-19hhts3">
    <div class="css-8ini9j">
      <div data-bn-type="text" class="css-l4zhg1">From</div>
      <div data-bn-type="text" class="css-bczmgg">Balance : -- Wm</div>
    </div>
    <div class="css-1jbmnp7">
      <div class="css-1wzfplb">
        <div class="css-diw8xz">
          <input type="number" placeholder="0.00" value="">
        </div>
        <div class="css-1lix6sn">
          <div data-bn-type="text" class="css-12prbrb">0.00</div>
          <div data-bn-type="text" class="css-8ckvgb">0.0037-14000</div>
        </div>
      </div>
      <div class="css-163x3ya">
        <div class="css-h7ddr">
          <img src="https://bin.Wmstatic.com/image/admin_mgs_image_upload/20220218/94863af2-c980-42cf-a139-7b9f462a36c2.png" class="css-1t83k2d">
          <div data-bn-type="text" class="css-ybr09d">Wm</div>
        </div>
        <div class="css-ix9wfv">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="css-1gagpxi">
            <path fill-rule="evenodd" clip-rule="evenodd" d="M12.288 12l-3.89 3.89 1.768 1.767L15.823 12l-1.768-1.768-3.889-3.889-1.768 1.768 3.89 3.89z" fill="currentColor"></path>
          </svg>
        </div>
      </div>
    </div>
  </div>
</div>
           
           </div>
       </div>
			</div>
			<!------------------------------------------------->
				<div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">
				   <div class="row align-items-center justify-content-center">
				    <div class="col-md-6 col-sm-12 col-xs-12">
				        <div class="price-box css-vurnku">
  <div class="symbol-row css-4cffwv">
    <div class="css-1aosppj">
      <img src="https://static-file-1306379396.file.myqcloud.com/image/admin_mgs_image_upload/20220218/94863af2-c980-42cf-a139-7b9f462a36c2.png" class="css-l950g5">
    </div>
    <div class="css-1aosppj">
      <img src="https://static-file-1306379396.file.myqcloud.com/image/admin_mgs_image_upload/20201110/3222a10d-5618-4100-8476-ee7fe0a6fb12.png" class="css-l950g5">
    </div>
    <div data-bn-type="text" class="symbol-name css-vurnku">Wm/BUSD</div>
    <div data-bn-type="text" class="css-1gkwei4">1 Wm = 272.8 BUSD</div>
  </div>
  <div class="price-content css-4cffwv">
    <div class="price-info css-4cffwv">
      <div data-bn-type="text" class="number css-vurnku">272.90197226</div>
      <div data-bn-type="text" class="change dec css-vurnku">-0.29%</div>
      <div data-bn-type="text" class="period css-vurnku">Past 24Hours</div>
    </div>
    <div class="css-4cffwv">
      <div class="period-select css-4cffwv">
        <div class="period-item on css-vurnku">24H</div>
        <div class="period-item  css-vurnku">1W</div>
        <div class="period-item  css-vurnku">1M</div>
      </div>
    </div>
  </div>
</div>
				        </div>
				         <div class="col-md-6 col-sm-12 col-xs-12">
				        <div class="mb-3">
  
  <div class="css-19hhts3">
    <div class="css-8ini9j">
      <div data-bn-type="text" class="css-l4zhg1">From</div>
      <div data-bn-type="text" class="css-bczmgg">Balance : -- Wm</div>
    </div>
    <div class="css-1jbmnp7">
      <div class="css-1wzfplb">
        <div class="css-diw8xz">
          <input type="number" placeholder="0.00" value="">
        </div>
        <div class="css-1lix6sn">
          <div data-bn-type="text" class="css-12prbrb">0.00</div>
          <div data-bn-type="text" class="css-8ckvgb">0.0037-14000</div>
        </div>
      </div>
      <div class="css-163x3ya">
        <div class="css-h7ddr">
          <img src="https://bin.Wmstatic.com/image/admin_mgs_image_upload/20220218/94863af2-c980-42cf-a139-7b9f462a36c2.png" class="css-1t83k2d">
          <div data-bn-type="text" class="css-ybr09d">Wm</div>
        </div>
        <div class="css-ix9wfv">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="css-1gagpxi">
            <path fill-rule="evenodd" clip-rule="evenodd" d="M12.288 12l-3.89 3.89 1.768 1.767L15.823 12l-1.768-1.768-3.889-3.889-1.768 1.768 3.89 3.89z" fill="currentColor"></path>
          </svg>
        </div>
      </div>
    </div>
  </div>
</div>
                        <div class="mt-3">
  
  <div class="css-19hhts3">
    <div class="css-8ini9j">
      <div data-bn-type="text" class="css-l4zhg1">From</div>
      <div data-bn-type="text" class="css-bczmgg">Balance : -- Wm</div>
    </div>
    <div class="css-1jbmnp7">
      <div class="css-1wzfplb">
        <div class="css-diw8xz">
          <input type="number" placeholder="0.00" value="">
        </div>
        <div class="css-1lix6sn">
          <div data-bn-type="text" class="css-12prbrb">0.00</div>
          <div data-bn-type="text" class="css-8ckvgb">0.0037-14000</div>
        </div>
      </div>
      <div class="css-163x3ya">
        <div class="css-h7ddr">
          <img src="https://bin.Wmstatic.com/image/admin_mgs_image_upload/20220218/94863af2-c980-42cf-a139-7b9f462a36c2.png" class="css-1t83k2d">
          <div data-bn-type="text" class="css-ybr09d">Wm</div>
        </div>
        <div class="css-ix9wfv">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="css-1gagpxi">
            <path fill-rule="evenodd" clip-rule="evenodd" d="M12.288 12l-3.89 3.89 1.768 1.767L15.823 12l-1.768-1.768-3.889-3.889-1.768 1.768 3.89 3.89z" fill="currentColor"></path>
          </svg>
        </div>
      </div>
    </div>
  </div>
</div>
                        <div class="revert able css-4cffwv">
  <div class="icon css-4cffwv">
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="css-1iztezc">
      <path d="M7.5 3h3v18.5l-7-7h4V3zM16.5 21h-3V2.5l7 7h-4V21z" fill="currentColor"></path>
    </svg>
  </div>
</div>
                        <div class=" css-vurnku">
  
  <div class="css-19hhts3">
    <div class="css-8ini9j">
      <div data-bn-type="text" class="css-l4zhg1">From</div>
      <div data-bn-type="text" class="css-bczmgg">Balance : -- Wm</div>
    </div>
    <div class="css-1jbmnp7">
      <div class="css-1wzfplb">
        <div class="css-diw8xz">
          <input type="number" placeholder="0.00" value="">
        </div>
        <div class="css-1lix6sn">
          <div data-bn-type="text" class="css-12prbrb">0.00</div>
          <div data-bn-type="text" class="css-8ckvgb">0.0037-14000</div>
        </div>
      </div>
      <div class="css-163x3ya">
        <div class="css-h7ddr">
          <img src="https://bin.Wmstatic.com/image/admin_mgs_image_upload/20220218/94863af2-c980-42cf-a139-7b9f462a36c2.png" class="css-1t83k2d">
          <div data-bn-type="text" class="css-ybr09d">Wm</div>
        </div>
        <div class="css-ix9wfv">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="css-1gagpxi">
            <path fill-rule="evenodd" clip-rule="evenodd" d="M12.288 12l-3.89 3.89 1.768 1.767L15.823 12l-1.768-1.768-3.889-3.889-1.768 1.768 3.89 3.89z" fill="currentColor"></path>
          </svg>
        </div>
      </div>
    </div>
  </div>
</div>
				        </div>
				    </div>
				    </div>
		</div>
      
   </div>

      
   
    
    
    </div>
    </div>
    
 <div class="height-4px conver-sec" ></div>  
    
   <section class="wm-pay-accordian-section wm-convert-acordian">
    <div class="container">
        <div class="outlet-main-div">
                 <div class="wm-outlet-div">
                           
                            <div class="sec-title text-center mb-2">
                           <h2 class="heading-h2">FAQs</h2>
                            </div>
                           
                        </div>
                         <div class="wm-outlet-div text-right justify-content-end">
                           
                            <a href="#" class="learn-more btn-6">
                           <span>Learn More </span>
                           <span><i class="bi bi-chevron-right"></i></span>
                        </a>
                           
                        </div>
                        </div>
    </div>
    <div class="container">
        
  <div class="accordion" id="accordionExample">
      <div class="row">
          <div class="col-md-6 col-sm-6 col-xs-12">
              
              <div class="card">
    <div class="card-head" id="headingOne">
      <h2 class="mb-0 collapsed" data-toggle="collapse" data-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
        1. Are there any trading fees?
      </h2>
    </div>

    <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
      <div class="card-body">
      <div class="text">   Wealthmark pay is available to all eligible users on Wealthmark.com. To start using Wealthmark Pay, please register on Wealthmark.com and complete your Identity Verification.</div>
      </div>
    </div>
  </div>
      <div class="card">
    <div class="card-head" id="heading2">
      <h2 class="mb-0 collapsed" data-toggle="collapse" data-target="#collapse2" aria-expanded="false" aria-controls="collapse2">
         2. What are the benefits of using Wealthmark Convert and how do I get started using the platform?
      </h2>
    </div>

    <div id="collapse2" class="collapse" aria-labelledby="heading2" data-parent="#accordionExample">
      <div class="card-body">
      <div class="text">   Wealthmark pay is available to all eligible users on Wealthmark.com. To start using Wealthmark Pay, please register on Wealthmark.com and complete your Identity Verification.</div>
      </div>
    </div>
  </div>
      <div class="card">
    <div class="card-head" id="heading3">
      <h2 class="mb-0 collapsed" data-toggle="collapse" data-target="#collapse3" aria-expanded="false" aria-controls="collapse3">
         3. What are the requirements to use the portal?
      </h2>
    </div>

    <div id="collapse3" class="collapse" aria-labelledby="heading3" data-parent="#accordionExample">
      <div class="card-body">
      <div class="text">   Wealthmark pay is available to all eligible users on Wealthmark.com. To start using Wealthmark Pay, please register on Wealthmark.com and complete your Identity Verification.</div>
      </div>
    </div>
  </div>
      <div class="card">
    <div class="card-head" id="heading4">
      <h2 class="mb-0 collapsed" data-toggle="collapse" data-target="#collapse4" aria-expanded="false" aria-controls="collapse4">
          4. What are the minimum and maximum trade amounts?
      </h2>
    </div>

    <div id="collapse4" class="collapse" aria-labelledby="heading4" data-parent="#accordionExample">
      <div class="card-body">
      <div class="text">   Wealthmark pay is available to all eligible users on Wealthmark.com. To start using Wealthmark Pay, please register on Wealthmark.com and complete your Identity Verification.</div>
      </div>
    </div>
  </div>
              
          </div>
          
            <div class="col-md-6 col-sm-6 col-xs-12">
              
              <div class="card">
    <div class="card-head" id="heading5">
      <h2 class="mb-0 collapsed" data-toggle="collapse" data-target="#collapse5" aria-expanded="false" aria-controls="collapse5">
       5. How does settlement work?
      </h2>
    </div>

    <div id="collapse5" class="collapse" aria-labelledby="heading5" data-parent="#accordionExample">
      <div class="card-body">
      <div class="text">   Wealthmark pay is available to all eligible users on Wealthmark.com. To start using Wealthmark Pay, please register on Wealthmark.com and complete your Identity Verification.</div>
      </div>
    </div>
  </div>
      <div class="card">
    <div class="card-head" id="heading6">
      <h2 class="mb-0 collapsed" data-toggle="collapse" data-target="#collapse6" aria-expanded="false" aria-controls="collapse6">
      6.  Why is the price quoted different from the last traded price on the exchange?
      </h2>
    </div>

    <div id="collapse6" class="collapse" aria-labelledby="heading6" data-parent="#accordionExample">
      <div class="card-body">
      <div class="text">   Wealthmark pay is available to all eligible users on Wealthmark.com. To start using Wealthmark Pay, please register on Wealthmark.com and complete your Identity Verification.</div>
      </div>
    </div>
  </div>
      <div class="card">
    <div class="card-head" id="heading7">
      <h2 class="mb-0 collapsed" data-toggle="collapse" data-target="#collapse7" aria-expanded="false" aria-controls="collapse7">
     7. Why did I receive an “insufficient funds” error?
      </h2>
    </div>

    <div id="collapse7" class="collapse" aria-labelledby="heading7" data-parent="#accordionExample">
      <div class="card-body">
      <div class="text">   Wealthmark pay is available to all eligible users on Wealthmark.com. To start using Wealthmark Pay, please register on Wealthmark.com and complete your Identity Verification.</div>
      </div>
    </div>
  </div>
      <div class="card">
    <div class="card-head" id="heading8">
      <h2 class="mb-0 collapsed" data-toggle="collapse" data-target="#collapse8" aria-expanded="false" aria-controls="collapse8">
         8. What is the difference between "Market" mode and "Limit" mode?
      </h2>
    </div>

    <div id="collapse8" class="collapse" aria-labelledby="heading8" data-parent="#accordionExample">
      <div class="card-body">
      <div class="text">   Wealthmark pay is available to all eligible users on Wealthmark.com. To start using Wealthmark Pay, please register on Wealthmark.com and complete your Identity Verification.</div>
      </div>
    </div>
  </div>
              
          </div>
          
        
      </div>
  
  
  
</div>
</div>
</section>
  @include('template.country_language')
    @include('template.web_footer') 
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/js/bootstrap.min.js"></script>
   <div id="css-1u2pn8e" style="display:none">
  <div class="css-1u2pn8e" >
  <div class="css-a4v9py">
    <div class="css-6ccfl4">
      <div data-bn-type="text" class="css-8mokm4">Setting</div>
      <svg id="close-modal-div"  xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" cursor="pointer" class="svg-cross" >
        <path d="M6.697 4.575L4.575 6.697 9.88 12l-5.304 5.303 2.122 2.122L12 14.12l5.303 5.304 2.122-2.122L14.12 12l5.304-5.303-2.122-2.122L12 9.88 6.697 4.575z" fill="currentColor"></path>
      </svg>
    </div>
    <div class="dialogContainer css-vurnku">
      <div class="css-186t46b">
        <div class="setting-col css-4cffwv">
          <div class="label css-4cffwv">
            <div data-bn-type="text" class="css-vurnku">To old version</div>
          </div>
          <button data-bn-type="button" class=" css-17nzfcu">
            <div data-bn-type="text" class="css-1c82c04">Switch</div>
          </button>
        </div>
      </div>
    </div>
  </div>
  <div class="css-1x6mg2r"></div>
</div>
</div>


<script>
    $( document ).ready(function() {
  
   $("#Convert-setting-btn").click(function () {
    $("#css-1u2pn8e").css("display", "block");
});
 $("#close-modal-div").click(function () {
    $("#css-1u2pn8e").css("display", "none");
});
});
</script>
    </body>
</html>