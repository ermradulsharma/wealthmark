<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <title>Wealth Mark | {{ Request::segment(2) }}</title>
    @include('template.web_css')
    <link rel='stylesheet' href="{{('../public/assets/css/deepak_custom.css') }}">
    <script src="http://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
</head>

<body>
    @include('template.mobile_menu')
    @include('template.web_menu')

    <section class="deposit-fee-section" id="deposit-fee-block">
        <div class="container">
            <div class="row">
                <div class="sec-title text-left">
                    <span class="title">Know About</span>
                    <h2 class="heading-h2"><a class="trading-fee-boxes text-upppercase">TRADING FEE | </a> <a
                            class="deposit-withdrawal-boxes text-upppercase">DEPOSIT WITHDRAWAL FEE</a></h2>
                </div>
            </div>

            <div class=" row">
                <div class="deposit_withdrawal-fee-tabs">
                    <ul class="nav nav-tabs" id="deposit-fee-tabs" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#home"
                                type="button" role="tab" aria-controls="home" aria-selected="true">Crypto</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile"
                                type="button" role="tab" aria-controls="profile" aria-selected="false">FIAT</button>
                        </li>
                    </ul>
                    <div class="tab-content" id="deposit-fee-tabsContent">
                        <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                            <div class="crypto-tab">
                                <h4>Wealth Mark does not charge deposit fees.</h4>
                                <p>For each withdrawal, a flat fee is paid by users to cover the transaction costs of
                                    moving the cryptocurrency out of their Wealth Mark account.
                                    Withdrawals rates are determined by the blockchain network and can fluctuate without
                                    notice due to factors such as network congestion. Please check the most recent data
                                    listed on each withdrawal page.</p>

                                <div class="row">
                                    <div class="col-md-3 col-lg-3 col-sm-12 col-xs-12 input-group mb-3 mt-3">
                                        <input type="text" class="form-control" placeholder="Search" aria-label="Search"
                                            aria-describedby="basic-addon2">
                                        <span class="input-group-text" id="basic-addon2">Search</span>
                                    </div>
                                </div>
                                <div class="table-responsive mt-2">
                                        <table class="table table-bordered table-hover table-striped">
                                            <thead class="bn-table-thead">
                                                <tr>
                                                    <th>
                                                        Coin/Token</th>
                                                    <th class="bn-table-cell">Full Name</th>
                                                    <th class="bn-table-cell">Network</th>
                                                    <th class="bn-table-cell">Minimum
                                                        Withdrawal</th>
                                                    <th class="bn-table-cell">Deposit Fee</th>
                                                    <th class="bn-table-cell">Withdrawal Fee
                                                    </th>
                                                </tr>
                                            </thead>
                                            <tbody class="bn-table-tbody">
                                                <tr data-row-key="0" class="bn-table-row bn-table-row-level-0">
                                                    <td>
                                                        <div data-bn-type="text" class="css-1jq4ozh">1INCH</div>
                                                    </td>
                                                    <td class="bn-table-cell">
                                                        <div data-bn-type="text" class="css-9awplo">1inch</div>
                                                    </td>
                                                    <td class="bn-table-cell">
                                                        <div data-bn-type="text" class="css-1p1msbr">BNB Smart Chain
                                                            (BEP20)</div>
                                                        <div data-bn-type="text" class="css-1p1msbr">Ethereum (ERC20)
                                                        </div>
                                                    </td>
                                                    <td class="bn-table-cell">
                                                        <div data-bn-type="text" class="css-1p1msbr">0.34</div>
                                                        <div data-bn-type="text" class="css-1p1msbr">12</div>
                                                    </td>
                                                    <td class="bn-table-cell">
                                                        <div data-bn-type="text" class="css-1p1msbr">Free</div>
                                                        <div data-bn-type="text" class="css-1p1msbr">Free</div>
                                                    </td>
                                                    <td class="bn-table-cell">
                                                        <div data-bn-type="text" class="css-1p1msbr">0.17</div>
                                                        <div data-bn-type="text" class="css-1p1msbr">6.02</div>
                                                    </td>
                                                </tr>
                                                <tr data-row-key="1" class="bn-table-row bn-table-row-level-0">
                                                    <td>
                                                        <div data-bn-type="text" class="css-1jq4ozh">AGLD</div>
                                                    </td>
                                                    <td class="bn-table-cell">
                                                        <div data-bn-type="text" class="css-9awplo">Adventure Gold</div>
                                                    </td>
                                                    <td class="bn-table-cell">
                                                        <div data-bn-type="text" class="css-1p1msbr">Ethereum (ERC20)
                                                        </div>
                                                    </td>
                                                    <td class="bn-table-cell">
                                                        <div data-bn-type="text" class="css-1p1msbr">19</div>
                                                    </td>
                                                    <td class="bn-table-cell">
                                                        <div data-bn-type="text" class="css-1p1msbr">Free</div>
                                                    </td>
                                                    <td class="bn-table-cell">
                                                        <div data-bn-type="text" class="css-1p1msbr">9.98</div>
                                                    </td>
                                                </tr>
                                                <tr data-row-key="2" class="bn-table-row bn-table-row-level-0">
                                                    <td>
                                                        <div data-bn-type="text" class="css-1jq4ozh">ATEM</div>
                                                    </td>
                                                    <td class="bn-table-cell">
                                                        <div data-bn-type="text" class="css-9awplo">ATEM</div>
                                                    </td>
                                                    <td class="bn-table-cell">
                                                        <div data-bn-type="text" class="css-1p1msbr">BNB Smart Chain
                                                            (BEP20)</div>
                                                        <div data-bn-type="text" class="css-1p1msbr">Ethereum (ERC20)
                                                        </div>
                                                    </td>
                                                    <td class="bn-table-cell">
                                                        <div data-bn-type="text" class="css-1p1msbr">7162</div>
                                                        <div data-bn-type="text" class="css-1p1msbr">260204</div>
                                                    </td>
                                                    <td class="bn-table-cell">
                                                        <div data-bn-type="text" class="css-1p1msbr">Free</div>
                                                        <div data-bn-type="text" class="css-1p1msbr">Free</div>
                                                    </td>
                                                    <td class="bn-table-cell">
                                                        <div data-bn-type="text" class="css-1p1msbr">3581</div>
                                                        <div data-bn-type="text" class="css-1p1msbr">130102</div>
                                                    </td>
                                                </tr>
                                                <tr data-row-key="3" class="bn-table-row bn-table-row-level-0">
                                                    <td>
                                                        <div data-bn-type="text" class="css-1jq4ozh">AUDIO</div>
                                                    </td>
                                                    <td class="bn-table-cell">
                                                        <div data-bn-type="text" class="css-9awplo">Audius</div>
                                                    </td>
                                                    <td class="bn-table-cell">
                                                        <div data-bn-type="text" class="css-1p1msbr">Ethereum (ERC20)
                                                        </div>
                                                    </td>
                                                    <td class="bn-table-cell">
                                                        <div data-bn-type="text" class="css-1p1msbr">32</div>
                                                    </td>
                                                    <td class="bn-table-cell">
                                                        <div data-bn-type="text" class="css-1p1msbr">Free</div>
                                                    </td>
                                                    <td class="bn-table-cell">
                                                        <div data-bn-type="text" class="css-1p1msbr">16</div>
                                                    </td>
                                                </tr>
                                                <tr data-row-key="4" class="bn-table-row bn-table-row-level-0">
                                                    <td>
                                                        <div data-bn-type="text" class="css-1jq4ozh">AION</div>
                                                    </td>
                                                    <td class="bn-table-cell">
                                                        <div data-bn-type="text" class="css-9awplo">AION</div>
                                                    </td>
                                                    <td class="bn-table-cell">
                                                        <div data-bn-type="text" class="css-1p1msbr">Aion</div>
                                                        <div data-bn-type="text" class="css-1p1msbr">Ethereum (ERC20)
                                                        </div>
                                                    </td>
                                                    <td class="bn-table-cell">
                                                        <div data-bn-type="text" class="css-1p1msbr">0.2</div>
                                                        <div data-bn-type="text" class="css-1p1msbr">188</div>
                                                    </td>
                                                    <td class="bn-table-cell">
                                                        <div data-bn-type="text" class="css-1p1msbr">Free</div>
                                                        <div data-bn-type="text" class="css-1p1msbr">Free</div>
                                                    </td>
                                                    <td class="bn-table-cell">
                                                        <div data-bn-type="text" class="css-1p1msbr">0.1</div>
                                                        <div data-bn-type="text" class="css-1p1msbr">94</div>
                                                    </td>
                                                </tr>
                                                <tr data-row-key="5" class="bn-table-row bn-table-row-level-0">
                                                    <td>
                                                        <div data-bn-type="text" class="css-1jq4ozh">AR</div>
                                                    </td>
                                                    <td class="bn-table-cell">
                                                        <div data-bn-type="text" class="css-9awplo">Arweave</div>
                                                    </td>
                                                    <td class="bn-table-cell">
                                                        <div data-bn-type="text" class="css-1p1msbr">Arweave</div>
                                                    </td>
                                                    <td class="bn-table-cell">
                                                        <div data-bn-type="text" class="css-1p1msbr">0.1</div>
                                                    </td>
                                                    <td class="bn-table-cell">
                                                        <div data-bn-type="text" class="css-1p1msbr">Free</div>
                                                    </td>
                                                    <td class="bn-table-cell">
                                                        <div data-bn-type="text" class="css-1p1msbr">0.03</div>
                                                    </td>
                                                </tr>
                                                <tr data-row-key="6" class="bn-table-row bn-table-row-level-0">
                                                    <td>
                                                        <div data-bn-type="text" class="css-1jq4ozh">ACA</div>
                                                    </td>
                                                    <td class="bn-table-cell">
                                                        <div data-bn-type="text" class="css-9awplo">Acala Token</div>
                                                    </td>
                                                    <td class="bn-table-cell">
                                                        <div data-bn-type="text" class="css-1p1msbr">Acala</div>
                                                    </td>
                                                    <td class="bn-table-cell">
                                                        <div data-bn-type="text" class="css-1p1msbr">1</div>
                                                    </td>
                                                    <td class="bn-table-cell">
                                                        <div data-bn-type="text" class="css-1p1msbr">Free</div>
                                                    </td>
                                                    <td class="bn-table-cell">
                                                        <div data-bn-type="text" class="css-1p1msbr">0.2</div>
                                                    </td>
                                                </tr>
                                                <tr data-row-key="7" class="bn-table-row bn-table-row-level-0">
                                                    <td>
                                                        <div data-bn-type="text" class="css-1jq4ozh">ARDR</div>
                                                    </td>
                                                    <td class="bn-table-cell">
                                                        <div data-bn-type="text" class="css-9awplo">Ardor</div>
                                                    </td>
                                                    <td class="bn-table-cell">
                                                        <div data-bn-type="text" class="css-1p1msbr">Ardor</div>
                                                    </td>
                                                    <td class="bn-table-cell">
                                                        <div data-bn-type="text" class="css-1p1msbr">4</div>
                                                    </td>
                                                    <td class="bn-table-cell">
                                                        <div data-bn-type="text" class="css-1p1msbr">Free</div>
                                                    </td>
                                                    <td class="bn-table-cell">
                                                        <div data-bn-type="text" class="css-1p1msbr">2</div>
                                                    </td>
                                                </tr>
                                                <tr data-row-key="8" class="bn-table-row bn-table-row-level-0">
                                                    <td>
                                                        <div data-bn-type="text" class="css-1jq4ozh">ACH</div>
                                                    </td>
                                                    <td class="bn-table-cell">
                                                        <div data-bn-type="text" class="css-9awplo">Alchemy Pay</div>
                                                    </td>
                                                    <td class="bn-table-cell">
                                                        <div data-bn-type="text" class="css-1p1msbr">BNB Smart Chain
                                                            (BEP20)</div>
                                                        <div data-bn-type="text" class="css-1p1msbr">Ethereum (ERC20)
                                                        </div>
                                                    </td>
                                                    <td class="bn-table-cell">
                                                        <div data-bn-type="text" class="css-1p1msbr">17</div>
                                                        <div data-bn-type="text" class="css-1p1msbr">616</div>
                                                    </td>
                                                    <td class="bn-table-cell">
                                                        <div data-bn-type="text" class="css-1p1msbr">Free</div>
                                                        <div data-bn-type="text" class="css-1p1msbr">Free</div>
                                                    </td>
                                                    <td class="bn-table-cell">
                                                        <div data-bn-type="text" class="css-1p1msbr">8.5</div>
                                                        <div data-bn-type="text" class="css-1p1msbr">308</div>
                                                    </td>
                                                </tr>
                                                <tr data-row-key="9" class="bn-table-row bn-table-row-level-0">
                                                    <td>
                                                        <div data-bn-type="text" class="css-1jq4ozh">ACM</div>
                                                    </td>
                                                    <td class="bn-table-cell">
                                                        <div data-bn-type="text" class="css-9awplo">AC Milan Fan Token
                                                        </div>
                                                    </td>
                                                    <td class="bn-table-cell">
                                                        <div data-bn-type="text" class="css-1p1msbr">Chiliz Chain (CHZ)
                                                        </div>
                                                    </td>
                                                    <td class="bn-table-cell">
                                                        <div data-bn-type="text" class="css-1p1msbr">1</div>
                                                    </td>
                                                    <td class="bn-table-cell">
                                                        <div data-bn-type="text" class="css-1p1msbr">Free</div>
                                                    </td>
                                                    <td class="bn-table-cell">
                                                        <div data-bn-type="text" class="css-1p1msbr">0</div>
                                                    </td>
                                                </tr>
                                                <tr data-row-key="10" class="bn-table-row bn-table-row-level-0">
                                                    <td>
                                                        <div data-bn-type="text" class="css-1jq4ozh">ADA</div>
                                                    </td>
                                                    <td class="bn-table-cell">
                                                        <div data-bn-type="text" class="css-9awplo">Cardano</div>
                                                    </td>
                                                    <td class="bn-table-cell">
                                                        <div data-bn-type="text" class="css-1p1msbr">BNB Smart Chain
                                                            (BEP20)</div>
                                                        <div data-bn-type="text" class="css-1p1msbr">Cardano</div>
                                                        <div data-bn-type="text" class="css-1p1msbr">BNB Beacon Chain
                                                            (BEP2)</div>
                                                    </td>
                                                    <td class="bn-table-cell">
                                                        <div data-bn-type="text" class="css-1p1msbr">0.52</div>
                                                        <div data-bn-type="text" class="css-1p1msbr">10</div>
                                                        <div data-bn-type="text" class="css-1p1msbr">0.86</div>
                                                    </td>
                                                    <td class="bn-table-cell">
                                                        <div data-bn-type="text" class="css-1p1msbr">Free</div>
                                                        <div data-bn-type="text" class="css-1p1msbr">Free</div>
                                                        <div data-bn-type="text" class="css-1p1msbr">Free</div>
                                                    </td>
                                                    <td class="bn-table-cell">
                                                        <div data-bn-type="text" class="css-1p1msbr">0.26</div>
                                                        <div data-bn-type="text" class="css-1p1msbr">0.8</div>
                                                        <div data-bn-type="text" class="css-1p1msbr">0.43</div>
                                                    </td>
                                                </tr>
                                              
                                                <tr data-row-key="14" class="bn-table-row bn-table-row-level-0">
                                                    <td>
                                                        <div data-bn-type="text" class="css-1jq4ozh">API3</div>
                                                    </td>
                                                    <td>
                                                        <div data-bn-type="text" class="css-9awplo">API3</div>
                                                    </td>
                                                    <td>
                                                        <div data-bn-type="text" class="css-1p1msbr">Ethereum (ERC20)
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div data-bn-type="text" class="css-1p1msbr">3.54</div>
                                                    </td>
                                                    <td>
                                                        <div data-bn-type="text" class="css-1p1msbr">Free</div>
                                                    </td>
                                                    <td>
                                                        <div data-bn-type="text" class="css-1p1msbr">1.77</div>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <section class="fee-section" id="fee-rate-widgets-section">
        <div class="container">
            <div class="row">
                <div class="sec-title text-left">
                    <span class="title">Know About</span>
                    <h2 class="heading-h2"><a class="trading-fee-boxes">Trading Fee | </a> <a
                            class="deposit-withdrawal-boxes">Deposit Withdrawal Fee</a></h2>
                </div>
            </div>

            <div class="row">
                <div class="col-md-12">
                    <h5>Log in to check your trading fee rate. <a class="text-warning"> Login</a> </h5>
                    <h5>Enjoy higher discounts and privilege.<a class="text-warning"> VIP program</a> </h5>
                    <h5 class="text-warning">Enjoy more benefits with fee deductions for the following transactions.
                    </h5>
                </div>
            </div>

            <div class="row mt-3">
                <div class="col-xl-3 col-lg-3 col-md-3 col-xs-6 col-sm-6">
                    <div class="card border-0 shadow">
                        <div class="card-body">
                            <div class="row d-block d-xl-flex align-items-center">
                                <div class="widgets-block">
                                    <h2 class="fw-extrabold h5"><svg 
                                            viewBox="0 0 24 24" fill="none" class="css-ivry7e">
                                            <path
                                                d="M5.94 19.574C7.612 21.19 9.806 22 12 22c2.194 0 4.387-.809 6.061-2.426 3.347-3.236 3.347-8.48 0-11.716L12.001 2 5.938 7.858c-3.347 3.235-3.347 8.48 0 11.716z"
                                                fill="url(#hot-g_svg__paint0_linear_1330_2334)"></path>
                                            <path
                                                d="M8.506 18.544A4.911 4.911 0 0012 20a4.91 4.91 0 003.494-1.456 4.992 4.992 0 000-7.03L12 8l-3.494 3.515a4.991 4.991 0 000 7.03z"
                                                fill="#76808F"></path>
                                            <path d="M3 3.5L5.5 6 8 3.5 5.5 1 3 3.5z"
                                                fill="url(#hot-g_svg__paint1_linear_1330_2334)"></path>
                                            <path d="M20 7.5L21.5 9 23 7.5 21.5 6 20 7.5z" fill="#76808F"></path>
                                            <path d="M1 20l1.5 1.5L4 20l-1.5-1.5L1 20z"
                                                fill="url(#hot-g_svg__paint2_linear_1330_2334)"></path>
                                            <defs>
                                                <linearGradient id="hot-g_svg__paint0_linear_1330_2334" x1="12" y1="22"
                                                    x2="12" y2="2" gradientUnits="userSpaceOnUse">
                                                    <stop stop-color="#F0B90B"></stop>
                                                    <stop offset="1" stop-color="#F8D33A"></stop>
                                                </linearGradient>
                                                <linearGradient id="hot-g_svg__paint1_linear_1330_2334" x1="5.5" y1="6"
                                                    x2="5.5" y2="1" gradientUnits="userSpaceOnUse">
                                                    <stop stop-color="#F0B90B"></stop>
                                                    <stop offset="1" stop-color="#F8D33A"></stop>
                                                </linearGradient>
                                                <linearGradient id="hot-g_svg__paint2_linear_1330_2334" x1="2.5"
                                                    y1="21.5" x2="2.5" y2="18.5" gradientUnits="userSpaceOnUse">
                                                    <stop stop-color="#F0B90B"></stop>
                                                    <stop offset="1" stop-color="#F8D33A"></stop>
                                                </linearGradient>
                                            </defs>
                                        </svg>BTC Spot Trading Pairs</h2>
                                    <h3 class="mb-1">0% Fee</h3>
                                    <p><span class="badge rounded-pill bg-warning">zero</span> fee on selected fiat and
                                        pairs</p>
                                    <a class="text-primary fee-learn-more-link">Learn More <svg
                                             width="16" height="16"
                                            fill="currentColor" class="bi bi-arrow-right" viewBox="0 0 16 16">
                                            <path fill-rule="evenodd"
                                                d="M1 8a.5.5 0 0 1 .5-.5h11.793l-3.147-3.146a.5.5 0 0 1 .708-.708l4 4a.5.5 0 0 1 0 .708l-4 4a.5.5 0 0 1-.708-.708L13.293 8.5H1.5A.5.5 0 0 1 1 8z" />
                                        </svg></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xl-3 col-lg-3 col-md-3 col-xs-6 col-sm-6">
                    <div class="card border-0 shadow">
                        <div class="card-body">
                            <div class="row d-block d-xl-flex align-items-center">
                                <div class="widgets-block">
                                    <h2 class="fw-extrabold h5"><svg 
                                            viewBox="0 0 24 24" fill="none" class="css-ivry7e">
                                            <path
                                                d="M5.94 19.574C7.612 21.19 9.806 22 12 22c2.194 0 4.387-.809 6.061-2.426 3.347-3.236 3.347-8.48 0-11.716L12.001 2 5.938 7.858c-3.347 3.235-3.347 8.48 0 11.716z"
                                                fill="url(#hot-g_svg__paint0_linear_1330_2334)"></path>
                                            <path
                                                d="M8.506 18.544A4.911 4.911 0 0012 20a4.91 4.91 0 003.494-1.456 4.992 4.992 0 000-7.03L12 8l-3.494 3.515a4.991 4.991 0 000 7.03z"
                                                fill="#76808F"></path>
                                            <path d="M3 3.5L5.5 6 8 3.5 5.5 1 3 3.5z"
                                                fill="url(#hot-g_svg__paint1_linear_1330_2334)"></path>
                                            <path d="M20 7.5L21.5 9 23 7.5 21.5 6 20 7.5z" fill="#76808F"></path>
                                            <path d="M1 20l1.5 1.5L4 20l-1.5-1.5L1 20z"
                                                fill="url(#hot-g_svg__paint2_linear_1330_2334)"></path>
                                            <defs>
                                                <linearGradient id="hot-g_svg__paint0_linear_1330_2334" x1="12" y1="22"
                                                    x2="12" y2="2" gradientUnits="userSpaceOnUse">
                                                    <stop stop-color="#F0B90B"></stop>
                                                    <stop offset="1" stop-color="#F8D33A"></stop>
                                                </linearGradient>
                                                <linearGradient id="hot-g_svg__paint1_linear_1330_2334" x1="5.5" y1="6"
                                                    x2="5.5" y2="1" gradientUnits="userSpaceOnUse">
                                                    <stop stop-color="#F0B90B"></stop>
                                                    <stop offset="1" stop-color="#F8D33A"></stop>
                                                </linearGradient>
                                                <linearGradient id="hot-g_svg__paint2_linear_1330_2334" x1="2.5"
                                                    y1="21.5" x2="2.5" y2="18.5" gradientUnits="userSpaceOnUse">
                                                    <stop stop-color="#F0B90B"></stop>
                                                    <stop offset="1" stop-color="#F8D33A"></stop>
                                                </linearGradient>
                                            </defs>
                                        </svg>BUSD Spot Trading Pairs</h2>
                                    <h3 class="mb-1">0% Fee</h3>
                                    <p>Zero maker fee on BUSD pairs</p>
                                    <a class="text-primary fee-learn-more-link">Learn More <svg
                                             width="16" height="16"
                                            fill="currentColor" class="bi bi-arrow-right" viewBox="0 0 16 16">
                                            <path fill-rule="evenodd"
                                                d="M1 8a.5.5 0 0 1 .5-.5h11.793l-3.147-3.146a.5.5 0 0 1 .708-.708l4 4a.5.5 0 0 1 0 .708l-4 4a.5.5 0 0 1-.708-.708L13.293 8.5H1.5A.5.5 0 0 1 1 8z" />
                                        </svg></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xl-3 col-lg-3 col-md-3 col-xs-6 col-sm-6">
                    <div class="card border-0 shadow">
                        <div class="card-body">
                            <div class="row d-block d-xl-flex align-items-center">
                                <div class="widgets-block">
                                    <h2 class="fw-extrabold h5"><svg 
                                            viewBox="0 0 24 24" fill="none" class="css-ivry7e">
                                            <path
                                                d="M5.94 19.574C7.612 21.19 9.806 22 12 22c2.194 0 4.387-.809 6.061-2.426 3.347-3.236 3.347-8.48 0-11.716L12.001 2 5.938 7.858c-3.347 3.235-3.347 8.48 0 11.716z"
                                                fill="url(#hot-g_svg__paint0_linear_1330_2334)"></path>
                                            <path
                                                d="M8.506 18.544A4.911 4.911 0 0012 20a4.91 4.91 0 003.494-1.456 4.992 4.992 0 000-7.03L12 8l-3.494 3.515a4.991 4.991 0 000 7.03z"
                                                fill="#76808F"></path>
                                            <path d="M3 3.5L5.5 6 8 3.5 5.5 1 3 3.5z"
                                                fill="url(#hot-g_svg__paint1_linear_1330_2334)"></path>
                                            <path d="M20 7.5L21.5 9 23 7.5 21.5 6 20 7.5z" fill="#76808F"></path>
                                            <path d="M1 20l1.5 1.5L4 20l-1.5-1.5L1 20z"
                                                fill="url(#hot-g_svg__paint2_linear_1330_2334)"></path>
                                            <defs>
                                                <linearGradient id="hot-g_svg__paint0_linear_1330_2334" x1="12" y1="22"
                                                    x2="12" y2="2" gradientUnits="userSpaceOnUse">
                                                    <stop stop-color="#F0B90B"></stop>
                                                    <stop offset="1" stop-color="#F8D33A"></stop>
                                                </linearGradient>
                                                <linearGradient id="hot-g_svg__paint1_linear_1330_2334" x1="5.5" y1="6"
                                                    x2="5.5" y2="1" gradientUnits="userSpaceOnUse">
                                                    <stop stop-color="#F0B90B"></stop>
                                                    <stop offset="1" stop-color="#F8D33A"></stop>
                                                </linearGradient>
                                                <linearGradient id="hot-g_svg__paint2_linear_1330_2334" x1="2.5"
                                                    y1="21.5" x2="2.5" y2="18.5" gradientUnits="userSpaceOnUse">
                                                    <stop stop-color="#F0B90B"></stop>
                                                    <stop offset="1" stop-color="#F8D33A"></stop>
                                                </linearGradient>
                                            </defs>
                                        </svg>BNB Deduction</h2>
                                    <h3 class="mb-1">25% Fee</h3>
                                    <p>On USDⓈ-M Futures Trading fee</p>
                                    <a class="text-primary fee-learn-more-link">Learn More <svg
                                             width="16" height="16"
                                            fill="currentColor" class="bi bi-arrow-right" viewBox="0 0 16 16">
                                            <path fill-rule="evenodd"
                                                d="M1 8a.5.5 0 0 1 .5-.5h11.793l-3.147-3.146a.5.5 0 0 1 .708-.708l4 4a.5.5 0 0 1 0 .708l-4 4a.5.5 0 0 1-.708-.708L13.293 8.5H1.5A.5.5 0 0 1 1 8z" />
                                        </svg></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xl-3 col-lg-3 col-md-3 col-xs-6 col-sm-6">
                    <div class="card border-0 shadow">
                        <div class="card-body">
                            <div class="row d-block d-xl-flex align-items-center">
                                <div class="widgets-block">
                                    <h2 class="fw-extrabold h5"><svg 
                                            viewBox="0 0 24 24" fill="none" class="css-ivry7e">
                                            <path
                                                d="M5.94 19.574C7.612 21.19 9.806 22 12 22c2.194 0 4.387-.809 6.061-2.426 3.347-3.236 3.347-8.48 0-11.716L12.001 2 5.938 7.858c-3.347 3.235-3.347 8.48 0 11.716z"
                                                fill="url(#hot-g_svg__paint0_linear_1330_2334)"></path>
                                            <path
                                                d="M8.506 18.544A4.911 4.911 0 0012 20a4.91 4.91 0 003.494-1.456 4.992 4.992 0 000-7.03L12 8l-3.494 3.515a4.991 4.991 0 000 7.03z"
                                                fill="#76808F"></path>
                                            <path d="M3 3.5L5.5 6 8 3.5 5.5 1 3 3.5z"
                                                fill="url(#hot-g_svg__paint1_linear_1330_2334)"></path>
                                            <path d="M20 7.5L21.5 9 23 7.5 21.5 6 20 7.5z" fill="#76808F"></path>
                                            <path d="M1 20l1.5 1.5L4 20l-1.5-1.5L1 20z"
                                                fill="url(#hot-g_svg__paint2_linear_1330_2334)"></path>
                                            <defs>
                                                <linearGradient id="hot-g_svg__paint0_linear_1330_2334" x1="12" y1="22"
                                                    x2="12" y2="2" gradientUnits="userSpaceOnUse">
                                                    <stop stop-color="#F0B90B"></stop>
                                                    <stop offset="1" stop-color="#F8D33A"></stop>
                                                </linearGradient>
                                                <linearGradient id="hot-g_svg__paint1_linear_1330_2334" x1="5.5" y1="6"
                                                    x2="5.5" y2="1" gradientUnits="userSpaceOnUse">
                                                    <stop stop-color="#F0B90B"></stop>
                                                    <stop offset="1" stop-color="#F8D33A"></stop>
                                                </linearGradient>
                                                <linearGradient id="hot-g_svg__paint2_linear_1330_2334" x1="2.5"
                                                    y1="21.5" x2="2.5" y2="18.5" gradientUnits="userSpaceOnUse">
                                                    <stop stop-color="#F0B90B"></stop>
                                                    <stop offset="1" stop-color="#F8D33A"></stop>
                                                </linearGradient>
                                            </defs>
                                        </svg>BTC Spot Trading Pairs</h2>
                                    <h3 class="mb-1">0% Fee</h3>
                                    <p>On USDⓈ-M Futures Trading fee</p>
                                    <a class="text-primary fee-learn-more-link">Learn More <svg
                                             width="16" height="16"
                                            fill="currentColor" class="bi bi-arrow-right" viewBox="0 0 16 16">
                                            <path fill-rule="evenodd"
                                                d="M1 8a.5.5 0 0 1 .5-.5h11.793l-3.147-3.146a.5.5 0 0 1 .708-.708l4 4a.5.5 0 0 1 0 .708l-4 4a.5.5 0 0 1-.708-.708L13.293 8.5H1.5A.5.5 0 0 1 1 8z" />
                                        </svg></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>


    <section class="fee-rate-tabing" id="fee-tabs">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <ul class="nav nav-tabs mb-2" id="fee-rates-tab" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active" id="Spot-Trading-tab" data-bs-toggle="tab"
                                data-bs-target="#Spot-Trading" type="button" role="tab" aria-controls="Spot-Trading"
                                aria-selected="true">Spot Trading</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="Margin-borrow-interest-tab" data-bs-toggle="tab"
                                data-bs-target="#Margin-borrow-interest" type="button" role="tab"
                                aria-controls="Margin-borrow-interest" aria-selected="false">Margin Borrow
                                Interest</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="USDFutures-Trading-tab" data-bs-toggle="tab"
                                data-bs-target="#USDFutures-Trading" type="button" role="tab"
                                aria-controls="USDFutures-Trading" aria-selected="false">USDⓈ-M Futures Trading</button>
                        </li>

                        <li class="nav-item" role="presentation">
                            <button class="nav-link " id="coin-m-future-trading-tab" data-bs-toggle="tab"
                                data-bs-target="#coin-m-future-trading" type="button" role="tab"
                                aria-controls="coin-m-future-trading" aria-selected="true">COIN-M Futures
                                Trading</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="cross-interest-tab" data-bs-toggle="tab"
                                data-bs-target="#cross-interest" type="button" role="tab" aria-controls="cross-interest"
                                aria-selected="false">Cross Collateral Interest</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="swap-farming-tab" data-bs-toggle="tab"
                                data-bs-target="#swap-farming" type="button" role="tab" aria-controls="swap-farming"
                                aria-selected="false">Swap Farming</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link " id="fee-p2p-tab" data-bs-toggle="tab" data-bs-target="#fee-p2p"
                                type="button" role="tab" aria-controls="fee-p2p" aria-selected="true">P2P</button>
                        </li>

                    </ul>
                    <div class="tab-content" id="fee-rates-tabContent">

                        <div class="tab-pane fade show active" id="Spot-Trading" role="tabpanel"
                            aria-labelledby="Spot-Trading-tab">

                          <div class="table-responsive"> 
                          <table class="table table-striped table-hover table-bordered">
                                <thead>
                                    <tr>
                                        <th>Level</th>
                                        <th>30d Trade Volume (BUSD)</th>
                                        <th>and/or</th>
                                        <th>BNB Balance</th>
                                        <th>Maker / Taker</th>
                                        <th>Maker / Taker <small>BNB 25% off</small></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>Regular User</td>
                                        <td>
                                            < 1,000,000 BUSD </td>
                                        <td>or</td>
                                        <td>≥ 0 BNB</td>
                                        <td>0.1000% / 0.1000%</td>
                                        <td>0.0750% / 0.0750%</td>
                                    </tr>


                                    <tr>
                                        <td>VIP 1</td>
                                        <td>
                                            < 1,000,000 BUSD </td>
                                        <td>or</td>
                                        <td>≥ 0 BNB</td>
                                        <td>0.1000% / 0.1000%</td>
                                        <td>0.0750% / 0.0750%</td>
                                    </tr>
                                    <tr>
                                        <td>VIP 2</td>
                                        <td>≥ 20,000,000 BUSD </td>
                                        <td>or</td>
                                        <td>≥ 0 BNB</td>
                                        <td>0.1000% / 0.1000%</td>
                                        <td>0.0750% / 0.0750%</td>
                                    </tr>
                                    <tr>
                                        <td>VIP 3</td>
                                        <td>
                                            < 1,000,000 BUSD </td>
                                        <td>or</td>
                                        <td>≥ 0 BNB</td>
                                        <td>0.1000% / 0.1000%</td>
                                        <td>0.0750% / 0.0750%</td>
                                    </tr>
                                    <tr>
                                        <td>VIP 4</td>
                                        <td>
                                            < 1,000,000 BUSD </td>
                                        <td>or</td>
                                        <td>≥ 0 BNB</td>
                                        <td><del>0.1000% / 0.1000% </del> <br /><span class="text-warning">0.0200% /
                                                0.0400% </span></td>
                                        <td><del>0.1000% / 0.1000% </del> <br /><span class="text-warning">0.0200% /
                                                0.0400% </span></td>
                                    </tr>
                                    <tr>
                                        <td>VIP 5 <svg  viewBox="0 0 24 24"
                                                fill="none" class="css-7dirbb">
                                                <path
                                                    d="M5.94 19.574C7.612 21.19 9.806 22 12 22c2.194 0 4.387-.809 6.061-2.426 3.347-3.236 3.347-8.48 0-11.716L12.001 2 5.938 7.858c-3.347 3.235-3.347 8.48 0 11.716z"
                                                    fill="url(#hot-g_svg__paint0_linear_1330_2334)"></path>
                                                <path
                                                    d="M8.506 18.544A4.911 4.911 0 0012 20a4.91 4.91 0 003.494-1.456 4.992 4.992 0 000-7.03L12 8l-3.494 3.515a4.991 4.991 0 000 7.03z"
                                                    fill="#76808F"></path>
                                                <path d="M3 3.5L5.5 6 8 3.5 5.5 1 3 3.5z"
                                                    fill="url(#hot-g_svg__paint1_linear_1330_2334)"></path>
                                                <path d="M20 7.5L21.5 9 23 7.5 21.5 6 20 7.5z" fill="#76808F"></path>
                                                <path d="M1 20l1.5 1.5L4 20l-1.5-1.5L1 20z"
                                                    fill="url(#hot-g_svg__paint2_linear_1330_2334)"></path>
                                                <defs>
                                                    <linearGradient id="hot-g_svg__paint0_linear_1330_2334" x1="12"
                                                        y1="22" x2="12" y2="2" gradientUnits="userSpaceOnUse">
                                                        <stop stop-color="#F0B90B"></stop>
                                                        <stop offset="1" stop-color="#F8D33A"></stop>
                                                    </linearGradient>
                                                    <linearGradient id="hot-g_svg__paint1_linear_1330_2334" x1="5.5"
                                                        y1="6" x2="5.5" y2="1" gradientUnits="userSpaceOnUse">
                                                        <stop stop-color="#F0B90B"></stop>
                                                        <stop offset="1" stop-color="#F8D33A"></stop>
                                                    </linearGradient>
                                                    <linearGradient id="hot-g_svg__paint2_linear_1330_2334" x1="2.5"
                                                        y1="21.5" x2="2.5" y2="18.5" gradientUnits="userSpaceOnUse">
                                                        <stop stop-color="#F0B90B"></stop>
                                                        <stop offset="1" stop-color="#F8D33A"></stop>
                                                    </linearGradient>
                                                </defs>
                                            </svg></td>
                                        <td>
                                            < 1,000,000 BUSD </td>
                                        <td>or</td>
                                        <td>≥ 0 BNB</td>
                                        <td><del>0.1000% / 0.1000% </del> <br /><span class="text-warning">0.0200% /
                                                0.0400% </span></td>
                                        <td><del>0.1000% / 0.1000% </del> <br /><span class="text-warning">0.0200% /
                                                0.0400% </span></td>
                                    </tr>
                                    <tr>
                                        <td>VIP 6 <svg  viewBox="0 0 24 24"
                                                fill="none" class="css-7dirbb">
                                                <path
                                                    d="M5.94 19.574C7.612 21.19 9.806 22 12 22c2.194 0 4.387-.809 6.061-2.426 3.347-3.236 3.347-8.48 0-11.716L12.001 2 5.938 7.858c-3.347 3.235-3.347 8.48 0 11.716z"
                                                    fill="url(#hot-g_svg__paint0_linear_1330_2334)"></path>
                                                <path
                                                    d="M8.506 18.544A4.911 4.911 0 0012 20a4.91 4.91 0 003.494-1.456 4.992 4.992 0 000-7.03L12 8l-3.494 3.515a4.991 4.991 0 000 7.03z"
                                                    fill="#76808F"></path>
                                                <path d="M3 3.5L5.5 6 8 3.5 5.5 1 3 3.5z"
                                                    fill="url(#hot-g_svg__paint1_linear_1330_2334)"></path>
                                                <path d="M20 7.5L21.5 9 23 7.5 21.5 6 20 7.5z" fill="#76808F"></path>
                                                <path d="M1 20l1.5 1.5L4 20l-1.5-1.5L1 20z"
                                                    fill="url(#hot-g_svg__paint2_linear_1330_2334)"></path>
                                                <defs>
                                                    <linearGradient id="hot-g_svg__paint0_linear_1330_2334" x1="12"
                                                        y1="22" x2="12" y2="2" gradientUnits="userSpaceOnUse">
                                                        <stop stop-color="#F0B90B"></stop>
                                                        <stop offset="1" stop-color="#F8D33A"></stop>
                                                    </linearGradient>
                                                    <linearGradient id="hot-g_svg__paint1_linear_1330_2334" x1="5.5"
                                                        y1="6" x2="5.5" y2="1" gradientUnits="userSpaceOnUse">
                                                        <stop stop-color="#F0B90B"></stop>
                                                        <stop offset="1" stop-color="#F8D33A"></stop>
                                                    </linearGradient>
                                                    <linearGradient id="hot-g_svg__paint2_linear_1330_2334" x1="2.5"
                                                        y1="21.5" x2="2.5" y2="18.5" gradientUnits="userSpaceOnUse">
                                                        <stop stop-color="#F0B90B"></stop>
                                                        <stop offset="1" stop-color="#F8D33A"></stop>
                                                    </linearGradient>
                                                </defs>
                                            </svg></td>
                                        <td>
                                            < 1,000,000 BUSD </td>
                                        <td>or</td>
                                        <td>≥ 0 BNB</td>
                                        <td><del>0.1000% / 0.1000% </del> <br /><span class="text-warning">0.0200% /
                                                0.0400% </span></td>
                                        <td><del>0.1000% / 0.1000% </del> <br /><span class="text-warning">0.0200% /
                                                0.0400% </span></td>
                                    </tr>
                                    <tr>
                                        <td>VIP 7 <svg  viewBox="0 0 24 24"
                                                fill="none" class="css-7dirbb">
                                                <path
                                                    d="M5.94 19.574C7.612 21.19 9.806 22 12 22c2.194 0 4.387-.809 6.061-2.426 3.347-3.236 3.347-8.48 0-11.716L12.001 2 5.938 7.858c-3.347 3.235-3.347 8.48 0 11.716z"
                                                    fill="url(#hot-g_svg__paint0_linear_1330_2334)"></path>
                                                <path
                                                    d="M8.506 18.544A4.911 4.911 0 0012 20a4.91 4.91 0 003.494-1.456 4.992 4.992 0 000-7.03L12 8l-3.494 3.515a4.991 4.991 0 000 7.03z"
                                                    fill="#76808F"></path>
                                                <path d="M3 3.5L5.5 6 8 3.5 5.5 1 3 3.5z"
                                                    fill="url(#hot-g_svg__paint1_linear_1330_2334)"></path>
                                                <path d="M20 7.5L21.5 9 23 7.5 21.5 6 20 7.5z" fill="#76808F"></path>
                                                <path d="M1 20l1.5 1.5L4 20l-1.5-1.5L1 20z"
                                                    fill="url(#hot-g_svg__paint2_linear_1330_2334)"></path>
                                                <defs>
                                                    <linearGradient id="hot-g_svg__paint0_linear_1330_2334" x1="12"
                                                        y1="22" x2="12" y2="2" gradientUnits="userSpaceOnUse">
                                                        <stop stop-color="#F0B90B"></stop>
                                                        <stop offset="1" stop-color="#F8D33A"></stop>
                                                    </linearGradient>
                                                    <linearGradient id="hot-g_svg__paint1_linear_1330_2334" x1="5.5"
                                                        y1="6" x2="5.5" y2="1" gradientUnits="userSpaceOnUse">
                                                        <stop stop-color="#F0B90B"></stop>
                                                        <stop offset="1" stop-color="#F8D33A"></stop>
                                                    </linearGradient>
                                                    <linearGradient id="hot-g_svg__paint2_linear_1330_2334" x1="2.5"
                                                        y1="21.5" x2="2.5" y2="18.5" gradientUnits="userSpaceOnUse">
                                                        <stop stop-color="#F0B90B"></stop>
                                                        <stop offset="1" stop-color="#F8D33A"></stop>
                                                    </linearGradient>
                                                </defs>
                                            </svg></td>
                                        <td>
                                            < 1,000,000 BUSD </td>
                                        <td>or</td>
                                        <td>≥ 0 BNB</td>
                                        <td><del>0.1000% / 0.1000% </del> <br /><span class="text-warning">0.0200% /
                                                0.0400% </span></td>
                                        <td><del>0.1000% / 0.1000% </del> <br /><span class="text-warning">0.0200% /
                                                0.0400% </span></td>
                                    </tr>
                                    <tr>
                                        <td>VIP 8</td>
                                        <td>
                                            < 1,000,000 BUSD </td>
                                        <td>or</td>
                                        <td>≥ 0 BNB</td>
                                        <td><del>0.1000% / 0.1000% </del> <br /><span class="text-warning">0.0200% /
                                                0.0400% </span></td>
                                        <td><del>0.1000% / 0.1000% </del> <br /><span class="text-warning">0.0200% /
                                                0.0400% </span></td>
                                    </tr>
                                    <tr>
                                        <td>VIP 9 <svg  viewBox="0 0 24 24"
                                                fill="none" class="css-7dirbb">
                                                <path
                                                    d="M5.94 19.574C7.612 21.19 9.806 22 12 22c2.194 0 4.387-.809 6.061-2.426 3.347-3.236 3.347-8.48 0-11.716L12.001 2 5.938 7.858c-3.347 3.235-3.347 8.48 0 11.716z"
                                                    fill="url(#hot-g_svg__paint0_linear_1330_2334)"></path>
                                                <path
                                                    d="M8.506 18.544A4.911 4.911 0 0012 20a4.91 4.91 0 003.494-1.456 4.992 4.992 0 000-7.03L12 8l-3.494 3.515a4.991 4.991 0 000 7.03z"
                                                    fill="#76808F"></path>
                                                <path d="M3 3.5L5.5 6 8 3.5 5.5 1 3 3.5z"
                                                    fill="url(#hot-g_svg__paint1_linear_1330_2334)"></path>
                                                <path d="M20 7.5L21.5 9 23 7.5 21.5 6 20 7.5z" fill="#76808F"></path>
                                                <path d="M1 20l1.5 1.5L4 20l-1.5-1.5L1 20z"
                                                    fill="url(#hot-g_svg__paint2_linear_1330_2334)"></path>
                                                <defs>
                                                    <linearGradient id="hot-g_svg__paint0_linear_1330_2334" x1="12"
                                                        y1="22" x2="12" y2="2" gradientUnits="userSpaceOnUse">
                                                        <stop stop-color="#F0B90B"></stop>
                                                        <stop offset="1" stop-color="#F8D33A"></stop>
                                                    </linearGradient>
                                                    <linearGradient id="hot-g_svg__paint1_linear_1330_2334" x1="5.5"
                                                        y1="6" x2="5.5" y2="1" gradientUnits="userSpaceOnUse">
                                                        <stop stop-color="#F0B90B"></stop>
                                                        <stop offset="1" stop-color="#F8D33A"></stop>
                                                    </linearGradient>
                                                    <linearGradient id="hot-g_svg__paint2_linear_1330_2334" x1="2.5"
                                                        y1="21.5" x2="2.5" y2="18.5" gradientUnits="userSpaceOnUse">
                                                        <stop stop-color="#F0B90B"></stop>
                                                        <stop offset="1" stop-color="#F8D33A"></stop>
                                                    </linearGradient>
                                                </defs>
                                            </svg></td>
                                        <td>
                                            < 1,000,000 BUSD </td>
                                        <td>or</td>
                                        <td>≥ 0 BNB</td>
                                        <td>0.1000% / 0.1000%</td>
                                        <td>0.0750% / 0.0750%</td>
                                    </tr>

                                </tbody>
                            </table>
                          </div>
                        </div>

                        <div class="tab-pane fade" id="Margin-borrow-interest" role="tabpanel"
                            aria-labelledby="Margin-borrow-interest-tab">

                            <div class="table-responsive">
                                <table class="table table-striped table-hover table-bordered">
                                    <thead class="bn-table-thead">
                                        <tr>
                                            <th rowspan="2"
                                                class="bn-table-cell bn-table-cell-fix-left bn-table-cell-fix-left-last"
                                                style="text-align: left; position: sticky; left: 0px;">
                                                <div class="css-ucxrtv">
                                                    <div class="item css-vurnku">Level</div>
                                                    <div class="item css-vurnku">Coin</div>
                                                </div>
                                            </th>
                                        </tr>
                                       <tr> 
                                       <th class="bn-table-cell" style="text-align: left;">
                                                <div class="fee-borrow-box"><img
                                                        src="{{ asset('public/assets/img/fee-borrow-icon-1.png') }}"
                                                        class="img-fluid" alt="gift Card Image" />1INCH</div>
                                            </th>
                                            <th class="bn-table-cell" style="text-align: left;">
                                                <div class="fee-borrow-box"><img
                                                        src="{{ asset('public/assets/img/fee-borrow-icon-2.png') }}"
                                                        class="img-fluid" alt="gift Card Image" />AAVE</div>
                                            </th>
                                            <th class="bn-table-cell" style="text-align: left;">
                                                <div class="fee-borrow-box"><img
                                                        src="{{ asset('public/assets/img/fee-borrow-icon-3.png') }}"
                                                        class="img-fluid" alt="gift Card Image" />ACH</div>
                                            </th>
                                            <th class="bn-table-cell" style="text-align: left;">
                                                <div class="fee-borrow-box"><img
                                                        src="{{ asset('public/assets/img/fee-borrow-icon-4.png') }}"
                                                        class="img-fluid" alt="gift Card Image" />ADA</div>
                                            </th>
                                            <th class="bn-table-cell" style="text-align: left;">
                                                <div class="fee-borrow-box"><img
                                                        src="{{ asset('public/assets/img/fee-borrow-icon-5.png') }}"
                                                        class="img-fluid" alt="gift Card Image" />AGLD</div>
                                            </th>
                                            <th class="bn-table-cell" style="text-align: left;">
                                                <div class="fee-borrow-box"><img
                                                        src="{{ asset('public/assets/img/fee-borrow-icon-1.png') }}"
                                                        class="img-fluid" alt="gift Card Image" />ALGO</div>
                                            </th>
                                            <th class="bn-table-cell" style="text-align: left;">
                                                <div class="fee-borrow-box"><img
                                                        src="{{ asset('public/assets/img/fee-borrow-icon-4.png') }}"
                                                        class="img-fluid" alt="gift Card Image" />1INCH</div>
                                            </th>
                                            <th class="bn-table-cell" style="text-align: left;">
                                                <div class="fee-borrow-box"><img
                                                        src="{{ asset('public/assets/img/fee-borrow-icon-2.png') }}"
                                                        class="img-fluid" alt="gift Card Image" />AAVE</div>
                                            </th>
                                            <th class="bn-table-cell" style="text-align: left;">
                                                <div class="fee-borrow-box"><img
                                                        src="{{ asset('public/assets/img/fee-borrow-icon-3.png') }}"
                                                        class="img-fluid" alt="gift Card Image" />ACH</div>
                                            </th>
                                            <th class="bn-table-cell" style="text-align: left;">
                                                <div class="fee-borrow-box"><img
                                                        src="{{ asset('public/assets/img/fee-borrow-icon-4.png') }}"
                                                        class="img-fluid" alt="gift Card Image" />ADA</div>
                                            </th>
                                            <th class="bn-table-cell" style="text-align: left;">
                                                <div class="fee-borrow-box"><img
                                                        src="{{ asset('public/assets/img/fee-borrow-icon-5.png') }}"
                                                        class="img-fluid" alt="gift Card Image" />AGLD</div>
                                            </th>
                                            <th class="bn-table-cell" style="text-align: left;">
                                                <div class="fee-borrow-box"><img
                                                        src="{{ asset('public/assets/img/fee-borrow-icon-4.png') }}"
                                                        class="img-fluid" alt="gift Card Image" />ALGO</div>
                                            </th>
                                            <th class="bn-table-cell" style="text-align: left;">
                                                <div class="fee-borrow-box"><img
                                                        src="{{ asset('public/assets/img/fee-borrow-icon-1.png') }}"
                                                        class="img-fluid" alt="gift Card Image" />1INCH</div>
                                            </th>
                                            <th class="bn-table-cell" style="text-align: left;">
                                                <div class="fee-borrow-box"><img
                                                        src="{{ asset('public/assets/img/fee-borrow-icon-2.png') }}"
                                                        class="img-fluid" alt="gift Card Image" />AAVE</div>
                                            </th>
                                            <th class="bn-table-cell" style="text-align: left;">
                                                <div class="fee-borrow-box"><img
                                                        src="{{ asset('public/assets/img/fee-borrow-icon-3.png') }}"
                                                        class="img-fluid" alt="gift Card Image" />ACH</div>
                                            </th>
                                            <th class="bn-table-cell" style="text-align: left;">
                                                <div class="fee-borrow-box"><img
                                                        src="{{ asset('public/assets/img/fee-borrow-icon-4.png') }}"
                                                        class="img-fluid" alt="gift Card Image" />ADA</div>
                                            </th>
                                            <th class="bn-table-cell" style="text-align: left;">
                                                <div class="fee-borrow-box"><img
                                                        src="{{ asset('public/assets/img/fee-borrow-icon-5.png') }}"
                                                        class="img-fluid" alt="gift Card Image" />AGLD</div>
                                            </th>
                                            <th class="bn-table-cell" style="text-align: left;">
                                                <div class="fee-borrow-box"><img
                                                        src="{{ asset('public/assets/img/fee-borrow-icon-1.png') }}"
                                                        class="img-fluid" alt="gift Card Image" />ALGO</div>
                                            </th>
                                            <th class="bn-table-cell" style="text-align: left;">
                                                <div class="fee-borrow-box"><img
                                                        src="{{ asset('public/assets/img/fee-borrow-icon-4.png') }}"
                                                        class="img-fluid" alt="gift Card Image" />1INCH</div>
                                            </th>
                                            <th class="bn-table-cell" style="text-align: left;">
                                                <div class="fee-borrow-box"><img
                                                        src="{{ asset('public/assets/img/fee-borrow-icon-2.png') }}"
                                                        class="img-fluid" alt="gift Card Image" />AAVE</div>
                                            </th>
                                            <th class="bn-table-cell" style="text-align: left;">
                                                <div class="fee-borrow-box"><img
                                                        src="{{ asset('public/assets/img/fee-borrow-icon-3.png') }}"
                                                        class="img-fluid" alt="gift Card Image" />ACH</div>
                                            </th>
                                            <th class="bn-table-cell" style="text-align: left;">
                                                <div class="fee-borrow-box"><img
                                                        src="{{ asset('public/assets/img/fee-borrow-icon-4.png') }}"
                                                        class="img-fluid" alt="gift Card Image" />ADA</div>
                                            </th>
                                            <th class="bn-table-cell" style="text-align: left;">
                                                <div class="fee-borrow-box"><img
                                                        src="{{ asset('public/assets/img/fee-borrow-icon-5.png') }}"
                                                        class="img-fluid" alt="gift Card Image" />AGLD</div>
                                            </th>
                                            <th class="bn-table-cell" style="text-align: left;">
                                                <div class="fee-borrow-box"><img
                                                        src="{{ asset('public/assets/img/fee-borrow-icon-4.png') }}"
                                                        class="img-fluid" alt="gift Card Image" />ALGO</div>
                                            </th>
                                       </tr>
                                    </thead>
                                    <tbody class="bn-table-tbody">
                                        <tr aria-hidden="true" class="bn-table-measure-row"
                                            style="height: 0px; font-size: 0px;">
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                            <td style="padding: 0px; border: 0px; height: 0px;">
                                                <div style="height: 0px; overflow: hidden;">&nbsp;</div>
                                            </td>
                                        </tr>

                                        <tr data-row-key="0" class="bn-table-row bn-table-row-level-0">
                                            <td class="bn-table-cell bn-table-cell-fix-left bn-table-cell-fix-left-last"
                                                style="text-align: left; position: sticky; left: 0px;">
                                                <div class="level css-4cffwv">
                                                    <div data-bn-type="text" class="css-akaa8f">Regular User</div>
                                                </div>
                                            </td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016990%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.100000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.027260%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.030000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.060000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.071631%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.010000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.029040%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.046575%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.029972%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.050000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.038900%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.135590%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.050000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.050000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.050000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.030000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.030000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.030000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.300000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.110000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.050000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.080000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.005100%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.008220%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.050000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.070000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.030000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.100000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.030000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.060000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.040000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.050000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.030000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.050000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.011369%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.060600%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.040000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.080000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.120000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.050000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.015900%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.030000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.030000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.033534%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.005123%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.040000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.080000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.014060%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.027680%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.030000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.176460%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.050000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.010000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.030000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.090000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.040000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.030000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.060000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.040000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.060000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017680%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.230000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.080000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.080000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.050000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.060000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.030000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.080000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.028219%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.025000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.022740%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.024657%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.014767%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.013730%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.030000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.030000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.010000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.050000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.033561%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.023700%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.050000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.090000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.040000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.041095%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.034250%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.030000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.028219%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.050000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.030000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.030958%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.040000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.050000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.030000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.030000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.028220%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.030000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.050000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.041120%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.027400%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.080000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.015535%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.050000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.027562%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.040000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.050000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.070000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.060000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.050000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.030000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.030000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.150000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.100000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016712%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.010274%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016712%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.050000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.030000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.100000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.090000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.010000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.080000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.011534%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.030000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                        </tr>

                                        <tr data-row-key="1" class="bn-table-row bn-table-row-level-0">
                                            <td class="bn-table-cell bn-table-cell-fix-left bn-table-cell-fix-left-last"
                                                style="text-align: left; position: sticky; left: 0px;">
                                                <div class="level css-4cffwv">
                                                    <div data-bn-type="text" class="css-akaa8f">VIP 1</div>
                                                </div>
                                            </td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016140%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.095000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.025897%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.028500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.057000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.068049%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.027588%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.044246%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.028473%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.047500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.036955%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.128810%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.047500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.047500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.047500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.028500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.028500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.028500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.285000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.104500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.047500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.076000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.004998%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.007809%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.047500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.066500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.028500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.095000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.028500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.057000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.038000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.047500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.028500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.047500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.010801%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.057570%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.038000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.076000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.114000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.047500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.015582%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.028500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.028500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.031857%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.005021%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.038000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.076000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.013779%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.026296%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.028500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.167637%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.047500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.028500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.085500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.038000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.028500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.057000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.038000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.057000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017326%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.218500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.076000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.076000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.047500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.057000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.028500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.076000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.026808%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.023750%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.021603%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.023424%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.014472%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.013455%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.028500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.028500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.047500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.031883%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.022515%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.047500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.085500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.038000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.039040%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.032538%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.028500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.026808%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.047500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.028500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.029410%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.038000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.047500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.028500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.028500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.026809%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.028500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.047500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.039064%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.026030%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.076000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.015224%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.047500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.026184%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.038000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.047500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.066500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.057000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.047500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.028500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.028500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.142500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.095000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.015876%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009452%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.015876%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.047500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.028500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.095000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.085500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.076000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.011303%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.028500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                        </tr>

                                        <tr data-row-key="2" class="bn-table-row bn-table-row-level-0">
                                            <td class="bn-table-cell bn-table-cell-fix-left bn-table-cell-fix-left-last"
                                                style="text-align: left; position: sticky; left: 0px;">
                                                <div class="level css-4cffwv">
                                                    <div data-bn-type="text" class="css-akaa8f">VIP 2</div>
                                                </div>
                                            </td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016140%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.095000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.025897%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.015000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.057000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.010000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.035816%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.027588%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.044246%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.010000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.028473%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.025000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.036955%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.101692%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.047500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.047500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.047500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.028500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.015000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.028500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.285000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.104500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.047500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.076000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.004845%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.007562%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.025000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.066500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.015000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.010000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.095000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.028500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.057000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.038000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.047500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.028500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.025000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.005684%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.057570%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.038000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.076000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.060000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.047500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.015105%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.015000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.028500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.031857%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.004867%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.038000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.076000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.013357%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.026296%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.010000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.015000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.167637%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.047500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.010000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.028500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.045000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.010000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.038000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.015000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.057000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.038000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.030000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016796%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.218500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.076000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.076000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.047500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.057000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.028500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.076000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.026808%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.023750%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.010000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.010000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.021603%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.023424%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.014029%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.010000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.013044%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.015000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.028500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.047500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.031883%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.022515%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.047500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.045000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.038000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.010000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.039040%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.032538%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.015000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.026808%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.047500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.028500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.029410%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.038000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.025000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.028500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.028500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.026809%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.015000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.010000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.047500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020560%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.026030%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.076000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.014758%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.047500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.013781%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.038000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.025000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.010000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.066500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.057000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.025000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.028500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.028500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.142500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.050000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.015876%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.008938%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.015876%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.047500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.028500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.050000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.045000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.076000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.010957%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.028500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019000%</td>
                                        </tr>

                                        <tr data-row-key="3" class="bn-table-row bn-table-row-level-0">
                                            <td class="bn-table-cell bn-table-cell-fix-left bn-table-cell-fix-left-last"
                                                style="text-align: left; position: sticky; left: 0px;">
                                                <div class="level css-4cffwv">
                                                    <div data-bn-type="text" class="css-akaa8f">VIP 3</div>
                                                </div>
                                            </td>
                                            <td class="bn-table-cell" style="text-align: left;">0.015291%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.090000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.024534%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.014250%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.054000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.034025%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.026136%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.041918%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.026975%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.023750%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.035010%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.094913%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.045000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.045000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.045000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.027000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.014250%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.027000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.270000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.099000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.045000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.072000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.004743%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.007069%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.023750%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.063000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.014250%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.090000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.027000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.054000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.036000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.045000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.027000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.023750%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.005400%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.054540%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.036000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.072000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.057000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.045000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.014787%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.014250%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.027000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.030181%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.004764%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.036000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.072000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.013076%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.024912%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.014250%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.158814%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.045000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.027000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.042750%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.036000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.014250%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.054000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.036000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.028500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016442%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.207000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.072000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.072000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.045000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.054000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.027000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.072000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.025397%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.022500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020466%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.022191%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.013733%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.012769%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.014250%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.027000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.045000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.030205%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.021330%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.045000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.042750%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.036000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.036986%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.030825%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.014250%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.025397%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.045000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.027000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.027862%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.036000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.023750%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.027000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.027000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.025398%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.014250%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.045000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019532%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.024660%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.072000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.014448%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.045000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.013092%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.036000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.023750%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.063000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.054000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.023750%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.027000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.027000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.135000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.047500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.015041%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.008116%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.015041%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.045000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.027000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.047500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.042750%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.072000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.010727%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.027000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                        </tr>

                                        <tr data-row-key="4" class="bn-table-row bn-table-row-level-0">
                                            <td class="bn-table-cell bn-table-cell-fix-left bn-table-cell-fix-left-last"
                                                style="text-align: left; position: sticky; left: 0px;">
                                                <div class="level css-4cffwv">
                                                    <div data-bn-type="text" class="css-akaa8f">VIP 4</div>
                                                </div>
                                            </td>
                                            <td class="bn-table-cell" style="text-align: left;">0.015291%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.090000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.024534%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.014250%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.054000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.034025%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.026136%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.041918%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.026975%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.023750%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.035010%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.094913%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.045000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.045000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.045000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.027000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.014250%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.027000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.270000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.099000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.045000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.072000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.004590%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.006576%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.023750%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.063000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.014250%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.090000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.027000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.054000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.036000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.045000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.027000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.023750%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.005400%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.054540%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.036000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.072000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.057000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.045000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.014310%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.014250%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.027000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.030181%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.004611%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.036000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.072000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.012654%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.024912%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.014250%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.158814%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.045000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.027000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.042750%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.036000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.014250%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.054000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.036000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.028500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.015912%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.207000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.072000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.072000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.045000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.054000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.027000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.072000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.025397%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.022500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020466%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020958%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.013290%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.012357%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.014250%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.027000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.045000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.030205%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.021330%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.045000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.042750%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.036000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.036986%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.030825%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.014250%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.025397%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.045000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.027000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.027862%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.036000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.023750%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.027000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.027000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.025398%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.014250%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.045000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019532%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.024660%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.072000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.013982%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.045000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.012403%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.036000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.023750%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.063000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.054000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.023750%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.027000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.027000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.135000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.047500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.015041%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.007397%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.015041%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.045000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.027000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.047500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.042750%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.072000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.010381%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.027000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                        </tr>

                                        <tr data-row-key="5" class="bn-table-row bn-table-row-level-0">
                                            <td class="bn-table-cell bn-table-cell-fix-left bn-table-cell-fix-left-last"
                                                style="text-align: left; position: sticky; left: 0px;">
                                                <div class="level css-4cffwv">
                                                    <div data-bn-type="text" class="css-akaa8f">VIP 5</div>
                                                </div>
                                            </td>
                                            <td class="bn-table-cell" style="text-align: left;">0.015291%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.090000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.024534%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.014250%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.054000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.034025%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.026136%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.041918%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.026975%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.023750%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.035010%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.094913%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.045000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.045000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.045000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.027000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.014250%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.027000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.270000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.099000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.045000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.072000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.004182%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.006083%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.023750%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.063000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.014250%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.090000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.027000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.054000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.036000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.045000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.027000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.023750%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.005400%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.054540%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.036000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.072000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.057000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.045000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.013992%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.014250%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.027000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.030181%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.004508%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.036000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.072000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.012373%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.024912%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.008000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.014250%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.158814%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.045000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.027000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.042750%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.036000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.014250%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.054000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.036000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.028500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.015558%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.207000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.072000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.072000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.045000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.054000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.027000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.072000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.025397%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.022500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020466%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019726%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.012995%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.012082%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.014250%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.027000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.045000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.030205%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.021330%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.045000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.042750%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.036000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.036986%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.030825%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.014250%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.025397%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.045000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.027000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.027862%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.036000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.023750%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.027000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.027000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.025398%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.014250%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.045000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019532%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.024660%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.072000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.013671%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.045000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.011025%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.036000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.023750%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.063000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.054000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.023750%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.027000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.027000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.135000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.047500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.015041%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.006575%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.015041%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.045000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.027000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.047500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.042750%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.072000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.010150%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.027000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018000%</td>
                                        </tr>

                                        <tr data-row-key="6" class="bn-table-row bn-table-row-level-0">
                                            <td class="bn-table-cell bn-table-cell-fix-left bn-table-cell-fix-left-last"
                                                style="text-align: left; position: sticky; left: 0px;">
                                                <div class="level css-4cffwv">
                                                    <div data-bn-type="text" class="css-akaa8f">VIP 6</div>
                                                </div>
                                            </td>
                                            <td class="bn-table-cell" style="text-align: left;">0.014442%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.085000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.023171%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.013500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.051000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.032234%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.008500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.024684%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.039589%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.025476%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.022500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.033065%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.088134%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.042500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.042500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.042500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.025500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.013500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.025500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.255000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.093500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.042500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.068000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.003570%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.004110%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.022500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.059500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.013500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.085000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.025500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.051000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.034000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.042500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.025500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.022500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.005116%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.051510%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.034000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.068000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.054000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.042500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.013515%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.013500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.025500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.028504%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.004355%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.034000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.068000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.011951%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.023528%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.007000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.013500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.149991%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.042500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.008500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.025500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.040500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.034000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.013500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.051000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.034000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.027000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.015205%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.195500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.068000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.068000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.042500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.051000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.025500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.068000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.023986%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.021250%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019329%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017260%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.012552%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.011670%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.013500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.025500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.008500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.042500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.028527%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020145%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.042500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.040500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.034000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.034931%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.029112%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.013500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.023986%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.042500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.025500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.026314%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.034000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.022500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.025500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.025500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.023987%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.013500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.042500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018504%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.023290%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.068000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.013205%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.042500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009647%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.034000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.022500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.059500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.051000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.022500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.025500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.025500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.127500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.045000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.014205%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.005753%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.014205%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.042500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.025500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.045000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.040500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.008500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.068000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009804%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.025500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                        </tr>

                                        <tr data-row-key="7" class="bn-table-row bn-table-row-level-0">
                                            <td class="bn-table-cell bn-table-cell-fix-left bn-table-cell-fix-left-last"
                                                style="text-align: left; position: sticky; left: 0px;">
                                                <div class="level css-4cffwv">
                                                    <div data-bn-type="text" class="css-akaa8f">VIP 7</div>
                                                </div>
                                            </td>
                                            <td class="bn-table-cell" style="text-align: left;">0.014442%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.085000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.023171%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.013500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.051000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.032234%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.008500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.024684%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.039589%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.025476%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.022500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.033065%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.088134%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.042500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.042500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.042500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.025500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.013500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.025500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.255000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.093500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.042500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.068000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.003162%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.003699%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.022500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.059500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.013500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.085000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.025500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.051000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.034000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.042500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.025500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.022500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.005116%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.051510%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.034000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.068000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.054000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.042500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.013356%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.013500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.025500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.028504%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.004303%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.034000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.068000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.011810%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.023528%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.006000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.013500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.149991%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.042500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.008500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.025500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.040500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.034000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.013500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.051000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.034000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.027000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.014851%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.195500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.068000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.068000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.042500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.051000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.025500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.068000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.023986%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.021250%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.019329%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016027%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.012404%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.010984%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.013500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.025500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.008500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.042500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.028527%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020145%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.042500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.040500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.034000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.034931%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.029112%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.013500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.023986%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.042500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.025500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.026314%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.034000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.022500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.025500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.025500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.023987%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.013500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.042500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018504%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.023290%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.068000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.013049%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.042500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.008269%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.034000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.022500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.059500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.051000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.022500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.025500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.025500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.127500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.045000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.014205%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.004829%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.014205%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.042500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.025500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.045000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.040500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.008500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.068000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009689%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.025500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017000%</td>
                                        </tr>

                                        <tr data-row-key="8" class="bn-table-row bn-table-row-level-0">
                                            <td class="bn-table-cell bn-table-cell-fix-left bn-table-cell-fix-left-last"
                                                style="text-align: left; position: sticky; left: 0px;">
                                                <div class="level css-4cffwv">
                                                    <div data-bn-type="text" class="css-akaa8f">VIP 8</div>
                                                </div>
                                            </td>
                                            <td class="bn-table-cell" style="text-align: left;">0.013592%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.080000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.021808%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.012750%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.048000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.008500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.030443%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.008000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.023232%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.037260%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.008500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.023978%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.021250%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.031120%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.081354%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.040000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.040000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.040000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.024000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.012750%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.024000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.240000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.088000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.040000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.064000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.002958%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.003288%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.021250%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.056000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.012750%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.008500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.080000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.024000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.048000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.032000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.040000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.024000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.021250%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.004832%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.048480%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.032000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.064000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.051000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.040000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.012879%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.012750%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.024000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.026827%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.004150%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.032000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.064000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.011389%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.022144%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.005000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.012750%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.141168%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.040000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.008500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.008000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.024000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.038250%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.008500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.032000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.012750%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.048000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.032000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.025500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.014498%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.184000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.064000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.064000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.040000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.048000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.024000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.064000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.022575%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.008500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.008500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018192%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.014301%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.011961%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.008500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.010298%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.012750%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.024000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.008000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.040000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.026849%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018960%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.040000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.038250%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.032000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.008500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.032876%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.027400%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.012750%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.022575%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.040000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.024000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.024766%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.032000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.021250%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.024000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.024000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.022576%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.012750%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.008500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.040000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017476%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.021920%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.064000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.012583%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.040000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.006890%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.032000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.021250%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.008500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.056000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.048000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.021250%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.024000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.024000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.120000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.042500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.013370%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.004110%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.013370%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.040000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.024000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.042500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.038250%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.008000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.064000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009343%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.024000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                        </tr>

                                        <tr data-row-key="9" class="bn-table-row bn-table-row-level-0">
                                            <td class="bn-table-cell bn-table-cell-fix-left bn-table-cell-fix-left-last"
                                                style="text-align: left; position: sticky; left: 0px;">
                                                <div class="level css-4cffwv">
                                                    <div data-bn-type="text" class="css-akaa8f">VIP 9</div>
                                                </div>
                                            </td>
                                            <td class="bn-table-cell" style="text-align: left;">0.013592%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.080000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.021808%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.012750%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.048000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.008500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.030443%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.008000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.023232%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.037260%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.008500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.023978%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.021250%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.031120%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.081354%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.040000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.040000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.040000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.024000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.012750%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.024000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.240000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.088000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.040000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.064000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.002754%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.002959%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.021250%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.056000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.012750%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.008500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.080000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.024000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.048000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.032000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.040000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.024000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.021250%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.004832%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.048480%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.032000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.064000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.051000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.040000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.012402%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.012750%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.024000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.026827%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.003996%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.032000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.064000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.010967%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.022144%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.004000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.012750%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.141168%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.040000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.008500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.008000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.024000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.038250%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.008500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.032000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.012750%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.048000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.032000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.025500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.014144%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.184000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.064000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.064000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.040000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.048000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.024000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.064000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.022575%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.020000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.008500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.008500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018192%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.012328%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.011518%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.008500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.009611%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.012750%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.024000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.008000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.040000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.026849%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.018960%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.040000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.038250%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.032000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.008500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.027534%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.027400%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.012750%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.022575%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.040000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.024000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.024766%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.032000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.021250%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.024000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.024000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.022576%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.012750%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.008500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.040000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.017476%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.021920%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.064000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.012117%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.040000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.005512%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.032000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.021250%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.008500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.056000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.048000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.021250%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.024000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.024000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.120000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.042500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.013370%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.003801%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.013370%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.040000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.024000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.042500%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.038250%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.008000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.064000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.008997%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.024000%</td>
                                            <td class="bn-table-cell" style="text-align: left;">0.016000%</td>
                                        </tr>
                                        
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <div class="tab-pane fade" id="USDFutures-Trading" role="tabpanel"
                            aria-labelledby="USDFutures-Trading-tab">
                            <div class="table-responsive"> 
                            <table class="table table-striped table-hover table-bordered">
                                <thead>
                                    <tr>
                                        <th>Level</th>
                                        <th>30d Trade Volume (BUSD)</th>
                                        <th>and/or</th>
                                        <th>BNB Balance</th>
                                        <th>Maker / Taker</th>
                                        <th>Maker / Taker <small>BNB 25% off</small></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>Regular User</td>
                                        <td>
                                            < 1,000,000 BUSD </td>
                                        <td>or</td>
                                        <td>≥ 0 BNB</td>
                                        <td>0.1000% / 0.1000%</td>
                                        <td>0.0750% / 0.0750%</td>
                                    </tr>


                                    <tr>
                                        <td>VIP 1</td>
                                        <td>
                                            < 1,000,000 BUSD </td>
                                        <td>or</td>
                                        <td>≥ 0 BNB</td>
                                        <td>0.1000% / 0.1000%</td>
                                        <td>0.0750% / 0.0750%</td>
                                    </tr>
                                    <tr>
                                        <td>VIP 2</td>
                                        <td>≥ 20,000,000 BUSD </td>
                                        <td>or</td>
                                        <td>≥ 0 BNB</td>
                                        <td>0.1000% / 0.1000%</td>
                                        <td>0.0750% / 0.0750%</td>
                                    </tr>
                                    <tr>
                                        <td>VIP 3</td>
                                        <td>
                                            < 1,000,000 BUSD </td>
                                        <td>or</td>
                                        <td>≥ 0 BNB</td>
                                        <td>0.1000% / 0.1000%</td>
                                        <td>0.0750% / 0.0750%</td>
                                    </tr>
                                    <tr>
                                        <td>VIP 4</td>
                                        <td>
                                            < 1,000,000 BUSD </td>
                                        <td>or</td>
                                        <td>≥ 0 BNB</td>
                                        <td><del>0.1000% / 0.1000% </del> <br /><span class="text-warning">0.0200% /
                                                0.0400% </span></td>
                                        <td><del>0.1000% / 0.1000% </del> <br /><span class="text-warning">0.0200% /
                                                0.0400% </span></td>
                                    </tr>
                                    <tr>
                                        <td>VIP 5 <svg  viewBox="0 0 24 24"
                                                fill="none" class="css-7dirbb">
                                                <path
                                                    d="M5.94 19.574C7.612 21.19 9.806 22 12 22c2.194 0 4.387-.809 6.061-2.426 3.347-3.236 3.347-8.48 0-11.716L12.001 2 5.938 7.858c-3.347 3.235-3.347 8.48 0 11.716z"
                                                    fill="url(#hot-g_svg__paint0_linear_1330_2334)"></path>
                                                <path
                                                    d="M8.506 18.544A4.911 4.911 0 0012 20a4.91 4.91 0 003.494-1.456 4.992 4.992 0 000-7.03L12 8l-3.494 3.515a4.991 4.991 0 000 7.03z"
                                                    fill="#76808F"></path>
                                                <path d="M3 3.5L5.5 6 8 3.5 5.5 1 3 3.5z"
                                                    fill="url(#hot-g_svg__paint1_linear_1330_2334)"></path>
                                                <path d="M20 7.5L21.5 9 23 7.5 21.5 6 20 7.5z" fill="#76808F"></path>
                                                <path d="M1 20l1.5 1.5L4 20l-1.5-1.5L1 20z"
                                                    fill="url(#hot-g_svg__paint2_linear_1330_2334)"></path>
                                                <defs>
                                                    <linearGradient id="hot-g_svg__paint0_linear_1330_2334" x1="12"
                                                        y1="22" x2="12" y2="2" gradientUnits="userSpaceOnUse">
                                                        <stop stop-color="#F0B90B"></stop>
                                                        <stop offset="1" stop-color="#F8D33A"></stop>
                                                    </linearGradient>
                                                    <linearGradient id="hot-g_svg__paint1_linear_1330_2334" x1="5.5"
                                                        y1="6" x2="5.5" y2="1" gradientUnits="userSpaceOnUse">
                                                        <stop stop-color="#F0B90B"></stop>
                                                        <stop offset="1" stop-color="#F8D33A"></stop>
                                                    </linearGradient>
                                                    <linearGradient id="hot-g_svg__paint2_linear_1330_2334" x1="2.5"
                                                        y1="21.5" x2="2.5" y2="18.5" gradientUnits="userSpaceOnUse">
                                                        <stop stop-color="#F0B90B"></stop>
                                                        <stop offset="1" stop-color="#F8D33A"></stop>
                                                    </linearGradient>
                                                </defs>
                                            </svg></td>
                                        <td>
                                            < 1,000,000 BUSD </td>
                                        <td>or</td>
                                        <td>≥ 0 BNB</td>
                                        <td><del>0.1000% / 0.1000% </del> <br /><span class="text-warning">0.0200% /
                                                0.0400% </span></td>
                                        <td><del>0.1000% / 0.1000% </del> <br /><span class="text-warning">0.0200% /
                                                0.0400% </span></td>
                                    </tr>
                                    <tr>
                                        <td>VIP 6 <svg  viewBox="0 0 24 24"
                                                fill="none" class="css-7dirbb">
                                                <path
                                                    d="M5.94 19.574C7.612 21.19 9.806 22 12 22c2.194 0 4.387-.809 6.061-2.426 3.347-3.236 3.347-8.48 0-11.716L12.001 2 5.938 7.858c-3.347 3.235-3.347 8.48 0 11.716z"
                                                    fill="url(#hot-g_svg__paint0_linear_1330_2334)"></path>
                                                <path
                                                    d="M8.506 18.544A4.911 4.911 0 0012 20a4.91 4.91 0 003.494-1.456 4.992 4.992 0 000-7.03L12 8l-3.494 3.515a4.991 4.991 0 000 7.03z"
                                                    fill="#76808F"></path>
                                                <path d="M3 3.5L5.5 6 8 3.5 5.5 1 3 3.5z"
                                                    fill="url(#hot-g_svg__paint1_linear_1330_2334)"></path>
                                                <path d="M20 7.5L21.5 9 23 7.5 21.5 6 20 7.5z" fill="#76808F"></path>
                                                <path d="M1 20l1.5 1.5L4 20l-1.5-1.5L1 20z"
                                                    fill="url(#hot-g_svg__paint2_linear_1330_2334)"></path>
                                                <defs>
                                                    <linearGradient id="hot-g_svg__paint0_linear_1330_2334" x1="12"
                                                        y1="22" x2="12" y2="2" gradientUnits="userSpaceOnUse">
                                                        <stop stop-color="#F0B90B"></stop>
                                                        <stop offset="1" stop-color="#F8D33A"></stop>
                                                    </linearGradient>
                                                    <linearGradient id="hot-g_svg__paint1_linear_1330_2334" x1="5.5"
                                                        y1="6" x2="5.5" y2="1" gradientUnits="userSpaceOnUse">
                                                        <stop stop-color="#F0B90B"></stop>
                                                        <stop offset="1" stop-color="#F8D33A"></stop>
                                                    </linearGradient>
                                                    <linearGradient id="hot-g_svg__paint2_linear_1330_2334" x1="2.5"
                                                        y1="21.5" x2="2.5" y2="18.5" gradientUnits="userSpaceOnUse">
                                                        <stop stop-color="#F0B90B"></stop>
                                                        <stop offset="1" stop-color="#F8D33A"></stop>
                                                    </linearGradient>
                                                </defs>
                                            </svg></td>
                                        <td>
                                            < 1,000,000 BUSD </td>
                                        <td>or</td>
                                        <td>≥ 0 BNB</td>
                                        <td><del>0.1000% / 0.1000% </del> <br /><span class="text-warning">0.0200% /
                                                0.0400% </span></td>
                                        <td><del>0.1000% / 0.1000% </del> <br /><span class="text-warning">0.0200% /
                                                0.0400% </span></td>
                                    </tr>
                                    <tr>
                                        <td>VIP 7 <svg  viewBox="0 0 24 24"
                                                fill="none" class="css-7dirbb">
                                                <path
                                                    d="M5.94 19.574C7.612 21.19 9.806 22 12 22c2.194 0 4.387-.809 6.061-2.426 3.347-3.236 3.347-8.48 0-11.716L12.001 2 5.938 7.858c-3.347 3.235-3.347 8.48 0 11.716z"
                                                    fill="url(#hot-g_svg__paint0_linear_1330_2334)"></path>
                                                <path
                                                    d="M8.506 18.544A4.911 4.911 0 0012 20a4.91 4.91 0 003.494-1.456 4.992 4.992 0 000-7.03L12 8l-3.494 3.515a4.991 4.991 0 000 7.03z"
                                                    fill="#76808F"></path>
                                                <path d="M3 3.5L5.5 6 8 3.5 5.5 1 3 3.5z"
                                                    fill="url(#hot-g_svg__paint1_linear_1330_2334)"></path>
                                                <path d="M20 7.5L21.5 9 23 7.5 21.5 6 20 7.5z" fill="#76808F"></path>
                                                <path d="M1 20l1.5 1.5L4 20l-1.5-1.5L1 20z"
                                                    fill="url(#hot-g_svg__paint2_linear_1330_2334)"></path>
                                                <defs>
                                                    <linearGradient id="hot-g_svg__paint0_linear_1330_2334" x1="12"
                                                        y1="22" x2="12" y2="2" gradientUnits="userSpaceOnUse">
                                                        <stop stop-color="#F0B90B"></stop>
                                                        <stop offset="1" stop-color="#F8D33A"></stop>
                                                    </linearGradient>
                                                    <linearGradient id="hot-g_svg__paint1_linear_1330_2334" x1="5.5"
                                                        y1="6" x2="5.5" y2="1" gradientUnits="userSpaceOnUse">
                                                        <stop stop-color="#F0B90B"></stop>
                                                        <stop offset="1" stop-color="#F8D33A"></stop>
                                                    </linearGradient>
                                                    <linearGradient id="hot-g_svg__paint2_linear_1330_2334" x1="2.5"
                                                        y1="21.5" x2="2.5" y2="18.5" gradientUnits="userSpaceOnUse">
                                                        <stop stop-color="#F0B90B"></stop>
                                                        <stop offset="1" stop-color="#F8D33A"></stop>
                                                    </linearGradient>
                                                </defs>
                                            </svg></td>
                                        <td>
                                            < 1,000,000 BUSD </td>
                                        <td>or</td>
                                        <td>≥ 0 BNB</td>
                                        <td><del>0.1000% / 0.1000% </del> <br /><span class="text-warning">0.0200% /
                                                0.0400% </span></td>
                                        <td><del>0.1000% / 0.1000% </del> <br /><span class="text-warning">0.0200% /
                                                0.0400% </span></td>
                                    </tr>
                                    <tr>
                                        <td>VIP 8</td>
                                        <td>
                                            < 1,000,000 BUSD </td>
                                        <td>or</td>
                                        <td>≥ 0 BNB</td>
                                        <td><del>0.1000% / 0.1000% </del> <br /><span class="text-warning">0.0200% /
                                                0.0400% </span></td>
                                        <td><del>0.1000% / 0.1000% </del> <br /><span class="text-warning">0.0200% /
                                                0.0400% </span></td>
                                    </tr>
                                    <tr>
                                        <td>VIP 9 <svg  viewBox="0 0 24 24"
                                                fill="none" class="css-7dirbb">
                                                <path
                                                    d="M5.94 19.574C7.612 21.19 9.806 22 12 22c2.194 0 4.387-.809 6.061-2.426 3.347-3.236 3.347-8.48 0-11.716L12.001 2 5.938 7.858c-3.347 3.235-3.347 8.48 0 11.716z"
                                                    fill="url(#hot-g_svg__paint0_linear_1330_2334)"></path>
                                                <path
                                                    d="M8.506 18.544A4.911 4.911 0 0012 20a4.91 4.91 0 003.494-1.456 4.992 4.992 0 000-7.03L12 8l-3.494 3.515a4.991 4.991 0 000 7.03z"
                                                    fill="#76808F"></path>
                                                <path d="M3 3.5L5.5 6 8 3.5 5.5 1 3 3.5z"
                                                    fill="url(#hot-g_svg__paint1_linear_1330_2334)"></path>
                                                <path d="M20 7.5L21.5 9 23 7.5 21.5 6 20 7.5z" fill="#76808F"></path>
                                                <path d="M1 20l1.5 1.5L4 20l-1.5-1.5L1 20z"
                                                    fill="url(#hot-g_svg__paint2_linear_1330_2334)"></path>
                                                <defs>
                                                    <linearGradient id="hot-g_svg__paint0_linear_1330_2334" x1="12"
                                                        y1="22" x2="12" y2="2" gradientUnits="userSpaceOnUse">
                                                        <stop stop-color="#F0B90B"></stop>
                                                        <stop offset="1" stop-color="#F8D33A"></stop>
                                                    </linearGradient>
                                                    <linearGradient id="hot-g_svg__paint1_linear_1330_2334" x1="5.5"
                                                        y1="6" x2="5.5" y2="1" gradientUnits="userSpaceOnUse">
                                                        <stop stop-color="#F0B90B"></stop>
                                                        <stop offset="1" stop-color="#F8D33A"></stop>
                                                    </linearGradient>
                                                    <linearGradient id="hot-g_svg__paint2_linear_1330_2334" x1="2.5"
                                                        y1="21.5" x2="2.5" y2="18.5" gradientUnits="userSpaceOnUse">
                                                        <stop stop-color="#F0B90B"></stop>
                                                        <stop offset="1" stop-color="#F8D33A"></stop>
                                                    </linearGradient>
                                                </defs>
                                            </svg></td>
                                        <td>
                                            < 1,000,000 BUSD </td>
                                        <td>or</td>
                                        <td>≥ 0 BNB</td>
                                        <td>0.1000% / 0.1000%</td>
                                        <td>0.0750% / 0.0750%</td>
                                    </tr>

                                </tbody>
                            </table>
                            </div>
                        </div>

                        <div class="tab-pane fade show" id="coin-m-future-trading" role="tabpanel"
                            aria-labelledby="coin-m-future-trading-tab">
                          <div class="table-responsive"> 
                          <table class="table table-striped table-hover table-bordered">
                                <thead>
                                    <tr>
                                        <th>Level</th>
                                        <th>30d Trade Volume (BUSD)</th>
                                        <th>and/or</th>
                                        <th>BNB Balance</th>
                                        <th>Maker / Taker</th>
                                        <th>Maker / Taker <small>BNB 25% off</small></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>Regular User</td>
                                        <td>
                                            < 1,000,000 BUSD </td>
                                        <td>or</td>
                                        <td>≥ 0 BNB</td>
                                        <td>0.1000% / 0.1000%</td>
                                        <td>0.0750% / 0.0750%</td>
                                    </tr>


                                    <tr>
                                        <td>VIP 1</td>
                                        <td>
                                            < 1,000,000 BUSD </td>
                                        <td>or</td>
                                        <td>≥ 0 BNB</td>
                                        <td>0.1000% / 0.1000%</td>
                                        <td>0.0750% / 0.0750%</td>
                                    </tr>
                                    <tr>
                                        <td>VIP 2</td>
                                        <td>≥ 20,000,000 BUSD </td>
                                        <td>or</td>
                                        <td>≥ 0 BNB</td>
                                        <td>0.1000% / 0.1000%</td>
                                        <td>0.0750% / 0.0750%</td>
                                    </tr>
                                    <tr>
                                        <td>VIP 3</td>
                                        <td>
                                            < 1,000,000 BUSD </td>
                                        <td>or</td>
                                        <td>≥ 0 BNB</td>
                                        <td>0.1000% / 0.1000%</td>
                                        <td>0.0750% / 0.0750%</td>
                                    </tr>
                                    <tr>
                                        <td>VIP 4</td>
                                        <td>
                                            < 1,000,000 BUSD </td>
                                        <td>or</td>
                                        <td>≥ 0 BNB</td>
                                        <td><del>0.1000% / 0.1000% </del> <br /><span class="text-warning">0.0200% /
                                                0.0400% </span></td>
                                        <td><del>0.1000% / 0.1000% </del> <br /><span class="text-warning">0.0200% /
                                                0.0400% </span></td>
                                    </tr>
                                    <tr>
                                        <td>VIP 5 <svg  viewBox="0 0 24 24"
                                                fill="none" class="css-7dirbb">
                                                <path
                                                    d="M5.94 19.574C7.612 21.19 9.806 22 12 22c2.194 0 4.387-.809 6.061-2.426 3.347-3.236 3.347-8.48 0-11.716L12.001 2 5.938 7.858c-3.347 3.235-3.347 8.48 0 11.716z"
                                                    fill="url(#hot-g_svg__paint0_linear_1330_2334)"></path>
                                                <path
                                                    d="M8.506 18.544A4.911 4.911 0 0012 20a4.91 4.91 0 003.494-1.456 4.992 4.992 0 000-7.03L12 8l-3.494 3.515a4.991 4.991 0 000 7.03z"
                                                    fill="#76808F"></path>
                                                <path d="M3 3.5L5.5 6 8 3.5 5.5 1 3 3.5z"
                                                    fill="url(#hot-g_svg__paint1_linear_1330_2334)"></path>
                                                <path d="M20 7.5L21.5 9 23 7.5 21.5 6 20 7.5z" fill="#76808F"></path>
                                                <path d="M1 20l1.5 1.5L4 20l-1.5-1.5L1 20z"
                                                    fill="url(#hot-g_svg__paint2_linear_1330_2334)"></path>
                                                <defs>
                                                    <linearGradient id="hot-g_svg__paint0_linear_1330_2334" x1="12"
                                                        y1="22" x2="12" y2="2" gradientUnits="userSpaceOnUse">
                                                        <stop stop-color="#F0B90B"></stop>
                                                        <stop offset="1" stop-color="#F8D33A"></stop>
                                                    </linearGradient>
                                                    <linearGradient id="hot-g_svg__paint1_linear_1330_2334" x1="5.5"
                                                        y1="6" x2="5.5" y2="1" gradientUnits="userSpaceOnUse">
                                                        <stop stop-color="#F0B90B"></stop>
                                                        <stop offset="1" stop-color="#F8D33A"></stop>
                                                    </linearGradient>
                                                    <linearGradient id="hot-g_svg__paint2_linear_1330_2334" x1="2.5"
                                                        y1="21.5" x2="2.5" y2="18.5" gradientUnits="userSpaceOnUse">
                                                        <stop stop-color="#F0B90B"></stop>
                                                        <stop offset="1" stop-color="#F8D33A"></stop>
                                                    </linearGradient>
                                                </defs>
                                            </svg></td>
                                        <td>
                                            < 1,000,000 BUSD </td>
                                        <td>or</td>
                                        <td>≥ 0 BNB</td>
                                        <td><del>0.1000% / 0.1000% </del> <br /><span class="text-warning">0.0200% /
                                                0.0400% </span></td>
                                        <td><del>0.1000% / 0.1000% </del> <br /><span class="text-warning">0.0200% /
                                                0.0400% </span></td>
                                    </tr>
                                    <tr>
                                        <td>VIP 6 <svg  viewBox="0 0 24 24"
                                                fill="none" class="css-7dirbb">
                                                <path
                                                    d="M5.94 19.574C7.612 21.19 9.806 22 12 22c2.194 0 4.387-.809 6.061-2.426 3.347-3.236 3.347-8.48 0-11.716L12.001 2 5.938 7.858c-3.347 3.235-3.347 8.48 0 11.716z"
                                                    fill="url(#hot-g_svg__paint0_linear_1330_2334)"></path>
                                                <path
                                                    d="M8.506 18.544A4.911 4.911 0 0012 20a4.91 4.91 0 003.494-1.456 4.992 4.992 0 000-7.03L12 8l-3.494 3.515a4.991 4.991 0 000 7.03z"
                                                    fill="#76808F"></path>
                                                <path d="M3 3.5L5.5 6 8 3.5 5.5 1 3 3.5z"
                                                    fill="url(#hot-g_svg__paint1_linear_1330_2334)"></path>
                                                <path d="M20 7.5L21.5 9 23 7.5 21.5 6 20 7.5z" fill="#76808F"></path>
                                                <path d="M1 20l1.5 1.5L4 20l-1.5-1.5L1 20z"
                                                    fill="url(#hot-g_svg__paint2_linear_1330_2334)"></path>
                                                <defs>
                                                    <linearGradient id="hot-g_svg__paint0_linear_1330_2334" x1="12"
                                                        y1="22" x2="12" y2="2" gradientUnits="userSpaceOnUse">
                                                        <stop stop-color="#F0B90B"></stop>
                                                        <stop offset="1" stop-color="#F8D33A"></stop>
                                                    </linearGradient>
                                                    <linearGradient id="hot-g_svg__paint1_linear_1330_2334" x1="5.5"
                                                        y1="6" x2="5.5" y2="1" gradientUnits="userSpaceOnUse">
                                                        <stop stop-color="#F0B90B"></stop>
                                                        <stop offset="1" stop-color="#F8D33A"></stop>
                                                    </linearGradient>
                                                    <linearGradient id="hot-g_svg__paint2_linear_1330_2334" x1="2.5"
                                                        y1="21.5" x2="2.5" y2="18.5" gradientUnits="userSpaceOnUse">
                                                        <stop stop-color="#F0B90B"></stop>
                                                        <stop offset="1" stop-color="#F8D33A"></stop>
                                                    </linearGradient>
                                                </defs>
                                            </svg></td>
                                        <td>
                                            < 1,000,000 BUSD </td>
                                        <td>or</td>
                                        <td>≥ 0 BNB</td>
                                        <td><del>0.1000% / 0.1000% </del> <br /><span class="text-warning">0.0200% /
                                                0.0400% </span></td>
                                        <td><del>0.1000% / 0.1000% </del> <br /><span class="text-warning">0.0200% /
                                                0.0400% </span></td>
                                    </tr>
                                    <tr>
                                        <td>VIP 7 <svg  viewBox="0 0 24 24"
                                                fill="none" class="css-7dirbb">
                                                <path
                                                    d="M5.94 19.574C7.612 21.19 9.806 22 12 22c2.194 0 4.387-.809 6.061-2.426 3.347-3.236 3.347-8.48 0-11.716L12.001 2 5.938 7.858c-3.347 3.235-3.347 8.48 0 11.716z"
                                                    fill="url(#hot-g_svg__paint0_linear_1330_2334)"></path>
                                                <path
                                                    d="M8.506 18.544A4.911 4.911 0 0012 20a4.91 4.91 0 003.494-1.456 4.992 4.992 0 000-7.03L12 8l-3.494 3.515a4.991 4.991 0 000 7.03z"
                                                    fill="#76808F"></path>
                                                <path d="M3 3.5L5.5 6 8 3.5 5.5 1 3 3.5z"
                                                    fill="url(#hot-g_svg__paint1_linear_1330_2334)"></path>
                                                <path d="M20 7.5L21.5 9 23 7.5 21.5 6 20 7.5z" fill="#76808F"></path>
                                                <path d="M1 20l1.5 1.5L4 20l-1.5-1.5L1 20z"
                                                    fill="url(#hot-g_svg__paint2_linear_1330_2334)"></path>
                                                <defs>
                                                    <linearGradient id="hot-g_svg__paint0_linear_1330_2334" x1="12"
                                                        y1="22" x2="12" y2="2" gradientUnits="userSpaceOnUse">
                                                        <stop stop-color="#F0B90B"></stop>
                                                        <stop offset="1" stop-color="#F8D33A"></stop>
                                                    </linearGradient>
                                                    <linearGradient id="hot-g_svg__paint1_linear_1330_2334" x1="5.5"
                                                        y1="6" x2="5.5" y2="1" gradientUnits="userSpaceOnUse">
                                                        <stop stop-color="#F0B90B"></stop>
                                                        <stop offset="1" stop-color="#F8D33A"></stop>
                                                    </linearGradient>
                                                    <linearGradient id="hot-g_svg__paint2_linear_1330_2334" x1="2.5"
                                                        y1="21.5" x2="2.5" y2="18.5" gradientUnits="userSpaceOnUse">
                                                        <stop stop-color="#F0B90B"></stop>
                                                        <stop offset="1" stop-color="#F8D33A"></stop>
                                                    </linearGradient>
                                                </defs>
                                            </svg></td>
                                        <td>
                                            < 1,000,000 BUSD </td>
                                        <td>or</td>
                                        <td>≥ 0 BNB</td>
                                        <td><del>0.1000% / 0.1000% </del> <br /><span class="text-warning">0.0200% /
                                                0.0400% </span></td>
                                        <td><del>0.1000% / 0.1000% </del> <br /><span class="text-warning">0.0200% /
                                                0.0400% </span></td>
                                    </tr>
                                    <tr>
                                        <td>VIP 8</td>
                                        <td>
                                            < 1,000,000 BUSD </td>
                                        <td>or</td>
                                        <td>≥ 0 BNB</td>
                                        <td><del>0.1000% / 0.1000% </del> <br /><span class="text-warning">0.0200% /
                                                0.0400% </span></td>
                                        <td><del>0.1000% / 0.1000% </del> <br /><span class="text-warning">0.0200% /
                                                0.0400% </span></td>
                                    </tr>
                                    <tr>
                                        <td>VIP 9 <svg  viewBox="0 0 24 24"
                                                fill="none" class="css-7dirbb">
                                                <path
                                                    d="M5.94 19.574C7.612 21.19 9.806 22 12 22c2.194 0 4.387-.809 6.061-2.426 3.347-3.236 3.347-8.48 0-11.716L12.001 2 5.938 7.858c-3.347 3.235-3.347 8.48 0 11.716z"
                                                    fill="url(#hot-g_svg__paint0_linear_1330_2334)"></path>
                                                <path
                                                    d="M8.506 18.544A4.911 4.911 0 0012 20a4.91 4.91 0 003.494-1.456 4.992 4.992 0 000-7.03L12 8l-3.494 3.515a4.991 4.991 0 000 7.03z"
                                                    fill="#76808F"></path>
                                                <path d="M3 3.5L5.5 6 8 3.5 5.5 1 3 3.5z"
                                                    fill="url(#hot-g_svg__paint1_linear_1330_2334)"></path>
                                                <path d="M20 7.5L21.5 9 23 7.5 21.5 6 20 7.5z" fill="#76808F"></path>
                                                <path d="M1 20l1.5 1.5L4 20l-1.5-1.5L1 20z"
                                                    fill="url(#hot-g_svg__paint2_linear_1330_2334)"></path>
                                                <defs>
                                                    <linearGradient id="hot-g_svg__paint0_linear_1330_2334" x1="12"
                                                        y1="22" x2="12" y2="2" gradientUnits="userSpaceOnUse">
                                                        <stop stop-color="#F0B90B"></stop>
                                                        <stop offset="1" stop-color="#F8D33A"></stop>
                                                    </linearGradient>
                                                    <linearGradient id="hot-g_svg__paint1_linear_1330_2334" x1="5.5"
                                                        y1="6" x2="5.5" y2="1" gradientUnits="userSpaceOnUse">
                                                        <stop stop-color="#F0B90B"></stop>
                                                        <stop offset="1" stop-color="#F8D33A"></stop>
                                                    </linearGradient>
                                                    <linearGradient id="hot-g_svg__paint2_linear_1330_2334" x1="2.5"
                                                        y1="21.5" x2="2.5" y2="18.5" gradientUnits="userSpaceOnUse">
                                                        <stop stop-color="#F0B90B"></stop>
                                                        <stop offset="1" stop-color="#F8D33A"></stop>
                                                    </linearGradient>
                                                </defs>
                                            </svg></td>
                                        <td>
                                            < 1,000,000 BUSD </td>
                                        <td>or</td>
                                        <td>≥ 0 BNB</td>
                                        <td>0.1000% / 0.1000%</td>
                                        <td>0.0750% / 0.0750%</td>
                                    </tr>

                                </tbody>
                            </table>
                          </div>
                        </div>

                        <div class="tab-pane fade" id="cross-interest" role="tabpanel"
                            aria-labelledby="cross-interest-tab">
                            Collateral Coin
                            <div class="available-gift-card mt-2" id="added-gift-card">
                                <img src="http://127.0.0.1/beta-dlp/public/assets/img/added-card-icon.jpg"
                                    class="img-fluid" alt="fee page img">
                                <h5>No Record Found</h5>
                            </div>
                        </div>

                        <div class="tab-pane fade" id="swap-farming" role="tabpanel" aria-labelledby="swap-farming-tab">
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th scope="col">Level</th>
                                            <th scope="col">Pool</th>
                                            <th scope="col">Swap Fee</th>
                                            <th scope="col">Fee Rebate</th>
                                            <th scope="col">Effective Fee</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>Regular User</td>
                                            <td><img src="{{ asset('public/assets/img/trading-fee-pool-icon.png') }}"
                                                    class="img-fluid fee-pool-icon"
                                                    alt="fee page img" />&nbsp;&nbsp;WOO/USDT
                                            </td>
                                            <td>0.1500%</td>
                                            <td>45.00%</td>
                                            <td>0.0825%</td>
                                        </tr>
                                        <tr>
                                            <td>VIP 1</td>
                                            <td><img src="{{ asset('public/assets/img/trading-fee-pool-icon.png') }}"
                                                    class="img-fluid fee-pool-icon"
                                                    alt="fee page img" />&nbsp;&nbsp;WOO/USDT
                                            </td>
                                            <td>0.1000%</td>
                                            <td>45.00%</td>
                                            <td>0.0550%</td>
                                        </tr>
                                        <tr>
                                            <td>VIP 2</td>
                                            <td><img src="{{ asset('public/assets/img/trading-fee-pool-icon.png') }}"
                                                    class="img-fluid fee-pool-icon"
                                                    alt="fee page img" />&nbsp;&nbsp;WOO/USDT
                                            </td>
                                            <td>0.1000%</td>
                                            <td>45.00%</td>
                                            <td>0.0550%</td>
                                        </tr>

                                        <tr>
                                            <td>VIP 3</td>
                                            <td><img src="{{ asset('public/assets/img/trading-fee-pool-icon.png') }}"
                                                    class="img-fluid fee-pool-icon"
                                                    alt="fee page img" />&nbsp;&nbsp;WOO/USDT
                                            </td>
                                            <td>0.1000%</td>
                                            <td>45.00%</td>
                                            <td>0.0550%</td>
                                        </tr>
                                        <tr>
                                            <td>VIP 4</td>
                                            <td><img src="{{ asset('public/assets/img/trading-fee-pool-icon.png') }}"
                                                    class="img-fluid fee-pool-icon"
                                                    alt="fee page img" />&nbsp;&nbsp;WOO/USDT
                                            </td>
                                            <td>0.1000%</td>
                                            <td>45.00%</td>
                                            <td>0.0550%</td>
                                        </tr>

                                        <tr>
                                            <td>VIP 5</td>
                                            <td><img src="{{ asset('public/assets/img/trading-fee-pool-icon.png') }}"
                                                    class="img-fluid fee-pool-icon"
                                                    alt="fee page img" />&nbsp;&nbsp;WOO/USDT
                                            </td>
                                            <td>0.1000%</td>
                                            <td>45.00%</td>
                                            <td>0.0550%</td>
                                        </tr>
                                        <tr>
                                            <td>VIP 6</td>
                                            <td><img src="{{ asset('public/assets/img/trading-fee-pool-icon.png') }}"
                                                    class="img-fluid fee-pool-icon"
                                                    alt="fee page img" />&nbsp;&nbsp;WOO/USDT
                                            </td>
                                            <td>0.1000%</td>
                                            <td>45.00%</td>
                                            <td>0.0550%</td>
                                        </tr>

                                        <tr>
                                            <td>VIP 7</td>
                                            <td><img src="{{ asset('public/assets/img/trading-fee-pool-icon.png') }}"
                                                    class="img-fluid fee-pool-icon"
                                                    alt="fee page img" />&nbsp;&nbsp;WOO/USDT
                                            </td>
                                            <td>0.1000%</td>
                                            <td>45.00%</td>
                                            <td>0.0550%</td>
                                        </tr>
                                        <tr>
                                            <td>VIP 8</td>
                                            <td><img src="{{ asset('public/assets/img/trading-fee-pool-icon.png') }}"
                                                    class="img-fluid fee-pool-icon"
                                                    alt="fee page img" />&nbsp;&nbsp;WOO/USDT
                                            </td>
                                            <td>0.1000%</td>
                                            <td>45.00%</td>
                                            <td>0.0550%</td>
                                        </tr>

                                        <tr>
                                            <td>VIP 9</td>
                                            <td><img src="{{ asset('public/assets/img/trading-fee-pool-icon.png') }}"
                                                    class="img-fluid fee-pool-icon"
                                                    alt="fee page img" />&nbsp;&nbsp;WOO/USDT
                                            </td>
                                            <td>0.1000%</td>
                                            <td>45.00%</td>
                                            <td>0.0550%</td>
                                        </tr>
                                        <tr>
                                            <td>VIP 10</td>
                                            <td><img src="{{ asset('public/assets/img/trading-fee-pool-icon.png') }}"
                                                    class="img-fluid fee-pool-icon"
                                                    alt="fee page img" />&nbsp;&nbsp;WOO/USDT
                                            </td>
                                            <td>0.1000%</td>
                                            <td>45.00%</td>
                                            <td>0.0550%</td>
                                        </tr>

                                        <tr>
                                            <td>VIP 11</td>
                                            <td><img src="{{ asset('public/assets/img/trading-fee-pool-icon.png') }}"
                                                    class="img-fluid fee-pool-icon"
                                                    alt="fee page img" />&nbsp;&nbsp;WOO/USDT
                                            </td>
                                            <td>0.1000%</td>
                                            <td>45.00%</td>
                                            <td>0.0550%</td>
                                        </tr>
                                        <tr>
                                            <td>VIP 12</td>
                                            <td><img src="{{ asset('public/assets/img/trading-fee-pool-icon.png') }}"
                                                    class="img-fluid fee-pool-icon"
                                                    alt="fee page img" />&nbsp;&nbsp;WOO/USDT
                                            </td>
                                            <td>0.1000%</td>
                                            <td>45.00%</td>
                                            <td>0.0550%</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <div class="tab-pane fade show" id="fee-p2p" role="tabpanel" aria-labelledby="fee-p2p-tab">
                            <p>P2P transaction fees only apply to Maker. There is no fee for Taker <a
                                    class="text-warning">Learn more</a></p>
                            <p>Please log in to view your exclusive rates <a class="text-warning">Login</a></p>
                            <div class="col-md-2 col-lg-2 Fiat_search-box mt-2 mb-2">
                                <lable>Fiat </lable>
                                <select class="form-control select2">
                                    <option>Select</option>
                                    <option selected>&#x20B9 AED</option>
                                    <option>&#x20B9 AFN</option>
                                    <option>&#x20B9 AMD</option>
                                    <option>&#x20B9 ARS</option>
                                    <option>&#x20B9 AUD</option>
                                    <option>&#x20B9 AZN</option>

                                    <option>&#x20B9 BGN</option>
                                    <option>&#x20B9 BHD</option>
                                    <option>&#x20B9 BIF</option>
                                </select>
                            </div>
                            <div class="table-responsive">
                                <table class="table table-bordered table-hover table-striped fee-p2p-table">
                                    <thead class="bn-table-thead">
                                        <tr>
                                            <th>
                                                <div class="css-4cffwv">
                                                    <div data-bn-type="text" class="css-vurnku">Coin/Token</div>
                                                    <div class="css-1l871e7"><svg 
                                                            viewBox="0 0 24 24" fill="none" class="css-bgjo26">
                                                            <path fill-rule="evenodd" clip-rule="evenodd"
                                                                d="M12 21a9 9 0 100-18 9 9 0 000 18zM10.75 8.5V6h2.5v2.5h-2.5zm0 9.5v-7h2.5v7h-2.5z"
                                                                fill="currentColor"></path>
                                                        </svg></div>
                                                </div>
                                            </th>
                                            <th>
                                                <div class="css-4cffwv">
                                                    <div data-bn-type="text" class="css-wp1epn">Full name</div>
                                                    <div class="css-1l871e7"><svg 
                                                            viewBox="0 0 24 24" fill="none" class="css-bgjo26">
                                                            <path fill-rule="evenodd" clip-rule="evenodd"
                                                                d="M12 21a9 9 0 100-18 9 9 0 000 18zM10.75 8.5V6h2.5v2.5h-2.5zm0 9.5v-7h2.5v7h-2.5z"
                                                                fill="currentColor"></path>
                                                        </svg></div>
                                                </div>
                                            </th>
                                            <th>
                                                <div class="css-4cffwv">
                                                    <div data-bn-type="text" class="css-dyl994">Maker</div>
                                                    <div class="css-qkom0p">
                                                        <div class="css-vurnku"><svg 
                                                                viewBox="0 0 24 24" fill="none" class="css-bgjo26">
                                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                                    d="M12 21a9 9 0 100-18 9 9 0 000 18zM10.75 8.5V6h2.5v2.5h-2.5zm0 9.5v-7h2.5v7h-2.5z"
                                                                    fill="currentColor"></path>
                                                            </svg></div>
                                                    </div>
                                                </div>
                                            </th>
                                            <th>
                                                <div class="css-4cffwv">
                                                    <div data-bn-type="text" class="css-dyl994">Taker</div>
                                                    <div class="css-qkom0p">
                                                        <div class="css-vurnku"><svg 
                                                                viewBox="0 0 24 24" fill="none" class="css-bgjo26">
                                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                                    d="M12 21a9 9 0 100-18 9 9 0 000 18zM10.75 8.5V6h2.5v2.5h-2.5zm0 9.5v-7h2.5v7h-2.5z"
                                                                    fill="currentColor"></path>
                                                            </svg></div>
                                                    </div>
                                                </div>
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody class="bn-table-tbody">
                                        <tr data-row-key="0" class="bn-table-row bn-table-row-level-0">
                                            <td>
                                                <div class="fee-table-icon"><img
                                                        src="{{ asset('public/assets/img/fee-rate-icon-1.png') }}"
                                                        class="img-fluid" alt="fee page img" /> BNB</div>
                                            </td>
                                            <td>Wealth Mark Coin</td>
                                            <td>0.00%</td>
                                            <td>0.00%</td>
                                        </tr>
                                        <tr data-row-key="1" class="bn-table-row bn-table-row-level-0">
                                            <td>
                                                <div class="fee-table-icon"><img
                                                        src="{{ asset('public/assets/img/fee-rate-icon-2.png') }}"
                                                        class="img-fluid" alt="fee page img" />BTC</div>
                                            </td>
                                            <td>Bitcoin</td>
                                            <td>0.00%</td>
                                            <td>0.00%</td>
                                        </tr>
                                        <tr data-row-key="2" class="bn-table-row bn-table-row-level-0">
                                            <td>
                                                <div class="fee-table-icon"><img
                                                        src="{{ asset('public/assets/img/fee-rate-icon-3.png') }}"
                                                        class="img-fluid" alt="fee page img" />BUSD</div>
                                            </td>
                                            <td>Wealth Mark USD</td>
                                            <td>0.00%</td>
                                            <td>0.00%</td>
                                        </tr>
                                        <tr data-row-key="3" class="bn-table-row bn-table-row-level-0">
                                            <td>
                                                <div class="fee-table-icon"><img
                                                        src="{{ asset('public/assets/img/fee-rate-icon-4.png') }}"
                                                        class="img-fluid" alt="fee page img" /> DAI</div>
                                            </td>
                                            <td>DAI</td>
                                            <td>0.00%</td>
                                            <td>0.00%</td>
                                        </tr>
                                        <tr data-row-key="4" class="bn-table-row bn-table-row-level-0">
                                            <td>
                                                <div class="fee-table-icon"><img
                                                        src="{{ asset('public/assets/img/fee-rate-icon-5.png') }}"
                                                        class="img-fluid" alt="fee page img" /> ETH</div>
                                            </td>
                                            <td>Ethereum</td>
                                            <td>0.00%</td>
                                            <td>0.00%</td>
                                        </tr>
                                        <tr data-row-key="5" class="bn-table-row bn-table-row-level-0">
                                            <td>
                                                <div class="fee-table-icon"><img
                                                        src="{{ asset('public/assets/img/fee-rate-icon-6.png') }}"
                                                        class="img-fluid" alt="fee page img" />USDT</div>
                                            </td>
                                            <td>TetherUS</td>
                                            <td>0.00%</td>
                                            <td>0.00%</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>

                        </div>

                    </div>

                </div>
            </div>
            <div class="row">
                <div class="col-md-12 col-lg-12 col-xs-12 col-sm-12">
                    <ul class="fee-rates-list mt-2">
                        <li class="fee-list">“Taker” is an order that trades at a market price, “Maker” is an order that
                            trades at a limited price.Learn more</li>
                        <li class="fee-list">VIP trade volume levels are measured on the basis of the spot trading
                            volume, or whether the futures trading volume meets the standard (Futures trading volume
                            includes USDS-M futures and COIN-M futures).</li>
                        <li class="fee-list"> Refer friends to earn trading fees 20% kickback.Learn more</li>
                    </ul>
                </div>
            </div>
        </div>
    </section>

    <script>
    $('.select2').select2();
    </script>

    <script>
    $(document).ready(function() {
        $(".trading-fee-boxes").click(function() {
            $("#deposit-fee-block").hide();
            $("#fee-rate-widgets-section").show();
            $("#fee-tabs").show();
        });
        $(".deposit-withdrawal-boxes").click(function() {
            $("#fee-rate-widgets-section").hide();
            $("#fee-tabs").hide();
            $("#deposit-fee-block").show();
        });
    });
    </script>
    @include('template.country_language')
    @include('template.web_footer')
</body>

</html>