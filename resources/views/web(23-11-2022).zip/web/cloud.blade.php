<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <title>Wealth Mark | {{ Request::segment(2) }}</title>
    @include('template.web_css')
    <link rel='stylesheet' href="{{('../public/assets/css/deepak_custom.css') }}">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
   
    </style>
</head>

<body>
    @include('template.mobile_menu')
    @include('template.web_menu')
    <!-- <div class="text-center mt-3 bg-light-yellow">
        <a href="{{ url( app()->getLocale(), 'register') }}"> <span class="offer-text-head">
                Register now - Enjoy Welcome Rewards up to 1 BMK! ( for verified user)
            </span>
        </a>
    </div> -->

    <!-- first section -->
    <section class="lab d-flex justify-content-center align-content-center" id="cloud-section">
        <div class="container d-block">
            <div class="row">
                <div class="col-md-12">
                    <div class="banner-box">
                        <div class="container dark py-5 py-md-0 mt-5">
                            <div class="row justify-content-between col-mb-50">
                                <div class="col-lg-12 text-center pt-5">
                                    <h2 class="theme-blue-color fw-bold display-2 mb-0">Wealth Mark Cloud</h2>
                                    <p class="gradient-underline">Lorem ipsum dolor sit amet, consectetur
                                        adipiscing elit, sed do eiusmod tempor.</p>
                                    <span class="d-block">Leverage the superior security, technology, and liquidity
                                        solutions of Wealth Mark </span>
                                    <a href="#" class="btn btn-yellow shadow mt-3">Apply for Trial</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- second section -->
    <section class="why-build-us" id="why-build-us">
        <div class="container">
            <div class="row">
                <div class="sec-title text-left mb-5">
                    <span class="title">Know About</span>
                    <h2 class="heading-h2">Why Build with Wealth Mark Cloud? </h2>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="build-inner-block">
                        <img loading="lazy" src="{{ asset('public/assets/img/build-icon-1.png') }}" alt="Cloud "
                            class="why-chose-img">
                        <h4>Liquidity </h4>
                        <p>As the world’s leading digital asset exchange by real trading volume, Wealth Mark’s orders
                            account
                            for 50% market volume on the majority. </p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="build-inner-block">
                        <img loading="lazy" src="{{ asset('public/assets/img/build-icon-2.png') }}" alt="Cloud "
                            class="why-chose-img">
                        <h4>Liquidity </h4>
                        <p>As the world’s leading digital asset exchange by real trading volume, Wealth Mark’s orders
                            account
                            for 50% market volume on the majority. </p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="build-inner-block">
                        <img loading="lazy" src="{{ asset('public/assets/img/build-icon-3.png') }}" alt="Cloud "
                            class="why-chose-img">
                        <h4>Liquidity </h4>
                        <p>As the world’s leading digital asset exchange by real trading volume, Wealth Mark’s orders
                            account
                            for 50% market volume on the majority. </p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="build-inner-block">
                        <img loading="lazy" src="{{ asset('public/assets/img/build-icon-1.png') }}" alt="Cloud "
                            class="why-chose-img">
                        <h4>Liquidity </h4>
                        <p>As the world’s leading digital asset exchange by real trading volume, Wealth Mark’s orders
                            account
                            for 50% market volume on the majority. </p>
                    </div>
                </div>
            </div>

        </div>
    </section>

    <section class="cloud-carousel-slider">
        <div class="container" id="featureContainer">
            <div class="row">
                <div class="sec-title text-left mb-5">
                    <span class="title">Know About</span>
                    <h2 class="heading-h2">Our Solution</h2>
                </div>
            </div>

            <div class="row mx-auto my-auto justify-content-center">
                <div id="featureCarousel" class="carousel slide" data-bs-ride="carousel">
                    <div class="float-end pe-md-4 mb-4">
                        <a class="indicator" href="#featureCarousel" role="button" data-bs-slide="prev">
                            <span> &#8249;</span>
                        </a> &nbsp;&nbsp;
                        <a class="w-aut indicator" href="#featureCarousel" role="button" data-bs-slide="next">
                            <span> &#8250;</span>
                        </a>
                    </div>
                    <div class="carousel-inner" role="listbox">
                        <div class="carousel-item active">
                            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                                <div class="card">
                                    <div class="card-img">
                                        <img loading="lazy"
                                            src="{{ asset('public/assets/img/cloud-slider-img-1.png') }}" alt="Cloud "
                                            class="img-fluid">
                                    </div>
                                    <div class="card-img-overlays text-center">Wealth Mark Solutions</div>
                                </div>
                            </div>
                        </div>
                        <div class="carousel-item">
                            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                                <div class="card">
                                    <div class="card-img">
                                        <img loading="lazy"
                                            src="{{ asset('public/assets/img/cloud-slider-img-2.png') }}" alt="Cloud "
                                            class="img-fluid">
                                    </div>
                                    <div class="card-img-overlays text-center">Wealth Mark Solutions</div>
                                </div>
                            </div>
                        </div>
                        <div class="carousel-item">
                            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                                <div class="card">
                                    <div class="card-img">
                                        <img loading="lazy"
                                            src="{{ asset('public/assets/img/cloud-slider-img-3.png') }}" alt="Cloud "
                                            class="img-fluid">
                                    </div>
                                    <div class="card-img-overlays text-center">Wealth Mark Solutions</div>
                                </div>
                            </div>
                        </div>
                        <div class="carousel-item">
                            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                                <div class="card">
                                    <div class="card-img">
                                        <img loading="lazy"
                                            src="{{ asset('public/assets/img/cloud-slider-img-6.png') }}" alt="Cloud "
                                            class="img-fluid">
                                    </div>
                                    <div class="card-img-overlays text-center">Wealth Mark Solutions</div>
                                </div>
                            </div>
                        </div>
                        <div class="carousel-item">
                            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                                <div class="card">
                                    <div class="card-img">
                                        <img loading="lazy"
                                            src="{{ asset('public/assets/img/cloud-slider-img-4.png') }}" alt="Cloud "
                                            class="img-fluid">
                                    </div>
                                    <div class="card-img-overlays text-center">Wealth Mark Solutions</div>
                                </div>
                            </div>
                        </div>
                        <div class="carousel-item">
                            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                                <div class="card">
                                    <div class="card-img">
                                        <img loading="lazy"
                                            src="{{ asset('public/assets/img/cloud-slider-img-5.png') }}" alt="Cloud "
                                            class="img-fluid">
                                    </div>
                                    <div class="card-img-overlays text-center">Wealth Mark Solutions</div>
                                </div>
                            </div>
                        </div>
                        <div class="carousel-item">
                            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                                <div class="card">
                                    <div class="card-img">
                                        <img loading="lazy"
                                            src="{{ asset('public/assets/img/cloud-slider-img-6.png') }}" alt="Cloud "
                                            class="img-fluid">
                                    </div>
                                    <div class="card-img-overlays text-center">Wealth Mark Solutions</div>
                                </div>
                            </div>
                        </div>
                        <div class="carousel-item">
                            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                                <div class="card">
                                    <div class="card-img">
                                        <img loading="lazy"
                                            src="{{ asset('public/assets/img/cloud-slider-img-7.png') }}" alt="Cloud "
                                            class="img-fluid">
                                    </div>
                                    <div class="card-img-overlays text-center">Wealth Mark Solutions</div>
                                </div>
                            </div>
                        </div>
                        <div class="carousel-item">
                            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                                <div class="card">
                                    <div class="card-img">
                                        <img loading="lazy"
                                            src="{{ asset('public/assets/img/cloud-slider-img-8.png') }}" alt="Cloud "
                                            class="img-fluid">
                                    </div>
                                    <div class="card-img-overlays text-center">Wealth Mark Solutions</div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>


    <section class="get-started" id="cloud-customers">
        <div class="container">
            <div class="row">
                <div class="sec-title text-left mb-5">
                    <span class="title">Know About</span>
                    <h2 class="heading-h2">Our Customers</h2>
                </div>
            </div>
            </p>
            <div class="row">
                <div class="col-md-12">
                    <img loading="lazy" src="{{ asset('public/assets/img/our-customers.jpg') }}" alt="Cloud "
                        class="our-customer img-fluid">
                </div>

            </div>
    </section>


    <!-- third section -->
    <section class="get-started" id="get-started">
        <div class="container">
            <div class="row">
                <div class="sec-title text-left mb-5">
                    <span class="title">Know About</span>
                    <h2 class="heading-h2">Our Steps</h2>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="steps-inner-box">
                        <div class="show-number">
                            1
                        </div>
                        <h4>Consultation </h4>
                        <p>As the world’s leading digital asset exchange by real trading volume, Wealth Mark’s orders
                            account
                            for >50% market volume on the majority of listings.
                            account
                            for >50% market volume on the majority. </p>
                    </div>
                </div>

                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="steps-inner-box">
                        <div class="show-number">
                            2
                        </div>
                        <h4>Preparation </h4>
                        <p>As the world’s leading digital asset exchange by real trading volume, Wealth Mark’s orders
                            account
                            for >50% market volume on the majority of listings.
                            account
                            for >50% market volume on the majority. </p>
                    </div>
                </div>

                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="steps-inner-box">
                        <div class="show-number">
                            3
                        </div>
                        <h4>Deployment </h4>
                        <p>As the world’s leading digital asset exchange by real trading volume, Wealth Mark’s orders
                            account
                            for >50% market volume on the majority of listings.
                            account
                            for >50% market volume on the majority. </p>
                    </div>
                </div>

                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="steps-inner-box">
                        <div class="show-number">
                            4
                        </div>
                        <h4>Launch </h4>
                        <p>As the world’s leading digital asset exchange by real trading volume, Wealth Mark’s orders
                            account
                            for >50% market volume on the majority of listings.
                            account
                            for >50% market volume on the majority. </p>
                    </div>
                </div>

            </div>

        </div>
    </section>


    <!-- sixth section -->
    <!-- our collaboration with clients -->

    <section id="apply-now-section" class="apply-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12 d-block justify-content-center align-item-center">
                    <h3>Apply for Wealth Mark Labs</h3>
                    <span>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
                        labore et dolore magna aliqua.</span>
                    <p class="email-text">Email us at wealthmark@gmail.com for inquiries and supplementary materials.
                    </p>
                    <a href="#" class="btn btn-yellow shadow mt-3">APPLY NOW</a>
                </div>
            </div>
        </div>
    </section>


    @include('template.country_language')
    @include('template.web_footer')
    <script src="https://code.jquery.com/jquery-3.6.0.slim.min.js"></script>

    <script>
    let items = document.querySelectorAll('#featureContainer .carousel .carousel-item');
    items.forEach((el) => {
        const minPerSlide = 4
        let next = el.nextElementSibling
        for (var i = 1; i < minPerSlide; i++) {
            if (!next) {
                // wrap carousel by using first child
                next = items[0]
            }
            let cloneChild = next.cloneNode(true)
            el.appendChild(cloneChild.children[0])
            next = next.nextElementSibling
        }
    })
    $(document).ready(function() {
        $('#featureCarousel').carousel({
            interval: false
        });
        $('#featureCarousel').carousel('pause');
    });
    </script>
    
</body>

</html>