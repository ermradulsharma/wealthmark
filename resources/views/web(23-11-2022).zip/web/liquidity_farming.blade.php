  <!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
   <head>
      <meta charset="utf-8">
      <meta content="width=device-width, initial-scale=1.0" name="viewport">
      <title>Wealth Mark | Create Entity Account</title>
  @include('template.web_css')
   
  
 <style>
     #header{
         background:white;
         
     }


</style>
  
  
   </head>
   
 <body class="bg-white">
     
     @include('template.mobile_menu')
        @include('template.web_menu')
    <div class="Liquid_Swap_top pt-5 mb-0 pb-0">
     <div class="container">
         <div class="row align-items-center justify-content-center" >
             <div class="col-md-8 col-sm-10 col-xs-12">
                <div class="sec-title text-center">
                            <span class="title">Welcome to Wealthmark</span>
                            <h2 class="heading-h2 text-white">Wealthmark Liquid Swap </h2>
                            <div class="text text-center text-white">Trade Instantly & Pool Tokens to Earn Rewards</div>
                        </div>
                 
             </div>
             
         </div>
         
         </div>
     
 </div>




 <div class="Liquid_Swap_bg-overlay">
   <div class="container">
     <div class="tab-pills-div-top">
       <div class="tab-pills-div-top-left scrollbar-style">
         <a href="{{ url( app()->getLocale(), 'wm-pool') }}" class="lp-link-top">
           <div class="lp-link-top-block">
             <div class="lp-link-top-block-inner">
               <div class="lp-link-top-txt">Overview</div>
               </div>
              </div>
         </a>
         <a href="{{ url( app()->getLocale(), 'liquidity-farming') }}" class="lp-link-top">
           <div class="  active-tab lp-link-top-active">
             <div class="lp-link-top-block-inner">
               <div class="lp-link-top-txt">Liquidity</div>
                </div>
            </div>
         </a>
         <a href="{{ url( app()->getLocale(), 'swap-farming') }}" class="lp-link-top">
           <div class=" lp-link-top-block ">
             <div class="lp-link-top-block-inner">
                <div class="lp-link-top-txt">Swap</div>
                 <div class="lp-reward">
                   <div class="lp-reward-txt">Rewards</div>
                 </div>
               </div>
            </div>
         </a>
         <div class="lp-link-top-block">
           <div class="lp-link-top-block-inner">
             <div class="lp-link-top-txt">History</div>
           </div>
          </div>
       </div>
       <div class="tab-pills-div-top-right">
         <button type="button" class=" tutorial-btn">
           <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="tutorial-btn-video">
             <path d="M12 3.35c-4.8 0-8.8 3.9-8.8 8.8 0 4.8 3.9 8.8 8.8 8.8s8.8-3.9 8.8-8.8c0-4.8-4-8.8-8.8-8.8zm0 15.6c-3.7 0-6.8-3-6.8-6.8 0-3.7 3-6.8 6.8-6.8s6.8 3 6.8 6.8c0 3.7-3.1 6.8-6.8 6.8z" fill="currentColor"></path>
             <path d="M16.5 12.15l-6.8-3.9v7.8l6.8-3.9z" fill="currentColor"></path>
           </svg>
           <div class="tutorial-btn-txt">Tutorial</div>
         </button>
         <a href="#" class="tab-pills-div-top-right-txt">FAQ</a>
       </div>
     </div>
   </div>
 </div>
   
 


 <section style="background:#F5F5F5">
   <div class="container">
     <div class="row">
       <div class="outer-max-729px">
         <div class="rwrd-div-outer">
           <div class="rwrd-div-inner">
             <div class="rwrd-div">
               <div class="rwrd-title">Introducing the Newest Liquidity Pool</div>
              
             </div>
             <div class="rwrd-subtitle"> IOTX/USDT</div>
           </div>
           <button type="button" class=" claim-reward">Add Liquidity Now</button>
         </div>
       </div>
       <div class="coin-swap">
         <div class="coin-swap-left">
           <div class="coin-swap-left-div1">
       
 <h3 class="title">Liquid Swap</h3>
  <div class="d-flex">
    <div class="lf-change-optn">
      <svg viewBox="0 0 24 24" fill="none" class="lf-change-optn-icon" data-bs-toggle="tooltip" data-bs-placement="top" title="" data-bs-original-title="Refresh Pool Data">
        <path d="M20.7 11.925c0 2.1-.8 4.1-2.3 5.6-1.6 1.5-3.6 2.3-5.6 2.3-2 0-4-.8-5.6-2.3l-1.3-1.3 1.4-1.4 1.3 1.3c2.3 2.3 6 2.3 8.3 0 1.1-1.1 1.7-2.6 1.7-4.2s-.6-3.1-1.7-4.2c-2.3-2.3-6-2.3-8.3 0l-1.1 1.2h3.3v2H4v-6.8h2v3.4l1.2-1.2c3.1-3.1 8.1-3.1 11.2 0 1.5 1.5 2.3 3.5 2.3 5.6z" fill="currentColor"></path>
      </svg>
      
    </div>
  
    <div class="lf-change-optn">
      <svg viewBox="0 0 24 24" fill="none" class="lf-change-optn-icon">
        <path d="M15.3 16.125l-3.6-3.7v-5.2h2v4.4l3.1 3-1.5 1.5z" fill="currentColor"></path>
        <path d="M19.1 18.425c-1.7 1.7-3.9 2.6-6.2 2.6v-2c1.8 0 3.5-.8 4.8-2 2.7-2.7 2.7-7.2 0-9.9s-7.2-2.7-9.9 0-2.7 6.9-.2 9.7l1 1c-.1-.6-.2-1.2-.2-1.9v-2.3h2v7.4H3v-2h2.3c.6 0 1.2.1 1.8.2l-1-1c-3.3-3.6-3.2-9.1.2-12.6 3.5-3.5 9.2-3.5 12.7 0s3.6 9.3.1 12.8z" fill="currentColor"></path>
      </svg>
    </div>
    <div class="lf-change-optn">
      <svg viewBox="0 0 24 24" fill="none" class="lf-change-optn-icon" data-bs-toggle="tooltip" data-bs-placement="top" title="" data-bs-original-title="You can become a liquidity provider for this pair by adding assets in the liquid asset pool. As a liquidity provider you can enjoy the transaction fee income of users in the pool. You can remove your portion at any time. If you add one asset, a transaction fee will be charged.">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M12 4c4.411 0 8 3.589 8 8s-3.589 8-8 8-8-3.589-8-8 3.589-8 8-8zm0-2C6.477 2 2 6.477 2 12s4.477 10 10 10 10-4.477 10-10S17.523 2 12 2zm.997 9.004h-2.009v6h2.009v-6zm-2.009-4h2.009v2.009h-2.009v-2.01z" fill="currentColor"></path>
      </svg>
    </div>
   
  </div>

            
           </div>
          
          
          
           <div class="coin-select-main-div">
             <div class="coin-select">
               <div class=" coin-swap-from">
                 <input type="input" value="" placeholder="9.99900001-2499.75" class="search-box coin-swap-from-input">
                 <div class="lf-suffix">
                   <div class="coin-swap-from-status">
                     <div class="coin-swap-from-status-mid">
                       <div class=" coin-swap-from-status-last">
                         <input type="input" value="USDT" class="wm-lf-input coin-select-drpdn-inner-1-input">
                         <div class="lf-suffix">
                           <div class="coin-select-drpdn-icn">
                           
                             <i class="bi bi-caret-down-fill coin-select-drpdn-icn-1"></i>
                           </div>
                         </div>
                       </div>
                       <div class="wm-lf-value coin-drpdn-active">
                         <div class="coin-drpdn-active-inner">
                           <img src="{{ asset('public/assets/img/2b5c7d80-7bcd-4cfb-8bd9-d1760a752afc.png') }}" class="coin-drpdn-active-img">
                           <div class="coin-drpdn-active-lbl">USDT</div>
                         </div>
                       </div>
                 
                     </div>
                   </div>
                 </div>
                 <label class="lf-lbl lf-lbl-2">
                   <div class="lf-lbl-inner">Select Pool 
                   </div>
                 </label>
               </div>
             </div>
             
             
             <div class="lf-add-coin-div">
  <div class="lf-add-coin-div-active">
    <label class="lf-add-coin-lbl">
  <svg viewBox="0 0 16 16" fill="none" class="radion-svg">
    <circle cx="8" cy="8" r="7.5" stroke="currentColor"></circle>
    <circle cx="8" cy="8" r="4" fill="currentColor"></circle>
  </svg>
  <div class="lf-add-coin-lbl-inner">
    <div class="lf-add-coin-lbl-title">Add WOO + USDT <div class="lf-add-coin-lbl-title-tool">0 Fee</div>
    </div>
    <input hidden="" type="radio" name="modes" value="0" checked style="clip: rect(0px, 0px, 0px, 0px); position: absolute;">
  </div>
</label>
  </div>
 
  <div class="lf-add-coin-div-inactive">
    <label class="lf-add-coin-lbl">
      <svg viewBox="0 0 16 16" fill="none" class="radion-svg">
        <circle cx="8" cy="8" r="7.5" stroke="currentColor"></circle>
      </svg>
      <div class="lf-add-coin-lbl-inner">
        <div class="lf-add-coin-lbl-title" data-bs-toggle="tooltip" data-bs-placement="right" title="" data-bs-original-title="One coin staking will swap part of the portion value into another coin, then adding 2 coins. Swap transaction and slippage fees will affect your portion yield.">
         
          Add WOO
        </div>
        <input hidden="" type="radio"  name="modes" value="2" style="clip: rect(0px, 0px, 0px, 0px); position: absolute;">
      </div>
    </label>
  </div>
  <div class="lf-add-coin-div-inactive">
    <label class="lf-add-coin-lbl">
      <svg viewBox="0 0 16 16" fill="none" class="radion-svg">
        <circle cx="8" cy="8" r="7.5" stroke="currentColor"></circle>
      </svg>
      <div class="lf-add-coin-lbl-inner">
        <div class="lf-add-coin-lbl-title" data-bs-toggle="tooltip" data-bs-placement="right" title="" data-bs-original-title="One coin staking will swap part of the portion value into another coin, then adding 2 coins. Swap transaction and slippage fees will affect your portion yield.">
         
          Add USDT
        </div>
        <input hidden="" type="radio"  name="modes" value="2" style="clip: rect(0px, 0px, 0px, 0px); position: absolute;">
      </div>
    </label>
  </div>
  
</div>

             
             
             
             
             
             <div class="coin-select">
               <div class=" coin-swap-from">
                 <input type="input" value="" placeholder="9.99900001-2499.75" class="search-box coin-swap-from-input">
                 <div class="lf-suffix">
                   <div class="coin-swap-from-status">
                     <div class="coin-swap-from-status-mid">
                       <div class=" coin-swap-from-status-last">
                         <input type="input" value="USDT" class="wm-lf-input coin-select-drpdn-inner-1-input">
                         <div class="lf-suffix">
                           <div class="coin-select-drpdn-icn">
                           
                             <i class="bi bi-caret-down-fill coin-select-drpdn-icn-1"></i>
                           </div>
                         </div>
                       </div>
                       <div class="wm-lf-value coin-drpdn-active">
                         <div class="coin-drpdn-active-inner">
                           <img src="{{ asset('public/assets/img/2b5c7d80-7bcd-4cfb-8bd9-d1760a752afc.png') }}" class="coin-drpdn-active-img">
                           <div class="coin-drpdn-active-lbl">USDT</div>
                         </div>
                       </div>
                 
                     </div>
                   </div>
                 </div>
                 <label class="lf-lbl lf-lbl-2">
                   <div class="lf-lbl-inner">From <span class="lf-lbl-status">Available
                       : <span class="lf-lbl-status--">&nbsp;
                         --
                        &nbsp;
                       </span>USDT
                     </span>
                   </div>
                 </label>
               </div>
             </div>
            
         
             <div class="lf-lbl-txt">The ultimate price and output is determined by the amount of tokens in the pool at the time of your swap.</div>
           
           
           
           
           
           <div class="mt-4">
  <div class="smmry-txt">Amount Limit</div>
  <div class="d-flex align-items-center justify-content-between mt-2">
    <div class="d-flex align-items-center justify-content-between">
      <div class="lf-lbl-status me-3">Minimum:</div>
      <div class="max-min-value">74.46016382 WOO</div>
    </div>
    <div class="d-flex align-items-center justify-content-between">
      <div class="lf-lbl-status me-3">Maximum:</div>
      <div class="max-min-value">18615 WOO</div>
    </div>
  </div>
</div>
           
           
           
           </div>
         </div>
         <div class="coin-swap-right">
           <div class="">
             <div class="smmry-div">
               <div class="smmry-txt">Summary</div>
              
             </div>
             <div class="lf-status">
               <div class="lf-price-div">
                 
                   <div class="lf-price-lbl">Current pool size</div>
               
                 <span class="lf-currnt-status">
                   <div class="lf-status">
                     <div class="">
                       <div class="d-flex flex-column">
                         <div class=""> 3,422,953 WOO </div>
                         <div>+</div>
                         <div class=""> 459,946 USDT </div>
                       </div>
                     </div>
                   </div>
                 </span>
               </div>
               <div class="lf-price-div">
                
                   <div class="lf-price-lbl">Total yield</div>
               
                <span class="lf-currnt-status">
                     <div class="lf-currnt-status-green">0.00299645 wm</div>
                   </span>
               </div>
               <div class="emi-cal-div">
                  <i class="bi bi-calculator emi-cal-icon"></i>
                   <div class="emi-cal-txt">Impermanent Loss Calculator</div>
                </div>
              </div>
           </div>
           
           <div class="mt-3">
                 <div class="lf-login-con-div">
              <div class="lf-login-con-input-div">
                <input type="checkbox" id="agree_Liquid_Swap_Terms">
               
              </div>
              <span>I have read, understand, and agree to <a href="#" target="_blank"  class="lf-filter-view-all d-block m-0">Binance Liquid Swap Terms of Use.</a>
              </span>
            </div>
               <button type="button"  class=" lf-btn-login">Log In to Add</button>
           </div>
           
         </div>
       </div>
     </div>
   </div>
 </section>
   
  

<section class="swap-farming-learn-more bg-light-blue">
  <div class="container">
      
    <h1  class="title mb-4">Learn More</h1>
    
    <div class="row">
      <div class="col-md-4 col-sm-4">
          <div class="sf-block">
        <a  href="#" target="_blank">
          <img src="{{ asset('public/assets/img/sawp-academy-learn.svg') }}">
          <h3  class="title mt-3">Academy</h3>
          <div  class="text">Learn how to add liquidity to become a liquidity provider and earn high yield farming rewards.</div>
        </a>
        </div>
      </div>
      <div class="col-md-4 col-sm-4">
          <div class="sf-block">
        <a  href="#" target="_blank">
          <img src="{{ asset('public/assets/img/sawp-low-fees.svg') }}">
          <h3  class="title mt-3">Swap Fees</h3>
          
          <div  class="text">Low fees and high rewards. Swap to earn more wm.</div>
        </a>
        </div>
      </div>
      <div class="col-md-4 col-sm-4">
              <div class="sf-block">
        <a  href="#" target="_blank">
        <img src="{{ asset('public/assets/img/sawp-tutorial.svg') }}">
        <h3  class="title mt-3">Tutorials</h3>
        <div  class="text">Watch the video tutorials to learn more about the product.</div>
     </a>
     </div>
      </div>
    </div>
  </div>
</section>






  @include('template.country_language')
    @include('template.web_footer') 
    
    
    
<!-- Modal -->
<div class="modal fade liquidity-farming" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel">Risk warning</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="border p-2">
            <div class="text">
                Adding liquidity into a liquid pool and becoming a liquidity provider is not risk-free. When the market price of tokens fluctuates greatly, the staking income may be lower than the income of ordinary holding of the tokens, and losses may even occur. For more details about the principle of Liquidity, please refer to
            <span class="yellow-text">    Binance Liquid Swap Terms of Use </span>.
            </div>
        </div>
        <div class="agree-box">
            <div class="agree-check-box">
           <input type="checkbox" id="liquidity-farming-agree">
           </div>
           <div class="text">
               I confirm that I have read, understand, and agree to the Terms of Use and Conditions.
           </div>
        </div>
        
      </div>
      <div class="modal-footer">
      
        <button type="button" id="liquidity-farming-btn" class="btn btn-yellow inactive">Continue</button>
      </div>
    </div>
  </div>
</div>

 
  <script>
  $(document).ready(function(){
        $("#staticBackdrop").modal('show');
    });

$('#liquidity-farming-agree').change(function(){
    if($(this).is(":checked")) {
        $('#liquidity-farming-btn').removeClass('inactive');
    } else {
        $('#liquidity-farming-btn').addClass('inactive');
    }
});
 </script>

  
    </body>
</html>