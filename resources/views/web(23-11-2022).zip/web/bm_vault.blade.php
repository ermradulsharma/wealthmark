  <!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
   <head>
      <meta charset="utf-8">
      <meta content="width=device-width, initial-scale=1.0" name="viewport">
      <title>Wealth Mark | Create Entity Account</title>
  @include('template.web_css')
      
  
 <style>
     #header{
         background:white;
         
     }
     
  </style>
   </head>
   
 <body class="bg-white">
     
     @include('template.mobile_menu')
        @include('template.web_menu')
    
    
      <section  class="breadcrumbs shadow community-top">
          <div class="container-fluid mt-3">
              <div class="row">
                 <div class="col-lg-4 offset-lg-1 d-flex flex-column justify-content-center pt-lg-0 order-2 order-lg-1" data-aos="fade-up" data-aos-delay="200">
                 <h3 class="top-heading">Wealthmark Vault </h3>
                 <p class="top-p">One-click to earn multi-benefits with Wealthmark</p>
                
                 </div>
                 <div class="col-lg-5 offset-lg-1 order-1 order-lg-2 hero-img" data-aos="zoom-in" data-aos-delay="200">
                    <img src="{{ asset('public/assets/img/graphic-1-01.svg') }}" class="img-fluid animated" alt="" style="width:100%">
                 </div>
              </div>
           </div>
      </section>
      
      
      
      <div class="ecosystemt-content-block">
  <div class="eco-first-block-top">
    <div class="eco-first-block-left">
      <h3>Current Est. APR</h3>
      <div  class="green-text-large">0.35%</div>
    </div>
    <div class="eco-first-block-right">
      <span  class="text">BNB Vault combines rewards from Simple Earn and Launchpool and offers competitive returns.</span>
      <div cursor="pointer" class="video-div-eco-desk">
        <div>Tutorial</div>
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="svg-video">
          <path d="M12 3.35c-4.8 0-8.8 3.9-8.8 8.8 0 4.8 3.9 8.8 8.8 8.8s8.8-3.9 8.8-8.8c0-4.8-4-8.8-8.8-8.8zm0 15.6c-3.7 0-6.8-3-6.8-6.8 0-3.7 3-6.8 6.8-6.8s6.8 3 6.8 6.8c0 3.7-3.1 6.8-6.8 6.8z" fill="currentColor"></path>
          <path d="M16.5 12.15l-6.8-3.9v7.8l6.8-3.9z" fill="currentColor"></path>
        </svg>
      </div>
    </div>
  </div>
  <div class="eco-sys-mob-first">
    <div class="text">BNB Vault combines rewards from Simple Earn and Launchpool and offers competitive returns.</div>
    <div class="amt-box-mob">
      <span  class="amt-title-mob">Current Est. APR</span>
      <div  class="green-text-large-mob">0.35%</div>
    </div>
    <div class="video-div-eco">
      <div cursor="pointer" class="tutorial">
        <div   class="">Tutorial</div>
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="svg-video">
          <path d="M12 3.35c-4.8 0-8.8 3.9-8.8 8.8 0 4.8 3.9 8.8 8.8 8.8s8.8-3.9 8.8-8.8c0-4.8-4-8.8-8.8-8.8zm0 15.6c-3.7 0-6.8-3-6.8-6.8 0-3.7 3-6.8 6.8-6.8s6.8 3 6.8 6.8c0 3.7-3.1 6.8-6.8 6.8z" fill="currentColor"></path>
          <path d="M16.5 12.15l-6.8-3.9v7.8l6.8-3.9z" fill="currentColor"></path>
        </svg>
      </div>
    </div>
  </div>
  <div class="ecosystemt-content-main">
    <div class="ecosystemt-content-main-left">
      <h3>My Shares</h3>
      <div class="ecosystem-my-shares">
        <img src="{{ asset('public/assets/img/vault-coin-light.svg') }}" class="ecosystemt-content-main-left-img">
        <div class="btn-check-inner">
          <div  class="symbol-dash">-</div>
        </div>
        <div  class="eco-title">Staked Wealthmark</div>
      </div>
      <div class="ecosystemt-btn-div-inner">
        <button type="button" class="btn-yellow w-100 border-0">Login</button>
      </div>
      <a  target="_blank" href="#" class="a-btn-gray">
        <button type="button"  class=" btn-gray">Buy Wealthmark to Stake 
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="svg-chevron-right">
            <path d="M14.65 12.24l-4.24 4.24L9 15.06l2.82-2.82L9 9.42 10.41 8l4.24 4.24z" fill="currentColor"></path>
          </svg>
        </button>
      </a>
      <a  target="_blank" class="a-btn-gray" href="#">
        <button type="button"  class=" btn-gray">Join Launchpad <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="svg-chevron-right">
            <path d="M14.65 12.24l-4.24 4.24L9 15.06l2.82-2.82L9 9.42 10.41 8l4.24 4.24z" fill="currentColor"></path>
          </svg>
        </button>
      </a>
    </div>
    <div class="my-reward-sec">
      <div class="my-reward-sec-first">
        <h3>My Rewards</h3>
        <a  href="#" class="#">Distribution History</a>
      </div>
      <div  class="text">All Rewards will be distributed to spot wallet.</div>
      <div class="my-reward-inner-block">
        <div  class="my-reward-inner-block-left">
          <h6>Flexible Rewards</h6>
          <div  class="amt-title-desk">Est. APR
            <!-- -->
            <!-- -->0.35%
          </div>
        </div>
        <div class="my-reward-inner-block-mid">
          <div class="reward-div-main-outer">
            <div class="reward-div-main">
              <div class="d-flex align-items-center text-dark">
                <img class="reward-coin-img" src="{{ asset('public/assets/img/94863af2-c980-42cf-a139-7b9f462a36c2.png') }}">
                <div  class="reward-coin-name">BNB</div>
              </div>
            </div>
            <div  class="reward-number">0</div>
          </div>
        </div>
        <div class="my-reward-inner-block-right">
          <div class="div1">
            <div  class="amt-subtitle">Est. APR</div>
            <div  class="green-text-sm">0.35%</div>
          </div>
        </div>
      </div>
      <div class="my-reward-inner-block">
        <div  class="my-reward-inner-block-left">
          <h6>Launchpool Rewards</h6>
          <div  class="amt-title-desk">Est. APR
            <!-- -->
            <!-- -->0%
          </div>
        </div>
        <div class="my-reward-inner-block-mid">
          <div class="crnt-reward-div">
            <div  class="crnt-reward">Current Rewards</div>
            <div  class="symbol-dash">-</div>
          </div>
        </div>
        <div class="my-reward-inner-block-right">
          <div class="div1">
            <div  class="amt-subtitle">Yesterday’s APR</div>
            <div  class="green-text-sm">0%</div>
          </div>
        </div>
      </div>
      <div class="my-reward-inner-block">
        <div  class="my-reward-inner-block-left">
         <h6>Other Rewards</h6>
          <div  class="amt-title-desk">Est. APR
            <!-- -->
            <!-- -->0%
          </div>
        </div>
        <div class="my-reward-inner-block-mid">
          <div class="crnt-reward-div">
            <div  class="crnt-reward">Current Rewards</div>
            <div  class="symbol-dash">-</div>
          </div>
        </div>
        <div class="my-reward-inner-block-right">
          <div class="div1">
            <div  class="amt-subtitle">Est. APR</div>
            <div  class="green-text-sm">0%</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>





<div class="ecosystemt-main">
  <div class="ecosystemt-inner">
    <div class="ecosystemt-content-block">
      <div class="ecosystemt-contentinner">
        <img src="{{ asset('public/assets/img/vault-bg-circle.svg') }}" class="ecosystemt-img-left">
        <div class="top-img-box">
          <img src="{{ asset('public/assets/img/vault-bg-circle.svg') }}" class="ecosystemt-img">
          <div  class="top-img-box-subtitle">What is Wealthmark</div>
        </div>
        <div class="eco-content-left">
          <h3> Wealthmark Ecosystem</h3>
          <div  class="text">As the native coin of Wealthmark Chain, Wealthmark has multiple use cases: Fueling transactions on the Chain, paying for transaction fees on Wealthmark Exchange, making in-store payments, and many more.</div>
        </div>
      </div>
    </div>
  </div>
  <div class="ecosystemt-btn-div">
    <div class="ecosystemt-btn-div-inner">
      <div  class="eco-btns-inner">
        <div class="eco-btns-inner-main">
          <div class="eco-btns-border"></div>
          <div  class="eco-btns-text">Buy Wealthmark</div>
        </div>
      </div>
      <div  class="eco-btns">
        <div class="eco-btns-inner-main">
          <div class="eco-btns-border"></div>
          <div  class="eco-btns-text">Store Wealthmark</div>
        </div>
      </div>
      <div  class="eco-btns">
        <div class="eco-btns-inner-main">
          <div class="eco-btns-border"></div>
          <div  class="eco-btns-text">Use Wealthmark</div>
        </div>
      </div>
      <div class="eco-btns">
        <div class="eco-btns-inner-main">
          <div class="eco-btns-border"></div>
          <div  class="eco-btns-text">Burn Wealthmark</div>
        </div>
      </div>
    </div>
  </div>
  <div class="buy-section">
    <div class="buy-section-bg">
      <div class="buy-section-inner">
        <div class="buy-section-top">
          <div class="buy-section-top-left">
            <h3>Buy Wealthmark</h3>
            <div class="text">Buying Wealthmark is easy. Check the list below to find the place that suits you best!</div>
          </div>
          <img src="{{ asset('public/assets/img/vault-buy-wm-right.svg') }}" class="line-img">
        </div>
        <div class="our-partner-main">
          <div class="our-partner-block">
            <div class="our-partner-inner">
              <div class="our-partner-inner-div">
                <img src="{{ asset('public/assets/img/vault-spendlogo.svg') }}" class="partner-logo">
                <div  class="our-partner-inner-text">Buy &amp; Sell Wealthmark with bank account</div>
              
              </div>
              <a  href="#" target="_blank" class="a-hover-check">
                <button type="button" class="btn-check-hover">
                  <div class="btn-check-inner">Check
                    <!-- -->
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="svg-right-arrow">
                      <path d="M13.5 19l-1.4-1.4 5.1-5.1H3v-2h14.2l-5.1-5.1L13.5 4l7.5 7.5-7.5 7.5z" fill="currentColor"></path>
                    </svg>
                  </div>
                </button>
              </a>
            </div>
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="none" class="svg-plus-1">
              <path d="M2 7.25h12v1.5H2v-1.5z" fill="currentColor"></path>
              <path d="M8.75 2v12h-1.5V2h1.5z" fill="currentColor"></path>
            </svg>
          </div>
          <div class="our-partner-block">
            <div class="our-partner-inner">
              <div class="our-partner-inner-div">
                <img src="{{ asset('public/assets/img/vault-coinflip.svg') }} " class="partner-logo">
                <div  class="our-partner-inner-text">Buy Wealthmark with ATMs</div>
              
              </div>
              <a  href="#" target="_blank" class="a-hover-check">
                <button type="button" class="btn-check-hover">
                  <div class="btn-check-inner">Check
                    <!-- -->
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="svg-right-arrow">
                      <path d="M13.5 19l-1.4-1.4 5.1-5.1H3v-2h14.2l-5.1-5.1L13.5 4l7.5 7.5-7.5 7.5z" fill="currentColor"></path>
                    </svg>
                  </div>
                </button>
              </a>
            </div>
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="none" class="svg-plus-1">
              <path d="M2 7.25h12v1.5H2v-1.5z" fill="currentColor"></path>
              <path d="M8.75 2v12h-1.5V2h1.5z" fill="currentColor"></path>
            </svg>
          </div>
          <div class="our-partner-block">
            <div class="our-partner-inner">
              <div class="our-partner-inner-div">
                <img src="{{ asset('public/assets/img/vault-gb.svg') }}" class="partner-logo">
                <div  class="our-partner-inner-text">Buy Wealthmark with cash</div>
              
              </div>
              <a  href="#" target="_blank" class="a-hover-check">
                <button type="button" class="btn-check-hover">
                  <div class="btn-check-inner">Check
                    <!-- -->
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="svg-right-arrow">
                      <path d="M13.5 19l-1.4-1.4 5.1-5.1H3v-2h14.2l-5.1-5.1L13.5 4l7.5 7.5-7.5 7.5z" fill="currentColor"></path>
                    </svg>
                  </div>
                </button>
              </a>
            </div>
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="none" class="svg-plus-1">
              <path d="M2 7.25h12v1.5H2v-1.5z" fill="currentColor"></path>
              <path d="M8.75 2v12h-1.5V2h1.5z" fill="currentColor"></path>
            </svg>
          </div>
          <div class="our-partner-block">
            <div class="our-partner-inner">
              <div class="our-partner-inner-div">
                <img src="{{ asset('public/assets/img/vault-bravelion.svg') }}" class="partner-logo">
                <div  class="our-partner-inner-text">Trade Wealthmark and other crypto in Brave Browser</div>
              
              </div>
              <a  href="#" target="_blank" class="a-hover-check">
                <button type="button" class="btn-check-hover">
                  <div class="btn-check-inner">Check
                    <!-- -->
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="svg-right-arrow">
                      <path d="M13.5 19l-1.4-1.4 5.1-5.1H3v-2h14.2l-5.1-5.1L13.5 4l7.5 7.5-7.5 7.5z" fill="currentColor"></path>
                    </svg>
                  </div>
                </button>
              </a>
            </div>
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="none" class="svg-plus-1">
              <path d="M2 7.25h12v1.5H2v-1.5z" fill="currentColor"></path>
              <path d="M8.75 2v12h-1.5V2h1.5z" fill="currentColor"></path>
            </svg>
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="none" class="svg-plus-2">
              <path d="M2 7.25h12v1.5H2v-1.5z" fill="currentColor"></path>
              <path d="M8.75 2v12h-1.5V2h1.5z" fill="currentColor"></path>
            </svg>
          </div>
          <div class="our-partner-block">
            <div class="our-partner-inner">
              <div class="our-partner-inner-div">
                <img src="{{ asset('public/assets/img/vault-metalpay.svg') }}" class="partner-logo">
                <div  class="our-partner-inner-text">Purchasing and selling Wealthmark with USD</div>
              
              </div>
              <a  href="#" target="_blank" class="a-hover-check">
                <button type="button" class="btn-check-hover">
                  <div class="btn-check-inner">Check
                    <!-- -->
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="svg-right-arrow">
                      <path d="M13.5 19l-1.4-1.4 5.1-5.1H3v-2h14.2l-5.1-5.1L13.5 4l7.5 7.5-7.5 7.5z" fill="currentColor"></path>
                    </svg>
                  </div>
                </button>
              </a>
            </div>
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="none" class="svg-plus-1">
              <path d="M2 7.25h12v1.5H2v-1.5z" fill="currentColor"></path>
              <path d="M8.75 2v12h-1.5V2h1.5z" fill="currentColor"></path>
            </svg>
          </div>
          <div class="our-partner-block">
            <div class="our-partner-inner">
              <div class="our-partner-inner-div">
                <img src="{{ asset('public/assets/img/vault-dether.svg') }}" class="partner-logo">
                <div  class="our-partner-inner-text">Buy Wealthmark with cash</div>
              
              </div>
              <a  href="#" target="_blank" class="a-hover-check">
                <button type="button" class="btn-check-hover">
                  <div class="btn-check-inner">Check
                    <!-- -->
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="svg-right-arrow">
                      <path d="M13.5 19l-1.4-1.4 5.1-5.1H3v-2h14.2l-5.1-5.1L13.5 4l7.5 7.5-7.5 7.5z" fill="currentColor"></path>
                    </svg>
                  </div>
                </button>
              </a>
            </div>
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="none" class="svg-plus-1">
              <path d="M2 7.25h12v1.5H2v-1.5z" fill="currentColor"></path>
              <path d="M8.75 2v12h-1.5V2h1.5z" fill="currentColor"></path>
            </svg>
          </div>
          <div class="our-partner-block">
            <div class="our-partner-inner">
              <div class="our-partner-inner-div">
                <img src="{{ asset('public/assets/img/vault-netcoins.svg') }}" class="partner-logo">
                <div  class="our-partner-inner-text">Buy Wealthmark voucher</div>
              
              </div>
              <a  href="#" target="_blank" class="a-hover-check">
                <button type="button" class="btn-check-hover">
                  <div class="btn-check-inner">Check
                    <!-- -->
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="svg-right-arrow">
                      <path d="M13.5 19l-1.4-1.4 5.1-5.1H3v-2h14.2l-5.1-5.1L13.5 4l7.5 7.5-7.5 7.5z" fill="currentColor"></path>
                    </svg>
                  </div>
                </button>
              </a>
            </div>
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="none" class="svg-plus-1">
              <path d="M2 7.25h12v1.5H2v-1.5z" fill="currentColor"></path>
              <path d="M8.75 2v12h-1.5V2h1.5z" fill="currentColor"></path>
            </svg>
          </div>
          <div class="our-partner-block">
            <div class="our-partner-more">
              <div class="our-partner-more-inner">
                <h6>More in the future</h6>
              </div>
            </div>
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="none" class="svg-plus-1">
              <path d="M2 7.25h12v1.5H2v-1.5z" fill="currentColor"></path>
              <path d="M8.75 2v12h-1.5V2h1.5z" fill="currentColor"></path>
            </svg>
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="none" class="svg-plus-2">
              <path d="M2 7.25h12v1.5H2v-1.5z" fill="currentColor"></path>
              <path d="M8.75 2v12h-1.5V2h1.5z" fill="currentColor"></path>
            </svg>
          </div>
          
    
        </div>
      </div>
    </div>
  </div>
</div>



    
<section class="wm-pay-accordian-section">
    <div class="container">
        <div class="outlet-main-div">
                 <div class="wm-outlet-div">
                           
                            <div class="sec-title text-center mb-2">
                           <h2 class="heading-h2">FAQs</h2>
                            </div>
                           
                        </div>
                         <div class="wm-outlet-div text-right justify-content-end">
                           
                            <a href="#" class="learn-more btn-6">
                           <span>Learn More </span>
                           <span><i class="bi bi-chevron-right"></i></span>
                        </a>
                           
                        </div>
                        </div>
    </div>
    <div class="container">
  <div class="accordion" id="accordionExample">
  <div class="card">
    <div class="card-head" id="headingOne">
      <h2 class="mb-0 collapsed" data-toggle="collapse" data-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
        What is Wealthmark Vault？
      </h2>
    </div>

    <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
      <div class="card-body">
      <div class="text">  Wealthmark Vault is a Wealthmark yield aggregator. Depositing Wealthmark means participating in Launchpool, Simple Earn, Defi staking and other projects and at the same time gaining rewards..</div>
      </div>
    </div>
  </div>
  <div class="card">
    <div class="card-head" id="headingTwo">
      <h2 class="mb-0 collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
    What are the sources of Wealthmark Vault reward?
      </h2>
    </div>
    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
      <div class="card-body">
       <div class="text">The rewards from Wealthmark Vault is accumulated by the income of different projects. Currently it includes Simple Earn, Launchpool, Defi staking.</div>
      
      </div>
    </div>
  </div>
  <div class="card">
    <div class="card-head" id="headingThree">
      <h2 class="mb-0 collapsed" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
       When can I redeem after subscribing to Wealthmark vault?
      </h2>
    </div>
    <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
      <div class="card-body">
        <div class="text">The time frame for subscription and redemption is open from 00:10-23:50(UTC) every day.</div>
      </div>
    </div>
  </div>
  
  
  <div class="card">
    <div class="card-head" id="headingFour">
      <h2 class="mb-0 collapsed" data-toggle="collapse" data-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
     subscribing Wealthmark vault and participating in Launchpool projects？
      </h2>
    </div>
    <div id="collapseFour" class="collapse" aria-labelledby="headingFour" data-parent="#accordionExample">
      <div class="card-body">
  <div class="text">If there is only one project in Launchpool, the APR is the same in these two products; if there is more than one project on-going in Launchpool, Wealthmark vault will subscribe the projects for users automatically according to the configuration while in Launchpool users can choose which project to participate in and allocate their funds as they want.</div>     
      </div>
    </div>
  </div>
  
  
</div>
</div>
</section>





  @include('template.country_language')
    @include('template.web_footer') 
      <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/js/bootstrap.min.js"></script> 
   
  
    </body>
</html>