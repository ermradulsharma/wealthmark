<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <title>Wealth Mark | {{ Request::segment(2) }}</title>
    @include('template.web_css')
    <link rel='stylesheet' href="{{('../public/assets/css/deepak_custom.css') }}">
    <script src="https://kit.fontawesome.com/96b7211fcc.js" crossorigin="anonymous"></script>
</head>

<body>
    @include('template.mobile_menu')
    @include('template.web_menu')
    <section class="charity-banner-block" id="charity-banner-section">
        <div class="container mt-5d">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <h1 class="text-white banner-big-txt">Driving Transformative </h1>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-5 col-md-5 text-white" data-aos="fade-up">
                    <div class="banner-left-content">
                        <h3 class="top-heading text-white">Blockchain Solutions for Social Change</h3>
                        <p class="top-p text-white">We're Weakth Mark Charity, the first-ever blockchain-enabled
                            transparent
                            donation platform.</p>
                        <p class="top-p text-white">As a 501(c)(3) non-profit, we unlock the power of blockchain and
                            make
                            technology work for people. With our network of trusted partners and the crypto community,
                            we're
                            using blockchain to support the UN's Sustainable Development Goals by working to eradicate
                            poverty, fight inequality and ensure the health of people and our planet. </p>

                    </div>
                </div>
                <div class="col-md-7 col-lg-7 col-xs-12 col-sm-6"> </div>
            </div>
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    <div class="row">
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                            <div class="charity-fund-calculation">
                                <h5>5,384 </h5>
                                <p>Total Donations</p>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                            <div class="charity-fund-calculation">
                                <h5>1,990,562</h5>
                                <p>Total Beneficiaries</p>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                            <div class="charity-fund-calculation">
                                <h5>3,167.373BTC</h5>
                                <p>Amount Raised</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">

                </div>
            </div>
        </div>

    </section>

    <section class="wealth-mar-charity-block" id="wealth-mar-charity-section">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-lg-6 col-sm-12 col-xs-12">
                    <div class="sec-title text-left">
                        <span class="title">Know About</span>
                        <h2 class="heading-h2">Why <span class="yellow-text">We Care </span></h2>
                    </div>
                    <div class="charity-content-block pb-5 mb-3">
                        <h4>Direct Giving </h4>
                        <p class="mb-4">We transfer your donation directly to the end beneficiary - meaning 100% of your
                            money goes to those who need it most.</p>
                        <h4>Transparency </h4>
                        <p class="mb-4">Through the power of blockchain technology, we’re working to make the social
                            sector more transparent by providing tools that are entirely traceable, accountable and
                            immutable.</p>
                        <h4>Transformative Tech </h4>
                        <p class="mb-4">We believe blockchain must work for all people. So together with partners, we’re
                            driving transformative tech solutions to help address our world’s most complex issues.</p>
                        <a class="btn btn-yellow shadow mt-3">Full User Guidance </a>
                    </div>
                </div>
                <div class="col-md-6 col-lg-6 col-sm-12 col-xs-12">
                    <div class="charity-wecar-block mt-3 pb-4">
                        <img src="{{ asset('public/assets/img/charity-we-care-img.png') }}" class="img-fluid"
                            alt="Charity image" />
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="charity-carousel-slider">
        <div class="container" id="featureContainer">
            <div class="row">
                <div class="sec-title text-left ">
                    <span class="title">Know About</span>
                    <h2 class="heading-h2">Our Five Pillars</h2>
                </div>
            </div>

            <div class="row mx-auto my-auto justify-content-center">
                <div id="featureCarousel" class="carousel slide" data-bs-ride="carousel">
                    <div class="float-end pe-md-4 mb-4">
                        <a class="indicator" href="#featureCarousel" role="button" data-bs-slide="prev">
                            <span> &#8249;</span>
                        </a> &nbsp;&nbsp;
                        <a class="w-aut indicator" href="#featureCarousel" role="button" data-bs-slide="next">
                            <span> &#8250;</span>
                        </a>
                    </div>
                    <div class="carousel-inner" role="listbox">
                        <div class="carousel-item active">
                            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                                <div class="card">
                                    <div class="card-img">
                                        <img loading="lazy"
                                            src="{{ asset('public/assets/img/charity-five-piller-1.png') }}"
                                            alt="Charity"class="img-fluid">
                                    </div>

                                </div>
                                <div class="latest-news-data">
                                    <div class="card-img-overlays">
                                        <h4 class="fw-bolder">Closing the Poverty Gap</h4>
                                    </div>
                                    <p>We envisage a world, where cryptocurrency is used to level the playing field and
                                        put
                                        an end to poverty. </p>
                                </div>
                            </div>
                        </div>
                        <div class="carousel-item">
                            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                                <div class="card">
                                    <div class="card-img">
                                        <img loading="lazy"
                                            src="{{ asset('public/assets/img/charity-five-piller-2.png') }}"
                                            alt="Charity"class="img-fluid">
                                    </div>

                                </div>
                                <div class="latest-news-data">
                                    <div class="card-img-overlays">
                                        <h4 class="fw-bolder">Closing the Poverty Gap</h4>
                                    </div>
                                    <p>We envisage a world, where cryptocurrency is used to level the playing field and
                                        put
                                        an end to poverty. </p>
                                </div>
                            </div>
                        </div>
                        <div class="carousel-item">
                            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                                <div class="card">
                                    <div class="card-img">
                                        <img loading="lazy"
                                            src="{{ asset('public/assets/img/charity-five-piller-3.png') }}"
                                            alt="Charity"class="img-fluid">
                                    </div>

                                </div>
                                <div class="latest-news-data">
                                    <div class="card-img-overlays">
                                        <h4 class="fw-bolder">Closing the Poverty Gap</h4>
                                    </div>
                                    <p>We envisage a world, where cryptocurrency is used to level the playing field and
                                        put
                                        an end to poverty. </p>
                                </div>
                            </div>
                        </div>
                        <div class="carousel-item">
                            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                                <div class="card">
                                    <div class="card-img">
                                        <img loading="lazy"
                                            src="{{ asset('public/assets/img/charity-five-piller-4.png') }}"
                                            alt="Charity"class="img-fluid">
                                    </div>

                                </div>
                                <div class="latest-news-data">
                                    <div class="card-img-overlays">
                                        <h4 class="fw-bolder">Closing the Poverty Gap</h4>
                                    </div>
                                    <p>We envisage a world, where cryptocurrency is used to level the playing field and
                                        put
                                        an end to poverty. </p>
                                </div>
                            </div>
                        </div>
                        <div class="carousel-item">
                            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                                <div class="card">
                                    <div class="card-img">
                                        <img loading="lazy"
                                            src="{{ asset('public/assets/img/charity-five-piller-5.png') }}"
                                            alt="Charity"class="img-fluid">
                                    </div>

                                </div>
                                <div class="latest-news-data">
                                    <div class="card-img-overlays">
                                        <h4 class="fw-bolder">Closing the Poverty Gap</h4>
                                    </div>
                                    <p>We envisage a world, where cryptocurrency is used to level the playing field and
                                        put
                                        an end to poverty. </p>
                                </div>
                            </div>
                        </div>
                        <div class="carousel-item">
                            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                                <div class="card">
                                    <div class="card-img">
                                        <img loading="lazy"
                                            src="{{ asset('public/assets/img/charity-five-piller-1.png') }}"
                                            alt="Charity"class="img-fluid">
                                    </div>

                                </div>
                                <div class="latest-news-data">
                                    <div class="card-img-overlays">
                                        <h4 class="fw-bolder">Closing the Poverty Gap</h4>
                                    </div>
                                    <p>We envisage a world, where cryptocurrency is used to level the playing field and
                                        put
                                        an end to poverty. </p>
                                </div>
                            </div>
                        </div>
                        <div class="carousel-item">
                            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                                <div class="card">
                                    <div class="card-img">
                                        <img loading="lazy"
                                            src="{{ asset('public/assets/img/charity-five-piller-4.png') }}"
                                            alt="Charity"class="img-fluid">
                                    </div>

                                </div>
                                <div class="latest-news-data">
                                    <div class="card-img-overlays">
                                        <h4 class="fw-bolder">Closing the Poverty Gap</h4>
                                    </div>
                                    <p>We envisage a world, where cryptocurrency is used to level the playing field and
                                        put
                                        an end to poverty. </p>
                                </div>
                            </div>
                        </div>
                        <div class="carousel-item">
                            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                                <div class="card">
                                    <div class="card-img">
                                        <img loading="lazy"
                                            src="{{ asset('public/assets/img/charity-five-piller-3.png') }}"
                                            alt="Charity"class="img-fluid">
                                    </div>

                                </div>
                                <div class="latest-news-data">
                                    <div class="card-img-overlays">
                                        <h4 class="fw-bolder">Closing the Poverty Gap</h4>
                                    </div>
                                    <p>We envisage a world, where cryptocurrency is used to level the playing field and
                                        put
                                        an end to poverty. </p>
                                </div>
                            </div>
                        </div>
                        <div class="carousel-item">
                            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                                <div class="card">
                                    <div class="card-img">
                                        <img loading="lazy"
                                            src="{{ asset('public/assets/img/charity-five-piller-4.png') }}"
                                            alt="Charity"class="img-fluid">
                                    </div>

                                </div>
                                <div class="latest-news-data">
                                    <div class="card-img-overlays">
                                        <h4 class="fw-bolder">Closing the Poverty Gap</h4>
                                    </div>
                                    <p>We envisage a world, where cryptocurrency is used to level the playing field and
                                        put
                                        an end to poverty. </p>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>

    <section class="wealth-mar-charity-block" id="wealth-mar-charity-section">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-lg-6 col-sm-12 col-xs-12">
                    <div class="nft-video-block">
                        <img src="{{ asset('public/assets/img/Crypto_Giving.webp') }}"
                            class="img-fluid Crypto_Giving-img" alt="Charity image" />
                    </div>
                </div>
                <div class="col-md-6 col-lg-6 col-sm-12 col-xs-12">
                    <div class="sec-title text-left mt-3 pt-4">
                        <span class="title">Know About</span>
                        <h2 class="heading-h2">Why <span class="yellow-text">We Care </span></h2>
                    </div>
                    <div class="charity-content-block mt-3 pt-3">
                        <h4>Direct Giving </h4>
                        <p class="mb-4">We transfer your donation directly to the end beneficiary - meaning 100% of your
                            money goes to those who need it most.</p>
                        <h4>Transparency </h4>
                        <p class="mb-4">Through the power of blockchain technology, we’re working to make the social
                            sector more transparent by providing tools that are entirely traceable, accountable and
                            immutable.</p>
                        <h4>Transformative Tech </h4>
                        <p class="mb-4">We believe blockchain must work for all people. So together with partners, we’re
                            driving transformative tech solutions to help address our world’s most complex issues.</p>
                        <a class="btn btn-yellow shadow mt-3">Full User Guidance </a>
                    </div>
                </div>

            </div>
        </div>
    </section>

    <section class="charity-latest-news-slider">
        <div class="container" id="featureContainer">
            <div class="row">
                <div class="sec-title text-left mb-5">
                    <span class="title">Know About</span>
                    <h2 class="heading-h2">Latest News</h2>
                </div>
            </div>

            <div class="row mx-auto my-auto justify-content-center">
                <div id="featureCarousel" class="carousel slide" data-bs-ride="carousel">
                    <div class="float-end pe-md-4 mb-4">
                        <a class="indicator" href="#featureCarousel" role="button" data-bs-slide="prev">
                            <span> &#8249;</span>
                        </a> &nbsp;&nbsp;
                        <a class="w-aut indicator" href="#featureCarousel" role="button" data-bs-slide="next">
                            <span> &#8250;</span>
                        </a>
                    </div>
                    <div class="carousel-inner" role="listbox">
                        <div class="carousel-item active">
                            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                                <div class="card">
                                    <div class="card-img">
                                        <img loading="lazy" src="{{ asset('public/assets/img/latest-news-4.jpg') }}"
                                            alt="Charity"class="img-fluid">
                                    </div>

                                </div>
                                <div class="row">
                                    <div class="col-md-6 col-sm-6 col-xs-6">
                                        <div class="charity-topic-box">
                                            <h5>NEWS </h5>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-sm-6 col-xs-6">
                                        <div class="charity-time-box">
                                            <h5 class="text-warning fw-normal">22-10-2014 </h5>
                                        </div>
                                    </div>
                                </div>
                                <div class="charity-five-piller-data">
                                    <div class="card-img-overlays">
                                        <h4 class="fw-bolder">Closing the Poverty Gap</h4>
                                    </div>
                                    <p>We envisage a world, where cryptocurrency is used to level the playing field and
                                        put
                                        an end to poverty. </p>
                                </div>
                            </div>
                        </div>
                        <div class="carousel-item">
                            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                                <div class="card">
                                    <div class="card-img">
                                        <img loading="lazy" src="{{ asset('public/assets/img/latest-news-3.jpg') }}"
                                            alt="Charity"class="img-fluid">
                                    </div>

                                </div>
                                <div class="row">
                                    <div class="col-md-6 col-sm-6 col-xs-6">
                                        <div class="charity-topic-box">
                                            <h5>NEWS </h5>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-sm-6 col-xs-6">
                                        <div class="charity-time-box">
                                            <h5 class="text-warning fw-normal">22-10-2014 </h5>
                                        </div>
                                    </div>
                                </div>
                                <div class="charity-five-piller-data">
                                    <div class="card-img-overlays">
                                        <h4 class="fw-bolder">Closing the Poverty Gap</h4>
                                    </div>
                                    <p>We envisage a world, where cryptocurrency is used to level the playing field and
                                        put
                                        an end to poverty. </p>
                                </div>
                            </div>
                        </div>
                        <div class="carousel-item">
                            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                                <div class="card">
                                    <div class="card-img">
                                        <img loading="lazy" src="{{ asset('public/assets/img/latest-news-2.jpg') }}"
                                            alt="Charity"class="img-fluid">
                                    </div>

                                </div>
                                <div class="row">
                                    <div class="col-md-6 col-sm-6 col-xs-6">
                                        <div class="charity-topic-box">
                                            <h5>NEWS </h5>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-sm-6 col-xs-6">
                                        <div class="charity-time-box">
                                            <h5 class="text-warning fw-normal">22-10-2014 </h5>
                                        </div>
                                    </div>
                                </div>
                                <div class="charity-five-piller-data">
                                    <div class="card-img-overlays">
                                        <h4 class="fw-bolder">Closing the Poverty Gap</h4>
                                    </div>
                                    <p>We envisage a world, where cryptocurrency is used to level the playing field and
                                        put
                                        an end to poverty. </p>
                                </div>
                            </div>
                        </div>
                        <div class="carousel-item">
                            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                                <div class="card">
                                    <div class="card-img">
                                        <img loading="lazy" src="{{ asset('public/assets/img/latest-news-3.jpg') }}"
                                            alt="Charity"class="img-fluid">
                                    </div>

                                </div>
                                <div class="row">
                                    <div class="col-md-6 col-sm-6 col-xs-6">
                                        <div class="charity-topic-box">
                                            <h5>NEWS </h5>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-sm-6 col-xs-6">
                                        <div class="charity-time-box">
                                            <h5 class="text-warning fw-normal">22-10-2014 </h5>
                                        </div>
                                    </div>
                                </div>
                                <div class="charity-five-piller-data">
                                    <div class="card-img-overlays">
                                        <h4 class="fw-bolder">Closing the Poverty Gap</h4>
                                    </div>
                                    <p>We envisage a world, where cryptocurrency is used to level the playing field and
                                        put
                                        an end to poverty. </p>
                                </div>
                            </div>
                        </div>
                        <div class="carousel-item">
                            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                                <div class="card">
                                    <div class="card-img">
                                        <img loading="lazy" src="{{ asset('public/assets/img/latest-news-2.jpg') }}"
                                            alt="Charity"class="img-fluid">
                                    </div>

                                </div>
                                <div class="row">
                                    <div class="col-md-6 col-sm-6 col-xs-6">
                                        <div class="charity-topic-box">
                                            <h5>NEWS </h5>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-sm-6 col-xs-6">
                                        <div class="charity-time-box">
                                            <h5 class="text-warning fw-normal">22-10-2014 </h5>
                                        </div>
                                    </div>
                                </div>
                                <div class="charity-five-piller-data">
                                    <div class="card-img-overlays">
                                        <h4 class="fw-bolder">Closing the Poverty Gap</h4>
                                    </div>
                                    <p>We envisage a world, where cryptocurrency is used to level the playing field and
                                        put
                                        an end to poverty. </p>
                                </div>
                            </div>
                        </div>
                        <div class="carousel-item">
                            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                                <div class="card">
                                    <div class="card-img">
                                        <img loading="lazy" src="{{ asset('public/assets/img/latest-news-1.jpg') }}"
                                            alt="Charity"class="img-fluid">
                                    </div>

                                </div>
                                <div class="row">
                                    <div class="col-md-6 col-sm-6 col-xs-6">
                                        <div class="charity-topic-box">
                                            <h5>NEWS </h5>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-sm-6 col-xs-6">
                                        <div class="charity-time-box">
                                            <h5 class="text-warning fw-normal">22-10-2014 </h5>
                                        </div>
                                    </div>
                                </div>
                                <div class="charity-five-piller-data">
                                    <div class="card-img-overlays">
                                        <h4 class="fw-bolder">Closing the Poverty Gap</h4>
                                    </div>
                                    <p>We envisage a world, where cryptocurrency is used to level the playing field and
                                        put
                                        an end to poverty. </p>
                                </div>
                            </div>
                        </div>
                        <div class="carousel-item">
                            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                                <div class="card">
                                    <div class="card-img">
                                        <img loading="lazy" src="{{ asset('public/assets/img/latest-news-2.jpg') }}"
                                            alt="Charity"class="img-fluid">
                                    </div>

                                </div>
                                <div class="row">
                                    <div class="col-md-6 col-sm-6 col-xs-6">
                                        <div class="charity-topic-box">
                                            <h5>NEWS </h5>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-sm-6 col-xs-6">
                                        <div class="charity-time-box">
                                            <h5 class="text-warning fw-normal">22-10-2014 </h5>
                                        </div>
                                    </div>
                                </div>
                                <div class="charity-five-piller-data">
                                    <div class="card-img-overlays">
                                        <h4 class="fw-bolder">Closing the Poverty Gap</h4>
                                    </div>
                                    <p>We envisage a world, where cryptocurrency is used to level the playing field and
                                        put
                                        an end to poverty. </p>
                                </div>
                            </div>
                        </div>
                        <div class="carousel-item">
                            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                                <div class="card">
                                    <div class="card-img">
                                        <img loading="lazy" src="{{ asset('public/assets/img/latest-news-3.jpg') }}"
                                            alt="Charity"class="img-fluid">
                                    </div>

                                </div>
                                <div class="row">
                                    <div class="col-md-6 col-sm-6 col-xs-6">
                                        <div class="charity-topic-box">
                                            <h5>NEWS </h5>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-sm-6 col-xs-6">
                                        <div class="charity-time-box">
                                            <h5 class="text-warning fw-normal">22-10-2014 </h5>
                                        </div>
                                    </div>
                                </div>
                                <div class="charity-five-piller-data">
                                    <div class="card-img-overlays">
                                        <h4 class="fw-bolder">Closing the Poverty Gap</h4>
                                    </div>
                                    <p>We envisage a world, where cryptocurrency is used to level the playing field and
                                        put
                                        an end to poverty. </p>
                                </div>
                            </div>
                        </div>
                        <div class="carousel-item">
                            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                                <div class="card">
                                    <div class="card-img">
                                        <img loading="lazy" src="{{ asset('public/assets/img/latest-news-4.jpg') }}"
                                            alt="Charity"class="img-fluid">
                                    </div>

                                </div>
                                <div class="row">
                                    <div class="col-md-6 col-sm-6 col-xs-6">
                                        <div class="charity-topic-box">
                                            <h5>NEWS </h5>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-sm-6 col-xs-6">
                                        <div class="charity-time-box">
                                            <h5 class="text-warning fw-normal">22-10-2014 </h5>
                                        </div>
                                    </div>
                                </div>
                                <div class="charity-five-piller-data">
                                    <div class="card-img-overlays">
                                        <h4 class="fw-bolder">Closing the Poverty Gap</h4>
                                    </div>
                                    <p>We envisage a world, where cryptocurrency is used to level the playing field and
                                        put
                                        an end to poverty. </p>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>
    <script src="https://code.jquery.com/jquery-3.6.0.slim.min.js"></script>

    <script>
    let items = document.querySelectorAll('#featureContainer .carousel .carousel-item');
    items.forEach((el) => {
        const minPerSlide = 4
        let next = el.nextElementSibling
        for (var i = 1; i < minPerSlide; i++) {
            if (!next) {
                // wrap carousel by using first child
                next = items[0]
            }
            let cloneChild = next.cloneNode(true)
            el.appendChild(cloneChild.children[0])
            next = next.nextElementSibling
        }
    })
    $(document).ready(function() {
        $('#featureCarousel').carousel({
            interval: false
        });
        $('#featureCarousel').carousel('pause');
    });
    </script>
    @include('template.country_language')
    @include('template.web_footer')
</body>

</html>