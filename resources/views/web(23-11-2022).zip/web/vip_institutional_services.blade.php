<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <link rel='stylesheet' href="{{('../public/assets/css/deepak_custom.css') }}">
    <title>Wealth Mark | Create Entity Account</title>
    @include('template.web_css')
</head>

<body>

    @include('template.mobile_menu')
    @include('template.web_menu')


    <!-- <div class="text-center mt-3 bg-light-yellow">
                <a href="{{ url( app()->getLocale(), 'register') }}">    <span class="offer-text-head">
                    Register now - Enjoy Welcome Rewards up to 1 BMK! ( for verified user) 
                    </span>
                    </a>
                </div>
            -->

    <!-- first section -->

    <section class="breadcrumbs-box shadow-sm" id="vip-institutional-section">
        <div class="container mt-3">
            <div class="row">
                <div class="col-lg-6 d-flex flex-column justify-content-center pt-lg-0" data-aos="fade-up"
                    data-aos-delay="200">
                    <h1 class="top-heading-subheading"> Wealth Mark Institutional</h1>
                    <h3 class="top-heading">Your Trusted Platform in Digital Institutions</h3>
                    <p class="top-p">Built by the world's largest digital asset exchange, Wealth Mark Institutional
                        offers
                        unparalleled access to digital asset solutions for VIP clients and institutions.</p>
                    <a href="#" class="btn btn-yellow shadow vip-banner-btn mb-4">Get Started</a>
                </div>

            </div>
        </div>
    </section>

    <!-- second section -->
    <section class="institutional-solutions" id="institutional-solutions">
        <div class="container">
            <div class="row">
                <div class="sec-title text-left mb-5">
                    <span class="title">Know About</span>
                    <h2 class="heading-h2">Tailored Solutions for Institutions</h2>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    <div class="featured-block-left d-flex">
                        <img loading="lazy" src="{{ asset('public/assets/img/insittutional-featured-1.svg') }}"
                            alt="Cloud " class="img-fluid why-chose-img">
                        <div class="featured-content-right">
                            <h4>Execution & OTC Services</h4>
                            <p>Trade on credit and get flexible financing solutions for OTC with competitive rates and
                                preferred terms</p>
                            <a class="text-warning">Learn More &#8250;</a>
                        </div>
                    </div>

                    <div class="featured-block-left d-flex">
                        <img loading="lazy" src="{{ asset('public/assets/img/insittutional-featured-2.svg') }}"
                            alt="Cloud " class="img-fluid why-chose-img">
                        <div class="featured-content-right">
                            <h4>Execution & OTC Services</h4>
                            <p>Trade on credit and get flexible financing solutions for OTC with competitive rates and
                                preferred terms</p>
                            <a class="text-warning">Learn More &#8250;</a>
                        </div>
                    </div>

                    <div class="featured-block-left d-flex">
                        <img loading="lazy" src="{{ asset('public/assets/img/insittutional-featured-3.svg') }}"
                            alt="Cloud " class="img-fluid why-chose-img">
                        <div class="featured-content-right">
                            <h4>Execution & OTC Services</h4>
                            <p>Trade on credit and get flexible financing solutions for OTC with competitive rates and
                                preferred terms</p>
                            <a class="text-warning">Learn More &#8250;</a>
                        </div>
                    </div>

                    <div class="featured-block-left d-flex">
                        <img loading="lazy" src="{{ asset('public/assets/img/insittutional-featured-4.svg') }}"
                            alt="Cloud " class="img-fluid why-chose-img">
                        <div class="featured-content-right">
                            <h4>Execution & OTC Services</h4>
                            <p>Trade on credit and get flexible financing solutions for OTC with competitive rates and
                                preferred terms</p>
                            <a class="text-warning">Learn More &#8250;</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    <div class="featured-block-right d-flex justify-content-center align-items-center">
                        <img loading="lazy" src="{{ asset('public/assets/img/institute-img.svg') }}"
                            class="img-fluid animated">
                    </div>
                </div>
            </div>

        </div>
    </section>


    <!-- third section -->
    <section class="why-choose-wealthmark" id="choose-wealthmark">
        <div class="container">
            <div class="row">
                <div class="sec-title text-left mb-5">
                    <span class="title">Know About</span>
                    <h2 class="heading-h2">Why Institutions Choose wealth Mark</h2>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    <div class="institutional-solutions-left">
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
                            labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco
                            laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in
                            voluptate velit esse cillum dolore eu fugiat nulla pariatur. </p>

                        <ul class="list-1 mt-3 mb-3">
                            <li>Asset Managers </li>
                            <li>Brokers </li>
                            <li>Hedge Fund </li>
                            <li>Family Offices </li>
                            <li>Proprietary Firms </li>
                            <li>Liquidity Providers </li>
                            <li>HNWIs </li>
                            <li>Mining Companies </li>
                            <li>Corporates </li>
                        </ul>
                        <br />
                        <ul class="list-2">
                            <li>Over 1450 pairs for various spot trading needs </li>
                            <li>Largest futures trading volume with over 200 contracts </li>
                            <li>Comprehensive Wealth Mark blockchain ecosystem </li>
                            <li>Access to the deepest cryptocurrency liquidity pool </li>
                        </ul>
                        <br />
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    <div class="institute-widget-block">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="widget-inner card">
                                    <h4>$100</h4>
                                    <p>Hedge Fund</p>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="widget-inner card">
                                    <h4>$500 </h4>
                                    <p>Liquidity Providers</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="institute-widget-block">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="widget-inner card">
                                    <h4>$900 </h4>
                                    <p>Mining Companies</p>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="widget-inner card">
                                    <h4>$700 </h4>
                                    <p>Corporates</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- fourth section -->
    <section class="proprietary-offerings" id="proprietary">
        <div class="container">
            <div class="row">
                <div class="sec-title text-left mb-5">
                    <span class="title">Know About</span>
                    <h2 class="heading-h2">Wealth Mark's Proprietary Offerings</h2>
                </div>
            </div>
            <div class="row">
                <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="pills-home-tab" data-bs-toggle="pill"
                            data-bs-target="#pills-home" type="button" role="tab" aria-controls="pills-home"
                            aria-selected="true">Trading Solutions</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="pills-profile-tab" data-bs-toggle="pill"
                            data-bs-target="#pills-profile" type="button" role="tab" aria-controls="pills-profile"
                            aria-selected="false">Yield Products</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="pills-contact-tab" data-bs-toggle="pill"
                            data-bs-target="#pills-contact" type="button" role="tab" aria-controls="pills-contact"
                            aria-selected="false">Professional Services</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="pills-contact2-tab" data-bs-toggle="pill"
                            data-bs-target="#pills-contact2" type="button" role="tab" aria-controls="pills-contact2"
                            aria-selected="false">Data & Reporting</button>
                    </li>
                </ul>
                <div class="tab-content" id="pills-tabContent">
                    <div class="tab-pane fade show active" id="pills-home" role="tabpanel"
                        aria-labelledby="pills-home-tab">
                        <div class="row">
                            <div class="col-md-3">
                                <img loading="lazy" src="{{ asset('public/assets/img/trading-tab-img.svg') }}"
                                    class="img-fluid">
                            </div>
                            <div class="col-md-9 tab-right-content d-block justify-content-center align-items-center">
                                <p class="text-theme mt-4 mb-2 d-flex justify-content-center align-items-center">The
                                    Wealth Mark Portfolio Margin Program is a cross-asset margin program supporting
                                    consolidated margin balances across futures and margin with over 200 effective
                                    crypto collaterals. Supported crypto assets and positions in USDⓈ-M and COIN-M
                                    Futures, and Margin accounts are accounted as one single effective joint collateral
                                    to determine the account equity, margin balance and maintenance margin requirement.
                                </p>
                                <a class="text-warning">Learn More &#8250;</a>
                            </div>
                        </div>

                    </div>
                    <div class="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab">
                        <div class="row">
                            <div class="col-md-3">
                                <img loading="lazy" src="{{ asset('public/assets/img/yield-product-img.svg') }}"
                                    class="img-fluid">
                            </div>
                            <div class="col-md-9 tab-right-content d-block justify-content-center align-items-center">
                                <p class="text-theme mt-4 mb-2 d-flex justify-content-center align-items-center">Savings
                                    offers a wide selection of digital assets for you to deposit. Flexible Savings
                                    allows you to subscribe and earn daily rewards on digital assets, and have
                                    flexibility to withdraw the digital assets anytime as you wish. Locked Savings
                                    provides you higher earning rates in exchange for locking up the digital assets for
                                    a fixed period of time. Start earning daily passive rewards on your idle digital
                                    assets!</p>
                                <a class="text-warning">Flexible &#8250; &nbsp;</a>
                                <a class="text-warning">Locked &#8250;</a>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="pills-contact" role="tabpanel" aria-labelledby="pills-contact-tab">
                        <div class="row">
                            <div class="col-md-3">
                                <img loading="lazy" src="{{ asset('public/assets/img/professinal-services-img.svg') }}"
                                    class="img-fluid">
                            </div>
                            <div class="col-md-9 tab-right-content d-block justify-content-center align-items-center">
                                <p class="text-theme mt-4 mb-2 d-flex justify-content-center align-items-center">A
                                    popular feature amongst institutional traders, our sub-account feature allows
                                    organisations to set-up multiple trading accounts under one single master account -
                                    all with well-defined access and control parameters.</p>
                                <a class="text-warning">FAQ &#8250;</a>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="pills-contact2" role="tabpanel" aria-labelledby="pills-contact-tab">
                        <div class="row">
                            <div class="col-md-3">
                                <img loading="lazy" src="{{ asset('public/assets/img/data-reporting-img.svg') }}"
                                    class="img-fluid">
                            </div>
                            <div class="col-md-9 tab-right-content d-block justify-content-center align-items-center">
                                <p class="text-theme mt-4 mb-2 d-flex justify-content-center align-items-center">We
                                    offer diversified reporting services for your various reporting needs. Please kindly
                                    refer to below guide on how to generate reports within account service.</p>

                                <a class="text-warning">Account Statement &#8250; &nbsp;</a>
                                <a class="text-warning">Transaction History &#8250; &nbsp;</a>
                                <a class="text-warning">Tax API &#8250; &nbsp;</a>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- fifth section -->
    <section class="competitive-fees" id="competitive-fees">
        <div class="container">
            <div class="row">
                <div class="sec-title text-left mb-5">
                    <span class="title">Know About</span>
                    <h2 class="heading-h2">Competitive Fees</h2>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 order-2 order-lg-1">

                    <div class="featured-block-left d-flex">
                        <img loading="lazy" src="{{ asset('public/assets/img/btc-icon.svg') }}" alt="Cloud "
                            class="img-fluid why-chose-img">
                        <div class="featured-content-right">
                            <h4>Zero BTC Fees</h4>
                            <p>Trade on credit and get flexible financing solutions for OTC with competitive rates and
                                preferred terms</p>
                            <a class="text-warning">Trade BTC &#8250;</a>
                        </div>
                    </div>

                    <div class="featured-block-left d-flex">
                        <img loading="lazy" src="{{ asset('public/assets/img/bnb-icon.svg') }}" alt="Cloud "
                            class="img-fluid why-chose-img">
                        <div class="featured-content-right">
                            <h4>BNB Fee Deduction</h4>
                            <p>Trade on credit and get flexible financing solutions for OTC with competitive rates and
                                preferred terms</p>
                            <a class="text-warning">Get BNB &#8250;</a>
                        </div>
                    </div>

                    <div class="featured-block-left d-flex">
                        <img loading="lazy" src="{{ asset('public/assets/img/busd-icon.svg') }}" alt="Cloud "
                            class="img-fluid why-chose-img">
                        <div class="featured-content-right">
                            <h4>BUSD Trading Pairs</h4>
                            <p>Trade on credit and get flexible financing solutions for OTC with competitive rates and
                                preferred terms</p>
                            <a class="text-warning">Buy BUSD &#8250;</a>
                        </div>
                    </div>

                </div>
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 order-1 order-lg-2">
                    <div class="featured-block-right d-flex  mt-5 float-sm-left ">
                        <img loading="lazy" src="{{ asset('public/assets/img/fee-icon.svg') }}" class="img-fluid mt-5">
                    </div>
                </div>
            </div>

        </div>
    </section>


    <!-- sixth section -->
    <section class="vip-program-block" id="vip-program">
        <div class="container">
            <div class="row">
                <div class="sec-title text-left mb-5">
                    <span class="title">Know About</span>
                    <h2 class="heading-h2">Wealth Mark's VIP Programs</h2>
                </div>
            </div>

            <div class="row">
                <div class="col-md-12 col-xs-12 col-sm-12">
                    <p><strong>"Wealth Mark"</strong> is committed to creating diversified programs for VIP &
                        Institutional clients to serve various needs. Whether you’re a sophisticated trader, a passive
                        income-earner, or a long-term digital asset holder, we’ve designed a customized program for you.
                        If our current programs don’t meet your objectives, then please tell us in the contact form and
                        our VIP team will reach out to you as soon as possible. </p>
                    <p>Check latest fees and benchmark requirement for Spot and Futures trading, please visit this page.

                    </p>
                </div>
            </div>
            <div class="row mt-4">
                <div class="col-md-12">
                    <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active" id="pills-holder-program-tab" data-bs-toggle="pill"
                                data-bs-target="#pills-holder-program" type="button" role="tab"
                                aria-controls="pills-holder-program" aria-selected="true">Holder Program</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="pills-borrower-programe-tab" data-bs-toggle="pill"
                                data-bs-target="#pills-borrower-programe" type="button" role="tab"
                                aria-controls="pills-borrower-programe" aria-selected="false">Borrower Program</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="pills-investor-programe-tab" data-bs-toggle="pill"
                                data-bs-target="#pills-investor-programe" type="button" role="tab"
                                aria-controls="pills-investor-programe" aria-selected="false">Investor Program</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="pills-invitation-program-tab" data-bs-toggle="pill"
                                data-bs-target="#pills-invitation-programe" type="button" role="tab"
                                aria-controls="pills-invitation-programe" aria-selected="false">invitation
                                Program</button>
                        </li>
                    </ul>
                    <div class="tab-content" id="pills-tabContent">
                        <div class="tab-pane fade show active" id="pills-holder-program" role="tabpanel"
                            aria-labelledby="pills-holder-program-tab">
                            <p>
                                The Holder Program is designed for users with diversified holdings in a variety of
                                Wealth Mark products, including Spot, Margin, Futures, and Earn. With the required
                                amount of
                                net asset and BNB holdings, users could be qualified for VIP level increase. The new VIP
                                Holder Program no longer requires to apply. Any qualified users will be automatically
                                upgraded from the program, up to VIP 4 with no expiration date.
                                <a class="text-warning">Learn More &#8250;</a>
                            </p>
                            <p class="mt-4">Program entry requirement: 200,000 BUSD cumulative net asset holding and 25
                                BNB </p>
                            <div class="row mt-4">
                                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                                    <div class="card">
                                        <p>Wealth Mark Average Asset Hold</p>
                                        <h4>200,000</h4>
                                        <p>BNB Balance</p>
                                        <h4>25</h4>
                                        <p>Holder VIP Level</p>
                                        <h4>1</h4>
                                    </div>
                                </div>
                                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                                    <div class="card">
                                        <p>Wealth Mark Average Asset Hold</p>
                                        <h4>200,000</h4>
                                        <p>BNB Balance</p>
                                        <h4>25</h4>
                                        <p>Holder VIP Level</p>
                                        <h4>1</h4>
                                    </div>
                                </div>
                                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                                    <div class="card">
                                        <p>Wealth Mark Average Asset Hold</p>
                                        <h4>200,000</h4>
                                        <p>BNB Balance</p>
                                        <h4>25</h4>
                                        <p>Holder VIP Level</p>
                                        <h4>1</h4>
                                    </div>
                                </div>
                                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                                    <div class="card">
                                        <p>Wealth Mark Average Asset Hold</p>
                                        <h4>200,000</h4>
                                        <p>BNB Balance</p>
                                        <h4>25</h4>
                                        <p>Holder VIP Level</p>
                                        <h4>1</h4>
                                    </div>
                                </div>
                            </div>
                            <div class="row holder-prgram-btn-group mb-2 mt-2">
                                <div class="col-md-12 d-flex justify-content-center">
                                    <a class="btn btn-warning">Get PNB </a>
                                    <a class="btn btn-primary">My Program Detail</a>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="pills-borrower-programe" role="tabpanel"
                            aria-labelledby="pills-borrower-programe-tab">
                            <p>
                                The Holder Program is designed for users with diversified holdings in a variety of
                                Wealth Mark products, including Spot, Margin, Futures, and Earn. With the required
                                amount of
                                net asset and BNB holdings, users could be qualified for VIP level increase. The new VIP
                                Holder Program no longer requires to apply. Any qualified users will be automatically
                                upgraded from the program, up to VIP 4 with no expiration date.
                                <a class="text-warning">Learn More &#8250;</a>
                            </p>
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th class="vip-heading">VIP Level</th>
                                            <th class="vip-heading">30-Day Average</th>
                                            <th class="vip-heading">And</th>
                                            <th class="vip-heading">BNB Balance</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td scope="row" class="vip-heading">VIP 1</td>
                                            <td>≥ 250,000 BUSD</td>
                                            <td>And</td>
                                            <td>≥ 25 BNB</td>
                                        </tr>
                                        <tr>
                                            <td scope="row" class="vip-heading">VIP 1</td>
                                            <td>≥ 250,000 BUSD</td>
                                            <td>And</td>
                                            <td>≥ 25 BNB</td>
                                        </tr>
                                        <tr>
                                            <td scope="row" class="vip-heading">VIP 1</td>
                                            <td>≥ 250,000 BUSD</td>
                                            <td>And</td>
                                            <td>≥ 25 BNB</td>
                                        </tr>
                                        <tr>
                                            <td scope="row" class="vip-heading">VIP 1</td>
                                            <td>≥ 250,000 BUSD</td>
                                            <td>And</td>
                                            <td>≥ 25 BNB</td>
                                        </tr>
                                        <tr>
                                            <td scope="row" class="vip-heading">VIP 1</td>
                                            <td>≥ 250,000 BUSD</td>
                                            <td>And</td>
                                            <td>≥ 25 BNB</td>
                                        </tr>
                                        <tr>
                                            <td scope="row" class="vip-heading">VIP 1</td>
                                            <td>≥ 250,000 BUSD</td>
                                            <td>And</td>
                                            <td>≥ 25 BNB</td>
                                        </tr>
                                        <tr>
                                            <td scope="row" class="vip-heading">VIP 1</td>
                                            <td>≥ 250,000 BUSD</td>
                                            <td>And</td>
                                            <td>≥ 25 BNB</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <div class="row holder-prgram-btn-group mb-2 mt-2">
                                <div class="col-md-12 d-flex justify-content-center">
                                    <a class="btn btn-warning">Apply for VIP Loan</a>
                                    <a class="btn btn-primary">My Program Detail</a>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="pills-investor-programe" role="tabpanel"
                            aria-labelledby="pills-investor-programe-tab">
                            <p>
                                The Holder Program is designed for users with diversified holdings in a variety of
                                Wealth Mark products, including Spot, Margin, Futures, and Earn. With the required
                                amount of
                                net asset and BNB holdings, users could be qualified for VIP level increase. The new VIP
                                Holder Program no longer requires to apply. Any qualified users will be automatically
                                upgraded from the program, up to VIP 4 with no expiration date.
                                <a class="text-warning">Learn More &#8250;</a>
                            </p>
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th scope="col" class="vip-heading">VIP Level</th>
                                            <th scope="col" class="vip-heading">30-Day Average</th>
                                            <th scope="col" class="vip-heading">And</th>
                                            <th scope="col" class="vip-heading">BNB Balance</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td scope="row" class="vip-heading">VIP 1</td>
                                            <td>≥ 250,000 BUSD</td>
                                            <td>And</td>
                                            <td>≥ 25 BNB</td>
                                        </tr>
                                        <tr>
                                            <td scope="row" class="vip-heading">VIP 1</td>
                                            <td>≥ 250,000 BUSD</td>
                                            <td>And</td>
                                            <td>≥ 25 BNB</td>
                                        </tr>
                                        <tr>
                                            <td scope="row" class="vip-heading">VIP 1</td>
                                            <td>≥ 250,000 BUSD</td>
                                            <td>And</td>
                                            <td>≥ 25 BNB</td>
                                        </tr>
                                        <tr>
                                            <td scope="row" class="vip-heading">VIP 1</td>
                                            <td>≥ 250,000 BUSD</td>
                                            <td>And</td>
                                            <td>≥ 25 BNB</td>
                                        </tr>
                                        <tr>
                                            <td scope="row" class="vip-heading">VIP 1</td>
                                            <td>≥ 250,000 BUSD</td>
                                            <td>And</td>
                                            <td>≥ 25 BNB</td>
                                        </tr>
                                        <tr>
                                            <td scope="row" class="vip-heading">VIP 1</td>
                                            <td>≥ 250,000 BUSD</td>
                                            <td>And</td>
                                            <td>≥ 25 BNB</td>
                                        </tr>
                                        <tr>
                                            <td scope="row" class="vip-heading">VIP 1</td>
                                            <td>≥ 250,000 BUSD</td>
                                            <td>And</td>
                                            <td>≥ 25 BNB</td>
                                        </tr>
                                        <tr>
                                            <td scope="row" class="vip-heading">VIP 1</td>
                                            <td>≥ 250,000 BUSD</td>
                                            <td>And</td>
                                            <td>≥ 25 BNB</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <div class="row holder-prgram-btn-group mb-2 mt-2">
                                <div class="col-md-12 d-flex justify-content-center">
                                    <a class="btn btn-warning">Large Deposit Request</a>
                                    <a class="btn btn-primary">My Program Detail</a>
                                </div>
                            </div>
                        </div>

                        <div class="tab-pane fade" id="pills-invitation-programe" role="tabpanel"
                            aria-labelledby="pills-investor-programe-tab">
                            <p>
                                The Holder Program is designed for users with diversified holdings in a variety of
                                Wealth Mark products, including Spot, Margin, Futures, and Earn. With the required
                                amount of
                                net asset and BNB holdings, users could be qualified for VIP level increase. The new VIP
                                Holder Program no longer requires to apply. Any qualified users will be automatically
                                upgraded from the program, up to VIP 4 with no expiration date.
                                <a class="text-warning">Learn More &#8250;</a>
                            </p>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- seventh section -->
    <section class="institutional-contact-form">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    <div class="form-left-block">
                        <p>Let us know your needs</p>
                        <h2 class="heading-h2">Contact US</h2>
                        <div class="form-main-box">
                            <div class="form-inner-box d-flex align-itemn-center mb-3">
                                <div class="chat-icon-box chat-icon d-flex align-itemn-center mt-3"><svg
                                        viewBox="0 0 24 24" fill="none" class="css-1g6lkvi">
                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                            d="M3 3h18v14h-9l-5 5v-5H3V3zm15 3H6v2.5h12V6zm0 5.5H6V14h12v-2.5z"
                                            fill="currentColor"></path>
                                    </svg> </div>
                                <div class="chat-content-box">
                                    <h5>Chat</h5>
                                    <span>Speak with a live agent <span>
                                </div>
                            </div>

                            <div class="form-inner-box d-flex align-itemn-center mb-3">
                                <div class="chat-icon-box chat-icon d-flex align-itemn-center mt-3"><svg
                                        viewBox="0 0 24 24" fill="none" class="css-1g6lkvi">
                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                            d="M2.946 3v18h18v-9h-2.25v6.75h-13.5V5.25h7.25V3h-9.5z"
                                            fill="currentColor"></path>
                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                            d="M20.797 6.349l-3.2-3.2-1.455 1.454 3.2 3.2 1.455-1.454zM18.18 8.967l-3.201-3.2-6.693 6.693v3.2h3.2l6.694-6.693z"
                                            fill="currentColor"></path>
                                    </svg> </div>
                                <div class="chat-content-box">
                                    <h5>Feedback</h5>
                                    <span>Your your opinion<span>
                                </div>
                            </div>

                            <div class="form-inner-box d-flex align-itemn-center mb-3">
                                <div class="chat-icon-box chat-icon d-flex align-itemn-center mt-3"><svg width="16"
                                        height="16" viewBox="0 0 16 16" fill="none">
                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                            d="M3.33337 2.33337H12.6667V13.6667H3.33337V2.33337ZM10.3333 10.3333H8.33331H7.66664H5.66664V11.6666H7.66664H8.33331H10.3333V10.3333ZM10.3334 4.33337H5.66671V9.00004H10.3334V4.33337Z"
                                            fill="#929AA5"></path>
                                        <rect x="7.00012" y="5.66675" width="2" height="2" fill="#929AA5"></rect>
                                    </svg></div>
                                <div class="chat-content-box">
                                    <h5>FAQ</h5>
                                    <span>Explore more on Wealth Mark<span>
                                </div>

                            </div>


                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12" id="form-box-vip">
                    <div class="form-box">
                        <p class="text-center">More about the query</p>
                        <h2 class="heading-h2">Fill the Form & Send Us</h2>
                        <div class="rows">
                            <div class="col-md-12 col-xs-12 txtname"><input data-bn-type="input" value=""
                                    placeholder="Name" required="" maxlength="150" class="form-control custome-field">
                            </div>
                            <div class="col-md-12 col-xs-12 txtname"><input data-bn-type="input" value=""
                                    placeholder="Email" required="" maxlength="150" class="form-control custome-field">
                            </div>
                            <div class="col-md-12 col-sm-12 col-lg-12 col-xs-12"><textarea rows="+2" class="form-control"
                                    placeholder="Message"></textarea> </div>
                        </div>
                        <div class="col-md-12 col-sm-12 col-lg-12 col-xs-12">
                                <a href="#" class="btn btn-warning d-flex justify-content-center align-item-center text-center mt-3">Submit
                                </a>
                            </div>
                     
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- eight section -->
    <section class="competitive-fees" id="vip-program">
        <div class="container">
            <div class="row">
                <div class="sec-title text-left mb-5">
                    <span class="title">Know About</span>
                    <h2 class="heading-h2">Our Digital Asset Future with Wealth Mark</h2>
                </div>
            </div>
            <div class="row">
                <p class="text-center">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod
                    tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud
                    exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. </p>
            </div>
        </div>
        <div class="row digital-assets-row">
            <div class="col-md-12 d-flex">
                <a class="btn btn-warning institute-register-btn">Register Now </a>
                <a class="btn btn-primary">Trade Now</a>
            </div>
        </div>
        </div>
    </section>
    @include('template.country_language')
    @include('template.web_footer')



</body>

</html>