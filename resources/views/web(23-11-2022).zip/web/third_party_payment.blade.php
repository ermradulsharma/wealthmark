<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <title>Wealth Mark | {{ Request::segment(2) }}</title>
    @include('template.web_css')
    <link rel='stylesheet' href="{{('../public/assets/css/deepak_custom.css') }}">
</head>
<body>
    @include('template.mobile_menu')
    @include('template.web_menu')
  

    <section class="pt-8 pb-8 third-party-payment-box" id="third-party-payment-section">
        <div class="container">
            <div class="row align-items-center justify-content-center justify-content-md-between">
                <div class="col-12 col-lg-6 mb-8 text-md-left text-white order-2 order-lg-1">
                    <h1 class="display-3 font-weight-bold trust-wallet-heading">Verify your account Or Create New One</h1>
                    <p class="text-white-90 lead mb-4 banner-para">Get verified to achieve higher trading capacity.</p>
                    <a class="btn btn-yellow shadow">Get Verified </a><br/><br/>
                   
                </div>
                <div class="col-12 col-lg-6 text-center order-1 order-lg-2">
                <img src="{{ asset('public/assets/img/third-party-payment.png') }}" class="img-fluid"
                            alt="third party payment-img" /> 
                </div>
            </div>
        </div>
    </section>



    <section class="pt-8 pb-8 pt-sm-10 pb-sm-10" id="party-payment-steps-section">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center mb-2">
                    <h3 class="display-4 font-weight-bold">
                        Get started in 3 simple steps
                    </h3>
                    <p class="lead text-gray-700">Just follow the below steps</p>
                </div>
            </div>
            <div class="row no-gutters mt-8 mb-6 mb-md-7" id="character-group">
                <div class="col-12 col-md-4 col-xs-6 col-sm-6 text-center">
                    <div class="row step-row">
                        <a href="#">
                        <img src="{{ asset('public/assets/img/get-started-icon-1.png') }}" class="img-fluid"
                            alt="third party payment-img" /> 
                            
                        </a>
                        <h3 class="font-weight-bold">
                           Create Account
                        </h3>
                    </div>

                </div>
                <div class="col-12 col-md-4 col-xs-6 col-sm-6 text-center">
                    <div class="row step-row">
                        <a href="#">
                        <img src="{{ asset('public/assets/img/get-started-icon-2.png') }}" class="img-fluid"
                            alt="third party payment-img" /> 
                            
                        </a>
                        <h3 class="font-weight-bold">
                          Verify Account
                        </h3>
                    </div>

                </div>

                <div class="col-12 col-md-4 col-xs-6 col-sm-6 text-center">
                    <div class="row step-row">
                        <a href="#">
                        <img src="{{ asset('public/assets/img/get-started-icon-3.png') }}" class="img-fluid"
                            alt="third party payment-img" /> 
                            
                        </a>
                        <h3 class="font-weight-bold">
                           Go Ahead for Payment
                        </h3>
                    </div>

                </div>
              
            </div>
            <div class="row">
                <div class="col-12 text-center">
                    <a href="#" class="btn btn-yellow shadow mt-6 mx-auto info-button crypto-download-btn"> Download
                        Now</a>
                </div>
            </div>
        </div>
    </section>



    <section class="payement-third-box" id="third-party-payment-third-block">
        <div class="container">
            <div class="row bitcoin-inner">
                <div class="col-md-6 col-xs-6 col-sm-6">
                <img src="{{ asset('public/assets/img/eye-on-bitcoin-payment.png') }}" class="img-fluid"
                            alt="third party payment-img" /> 
                  
                </div>
                <div class="col-md-6 col-xs-6 col-sm-6">
                    <h2>Happy After payemnt done </h2>
                    <p>Every four years, the Bitcoin rewards are slashed in half. Find
                        out why on the Halving page.Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                        eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                    <a href="#" class="btn btn-yellow shadow mt-3">View More</a>
                </div>

            </div>
        </div>
    </section>

   
    <section class="pool-proof-work" id="pool-proof-work">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="sec-title">
                        <span class="title">Know About</span>
                        <h2 class="heading-h2">Popular <span class="yellow-text">Payments</span></h2>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-hover table-bordered">
                            <thead>
                                <tr>
                                    <th scope="col">Coin</th>
                                    <th scope="col">Algo</th>
                                    <th scope="col">Active Workers</th>
                                    <th scope="col">Hashrate</th>
                                    <th scope="col">Payment Done</th>
                                    <th scope="col">Tutorial</th>
                                    <th scope="col">#</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>      
                                    <td><img src="{{ asset('public/assets/img/proof-work-icon-1.svg') }}" class="img-fluid" alt="gift Card Image"></td>
                                    <td>SHA256</td>
                                    <td>695139</td>
                                    <td>38.53 Eh/s</td>
                                    <td>10000000</td>
                                    <td><span class="text-warning">View Tutorial </span></td>
                                    <td><span class="text-warning"><a>View More ↑ </a></span></td>

                                </tr>
                                <tr>
                                    <td><img src="{{ asset('public/assets/img/proof-work-icon-1.svg') }}" class="img-fluid" alt="gift Card Image"></td>
                                    <td>SHA256</td>
                                    <td>695139</td>
                                    <td>38.53 Eh/s</td>
                                    <td>15470000</td>
                                    <td><span class="text-warning">View Tutorial </span></td>
                                    <td><span class="text-warning"><a>View More ↑ </a></span></td>

                                </tr>
                                <tr>
                                    <td><img src="{{ asset('public/assets/img/proof-work-icon-1.svg') }}" class="img-fluid" alt="gift Card Image"></td>
                                    <td>SHA256</td>
                                    <td>695139</td>
                                    <td>38.53 Eh/s</td>
                                    <td>8570000</td>
                                    <td><span class="text-warning">View Tutorial </span></td>
                                    <td><span class="text-warning"><a>View More ↑ </a></span></td>

                                </tr>
                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
        
        </div>
    </section>
    <section class="third-party-payemnt-patners" id="payment-partners">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-xs-12 col-sm-12 sec-title text-left">
                    <span class="title">Know About</span>
                    <h2 class="heading-h2">Our Payment's <span class="yellow-text">Partner<span></h2>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-12 col-md-12">
                    <div class="third-party-payhemnts-box">
                    <img src="{{ asset('public/assets/img/third-party-payment-partner.png') }}" class="img-fluid"
                            alt="third party payment-img" />
                    </div>
                </div>


            </div>

        </div>
    </section>
    <section class="faq-block" id="faq-section">
        <div class="container">
            <div class="row">
                <div class="sec-title text-left">
                    <span class="title">Know About</span>
                    <h2 class="heading-h2">FAQ</h2>
                </div>
            </div>
            <div class="row">
                <div class="faq-inner-block" id="faq-inner-section">
                    <div class="col-md-12 col-lg-12 col-sm-12 col-sm-12">
                    <div class="accordion" id="accordian-api">
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingOne">
                                    <button class="accordion-button" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                        1. What is Wealthmark Pay?
                                    </button>
                                </h2>
                                <div id="collapseOne" class="accordion-collapse collapse show"
                                    aria-labelledby="headingOne" data-bs-parent="#accordian-api">
                                    <div class="accordion-body">
                                        <strong>This is the first item's accordion body.</strong> It is shown by
                                        default, until the collapse plugin adds the appropriate classes that we use to
                                        style each element. These classes control the overall appearance, as well as the
                                        showing and hiding via CSS transitions. You can modify any of this with custom
                                        CSS or overriding our default variables. It's also worth noting that just about
                                        any HTML can go within the <code>.accordion-body</code>, though the transition
                                        does limit overflow.
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingTwo">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                        2. Can I pay with Bitcoin, Wealthmark and other cryptocurrencies supported by
                                        Wealthmark?
                                    </button>
                                </h2>
                                <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo"
                                    data-bs-parent="#accordian-api">
                                    <div class="accordion-body">
                                        <strong>You can access your Wealthmark Pay Wallet by clicking [Wallets] -
                                            [Funding] - [Pay] on your Wealthmark App.
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingThree">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapseThree" aria-expanded="false"
                                        aria-controls="collapseThree">
                                        3. How long does it take for a Wealthmark Pay transaction to be completed?
                                    </button>
                                </h2>
                                <div id="collapseThree" class="accordion-collapse collapse"
                                    aria-labelledby="headingThree" data-bs-parent="#accordian-api">
                                    <div class="accordion-body">
                                        <strong>Wealthmark Pay transactions are usually confirmed instantly.
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingfour">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapsefour" aria-expanded="false"
                                        aria-controls="collapsefour">
                                        4. Can I pay with Bitcoin, Wealthmark and other cryptocurrencies supported by
                                        Wealthmark?
                                    </button>
                                </h2>
                                <div id="collapsefour" class="accordion-collapse collapse" aria-labelledby="headingfour"
                                    data-bs-parent="#accordian-api">
                                    <div class="accordion-body">
                                        <strong>You can access your Wealthmark Pay Wallet by clicking [Wallets] -
                                            [Funding] - [Pay] on your Wealthmark App.
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingfive">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapsefive" aria-expanded="false"
                                        aria-controls="collapsefive">
                                        5. How long does it take for a Wealthmark Pay transaction to be completed?
                                    </button>
                                </h2>
                                <div id="collapsefive" class="accordion-collapse collapse" aria-labelledby="headingfive"
                                    data-bs-parent="#accordian-api">
                                    <div class="accordion-body">
                                        <strong>Wealthmark Pay transactions are usually confirmed instantly.
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="sign-up p-5 bg-light-blue">
   <div class="container">
      <div class="row">
         <div class="col-md-12 col-sm-12 col-xs-12 text-center">
            <h3 class="app-heading">  Newsletter
            </h3>
            <span>You deserve easy access to cryptocurrencies Join our newsletter &amp; stay up-to-date with WealthMark</span>
         </div>
      </div>
      <div class="row">
         <div class="col-md-12 col-lg-12 col-sm-12 pt-4 ">
            <div class="subscribe">
               <form>
                  <div class=""> 
                     <input type="email" name="email" id="email" placeholder="Enter your email address" autocomplete="off">
                  </div>
                  &nbsp;   &nbsp;
                  <div class="">
                     <a href="javascript:void(0)" class="btn-yellow"><span> Subscribe </span> <span> <i class="bi-arrow-right"> </i> </span></a>
                  </div>
               </form>
            </div>
         </div>
      </div>
   </div>
</section>
    

    @include('template.country_language')
    @include('template.web_footer')
</body>

</html>