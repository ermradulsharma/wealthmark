<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <title>Wealth Mark | Create Entity Account</title>
    @include('template.web_css')
    <link rel='stylesheet' href="{{('../public/assets/css/deepak_custom.css') }}">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    
</head>

<body class="bg-white">

    @include('template.mobile_menu')
    @include('template.web_menu')

    <section class="pool-banner" id="pool-banner">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel">
                        <div class="carousel-indicators">
                            <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0"
                                class="active" aria-current="true" aria-label="Slide 1"></button>
                            <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1"
                                aria-label="Slide 2"></button>
                            <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2"
                                aria-label="Slide 3"></button>
                        </div>
                        <div class="carousel-inner">
                            <div class="carousel-item active">
                                <img src="{{ asset('public/assets/img/wmbanner-2.png') }}"
                                    class="img-fluid" alt="gift Card Image">

                            </div>
                            <div class="carousel-item">
                                <img src="{{ asset('public/assets/img/wmbanner-3.png') }}"
                                    class="img-fluid" alt="gift Card Image">

                            </div>
                            <div class="carousel-item">
                                <img src="{{ asset('public/assets/img/wmbanner-1.png') }}"
                                    class="img-fluid" alt="gift Card Image">

                            </div>
                        </div>
                        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions"
                            data-bs-slide="prev">
                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                            <span class="visually-hidden">Previous</span>
                        </button>
                        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions"
                            data-bs-slide="next">
                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                            <span class="visually-hidden">Next</span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <section class="pool-proof-work" id="pool-proof-work">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="sec-title">
                        <span class="title">Know About</span>
                        <h2 class="heading-h2">Proof of <span class="yellow-text">Work</span></h2>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-hover table-bordered">
                            <thead>
                                <tr>
                                    <th scope="col">Coin</th>
                                    <th scope="col">Algo</th>
                                    <th scope="col">Active Workers</th>
                                    <th scope="col">Hashrate</th>
                                    <th scope="col">Network</th>
                                    <th scope="col">Tutorial</th>
                                    <th scope="col">#</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td><img src="{{ asset('public/assets/img/proof-work-icon-1.svg') }}"
                                            class="img-fluid" alt="gift Card Image"></td>
                                    <td>SHA256</td>
                                    <td>695139</td>
                                    <td>38.53 Eh/s</td>
                                    <td>256.37 Eh/s 1.39 Eh/s</td>
                                    <td><span class="text-warning">View Tutorial </span></td>
                                    <td><span class="text-warning"><a data-bs-toggle="offcanvas" data-bs-target="#offcanvasBottom"
                                            aria-controls="offcanvasBottom">View More &#x2191; </a></span></td>

                                </tr>
                                <tr>
                                    <td><img src="{{ asset('public/assets/img/proof-work-icon-1.svg') }}"
                                            class="img-fluid" alt="gift Card Image"></td>
                                    <td>SHA256</td>
                                    <td>695139</td>
                                    <td>38.53 Eh/s</td>
                                    <td>256.37 Eh/s 1.39 Eh/s</td>
                                    <td><span class="text-warning">View Tutorial </span></td>
                                    <td><span class="text-warning"><a data-bs-toggle="offcanvas" data-bs-target="#offcanvasBottom"
                                            aria-controls="offcanvasBottom">View More &#x2191; </a></span></td>

                                </tr>
                                <tr>
                                    <td><img src="{{ asset('public/assets/img/proof-work-icon-1.svg') }}"
                                            class="img-fluid" alt="gift Card Image"></td>
                                    <td>SHA256</td>
                                    <td>695139</td>
                                    <td>38.53 Eh/s</td>
                                    <td>256.37 Eh/s 1.39 Eh/s</td>
                                    <td><span class="text-warning">View Tutorial </span></td>
                                    <td><span class="text-warning"><a data-bs-toggle="offcanvas" data-bs-target="#offcanvasBottom"
                                            aria-controls="offcanvasBottom">View More &#x2191; </a></span></td>

                                </tr>
                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="heading-block">
                        <div class="alert alert-warning">
                            <img src="{{ asset('public/assets/img/operation-services-icon.svg') }}" class="img-fluid"
                                alt="gift Card Image">
                            <strong class="text-warning">Operation Service </strong>&nbsp;
                            VIP Application: poolvip@wealthmark.com
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="pool-business-partner" id="pool-business-partner">
        <div class="container">
            <div class="row">
                <div class="sec-title text-left mb-5">
                    <span class="title">Know About</span>
                    <h2 class="heading-h2">Strategic <span class="yellow-text">Business Partners</span></h2>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="build-inner-block">
                        <img src="{{ asset('public/assets/img/Strategic-img-1.png') }}" class="img-fluid"
                            alt="gift Card Image">
                        <h4>Liquidity </h4>
                        <p>As the world’s leading digital asset exchange by real trading volume, Wealth Mark’s orders
                            account
                            for 50% market volume on the majority. </p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="build-inner-block">
                        <img src="{{ asset('public/assets/img/Strategic-img-4.png') }}" class="img-fluid"
                            alt="gift Card Image">
                        <h4>Liquidity </h4>
                        <p>As the world’s leading digital asset exchange by real trading volume, Wealth Mark’s orders
                            account
                            for 50% market volume on the majority. </p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="build-inner-block">
                        <img src="{{ asset('public/assets/img/Strategic-img-2.png') }}" class="img-fluid"
                            alt="gift Card Image">
                        <h4>Liquidity </h4>
                        <p>As the world’s leading digital asset exchange by real trading volume, Wealth Mark’s orders
                            account
                            for 50% market volume on the majority. </p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="build-inner-block">
                        <img src="{{ asset('public/assets/img/Strategic-img-3.png') }}" class="img-fluid"
                            alt="gift Card Image">
                        <h4>Liquidity </h4>
                        <p>As the world’s leading digital asset exchange by real trading volume, Wealth Mark’s orders
                            account
                            for 50% market volume on the majority. </p>
                    </div>
                </div>
            </div>

        </div>
    </section>


    <section class="welathmark-pool" id="welathmark-pool">
        <div class="container">
            <div class="row">
                <div class="sec-title text-left mb-5">
                    <span class="title">Know About</span>
                    <h2 class="heading-h2">Wealth Mark <span class="yellow-text">Pool</span></h2>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="build-inner-block">
                        <img loading="lazy" src="http://127.0.0.1/beta-dlp/public/assets/img/build-icon-1.png"
                            alt="Cloud " class="why-chose-img">
                        <h4>Secure and Transparent. </h4>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.</p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="build-inner-block">
                        <img loading="lazy" src="http://127.0.0.1/beta-dlp/public/assets/img/build-icon-2.png"
                            alt="Cloud " class="why-chose-img">
                        <h4>Steady Earnings. </h4>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.</p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="build-inner-block">
                        <img loading="lazy" src="http://127.0.0.1/beta-dlp/public/assets/img/build-icon-3.png"
                            alt="Cloud " class="why-chose-img">
                        <h4>Comprehensive Service. </h4>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.</p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                    <div class="build-inner-block">
                        <img loading="lazy" src="http://127.0.0.1/beta-dlp/public/assets/img/build-icon-1.png"
                            alt="Cloud " class="why-chose-img">
                        <h4>Wealth Mark Services </h4>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.</p>
                    </div>
                </div>
            </div>

        </div>
    </section>


    <section class="pool-faq-block" id="pool-faq-section">
        <div class="container">
            <div class="row">
                <div class="sec-title text-left">
                    <span class="title">Know About</span>
                    <h2 class="heading-h2">FAQ</h2>
                </div>
            </div>
            <div class="row">
                <div class="faq-inner-block" id="faq-inner-section">
                    <div class="col-md-12">
                    <div class="accordion" id="accordian-api">
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingOne">
                                    <button class="accordion-button" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                        1. What is Wealthmark Pay?
                                    </button>
                                </h2>
                                <div id="collapseOne" class="accordion-collapse collapse show"
                                    aria-labelledby="headingOne" data-bs-parent="#accordian-api">
                                    <div class="accordion-body">
                                        <strong>This is the first item's accordion body.</strong> It is shown by
                                        default, until the collapse plugin adds the appropriate classes that we use to
                                        style each element. These classes control the overall appearance, as well as the
                                        showing and hiding via CSS transitions. You can modify any of this with custom
                                        CSS or overriding our default variables. It's also worth noting that just about
                                        any HTML can go within the <code>.accordion-body</code>, though the transition
                                        does limit overflow.
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingTwo">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                        2. Can I pay with Bitcoin, Wealthmark and other cryptocurrencies supported by
                                        Wealthmark?
                                    </button>
                                </h2>
                                <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo"
                                    data-bs-parent="#accordian-api">
                                    <div class="accordion-body">
                                        <strong>You can access your Wealthmark Pay Wallet by clicking [Wallets] -
                                            [Funding] - [Pay] on your Wealthmark App.
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingThree">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapseThree" aria-expanded="false"
                                        aria-controls="collapseThree">
                                        3. How long does it take for a Wealthmark Pay transaction to be completed?
                                    </button>
                                </h2>
                                <div id="collapseThree" class="accordion-collapse collapse"
                                    aria-labelledby="headingThree" data-bs-parent="#accordian-api">
                                    <div class="accordion-body">
                                        <strong>Wealthmark Pay transactions are usually confirmed instantly.
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingfour">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapsefour" aria-expanded="false"
                                        aria-controls="collapsefour">
                                        4. Can I pay with Bitcoin, Wealthmark and other cryptocurrencies supported by
                                        Wealthmark?
                                    </button>
                                </h2>
                                <div id="collapsefour" class="accordion-collapse collapse" aria-labelledby="headingfour"
                                    data-bs-parent="#accordian-api">
                                    <div class="accordion-body">
                                        <strong>You can access your Wealthmark Pay Wallet by clicking [Wallets] -
                                            [Funding] - [Pay] on your Wealthmark App.
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingfive">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapsefive" aria-expanded="false"
                                        aria-controls="collapsefive">
                                        5. How long does it take for a Wealthmark Pay transaction to be completed?
                                    </button>
                                </h2>
                                <div id="collapsefive" class="accordion-collapse collapse" aria-labelledby="headingfive"
                                    data-bs-parent="#accordian-api">
                                    <div class="accordion-body">
                                        <strong>Wealthmark Pay transactions are usually confirmed instantly.
                                    </div>
                                </div>
                            </div>
                        </div>
                </div>
            </div>
        </div>
    </section>


    <div class="proof-of-work-offcanvas offcanvas offcanvas-bottom" tabindex="-1" id="offcanvasBottom"
        aria-labelledby="offcanvasBottomLabel">
        <div class="offcanvas-header">
            <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>
        <div class="offcanvas-body">
            <section class="work-offcanvas">
                <div class="sec-title text-left mb-2">
                            <h2 class="heading-h2">Proof of Work<span class="yellow-text"> Detailed Report</span> </h2>
                        </div>
                <div class="row main-row-offcanvas-1">
                    <div class="col-md-6 col-lg-6 col-sm-12 col-xs-6">
                        <div class="pool-chart-box">
                        <div id="chartContainer" style="height: 370px; width: 100%;"></div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-6 col-sm-12 col-xs-6">
                        <div class="pool-right-content-box">
                            <div class="row">
                                <div class="col-md-6 col-lg-6 col-sm-6 col-xs-6">
                                    <div class="pool-chart-box">
                                        <h5>Mining URL: </h5>
                                    </div>
                                </div>
                                <div class="col-md-6 col-lg-6 col-sm-6 col-xs-6">
                                    <div class="pool-right-content-box">
                                        <h5>Mining URL: </h5>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="pool-right-content-box-second">
                                        <p>stratum+tcp://sha256.poolWealth Mark.com:443 📄</p>
                                        <p class="alert alert-warning">Supports BTC/BCH and Smart Pool </p>
                                    </div>
                                    <div class="pool-right-content-box-second">
                                        <p>stratum+tcp://sha256.poolWealth Mark.com:443 📄</p>
                                        <p class="alert alert-warning">Supports BTC/BCH and Smart Pool </p>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="pool-right-content-box-second">
                                        <p>Supported ports: <span>8888</span> &nbsp;<span>3333</span>&nbsp;
                                            <span>1800</span>&nbsp; <span>443</span>
                                        </p>
                                    </div>

                                </div>
                            </div>
                            <div class="row mt-2 pool-calculation-box">
                                <div class="col-md-6">
                                    <div class="pool-chart-box">
                                        <label>Calculation </label>
                                        <div class="input-group mb-3">
                                            <input type="text" class="form-control" placeholder="Recipient's username"
                                                aria-label="Recipient's username" aria-describedby="basic-addon2">
                                            <span class="input-group-text" id="basic-addon2">Th/s &#8594</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="pool-right-content-box mt-2 alert alert-warning">
                                    <p><strong>0.9563757</strong> BCH </p>
                                        <p><strong>0.00063757</strong> BCH </p>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="pool-work-chart-content">
                                        <p>Mining Fee <strong> 2.50% </strong</p>
                                        <p>The latest Smart Pool enhancement ratio <strong> 0.00% </strong></p>
                                        <p>Settlement Method <strong> FPPS </strong></p>
                                        <p> Yesterday's BTC PPS Yield<strong> 101.34% </strong></p>
                                        <p>Settlement period <strong> 00:00 today to 00:00 UTC tomorrow </strong></p>
                                        <p>Payout time <strong> 02:00 to 10:00 UTC daily </strong></p> 
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
    <script>
window.onload = function () {

var options = {
	animationEnabled: true,  
	title:{
		text: "Wealth Mark Smart Pool Yield Curv"
	},
	axisX: {
		valueFormatString: "MMM"
	},
	axisY: {
		title: "Hash Rate",
		prefix: "$"
	},
	data: [{
		yValueFormatString: "$#,###",
		xValueFormatString: "MMMM",
		type: "spline",
		dataPoints: [
			{ x: new Date(2017, 0), y: 25060 },
			{ x: new Date(2017, 1), y: 27980 },
			{ x: new Date(2017, 2), y: 33800 },
			{ x: new Date(2017, 3), y: 49400 },
			{ x: new Date(2017, 4), y: 40260 },
			{ x: new Date(2017, 5), y: 33900 },
			{ x: new Date(2017, 6), y: 48000 },
			{ x: new Date(2017, 7), y: 31500 },
			{ x: new Date(2017, 8), y: 32300 },
			{ x: new Date(2017, 9), y: 42000 },
			{ x: new Date(2017, 10), y: 52160 },
			{ x: new Date(2017, 11), y: 49400 }
		]
	}]
};
$("#chartContainer").CanvasJSChart(options);

}
</script>
    @include('template.country_language')
    @include('template.web_footer')


    <script src="https://canvasjs.com/assets/script/jquery-1.11.1.min.js"></script>
<script src="https://canvasjs.com/assets/script/jquery.canvasjs.min.js"></script>
</body>

</html>