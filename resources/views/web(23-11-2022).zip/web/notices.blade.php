<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <title>Wealth Mark | {{ Request::segment(2) }}</title>
    @include('template.web_css')
    <link rel='stylesheet' href="{{('../public/assets/css/deepak_custom.css') }}">
</head>

<body>
    @include('template.mobile_menu')
    @include('template.web_menu')

    <section class="Notice-search-block pb-0 pt-0" id="notice-search-section">
        <div class="container">
            <div class="row notice-search-row">
                <div class="col-md-6 col-lg-6 col-xs-12 col-sm-12">
                    <div class="notice-search-img">
                        <img src="{{ asset('public/assets/img/notice-search-img.png') }}" class="img-fluid"
                            alt="gift Card Image">
                    </div>

                </div>
                <div class="col-md-6 col-lg-6 col-xs-12 col-sm-12 mb-3">
                    <div class="input-group mb-3">
                        <input type="text" class="form-control" placeholder="Type here and search announcements"
                            aria-label="Announcements" aria-describedby="basic-addon2">
                        <div class="input-group-append">
                            <span class="input-group-text" id="basic-addon2">Search</span>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>

    <section class="notice-listing-block" id="notice-listing-section">
        <div class="container">
        <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <div class="sec-title text-left">
                        <span class="title">Know About</span>
                        <h2 class="heading-h2">Notice</span>
                        </h2>
                    </div>
                </div>
            </div>
            <div class="row mb-2 mt-5">
                <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 mb-2">
                    <div class="notice-listing-box-1 notice-inner-box">
                            <h4>Notice: 1 </h4>
                            <p class="text-black">Special Notice About Wealth Mark Markets Limited,Special Notice About Wealth Mark Markets Limited </p>
                             
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 mb-2">
                    <div class="notice-listing-box-2 notice-inner-box">
                    <h4>Notice: 2 </h4>
                    <p class="text-black">All your cashback from eligible purchases are automatically deposited in your Funding Wallet so you only need to worry about spending your crypto.</p>
                     
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 mb-2">
                    <div class="notice-listing-box-3 notice-inner-box">
                    <h4>Notice: 3 </h4>
                    <p class="text-black">Regulatory Disclosures regarding Bifinity Digital Wallet, Regulatory Disclosures regarding Bifinity Digital Wallet</p>
                     
                    </div>
                </div>

                <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 mb-2">
                    <div class="notice-listing-box-4 notice-inner-box">
                    <h4>Notice: 4 </h4>
                    <p class="text-black">All your cashback from eligible purchases are automatically deposited in your Funding Wallet so you only need to worry about spending your crypto.</p>
                     
                    </div>
                </div>
            </div>
            <div class="row mb-2">
                <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 mb-2">
                    <div class="notice-listing-box-1 notice-inner-box">
                            <h4>Notice: 5 </h4>
                            <p class="text-black">All your cashback from eligible purchases are automatically deposited in your Funding Wallet so you only need to worry about spending your crypto.</p>
                             
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 mb-2">
                    <div class="notice-listing-box-2 notice-inner-box">
                    <h4>Notice: 6 </h4>
                    <p class="text-black">All your cashback from eligible purchases are automatically deposited in your Funding Wallet so you only need to worry about spending your crypto.</p>
                     
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 mb-2">
                    <div class="notice-listing-box-3 notice-inner-box">
                    <h4>Notice: 7 </h4>
                    <p class="text-black">All your cashback from eligible purchases are automatically deposited in your Funding Wallet so you only need to worry about spending your crypto.</p>
                     
                    </div>
                </div>

                <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 mb-2">
                    <div class="notice-listing-box-4 notice-inner-box">
                    <h4>Notice: 8 </h4>
                    <p class="text-black">All your cashback from eligible purchases are automatically deposited in your Funding Wallet so you only need to worry about spending your crypto.</p>
                     
                    </div>
                </div>
            </div>

        </div>
    </section>

    @include('template.country_language')
    @include('template.web_footer')
</body>

</html>